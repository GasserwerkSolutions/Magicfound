function syncTimeVisuals() {
  const minute = currentMinute();
  const today = isToday();
  const withinDay = today && minute >= OPEN_MINUTE && minute <= CLOSE_MINUTE;
  const afterClose = today && minute > CLOSE_MINUTE;
  const progress = today ? clamp((minute - OPEN_MINUTE) / DAY_DURATION, 0, 1) : 0;
  const position = progress * 100;
  const nowLine = root?.querySelector('.va-now-line');
  const shade = root?.querySelector('.va-past-shade');
  const timeLabelLayer = root?.querySelector('.va-time-label-layer');

  if (withinDay) {
    if (nowLine) nowLine.style.top = `${position}%`;
    if (shade) shade.style.height = `${position}%`;
    ensureNowLabel(timeLabelLayer, minute);
  } else {
    if (afterClose && shade) shade.style.height = '100%';
    timeLabelLayer?.querySelector('.va-now-label')?.remove();
  }

  const nowButton = root?.querySelector('.va-header-now');
  if (nowButton) {
    setText(nowButton, formatTime(minute));
    nowButton.setAttribute('aria-label', `Zu jetzt springen, ${formatTime(minute)}`);
  }
  if (root) {
    const cards = [...root.querySelectorAll('.va-appointment, .va-operational')];
    const lineZ = Number.parseInt(nowLine ? getComputedStyle(nowLine).zIndex : '3', 10) || 3;
    const cardZ = Math.min(...cards.map((card) => Number.parseInt(getComputedStyle(card).zIndex, 10) || 0));
    const temporalCardToneCount = cards.filter((card) => (
      card.classList.contains('is-running-now')
      || Boolean(card.style.getPropertyValue('--va-running-progress'))
    )).length;
    root.dataset.nowLineBehindCards = String(nowLine && lineZ < cardZ ? 1 : 0);
    root.dataset.tpTimeSource = salonTime.timeZone;
    root.dataset.tpNowMinute = String(minute);
    root.dataset.tpPastProgress = progress.toFixed(6);
    root.dataset.tpPastLayerCount = String(root.querySelectorAll('.va-past-shade').length);
    root.dataset.tpNowLineCount = String(root.querySelectorAll('.va-now-line').length);
    root.dataset.tpNowLineBehindCards = root.dataset.nowLineBehindCards;
    root.dataset.tpCardTimeToneCount = String(temporalCardToneCount);
    root.dataset.tpTimeSyncState = root.dataset.tpTimeProjectionState === 'stable' ? 'stable' : 'pending';
  }
}

function agendaLimits() {
  if (isLandscapeCompact()) return { current: 1, upcoming: 1 };
  if (isPortraitCompact()) return { current: 2, upcoming: 1 };
  return { current: Number.POSITIVE_INFINITY, upcoming: Number.POSITIVE_INFINITY };
}

function enhanceAgendaSection(section, role, limit) {
  const rowsContainer = section.querySelector(':scope > div');
  if (!rowsContainer) return 0;
  let rows = [...rowsContainer.querySelectorAll(':scope > .va-agenda-row')];
  if (role === 'current' && rows.length > 1) {
    const endMinute = (row) => {
      const value = row.querySelector('.va-agenda-time')?.textContent ?? '';
      const end = value.split('–')[1] ?? '';
      const [hour, minute] = end.trim().split(':').map(Number);
      return Number.isFinite(hour) && Number.isFinite(minute) ? hour * 60 + minute : Number.POSITIVE_INFINITY;
    };
    const sorted = [...rows].sort((left, right) => endMinute(left) - endMinute(right));
    if (sorted.some((row, index) => row !== rows[index])) {
      sorted.forEach((row) => rowsContainer.append(row));
      rows = sorted;
    }
  }
  const expanded = section.dataset.agendaExpanded === '1';
  const hiddenCount = Math.max(0, rows.length - limit);
  rows.forEach((row, index) => {
    const shouldHide = !expanded && index >= limit;
    if (row.hidden !== shouldHide) row.hidden = shouldHide;
  });

  let button = rowsContainer.querySelector(':scope > .va-agenda-more');
  if (!hiddenCount || !Number.isFinite(limit)) {
    button?.remove();
    return 0;
  }
  if (!button) {
    button = document.createElement('button');
    button.type = 'button';
    button.className = 'va-agenda-more';
    rowsContainer.append(button);
  }
  button.dataset.agendaMore = role;
  button.setAttribute('aria-expanded', String(expanded));
  const label = expanded
    ? 'Weniger anzeigen'
    : role === 'current'
      ? `${hiddenCount} weitere laufen`
      : `${hiddenCount} weitere danach`;
  setText(button, label);
  return hiddenCount;
}

function enhanceAgendas() {
  const limits = agendaLimits();
  let hiddenCurrent = 0;
  let hiddenUpcoming = 0;
  document.querySelectorAll('.va-agenda-panel').forEach((panel) => {
    const count = panel.querySelector('.va-agenda-count');
    if (count) {
      const value = count.textContent.trim();
      count.setAttribute('aria-label', `${value} aktuelle und nächste Termine`);
      count.title = `${value} aktuelle und nächste Termine`;
    }
    const current = panel.querySelector('.va-agenda-section.is-current');
    const upcoming = panel.querySelector('.va-agenda-section.is-next');
    if (current) hiddenCurrent = Math.max(hiddenCurrent, enhanceAgendaSection(current, 'current', limits.current));
    if (upcoming) hiddenUpcoming = Math.max(hiddenUpcoming, enhanceAgendaSection(upcoming, 'next', limits.upcoming));
  });
  if (root) {
    root.dataset.hiddenCurrentAgendaCount = String(hiddenCurrent);
    root.dataset.hiddenUpcomingAgendaCount = String(hiddenUpcoming);
    root.dataset.agendaHiddenCount = String(hiddenCurrent + hiddenUpcoming);
  }
}
