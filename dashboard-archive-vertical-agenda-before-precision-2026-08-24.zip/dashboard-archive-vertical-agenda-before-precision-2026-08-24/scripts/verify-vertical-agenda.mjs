import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const root = process.cwd();
const requiredFiles = [
  'docs/decisions/ADR-003-two-period-day-map.md',
  'docs/decisions/ADR-004-vertical-day-agenda.md',
  'docs/decisions/ADR-005-collapsible-header-agenda.md',
  'src/shell/dashboard-shell-v2.js',
  'src/styles/dashboard-shell-v2.css',
  'experiments/tagesplan-vertical-agenda/index.html',
  'experiments/tagesplan-vertical-agenda/page.js',
  'experiments/tagesplan-vertical-agenda/page.css',
  'experiments/tagesplan-vertical-agenda/polish.css',
  'experiments/tagesplan-vertical-agenda/reference-clock-sync.js',
  'experiments/tagesplan-vertical-agenda/header-agenda.js',
  'experiments/tagesplan-vertical-agenda/header-agenda.css',
  'experiments/tagesplan-vertical-agenda/README.md'
];

const failures = [];
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(root, file))) failures.push(`Fehlende Datei: ${file}`);
}

if (!failures.length) {
  const page = read('experiments/tagesplan-vertical-agenda/page.js');
  const css = read('experiments/tagesplan-vertical-agenda/page.css');
  const polish = read('experiments/tagesplan-vertical-agenda/polish.css');
  const clockSync = read('experiments/tagesplan-vertical-agenda/reference-clock-sync.js');
  const headerAgenda = read('experiments/tagesplan-vertical-agenda/header-agenda.js');
  const headerAgendaCss = read('experiments/tagesplan-vertical-agenda/header-agenda.css');
  const html = read('experiments/tagesplan-vertical-agenda/index.html');
  const readme = read('experiments/tagesplan-vertical-agenda/README.md');
  const adr3 = read('docs/decisions/ADR-003-two-period-day-map.md');
  const adr4 = read('docs/decisions/ADR-004-vertical-day-agenda.md');
  const adr5 = read('docs/decisions/ADR-005-collapsible-header-agenda.md');

  for (const [file, source] of [
    ['experiments/tagesplan-vertical-agenda/page.js', page],
    ['experiments/tagesplan-vertical-agenda/reference-clock-sync.js', clockSync],
    ['experiments/tagesplan-vertical-agenda/header-agenda.js', headerAgenda]
  ]) {
    try {
      new vm.SourceTextModule(source, { identifier: file });
    } catch (error) {
      failures.push(`${file}: JavaScript-Syntaxfehler: ${error.message}`);
    }
  }

  const requiredPageTerms = [
    'globalAgendaModel',
    'nextFreeGap',
    'temporalSurfaceMarkup',
    'va-past-shade',
    'va-calendar-grid',
    'va-agenda-panel',
    'va-now-line',
    'va-card-time',
    'data-focus-staff',
    'data-agenda-appointment-id',
    'data-staff-track',
    "query.get('referenceNow')",
    "query.get('focus')",
    'updateDiagnostics'
  ];
  for (const term of requiredPageTerms) if (!page.includes(term)) failures.push(`Vertikale Agenda enthält nicht: ${term}`);

  const forbiddenPageTerms = [
    'sequenceToneMap',
    'sequenceTonesEnabled',
    'is-sequence-before',
    'is-sequence-current',
    'is-sequence-next',
    "query.get('sequence')"
  ];
  for (const term of forbiddenPageTerms) if (page.includes(term)) failures.push(`Veraltete Dreiton-Logik verbleibt in page.js: ${term}`);

  const requiredCssTerms = [
    '--va-past-shade-strength: .05',
    '--va-focus-mask-strength: .34',
    '.va-past-shade',
    '.va-staff-track.is-context::after',
    '.va-staff-head.is-focused',
    '.va-card-time',
    '.va-appointment.is-search-hit',
    'background-size: 100% 10%, 100% 5%, 100% 2.5%',
    '.va-time-label.is-primary-anchor',
    '.va-mobile-agenda',
    'orientation: landscape',
    'overflow: hidden'
  ];
  for (const term of requiredCssTerms) if (!css.includes(term)) failures.push(`CSS-Vertrag fehlt: ${term}`);

  for (const term of ['is-sequence-before', 'is-sequence-current', 'is-sequence-next', '--va-sequence-']) {
    if (css.includes(term)) failures.push(`Veraltete Dreiton-CSS verbleibt im Kalender: ${term}`);
  }

  const requiredHeaderAgendaTerms = [
    "params.get('agenda') === 'open'",
    "params.get('verify') === '1'",
    'data-header-agenda-toggle',
    'summaryFrom',
    'sourcePanel',
    'MutationObserver',
    'va-agenda-popover',
    'visibleAgendaPanels',
    'permanentAgendaContainerCount',
    'legacyHeaderContextCount'
  ];
  for (const term of requiredHeaderAgendaTerms) {
    if (!headerAgenda.includes(term)) failures.push(`Kopfzeilenagenda enthält nicht: ${term}`);
  }

  const requiredHeaderAgendaCssTerms = [
    '.va-desktop-layout',
    'grid-template-columns: minmax(0, 1fr) !important',
    '.va-mobile-agenda,',
    'display: none !important',
    '.va-agenda-trigger',
    '.va-agenda-popover',
    '.va-agenda-section.is-before',
    '.va-agenda-section.is-current',
    '.va-agenda-section.is-next',
    '.va-agenda-trigger-mobile'
  ];
  for (const term of requiredHeaderAgendaCssTerms) {
    if (!headerAgendaCss.includes(term)) failures.push(`Kopfzeilenagenda-CSS enthält nicht: ${term}`);
  }

  for (const term of ['.va-appointment.is-before', '.va-appointment.is-current', '.va-appointment.is-next']) {
    if (headerAgendaCss.includes(term)) failures.push(`Dreiton-Test greift unzulässig auf Kalenderkarten zu: ${term}`);
  }

  if (!polish.includes('.va-desktop-agenda > .va-agenda-panel') || !polish.includes('height: 100%')) {
    failures.push('Archivierte Kompositionspolitur der ursprünglichen Agenda fehlt.');
  }
  if (!clockSync.includes('referenceNow') || !clockSync.includes('--gw-clock-hour-angle') || !clockSync.includes('MutationObserver')) {
    failures.push('Referenzuhr wird nicht deterministisch mit der Tagesplanzeit synchronisiert.');
  }
  if (!html.includes('../../src/styles/dashboard-shell-v2.css')) failures.push('Experiment lädt die Produktschale V2 nicht.');
  if (!html.includes('./page.css')) failures.push('Experiment lädt page.css nicht.');
  if (!html.includes('./polish.css')) failures.push('Experiment lädt polish.css nicht.');
  if (!html.includes('./header-agenda.css')) failures.push('Experiment lädt header-agenda.css nicht.');
  if (!html.includes('./reference-clock-sync.js')) failures.push('Experiment lädt die Referenzuhr-Synchronisierung nicht.');
  if (!html.includes('./header-agenda.js')) failures.push('Experiment lädt header-agenda.js nicht.');

  for (const term of [
    'Davor',
    'Jetzt',
    'Danach',
    '?referenceNow=11:22',
    '?referenceNow=11:22&agenda=open',
    '5 Prozent',
    'aufklappbarer Agenda',
    'keine produktive Persistenz'
  ]) {
    if (!readme.includes(term)) failures.push(`README dokumentiert nicht: ${term}`);
  }

  for (const term of [
    'Status: **Akzeptiert',
    'Globale vergangene Zeitfläche statt Kartentönen',
    '5 Prozent zusätzliche Dunkelheit',
    'Werte über **8 Prozent sind nicht zulässig**',
    'Ebenenordnung',
    'Personenfokus ohne Geometriewechsel',
    'Ausgangswert der Fokusmaske: **34 Prozent**',
    'keinen zweiten Einpersonen-Renderer'
  ]) {
    if (!adr4.includes(term)) failures.push(`ADR-004 enthält nicht: ${term}`);
  }

  for (const term of [
    'Status: **Akzeptiert',
    '„Als Nächstes“ ersetzt den Tagesplankontext',
    'Keine permanente Agenda-Fläche',
    'Nicht-modales Kopfzeilen-Popover',
    'Kontrollierter Dreiton-Test',
    'Davor',
    'Jetzt',
    'Danach',
    'globale vergangene Zeitfläche'
  ]) {
    if (!adr5.includes(term)) failures.push(`ADR-005 enthält nicht: ${term}`);
  }

  if (!adr3.includes('Abgelöst') && !adr3.includes('abgelöst')) failures.push('ADR-003 ist noch nicht als geometrisch abgelöst markiert.');
}

if (failures.length) {
  console.error('Prüfung der vertikalen Tagesfläche fehlgeschlagen:');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log('Vertikale Team-Tagesfläche, globale Zeitlage, Fokusmaske und aufklappbare Kopfzeilenagenda sind statisch konsistent.');
