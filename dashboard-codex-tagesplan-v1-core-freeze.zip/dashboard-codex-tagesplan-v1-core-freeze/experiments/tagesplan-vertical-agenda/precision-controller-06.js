function updateGlobalDiagnostics() {
  if (!root) return;
  root.dataset.documentOverflowX = String(Math.max(0, document.documentElement.scrollWidth - document.documentElement.clientWidth));
  root.dataset.visibleAgendaPanels = String([...document.querySelectorAll('.va-agenda-popover')].filter((node) => node.getClientRects().length && !node.hidden).length);
  root.dataset.permanentAgendaContainerCount = String([...root.querySelectorAll('.va-desktop-agenda, .va-mobile-agenda')].filter((node) => node.getClientRects().length).length);
  root.dataset.legacyHeaderContextCount = String(root.querySelector('#gw-page-context')?.textContent.includes('Zürich Enge · 08:00–18:00') ? 1 : 0);
  const nowLine = root.querySelector('.va-now-line');
  const card = root.querySelector('.va-appointment');
  const nowZ = Number.parseInt(nowLine ? getComputedStyle(nowLine).zIndex : '0', 10) || 0;
  const cardZ = Number.parseInt(card ? getComputedStyle(card).zIndex : '0', 10) || 0;
  root.dataset.nowLineBehindCards = String(nowLine && nowZ < cardZ ? 1 : 0);
  root.dataset.tpNowLineBehindCards = root.dataset.nowLineBehindCards;
  root.dataset.accountNameComplete = root.querySelector('.gw-account-card strong')?.textContent.trim() === 'Melanie Schneider' ? '1' : '0';
  const pill = root.querySelector('.va-header-now');
  const sidebarVisible = Boolean(root.querySelector('.gw-sidebar-v2')?.getClientRects().length);
  root.dataset.desktopTimePillCount = String(sidebarVisible && pill?.getClientRects().length ? 1 : 0);
}

function applyPrecision() {
  state.scheduled = false;
  ensureHeaderPrecision();
  const viewport = enhanceCalendarStructure();
  ensureStaffHeaderNames();
  ensureCardObserver();
  enhanceAgendas();
  syncTimeVisuals();
  updateScrollDiagnostics(viewport);
  updateCardDiagnostics();
  updateGlobalDiagnostics();

  if (viewport && isToday() && isCompactCalendar() && !state.userMovedCalendar && root?.dataset.calendarInitialNowPositioned !== '1') {
    scheduleInitialCalendarPosition(viewport);
  }
  if (viewport && query.get('verifyStaffScroll') === '1' && isPortraitCompact() && root?.dataset.mobileHorizontalScrollFunctional !== '1') {
    maybeVerifyHorizontalScroll(viewport);
  }
}

function schedulePrecision() {
  if (state.scheduled) return;
  state.scheduled = true;
  requestAnimationFrame(applyPrecision);
}

root?.addEventListener('gasserwerk:event', (event) => {
  const detail = event.detail ?? {};
  const type = detail.type ?? detail.eventType ?? '';
  if (type === 'day:date-change-requested') {
    const payload = currentEventPayload(event);
    if (payload.date) state.currentDate = payload.date;
    state.userMovedCalendar = false;
    state.initialPositionKey = '';
    state.scrollTop = 0;
    state.scrollLeft = 0;
    if (state.viewport) state.viewport.dataset.initialPositionState = '';
    if (root) delete root.dataset.calendarInitialNowPositioned;
  }
  schedulePrecision();
});

root?.addEventListener('click', (event) => {
  const searchToggle = event.target.closest('[data-mobile-search-toggle]');
  if (searchToggle) {
    state.searchOpen = !state.searchOpen;
    ensureSearchControls();
    if (state.searchOpen) requestAnimationFrame(() => root.querySelector('#gw-global-search')?.focus({ preventScroll: true }));
    return;
  }
  if (event.target.closest('[data-work-clock], [data-jump-to-now]')) {
    state.userMovedCalendar = false;
    if (state.viewport) state.viewport.dataset.initialPositionState = '';
    requestAnimationFrame(() => jumpCalendarToNow({ force: true }));
  }
}, true);

document.addEventListener('click', (event) => {
  const more = event.target.closest('[data-agenda-more]');
  if (!more) return;
  const section = more.closest('.va-agenda-section');
  if (!section) return;
  section.dataset.agendaExpanded = section.dataset.agendaExpanded === '1' ? '0' : '1';
  enhanceAgendas();
});

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape' || !state.searchOpen) return;
  state.searchOpen = false;
  ensureSearchControls();
  root?.querySelector('[data-mobile-search-toggle]')?.focus({ preventScroll: true });
}, true);

window.addEventListener('gasserwerk:salon-time', () => {
  schedulePrecision();
  if (!state.userMovedCalendar && isCompactCalendar()) {
    if (state.viewport) state.viewport.dataset.initialPositionState = '';
    scheduleInitialCalendarPosition(state.viewport);
  }
});

window.addEventListener('resize', () => {
  clearTimeout(state.resizeTimer);
  state.resizeTimer = window.setTimeout(() => {
    ensureHeaderPrecision();
    ensureStaffHeaderNames();
    enhanceAgendas();
    root?.querySelectorAll('.va-appointment').forEach(classifyCard);
    updateGlobalDiagnostics();
    updateScrollDiagnostics(state.viewport);
    if (state.viewport && isToday() && isCompactCalendar() && !state.userMovedCalendar && root?.dataset.calendarInitialNowPositioned !== '1') {
      scheduleInitialCalendarPosition(state.viewport);
    }
    if (state.viewport && query.get('verifyStaffScroll') === '1' && isPortraitCompact() && root?.dataset.mobileHorizontalScrollFunctional !== '1') {
      maybeVerifyHorizontalScroll(state.viewport);
    }
  }, 100);
}, { passive: true });

const observer = new MutationObserver(schedulePrecision);
if (root) observer.observe(root, { childList: true, subtree: true });

schedulePrecision();

window.addEventListener('pagehide', (event) => {
  clearTimeout(state.resizeTimer);
  if (event.persisted) return;
  observer.disconnect();
  state.cardObserver?.disconnect();
});

window.addEventListener('pageshow', (event) => {
  if (!event.persisted) return;
  state.scheduled = false;
  schedulePrecision();
});
