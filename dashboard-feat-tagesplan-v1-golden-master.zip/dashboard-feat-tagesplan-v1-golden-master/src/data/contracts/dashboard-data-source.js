function notImplemented(methodName) {
  throw new Error(`DashboardDataSource.${methodName}() is not implemented`);
}

/**
 * Framework-neutral data boundary for the Gasserwerk UI reference.
 *
 * Implementations may call HTTP APIs, server actions, local fixtures or another
 * transport. Pages only consume the normalized view-models described in the
 * page contracts and must not inspect transport-specific responses.
 */
export class DashboardDataSource {
  getSessionContext() {
    return notImplemented('getSessionContext');
  }

  getAuthenticationOptions() {
    return notImplemented('getAuthenticationOptions');
  }

  getOnboardingState() {
    return notImplemented('getOnboardingState');
  }

  getDayPlan(_query) {
    return notImplemented('getDayPlan');
  }

  listAppointments(_query) {
    return notImplemented('listAppointments');
  }

  getAppointment(_id) {
    return notImplemented('getAppointment');
  }

  listCustomers(_query) {
    return notImplemented('listCustomers');
  }

  getCustomer(_id) {
    return notImplemented('getCustomer');
  }

  listStaff(_query) {
    return notImplemented('listStaff');
  }

  getStaffMember(_id) {
    return notImplemented('getStaffMember');
  }

  listServices(_query) {
    return notImplemented('listServices');
  }

  getService(_id) {
    return notImplemented('getService');
  }

  getAdministrationSettings() {
    return notImplemented('getAdministrationSettings');
  }
}

/**
 * Runtime guard used by reference pages before accepting an adapter.
 * It checks shape only; domain validation belongs to dedicated normalizers.
 */
export function assertDashboardDataSource(candidate) {
  const methods = Object.getOwnPropertyNames(DashboardDataSource.prototype)
    .filter((name) => name !== 'constructor');

  const missing = methods.filter((name) => typeof candidate?.[name] !== 'function');
  if (missing.length) {
    throw new TypeError(`Dashboard data source is missing methods: ${missing.join(', ')}`);
  }

  return candidate;
}
