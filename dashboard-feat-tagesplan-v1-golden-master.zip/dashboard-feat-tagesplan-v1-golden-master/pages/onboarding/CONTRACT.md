# Onboarding · Seitenvertrag

Status: **Zur Freigabe – Fünf-Schritt-Vertrag konsolidiert, Pflichtlogik und Persistenz integrationsrelevant**  
Verantwortlicher Bereich: `Salon einrichten`  
Direkter Referenzpfad: `/dashboard/pages/onboarding/`  
Abhängige gemeinsame Verträge: `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

Das Onboarding führt einen neuen Salon beziehungsweise Standort zu einem minimal buchbaren Zustand.

Verbindliche Referenzschritte:

1. Salonprofil
2. Dienstleistungen
3. Team
4. Arbeitszeiten
5. Startklar

Primäre Arbeitsaufgabe:

- fehlende Grundlagen in einer verständlichen Reihenfolge ergänzen
- jederzeit erkennen, wie ein fehlender Wert die Buchbarkeit beeinflusst
- den Salon nach erfüllten Mindestbedingungen in den Tagesplan überführen

Das Onboarding ist kein dekorativer Produkt-Rundgang. Es bildet eine fachliche Abhängigkeitskette.

Nicht Bestandteil dieser V1:

- produktive Persistenz
- endgültige Pflicht-/Skip-Regeln
- Datenimport oder Migration
- Zahlungs- oder Vertragsabschluss
- vollständige Rollen- und Rechtevergabe

## 2. Eingabedaten

Datenquellenmethoden:

```js
getSessionContext()
getOnboardingState()
listServices()
listStaff()
getAdministrationSettings()
```

Normalisierter Eingang:

```js
{
  scope: {
    salonId,
    locationId
  },
  currentStepId,
  steps: [
    {
      id,
      label,
      state: "not-started" | "in-progress" | "complete" | "attention",
      canEnter,
      canSkip,
      blockingReasons
    }
  ],
  salonProfile,
  servicesSummary,
  staffSummary,
  workingHoursSummary,
  readiness: {
    isBookable,
    blockers,
    warnings
  },
  capabilities
}
```

Capabilities:

- Onboarding sehen und fortführen: `onboarding:manage`
- Teilbereiche können zusätzlich ihre Verwaltungs-Capability benötigen, wenn die Produktionsanwendung dies verlangt.

## 3. Fachliches View-Model

```js
{
  scope,
  progress: {
    currentStepIndex,
    totalSteps: 5,
    completedCount,
    progressLabel
  },
  steps: [
    {
      id,
      label,
      state,
      numberLabel,
      canEnter,
      blockingReasons
    }
  ],
  activeStep: {
    id,
    heading,
    description,
    fields,
    checks,
    impactNotice,
    actions
  },
  readiness: {
    isBookable,
    blockers,
    warnings,
    completionActionLabel
  }
}
```

Invarianten:

- Reihenfolge und Bezeichnungen der fünf Referenzschritte bleiben stabil, solange kein Produktentscheid sie ändert.
- `complete` bedeutet fachlich validiert, nicht nur lokal ausgefüllt.
- Fehlende Arbeitszeit darf nicht als Standardarbeitszeit ersetzt werden.
- Fehlende Dienstleistungsdauer verhindert die Behauptung vollständiger Buchbarkeit.
- Team und Dienstleistungen werden über stabile IDs verknüpft.
- `Startklar` ist eine Zusammenfassung und Freigabe, kein weiterer versteckter Datenerfassungsschritt.
- Warnungen und Blocker bleiben getrennt.

## 4. Ausgehende Ereignisse

### Schritt wechseln

```js
{
  type: "onboarding:step-change-requested",
  payload: { fromStepId, toStepId, scope }
}
```

### Schritt speichern und fortfahren

```js
{
  type: "onboarding:save-and-continue-requested",
  payload: {
    stepId,
    scope,
    values,
    targetStepId
  }
}
```

### Zurück

```js
{
  type: "onboarding:step-change-requested",
  payload: { fromStepId, toStepId, direction: "back", scope }
}
```

### Onboarding abschliessen

```js
{
  type: "onboarding:completed",
  payload: {
    scope,
    readinessVersion,
    target: "day-plan"
  }
}
```

Der Abschluss wird nur emittiert, wenn `readiness.isBookable` vom Adapter bestätigt ist.

## 5. Ladezustand

- Produktidentität, Onboardingtitel und bekannte Schrittstruktur bleiben sichtbar.
- Der aktive Schritt zeigt Skeletons für seine Daten.
- Fortschritt wird nicht aus nicht bestätigten lokalen Werten berechnet.
- Navigation zu einem anderen bereits bekannten Schritt darf möglich bleiben, sofern keine ungespeicherte Eingabe verloren geht.
- Der Fokus bleibt im aktiven Schritt und springt nach dem Laden auf dessen Überschrift oder erstes erforderliches Feld.

## 6. Leerzustand

Das Onboarding besitzt keinen globalen leeren Zustand; einzelne Schritte können leer sein.

### Keine Dienstleistungen

- erklärt den Einfluss auf Buchbarkeit
- bietet Dienstleistung anlegen beziehungsweise erfassen

### Kein Team

- erklärt, dass Termine keiner Person zugeordnet werden können
- bietet Person erfassen

### Keine Arbeitszeiten

- erklärt, dass Personen ohne Arbeitszeit nicht buchbar erscheinen
- bietet Arbeitszeiten festlegen

Leere Schritte zeigen keine erfundenen Standarddaten.

## 7. Fehlerzustand

Schrittladefehler:

- Schrittstruktur und Rückkehr bleiben sichtbar.
- aktive Fläche zeigt Retry.
- andere bereits geladene Schritte werden nicht unnötig verdeckt.

Validierungsfehler:

- sind den Feldern oder Checks zugeordnet
- erklären die Auswirkung auf Buchbarkeit
- unterscheiden Blocker und Warnungen

Speicherfehler:

- lokale Eingaben bleiben erhalten
- der Schritt wird nicht als `complete` markiert
- Retry und Abbruch sind verfügbar

Offline/Stale:

- bereits geladene Daten bleiben sichtbar.
- ein Schritt darf nicht als endgültig gespeichert oder abgeschlossen dargestellt werden, solange keine Bestätigung vorliegt.

## 8. Berechtigungszustände

- Ohne `onboarding:manage` erscheint ein Forbidden-Zustand beziehungsweise eine Weiterleitung in einen erlaubten Produktbereich.
- Ein Account mit nur lesendem Zugriff kann Fortschritt sehen, aber nicht speichern, falls dies später erlaubt wird.
- Teilbereichsdaten werden nur gemäss den entsprechenden Capabilities geliefert.
- Rollen- und Rechteverwaltung wird nicht stillschweigend aus fachlichen Teamrollen abgeleitet.
- `Startklar` darf nur die Freigabe anbieten, wenn die Abschluss-Capability vorliegt.

## 9. Desktopverhalten

- Das Onboarding verwendet eine eigene Schalenkonfiguration mit Fortschrittsbereich und Inhaltsfläche.
- Die linke Fortschrittsleiste zeigt alle fünf Schritte, Zustand und aktuellen Schritt.
- Inhaltsfläche priorisiert Überschrift, Auswirkung auf Buchbarkeit, Felder/Checks und Weiteraktion.
- Auf 14-Zoll-Viewports werden Abstände verdichtet; Schritte und Hauptfelder bleiben vollständig erreichbar.
- Lange Formulare scrollen innerhalb der Inhaltsfläche beziehungsweise im Dokumentfluss, ohne den Fortschrittskontext zu verlieren.
- Die primäre Aktion bleibt am logischen Ende des aktiven Schrittes.

## 10. Mobilverhalten

- Fortschrittsbereich wird zu einer horizontalen, scrollbaren oder kompakten Schrittübersicht.
- Aktiver Schritt füllt die Inhaltsfläche.
- Schrittbezeichnungen bleiben verständlich; Nummer allein genügt nicht als einzige Information.
- Primäre und sekundäre Aktion sind mit sicheren Touch-Zielen erreichbar.
- Bildschirmtastatur darf Felder und Weiteraktion nicht unzugänglich machen.
- Die mobile Fachlogik und Readinessprüfung entsprechen Desktop.

## 11. Tastatur und Fokus

- Fortschrittsschritte sind als Buttons erreichbar, sofern `canEnter` gilt.
- `Enter` oder Leertaste wechselt den Schritt nach der definierten Verlustschutzlogik.
- Feldlabels sind korrekt verbunden.
- Speichern und Weiter verhindert Doppelauslösung.
- Validierungsfehler fokussieren das erste fehlerhafte Feld und werden zusammenfassend angekündigt.
- Nach erfolgreichem Schrittwechsel geht der Fokus auf die neue Schrittüberschrift.
- `Escape` schliesst nur ein offenes Unteroverlay, nicht das gesamte Onboarding.
- Ungespeicherte Eingaben dürfen nicht ohne bewusste Entscheidung verloren gehen.

## 12. Abnahmekriterien

- Seite ist direkt aufrufbar.
- Alle fünf Referenzschritte sind vorhanden und korrekt benannt.
- Fortschritt, Blocker, Warnungen und `isBookable` bleiben getrennte Werte.
- Kein Schritt wird nur aufgrund lokaler Eingabe als vollständig dargestellt.
- Lade-, leere Teilzustände, Validierungs-, Speicher-, Fehler-, Offline-, Stale- und Forbidden-Zustände sind vorhanden.
- Auswirkungen fehlender Daten auf Buchbarkeit werden konkret erklärt.
- Desktop, 14-Zoll, Mobil Hochformat, Mobil Querformat und Bildschirmtastatur sind geprüft.
- Schrittwechsel, Validierungsfokus und Fortschrittsankündigung funktionieren per Tastatur.
- `onboarding:completed` wird nur bei bestätigter Readiness emittiert.
- Keine Gesamtseite läuft horizontal über.
- Keine Backendwerte oder Standardarbeitszeiten werden erfunden.

## 13. Integrationshinweise

- Offene Fragen: `Q-002`, `Q-003`, `Q-005`, `Q-006`, `Q-007`, `Q-ONB-001` bis `Q-ONB-003`, `Q-STAFF-001`, `Q-SVC-001` bis `Q-SVC-003`.
- Der Produktionsadapter bestimmt Pflichtfelder, Validierung und Scope von Fortschritt.
- Jeder Schritt kann später einen eigenen Domainservice verwenden; die Seite konsumiert weiterhin den normalisierten Onboardingzustand.
- Der Abschluss führt fachlich zum Tagesplan, aber Routing und Persistenz bleiben Produktionsverantwortung.
- Die Referenz darf Fortschritt simulieren, muss dies als Mockzustand kennzeichnen.
