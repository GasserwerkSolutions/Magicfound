const SVG_NAMESPACE = 'http://www.w3.org/2000/svg';

const ICONS = Object.freeze({
  tagesplan: [
    ['rect', { x: 3, y: 5, width: 18, height: 16, rx: 2 }],
    ['path', { d: 'M8 3v4M16 3v4M3 10h18' }]
  ],
  termine: [
    ['rect', { x: 4, y: 3, width: 16, height: 18, rx: 2 }],
    ['path', { d: 'M8 8h8M8 12h8M8 16h5' }]
  ],
  kundschaft: [
    ['circle', { cx: 9, cy: 8, r: 3 }],
    ['path', { d: 'M3 20c0-4 2.5-7 6-7s6 3 6 7M16 7h5M18.5 4.5v5' }]
  ],
  team: [
    ['circle', { cx: 8, cy: 8, r: 3 }],
    ['circle', { cx: 17, cy: 9, r: 2.5 }],
    ['path', { d: 'M2.5 20c0-4 2.3-7 5.5-7s5.5 3 5.5 7M13.5 15c.9-1 2-1.5 3.5-1.5 2.8 0 4.5 2.6 4.5 6.5' }]
  ],
  angebot: [
    ['path', { d: 'M4 5h16v14H4zM8 9h8M8 13h5' }],
    ['path', { d: 'M4 8h16' }]
  ],
  verwaltung: [
    ['circle', { cx: 12, cy: 12, r: 3 }],
    ['path', { d: 'M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21h-4v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3.1 14H3v-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.5V3h4v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.5 1h.1v4h-.1a1.7 1.7 0 0 0-1.5 1Z' }]
  ],
  search: [
    ['circle', { cx: 11, cy: 11, r: 7 }],
    ['path', { d: 'm20 20-4-4' }]
  ],
  plus: [['path', { d: 'M12 5v14M5 12h14' }]],
  close: [['path', { d: 'M6 6l12 12M18 6 6 18' }]],
  back: [['path', { d: 'm15 18-6-6 6-6' }]],
  next: [['path', { d: 'm9 18 6-6-6-6' }]],
  calendar: [
    ['rect', { x: 3, y: 5, width: 18, height: 16, rx: 2 }],
    ['path', { d: 'M8 3v4M16 3v4M3 10h18' }]
  ],
  clock: [
    ['circle', { cx: 12, cy: 12, r: 9 }],
    ['path', { d: 'M12 7v5l3 2' }]
  ],
  chevronDown: [['path', { d: 'm6 9 6 6 6-6' }]],
  retry: [
    ['path', { d: 'M20 11a8 8 0 1 0-2.3 5.7' }],
    ['path', { d: 'M20 5v6h-6' }]
  ],
  lock: [
    ['rect', { x: 5, y: 10, width: 14, height: 11, rx: 2 }],
    ['path', { d: 'M8 10V7a4 4 0 0 1 8 0v3' }]
  ]
});

export const PAGE_ICON_NAME = Object.freeze({
  tagesplan: 'tagesplan',
  termine: 'termine',
  kundschaft: 'kundschaft',
  team: 'team',
  angebot: 'angebot',
  verwaltung: 'verwaltung'
});

function setSvgAttributes(element, attributes) {
  for (const [name, value] of Object.entries(attributes)) {
    element.setAttribute(name, String(value));
  }
}

export function createIcon(name, options = {}) {
  if (typeof document === 'undefined') throw new Error('createIcon requires a DOM environment');
  const definition = ICONS[name];
  if (!definition) throw new RangeError(`unknown Gasserwerk icon: ${name}`);

  const svg = document.createElementNS(SVG_NAMESPACE, 'svg');
  setSvgAttributes(svg, {
    viewBox: '0 0 24 24',
    width: options.size ?? 20,
    height: options.size ?? 20,
    fill: 'none',
    stroke: 'currentColor',
    'stroke-width': options.strokeWidth ?? 1.8,
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
    'aria-hidden': options.title ? 'false' : 'true',
    focusable: 'false'
  });
  if (options.className) svg.setAttribute('class', options.className);

  if (options.title) {
    const title = document.createElementNS(SVG_NAMESPACE, 'title');
    title.textContent = options.title;
    svg.append(title);
  }

  for (const [tagName, attributes] of definition) {
    const child = document.createElementNS(SVG_NAMESPACE, tagName);
    setSvgAttributes(child, attributes);
    svg.append(child);
  }

  return svg;
}
