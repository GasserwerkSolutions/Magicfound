# Dashboard-Referenz veröffentlichen

Die veröffentlichte GitHub-Pages-Referenz wird durch den Workflow auf `main` erzeugt:

```text
.github/workflows/static.yml
```

## Automatischer Ablauf

1. Ein Commit wird auf `feat/canonical-product-surface-v1` geschrieben.
2. `Verify dashboard reference` prüft Verträge, Module, Mock-Daten und den statischen Build.
3. Nur nach einem erfolgreichen Push-Lauf startet der Pages-Workflow auf `main`.
4. Der Pages-Workflow checkt exakt den verifizierten Commit aus.
5. Die vollständige Tageslandkarte wird zusätzlich im echten Browser geprüft.
6. Erst danach wird das GitHub-Pages-Artefakt gebaut und veröffentlicht.

Die Ausführung auf `main` ist absichtlich gewählt: Das geschützte GitHub-Pages-Environment akzeptiert die Default-Branch-Pipeline, während die tatsächlich veröffentlichte Oberfläche weiterhin aus dem verifizierten Feature-Commit stammt. Der Verifikationsworkflow ist deshalb auch auf dem Default-Branch registriert; seine vollständigen Prüfschritte bleiben bis zur Zusammenführung im Feature-Branch.

## Aktueller Einstiegspunkt

```text
/experiments/tagesplan-two-period/
```

Sobald die Tageslandkarte freigegeben und nach `pages/tagesplan/` übernommen ist, wird nur der Einstiegspunkt der Veröffentlichung geändert.

## Manueller Lauf

Der Workflow `Deploy latest dashboard reference` kann über `workflow_dispatch` mit einem Branch, Tag oder Commit gestartet werden.

## Status

Der Pages-Workflow veröffentlicht den Commitstatus `dashboard-pages` auf dem tatsächlich ausgelieferten Quell-Commit. Bei Erfolg verweist der Status direkt auf die veröffentlichte Seite; bei einem Fehler auf den betreffenden Actions-Lauf.
