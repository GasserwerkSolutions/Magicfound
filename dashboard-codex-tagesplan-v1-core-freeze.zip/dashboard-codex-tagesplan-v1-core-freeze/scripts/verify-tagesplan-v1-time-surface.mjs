import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';

const root = process.cwd();
const referencePath = resolve(root, 'references/tagesplan/v1.0/tagesplan-reference.html');
const evidenceDirectory = resolve(root, 'references/tagesplan/v1.0/evidence/time-surface-r1');
const baseUrl = pathToFileURL(referencePath).href;
const checks = [];
const matrix = [];
const closeTo = (left, right, tolerance = 1) => Math.abs(left - right) <= tolerance;
const surfaceKeys = ['gridLeft', 'gridTop', 'gridWidth', 'gridHeight', 'shadeLeft', 'shadeTop', 'shadeWidth', 'shadeHeight', 'lineLeft', 'lineTop', 'lineWidth', 'scrollTop', 'scrollLeft'];
const sameSurface = (left, right) => surfaceKeys.every((key) => closeTo(left[key], right[key], 1));

mkdirSync(evidenceDirectory, { recursive: true });

function check(name, condition, detail = '') {
  assert.ok(condition, `${name}${detail ? `: ${detail}` : ''}`);
  checks.push(name);
}

async function waitForStable(page, compact = false) {
  await page.waitForFunction(() => {
    const rootNode = document.querySelector('#dashboard-root');
    return rootNode?.dataset.tpRenderState === 'ready'
      && rootNode.dataset.tpLayoutState === 'stable'
      && rootNode.dataset.tpTimeSyncState === 'stable'
      && Boolean(rootNode.querySelector('.va-calendar-grid'));
  }, null, { timeout: 15_000 });
  if (compact) {
    await page.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.calendarInitialNowPositioned === '1', null, { timeout: 15_000 });
  }
  await page.waitForTimeout(180);
  await page.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.tpLayoutState === 'stable', null, { timeout: 15_000 });
  await page.evaluate(() => new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done))));
}

async function openAt(browser, viewport, parameters, mobile = false) {
  const context = await browser.newContext({ viewport, isMobile: mobile, hasTouch: mobile });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto(`${baseUrl}?${parameters}`, { waitUntil: 'load' });
  await waitForStable(page, mobile);
  return { context, page, errors };
}

async function cardStyles(page) {
  return page.evaluate(() => Object.fromEntries([...document.querySelectorAll('.va-appointment')].map((card) => {
    const style = getComputedStyle(card);
    return [card.dataset.appointmentId, {
      accent: style.getPropertyValue('--va-status-accent').trim(),
      border: style.borderLeftColor,
      background: style.backgroundColor,
      color: style.color
    }];
  })));
}

async function surface(page) {
  return page.evaluate(() => {
    const rootNode = document.querySelector('#dashboard-root');
    const grid = rootNode.querySelector('.va-calendar-grid');
    const shade = rootNode.querySelector('.va-past-shade');
    const line = rootNode.querySelector('.va-now-line');
    const viewport = rootNode.querySelector('.va-calendar-viewport');
    const gridRect = grid.getBoundingClientRect();
    const shadeRect = shade?.getBoundingClientRect() ?? { left: gridRect.left, top: gridRect.top, width: 0, height: 0 };
    const lineRect = line?.getBoundingClientRect() ?? { left: gridRect.left, top: gridRect.top, width: 0, height: 0 };
    const faceStyle = getComputedStyle(rootNode.querySelector('.gw-clock-face'));
    const cards = [...rootNode.querySelectorAll('.va-appointment, .va-operational')];
    return {
      gridLeft: gridRect.left,
      gridTop: gridRect.top,
      gridWidth: gridRect.width,
      gridHeight: gridRect.height,
      shadeLeft: shadeRect.left,
      shadeTop: shadeRect.top,
      shadeWidth: shadeRect.width,
      shadeHeight: shadeRect.height,
      lineLeft: lineRect.left,
      lineTop: lineRect.top,
      lineWidth: lineRect.width,
      scrollTop: viewport.scrollTop,
      scrollLeft: viewport.scrollLeft,
      shadeCount: rootNode.querySelectorAll('.va-past-shade').length,
      lineCount: rootNode.querySelectorAll('.va-now-line').length,
      directShade: shade?.parentElement === grid,
      directLine: line?.parentElement === grid,
      trackShadeCount: rootNode.querySelectorAll('.va-staff-track .va-past-shade, .va-time-rail .va-past-shade').length,
      shadeImage: shade ? getComputedStyle(shade).backgroundImage : null,
      shadeBlend: shade ? getComputedStyle(shade).mixBlendMode : null,
      shadeColor: shade ? getComputedStyle(shade).backgroundColor : null,
      lineImage: line ? getComputedStyle(line).backgroundImage : null,
      lineAnimation: line ? getComputedStyle(line, '::before').animationName : null,
      shadeZ: shade ? Number.parseInt(getComputedStyle(shade).zIndex, 10) : null,
      lineZ: line ? Number.parseInt(getComputedStyle(line).zIndex, 10) : null,
      cardZMin: Math.min(...cards.map((node) => Number.parseInt(getComputedStyle(node).zIndex, 10) || 0)),
      shadePercent: shadeRect.height / gridRect.height * 100,
      linePercent: (lineRect.top - gridRect.top) / gridRect.height * 100,
      digital: rootNode.querySelector('[data-clock-digital]')?.textContent?.trim() ?? '',
      marker: rootNode.querySelector('.va-now-label')?.textContent?.trim() ?? '',
      hourAngle: Number.parseFloat(faceStyle.getPropertyValue('--gw-clock-hour-angle')),
      minuteAngle: Number.parseFloat(faceStyle.getPropertyValue('--gw-clock-minute-angle')),
      data: Object.fromEntries([...rootNode.attributes].filter(({ name }) => name.startsWith('data-tp-')).map(({ name, value }) => [name, value])),
      railMode: rootNode.dataset.tpTimeRailLayer,
      railPosition: getComputedStyle(rootNode.querySelector('.va-time-rail')).position,
      railZ: getComputedStyle(rootNode.querySelector('.va-time-rail')).zIndex,
      focusedHeadCount: rootNode.querySelectorAll('.va-staff-head.is-focused').length,
      focusedTrackCount: rootNode.querySelectorAll('.va-staff-track.is-focused').length,
      contextTrackCount: rootNode.querySelectorAll('.va-staff-track.is-context').length,
      visibleAgendaPanels: [...document.querySelectorAll('.va-agenda-popover')]
        .filter((node) => !node.hidden && node.getClientRects().length).length
    };
  });
}

async function hitTest(page) {
  return page.evaluate(() => {
    const grid = document.querySelector('.va-calendar-grid');
    const shade = document.querySelector('.va-past-shade');
    const line = document.querySelector('.va-now-line');
    const rail = document.querySelector('.va-time-rail');
    const gridRect = grid.getBoundingClientRect();
    const shadeRect = shade.getBoundingClientRect();
    const lineRect = line.getBoundingClientRect();
    const railRect = rail.getBoundingClientRect();
    const lineY = lineRect.top + Math.max(.25, lineRect.height / 2);
    shade.style.pointerEvents = 'auto';
    const shadeCoversRail = document.elementFromPoint(railRect.left + 3, gridRect.top + shadeRect.height * .5) === shade;
    shade.style.pointerEvents = '';
    line.style.pointerEvents = 'auto';
    const lineCoversRail = document.elementFromPoint(railRect.left + 3, lineY) === line;
    let freeHit = false;
    for (let x = railRect.right + 1; x < gridRect.right - 1; x += 2) {
      const target = document.elementFromPoint(x, lineY);
      if (target === line || line.contains(target)) { freeHit = true; break; }
    }
    const crossing = [...document.querySelectorAll('.va-appointment')].find((card) => {
      const rect = card.getBoundingClientRect();
      return rect.top < lineY && rect.bottom > lineY;
    });
    const crossingRect = crossing?.getBoundingClientRect();
    const cardHit = crossingRect ? document.elementFromPoint(crossingRect.left + crossingRect.width / 2, lineY) : null;
    const cardProtectsLine = cardHit?.closest('.va-appointment') === crossing;
    line.style.pointerEvents = '';
    return { shadeCoversRail, lineCoversRail, freeHit, cardProtectsLine, crossingCard: crossing?.dataset.appointmentId ?? null };
  });
}

async function horizontalOcclusion(page) {
  return page.evaluate(async () => {
    const currentNodes = () => ({
      viewport: document.querySelector('.va-calendar-viewport'),
      corner: document.querySelector('.va-time-corner')
    });
    const settlePosition = async (position) => {
      for (let attempt = 0; attempt < 4; attempt += 1) {
        const { viewport, corner } = currentNodes();
        if (!viewport || !corner) return null;
        const maxLeft = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
        viewport.scrollLeft = Math.min(position, maxLeft);
        await new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done)));
        const current = currentNodes();
        if (viewport.isConnected && corner.isConnected && current.viewport === viewport && current.corner === corner) {
          return { viewport, corner, maxLeft };
        }
      }
      return null;
    };
    const initial = currentNodes();
    const maxLeft = Math.max(0, (initial.viewport?.scrollWidth ?? 0) - (initial.viewport?.clientWidth ?? 0));
    const positions = [...new Set([0, .2, .4, .6, .8, 1].map((ratio) => Math.round(maxLeft * ratio)))];
    const samples = [];
    let sawUnderlyingHeader = false;
    for (const position of positions) {
      const settled = await settlePosition(position);
      if (!settled) {
        samples.push({ position, connected: false });
        continue;
      }
      const { corner } = settled;
      const cornerRect = corner.getBoundingClientRect();
      const staffHeads = [...document.querySelectorAll('.va-staff-head')];
      const overlapping = staffHeads.some((head) => {
        const rect = head.getBoundingClientRect();
        return rect.left < cornerRect.right && rect.right > cornerRect.left;
      });
      sawUnderlyingHeader ||= overlapping;
      const target = document.elementFromPoint(cornerRect.right - 2, cornerRect.top + cornerRect.height / 2);
      const style = getComputedStyle(corner);
      samples.push({
        position,
        connected: true,
        overlapping,
        cornerOwnsPaint: target === corner || corner.contains(target),
        background: style.backgroundColor,
        overflowX: style.overflowX,
        isolation: style.isolation,
        contain: style.contain
      });
    }
    const targetLeft = Math.min(336, maxLeft);
    const final = await settlePosition(targetLeft);
    return {
      maxLeft,
      targetLeft,
      sawUnderlyingHeader,
      stable: Boolean(final) && samples.every((sample) => sample.connected
        && sample.cornerOwnsPaint
        && sample.background !== 'rgba(0, 0, 0, 0)'
        && ['hidden', 'clip'].includes(sample.overflowX)
        && sample.isolation === 'isolate'
        && sample.contain.includes('paint')),
      samples
    };
  });
}

async function agendaTruth(page, minute) {
  return page.evaluate((now) => {
    const panel = document.querySelector('.va-agenda-panel');
    const ids = (selector) => [...panel.querySelectorAll(selector)].map((row) => row.dataset.agendaAppointmentId).filter(Boolean).sort();
    const current = ids('.va-agenda-section.is-current [data-agenda-appointment-id]');
    const previous = ids('.va-agenda-section.is-before [data-agenda-appointment-id]');
    const upcoming = ids('.va-agenda-section.is-next [data-agenda-appointment-id]');
    const cardFor = (id) => document.querySelector(`[data-appointment-id="${CSS.escape(id)}"]`);
    const truthful = current.every((id) => {
      const card = cardFor(id);
      return card && Number(card.dataset.startMinute) <= now && Number(card.dataset.endMinute) > now;
    }) && previous.every((id) => {
      const card = cardFor(id);
      return card && Number(card.dataset.endMinute) <= now;
    }) && upcoming.every((id) => {
      const card = cardFor(id);
      return card && Number(card.dataset.startMinute) > now;
    });
    return { current, previous, upcoming, truthful };
  }, minute);
}

async function captureEvidence(browser, item) {
  const { context, page, errors } = await openAt(browser, item.viewport, item.parameters, item.mobile);
  if (item.expectFocus) {
    await page.waitForFunction(() => document.querySelectorAll('.va-staff-head.is-focused').length === 1 && document.querySelectorAll('.va-staff-track.is-context').length === 4);
  }
  if (item.expectAgenda) {
    await page.waitForFunction(() => {
      const panels = [...document.querySelectorAll('.va-agenda-popover')].filter((node) => !node.hidden && node.getClientRects().length);
      const expanded = [...document.querySelectorAll('[data-header-agenda-toggle][aria-expanded="true"]')].some((node) => node.getClientRects().length);
      return panels.length === 1 && expanded;
    });
  }
  if (item.expectHorizontal) {
    await page.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.mobileHorizontalScrollFunctional === '1');
  }
  const snapshot = await surface(page);
  const horizontalHits = item.expectHorizontal ? await hitTest(page) : null;
  if (errors.length) throw new Error(`${item.name}: ${errors.join(' | ')}`);
  if (item.expectFocus) {
    assert.equal(snapshot.focusedHeadCount, 1, `${item.name}: genau ein fokussierter Mitarbeitendenkopf erwartet`);
    assert.equal(snapshot.focusedTrackCount, 1, `${item.name}: genau eine fokussierte Mitarbeitendenspalte erwartet`);
    assert.equal(snapshot.contextTrackCount, 4, `${item.name}: genau vier Kontextspalten erwartet`);
  }
  if (item.expectAgenda) {
    assert.equal(snapshot.visibleAgendaPanels, 1, `${item.name}: genau ein sichtbares Agenda-Popover erwartet`);
  }
  if (item.expectHorizontal) {
    assert.ok(snapshot.scrollLeft > 1 && snapshot.railMode === 'sticky', `${item.name}: horizontale Mitarbeitendenbewegung erwartet`);
    assert.ok(horizontalHits.shadeCoversRail && horizontalHits.lineCoversRail, `${item.name}: Zeitfläche muss die sticky Achse weiterhin umfassen`);
  }
  await page.screenshot({ path: resolve(evidenceDirectory, `${item.name}.png`), fullPage: true });
  matrix.push({
    name: item.name,
    viewport: item.viewport,
    parameters: item.parameters,
    machineState: snapshot.data,
    interactionState: {
      focusedHeadCount: snapshot.focusedHeadCount,
      focusedTrackCount: snapshot.focusedTrackCount,
      contextTrackCount: snapshot.contextTrackCount,
      visibleAgendaPanels: snapshot.visibleAgendaPanels,
      scrollLeft: snapshot.scrollLeft,
      railMode: snapshot.railMode,
      horizontalSurface: horizontalHits
    },
    geometry: Object.fromEntries(surfaceKeys.map((key) => [key, snapshot[key]]))
  });
  await context.close();
}

const browser = await chromium.launch({ headless: true });

try {
  const proofCases = [
    ['Desktop', { width: 1366, height: 768 }, false, 'desktop'],
    ['Mobil', { width: 390, height: 844 }, true, 'mobile']
  ];

  for (const [label, viewport, mobile, agendaVariant] of proofCases) {
    const baseline = await openAt(browser, viewport, 'referenceDate=2026-08-26&referenceNow=04%3A37', mobile);
    const baselineStyles = await cardStyles(baseline.page);
    check(`${label}: Voröffnung ohne JavaScriptfehler`, baseline.errors.length === 0, baseline.errors.join(' | '));
    await baseline.context.close();

    const { context, page, errors } = await openAt(browser, viewport, 'referenceDate=2026-08-26&referenceNow=11%3A22', mobile);
    const state = await surface(page);
    const hits = await hitTest(page);
    let shiftedHits = hits;
    let occlusion = null;
    if (mobile) {
      occlusion = await horizontalOcclusion(page);
      shiftedHits = await hitTest(page);
    }
    const currentStyles = await cardStyles(page);
    const agenda = await agendaTruth(page, 682);
    check(`${label}: 11:22 ohne JavaScriptfehler`, errors.length === 0, errors.join(' | '));
    check(`${label}: exakt eine globale Zeitfläche`, state.shadeCount === 1 && state.lineCount === 1 && state.directShade && state.directLine && state.trackShadeCount === 0, JSON.stringify(state));
    check(`${label}: Vergangenheit ist flach und ohne Blend`, state.shadeImage === 'none' && state.shadeBlend === 'normal' && state.shadeColor !== 'rgba(0, 0, 0, 0)', JSON.stringify(state));
    check(`${label}: Jetzt-Linie ist solid und ruhig`, state.lineImage === 'none' && state.lineAnimation === 'none', JSON.stringify(state));
    check(`${label}: Fläche umfasst Achse und alle Spalten`, closeTo(state.shadeLeft, state.gridLeft) && closeTo(state.shadeWidth, state.gridWidth) && hits.shadeCoversRail && hits.lineCoversRail && shiftedHits.shadeCoversRail && shiftedHits.lineCoversRail && (!mobile || (occlusion.stable && occlusion.sawUnderlyingHeader)), JSON.stringify({ state, hits, shiftedHits, occlusion }));
    check(`${label}: 11:22 liegt exakt bei 33.6667 Prozent`, closeTo(state.shadePercent, 33.6666667, .15) && closeTo(state.linePercent, 33.6666667, .15) && closeTo(state.shadeTop + state.shadeHeight, state.lineTop, 1), JSON.stringify(state));
    check(`${label}: Linie liegt über Raster und unter Karten`, state.shadeZ === 2 && state.lineZ === 3 && state.cardZMin >= 4 && hits.freeHit && hits.cardProtectsLine, JSON.stringify({ state, hits }));
    check(`${label}: Kartenstatusfarben bleiben unverändert`, JSON.stringify(currentStyles) === JSON.stringify(baselineStyles));
    check(`${label}: maschinenlesbare Zürcher Zeit ist 11:22`, state.digital === '11:22' && state.marker === '11:22' && closeTo(state.hourAngle, 341, .01) && closeTo(state.minuteAngle, 132, .01) && state.data['data-tp-time-source'] === 'Europe/Zurich' && state.data['data-tp-now-minute'] === '682' && state.data['data-tp-past-progress'] === '0.336667' && state.data['data-tp-past-layer-count'] === '1' && state.data['data-tp-now-line-count'] === '1' && state.data['data-tp-now-line-behind-cards'] === '1' && state.data['data-tp-card-time-tone-count'] === '0' && state.data['data-tp-time-sync-state'] === 'stable', JSON.stringify(state));
    check(`${label}: Agenda folgt derselben Minute`, agenda.truthful && JSON.stringify(agenda.current) === JSON.stringify(['a10', 'a6', 'a7', 'a8', 'a9']), JSON.stringify(agenda));

    const beforeFocus = await surface(page);
    await page.evaluate(() => document.querySelectorAll('[data-focus-staff]')[2].click());
    await page.waitForFunction(() => document.querySelectorAll('.va-staff-head.is-focused').length === 1);
    await waitForStable(page, mobile);
    const afterFocus = await surface(page);
    const focusCounts = await page.evaluate(() => ({
      focused: document.querySelectorAll('.va-staff-head.is-focused').length,
      context: document.querySelectorAll('.va-staff-track.is-context').length,
      tracks: document.querySelectorAll('.va-staff-track').length
    }));
    check(`${label}: Fokus verändert die Zeitfläche nicht`, sameSurface(beforeFocus, afterFocus) && focusCounts.focused === 1 && focusCounts.context === 4 && focusCounts.tracks === 5, JSON.stringify({ beforeFocus, afterFocus, focusCounts }));

    const beforeAgenda = await surface(page);
    await page.evaluate((variant) => document.querySelector(`[data-header-agenda-toggle][data-agenda-variant="${variant}"]`)?.click(), agendaVariant);
    await page.waitForFunction(() => {
      const panel = document.querySelector('.va-agenda-popover');
      return Boolean(panel && !panel.hidden && panel.getClientRects().length);
    });
    const whileAgenda = await surface(page);
    await page.evaluate(() => document.querySelector('[data-header-agenda-close]')?.click());
    await page.waitForFunction(() => {
      const panel = document.querySelector('.va-agenda-popover');
      return !panel || panel.hidden || panel.getClientRects().length === 0;
    });
    const afterAgenda = await surface(page);
    check(`${label}: Agenda verändert weder Geometrie noch Scrollposition`, sameSurface(beforeAgenda, whileAgenda) && sameSurface(beforeAgenda, afterAgenda), JSON.stringify({ beforeAgenda, whileAgenda, afterAgenda }));
    await context.close();
  }

  const liveContext = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await liveContext.addInitScript(({ startIso }) => {
    const NativeDate = Date;
    let nativeOrigin = NativeDate.now();
    let simulatedOrigin = NativeDate.parse(startIso);
    class ControlledDate extends NativeDate {
      constructor(...args) { super(...(args.length ? args : [simulatedOrigin + (NativeDate.now() - nativeOrigin)])); }
      static now() { return simulatedOrigin + (NativeDate.now() - nativeOrigin); }
    }
    window.Date = ControlledDate;
    window.__setSalonProofTime = (iso) => { simulatedOrigin = NativeDate.parse(iso); nativeOrigin = NativeDate.now(); };
  }, { startIso: '2026-08-26T09:29:58.500Z' });
  const livePage = await liveContext.newPage();
  const liveErrors = [];
  livePage.on('pageerror', (error) => liveErrors.push(error.message));
  await livePage.goto(`${baseUrl}?referenceDate=2026-08-26`, { waitUntil: 'load' });
  await livePage.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.tpTimeSyncReason === 'minute-boundary' && document.querySelector('#dashboard-root')?.dataset.tpTimeSyncState === 'stable' && document.querySelector('[data-clock-digital]')?.textContent?.trim() === '11:30', null, { timeout: 6_000 });
  const boundary = await surface(livePage);
  const boundaryAgenda = await agendaTruth(livePage, 690);
  check('Minutenwechsel bleibt ohne JavaScriptfehler', liveErrors.length === 0, liveErrors.join(' | '));
  check('Minutenwechsel synchronisiert Uhr, Fläche und Agenda', boundary.digital === '11:30' && boundary.marker === '11:30' && closeTo(boundary.hourAngle, 345, .01) && closeTo(boundary.minuteAngle, 180, .01) && closeTo(boundary.linePercent, 35, .15) && boundaryAgenda.truthful, JSON.stringify({ boundary, boundaryAgenda }));

  await livePage.locator('[data-create-appointment]').click();
  const customerInput = livePage.locator('[data-booking-form] input[name="customer"]');
  await customerInput.fill('Unverlorener Entwurf');
  await customerInput.focus();
  await livePage.evaluate(() => { window.__setSalonProofTime('2026-08-26T10:00:00.000Z'); document.dispatchEvent(new Event('visibilitychange')); });
  await livePage.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.tpTimeSyncReason === 'tab-resume' && document.querySelector('#dashboard-root')?.dataset.tpTimeSyncState === 'stable' && document.querySelector('[data-clock-digital]')?.textContent?.trim() === '12:00', null, { timeout: 4_000 });
  const resumed = await surface(livePage);
  const resumedAgenda = await agendaTruth(livePage, 720);
  const bookingPreserved = await livePage.evaluate(() => ({
    value: document.querySelector('[data-booking-form] input[name="customer"]')?.value ?? '',
    focused: document.activeElement === document.querySelector('[data-booking-form] input[name="customer"]')
  }));

  await livePage.locator('[data-close-overlay]').click();
  await livePage.locator('[data-header-agenda-toggle][data-agenda-variant="desktop"]').click();
  await livePage.waitForFunction(() => document.querySelector('.va-agenda-popover:not([hidden]) [data-header-agenda-close]') === document.activeElement);
  await livePage.evaluate(() => { window.__setSalonProofTime('2026-08-26T10:01:00.000Z'); window.__gasserwerkSalonTime.sync('manual-proof'); });
  await livePage.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.tpTimeSyncReason === 'manual-proof' && document.querySelector('#dashboard-root')?.dataset.tpTimeSyncState === 'stable' && document.querySelector('[data-clock-digital]')?.textContent?.trim() === '12:01');
  const agendaPreserved = await livePage.evaluate(() => ({
    visible: [...document.querySelectorAll('.va-agenda-popover')].filter((node) => !node.hidden && node.getClientRects().length).length,
    expanded: [...document.querySelectorAll('[data-header-agenda-toggle][aria-expanded="true"]')].some((node) => node.getClientRects().length),
    closeFocused: document.activeElement?.matches('[data-header-agenda-close]') ?? false
  }));

  await livePage.evaluate(() => {
    window.dispatchEvent(new PageTransitionEvent('pagehide', { persisted: true }));
    window.__setSalonProofTime('2026-08-26T10:02:00.000Z');
    window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true }));
  });
  await livePage.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.tpTimeSyncReason === 'bfcache-restore' && document.querySelector('#dashboard-root')?.dataset.tpTimeSyncState === 'stable' && document.querySelector('[data-clock-digital]')?.textContent?.trim() === '12:02');
  const bfcachePreserved = await livePage.evaluate(() => ({
    visible: [...document.querySelectorAll('.va-agenda-popover')].filter((node) => !node.hidden && node.getClientRects().length).length,
    expanded: [...document.querySelectorAll('[data-header-agenda-toggle][aria-expanded="true"]')].some((node) => node.getClientRects().length),
    closeFocused: document.activeElement?.matches('[data-header-agenda-close]') ?? false
  }));

  await livePage.evaluate(() => {
    window.__setSalonProofTime('2026-08-26T09:59:00.000Z');
    window.__gasserwerkSalonTime.sync('agenda-boundary-before');
  });
  await livePage.waitForFunction(() => document.querySelector('[data-clock-digital]')?.textContent?.trim() === '11:59');
  const disappearingAgendaRow = livePage.locator('.va-agenda-popover:not([hidden]) [data-agenda-appointment-id="a8"]');
  await disappearingAgendaRow.focus();
  await livePage.evaluate(() => {
    window.__setSalonProofTime('2026-08-26T10:00:00.000Z');
    window.__gasserwerkSalonTime.sync('agenda-boundary-after');
  });
  await livePage.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.tpTimeSyncReason === 'agenda-boundary-after' && document.querySelector('[data-clock-digital]')?.textContent?.trim() === '12:00');
  await livePage.evaluate(() => new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done))));
  const agendaBoundaryFocus = await livePage.evaluate(() => ({
    removedRowAbsent: !document.querySelector('.va-agenda-popover:not([hidden]) [data-agenda-appointment-id="a8"]'),
    closeFocused: document.activeElement?.matches('[data-header-agenda-close]') ?? false,
    activeTag: document.activeElement?.tagName ?? ''
  }));
  await liveContext.close();

  const lifecycleContext = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const lifecyclePage = await lifecycleContext.newPage();
  const lifecycleErrors = [];
  lifecyclePage.on('pageerror', (error) => lifecycleErrors.push(error.message));
  await lifecyclePage.goto(`${baseUrl}?referenceDate=2026-08-26&referenceNow=11%3A22`, { waitUntil: 'load' });
  await waitForStable(lifecyclePage, true);
  await lifecyclePage.locator('[data-create-appointment]').click();
  await lifecyclePage.locator('[data-booking-form] input[name="customer"]').fill('BFCache bleibt stabil');
  await lifecyclePage.evaluate(() => {
    window.dispatchEvent(new PageTransitionEvent('pagehide', { persisted: true }));
    window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true }));
  });
  await lifecyclePage.waitForFunction(() => document.querySelector('#dashboard-root')?.dataset.tpTimeSyncReason === 'bfcache-restore');
  await lifecyclePage.locator('[data-close-overlay]').click();
  await lifecyclePage.waitForFunction(() => {
    const rootNode = document.querySelector('#dashboard-root');
    return Boolean(rootNode?.querySelector('.va-calendar-viewport'))
      && rootNode.querySelector('.va-now-label')?.textContent?.trim() === '11:22'
      && rootNode.dataset.tpLayoutState === 'stable'
      && rootNode.dataset.calendarPrimaryScrollOwner === 'calendar-viewport';
  });
  const lifecycleOcclusion = await horizontalOcclusion(lifecyclePage);
  const lifecycleAfterRender = await lifecyclePage.evaluate(() => ({
    viewportCount: document.querySelectorAll('.va-calendar-viewport').length,
    nowLabel: document.querySelector('.va-now-label')?.textContent?.trim() ?? '',
    layoutState: document.querySelector('#dashboard-root')?.dataset.tpLayoutState ?? '',
    renderState: document.querySelector('#dashboard-root')?.dataset.tpRenderState ?? '',
    scrollOwner: document.querySelector('#dashboard-root')?.dataset.calendarPrimaryScrollOwner ?? ''
  }));
  await lifecycleContext.close();

  check('Tab-Wiederaufnahme synchronisiert Uhr, Fläche und Agenda', resumed.digital === '12:00' && resumed.marker === '12:00' && closeTo(resumed.hourAngle, 0, .01) && closeTo(resumed.minuteAngle, 0, .01) && closeTo(resumed.linePercent, 40, .15) && resumedAgenda.truthful && bookingPreserved.value === 'Unverlorener Entwurf' && bookingPreserved.focused && agendaPreserved.visible === 1 && agendaPreserved.expanded && agendaPreserved.closeFocused && bfcachePreserved.visible === 1 && bfcachePreserved.expanded && bfcachePreserved.closeFocused && agendaBoundaryFocus.removedRowAbsent && agendaBoundaryFocus.closeFocused && lifecycleAfterRender.viewportCount === 1 && lifecycleAfterRender.nowLabel === '11:22' && lifecycleAfterRender.layoutState === 'stable' && lifecycleAfterRender.renderState === 'ready' && lifecycleAfterRender.scrollOwner === 'calendar-viewport' && lifecycleOcclusion.stable && lifecycleOcclusion.sawUnderlyingHeader && liveErrors.length === 0 && lifecycleErrors.length === 0, JSON.stringify({ resumed, resumedAgenda, bookingPreserved, agendaPreserved, bfcachePreserved, agendaBoundaryFocus, lifecycleAfterRender, lifecycleOcclusion, liveErrors, lifecycleErrors }));

  const evidenceCases = [
    { name: 'reference-now-1122-1512x982', viewport: { width: 1512, height: 982 }, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22' },
    { name: 'reference-now-1122-1366x768', viewport: { width: 1366, height: 768 }, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22' },
    { name: 'reference-now-1122-390x844', viewport: { width: 390, height: 844 }, mobile: true, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22' },
    { name: 'reference-now-1122-844x390', viewport: { width: 844, height: 390 }, mobile: true, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22' },
    { name: 'reference-now-1122-mobile-horizontal-390x844', viewport: { width: 390, height: 844 }, mobile: true, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22&verifyStaffScroll=1', expectHorizontal: true },
    { name: 'reference-now-1122-focus-1512x982', viewport: { width: 1512, height: 982 }, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22&focus=lea', expectFocus: true },
    { name: 'reference-now-1122-agenda-1512x982', viewport: { width: 1512, height: 982 }, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22&agenda=open', expectAgenda: true },
    { name: 'state-pre-opening-0437-1512x982', viewport: { width: 1512, height: 982 }, parameters: 'referenceDate=2026-08-26&referenceNow=04%3A37' },
    { name: 'state-live-1122-1512x982', viewport: { width: 1512, height: 982 }, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22' },
    { name: 'state-after-close-1831-1512x982', viewport: { width: 1512, height: 982 }, parameters: 'referenceDate=2026-08-26&referenceNow=18%3A31' },
    { name: 'state-past-date-1122-1512x982', viewport: { width: 1512, height: 982 }, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22&dateMode=past' },
    { name: 'state-future-date-1122-1512x982', viewport: { width: 1512, height: 982 }, parameters: 'referenceDate=2026-08-26&referenceNow=11%3A22&dateMode=future' }
  ];
  for (const item of evidenceCases) await captureEvidence(browser, item);
} finally {
  await browser.close();
}

if (checks.length !== 29) throw new Error(`Zeitflächen-Suite muss exakt 29 Prüfungen enthalten, erhalten: ${checks.length}`);

writeFileSync(resolve(evidenceDirectory, 'matrix.json'), `${JSON.stringify({ referenceDate: '2026-08-26', cases: matrix }, null, 2)}\n`, 'utf8');
const output = JSON.stringify({ suite: 'Tagesplan v1 · Kalenderfläche und Zeitwahrheit', referenceNow: '11:22', passed: checks.length, failed: 0, checks }, null, 2);
writeFileSync(resolve(evidenceDirectory, 'verify-time-surface-29.txt'), `${output}\n`, 'utf8');
console.log(output);
