# Daten- und Backendgrenze

Das Backend ist während der UI-Referenzphase noch nicht verbindlich. Deshalb greifen Seiten niemals direkt auf HTTP-Endpunkte oder lokale Fixture-Dateien zu.

## Gemeinsamer Datenquellenvertrag

Die Referenz verwendet später eine zentrale `DashboardDataSource` mit fachlichen Methoden wie:

```js
getDayPlan(date)
listAppointments(filters)
getAppointment(id)
listCustomers(query)
getCustomer(id)
listStaff()
listServices()
getAdministrationSettings()
```

## Implementierungen

- `mock-dashboard-data-source.js`: liefert deterministische Referenzdaten und Zustände
- Produktionsadapter: wird später im echten Programm gegen das Backend implementiert

## Regel

Seiten kennen nur das fachliche View-Model und ausgehende Ereignisse. Sie kennen nicht:

- API-URLs
- HTTP-Clients
- Authentifizierungstokens
- Backendtabellen
- Persistenzmechanismen
- Framework-Stores

Dadurch kann jede Seite unabhängig entwickelt, abgenommen und später einzeln in die Produktionsanwendung integriert werden.

## Fixture-Sätze

Jede Seite erhält mindestens:

- Ladezustand
- Leerzustand
- Normalzustand
- dichter Stresszustand
- Fehlerzustand
- eingeschränkter Berechtigungszustand, sofern fachlich relevant
