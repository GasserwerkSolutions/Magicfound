import { DashboardEvent } from '../data/contracts/events.js';
import { createElement, replaceChildren } from '../lib/dom.js';
import { dispatchDashboardEvent } from '../lib/dashboard-events.js';
import { createIcon } from '../shell/icons.js';

function normalizeResult(result) {
  if (!result || typeof result !== 'object') throw new TypeError('search result must be an object');
  if (!result.id || !result.label) throw new TypeError('search result requires id and label');
  return {
    id: String(result.id),
    label: String(result.label),
    description: result.description ? String(result.description) : '',
    meta: result.meta ? String(result.meta) : '',
    type: result.type ? String(result.type) : 'result',
    payload: result.payload ?? {}
  };
}

export function createSearchSurface(options = {}) {
  const {
    id = 'global-search',
    label = 'Dashboard durchsuchen',
    placeholder = 'Kundschaft, Termin oder freie Zeit suchen',
    source = 'product-header-search',
    minimumQueryLength = 1,
    onQuery = null,
    onResultSelected = null
  } = options;

  let results = [];
  let open = false;

  const input = createElement('input', {
    className: 'gw-search-surface__input',
    attributes: {
      id,
      type: 'search',
      inputmode: 'search',
      autocomplete: 'off',
      placeholder,
      'aria-label': label,
      'aria-autocomplete': 'list',
      'aria-controls': `${id}-results`,
      'aria-expanded': 'false'
    }
  });

  const resultList = createElement('div', {
    className: 'gw-search-surface__results',
    attributes: {
      id: `${id}-results`,
      role: 'listbox',
      hidden: true
    }
  });

  const form = createElement('form', {
    className: 'gw-search-surface',
    attributes: { role: 'search', 'data-event-source': source },
    children: [
      createElement('span', {
        className: 'gw-search-surface__icon',
        attributes: { 'aria-hidden': 'true' },
        children: createIcon('search')
      }),
      input,
      resultList
    ]
  });

  function announceOpen() {
    if (open) return;
    open = true;
    input.setAttribute('aria-expanded', 'true');
    dispatchDashboardEvent(form, DashboardEvent.SEARCH_OPENED, {}, { source });
  }

  function close(options = {}) {
    if (!open && resultList.hidden) return;
    open = false;
    resultList.hidden = true;
    input.setAttribute('aria-expanded', 'false');
    input.removeAttribute('aria-activedescendant');
    if (options.clear) input.value = '';
    dispatchDashboardEvent(form, DashboardEvent.SEARCH_CLOSED, {
      query: input.value,
      reason: options.reason ?? 'explicit'
    }, { source });
  }

  function selectResult(result, origin) {
    dispatchDashboardEvent(form, DashboardEvent.SEARCH_RESULT_SELECTED, {
      resultId: result.id,
      resultType: result.type,
      query: input.value,
      ...result.payload
    }, { source });
    if (typeof onResultSelected === 'function') onResultSelected(result, origin);
  }

  function renderResults() {
    const items = results.map((result, index) => {
      const option = createElement('button', {
        className: 'gw-search-result',
        attributes: {
          type: 'button',
          role: 'option',
          id: `${id}-result-${index}`,
          'data-result-id': result.id
        },
        children: [
          createElement('strong', { text: result.label }),
          result.description ? createElement('small', { text: result.description }) : null,
          result.meta ? createElement('span', { className: 'gw-search-result__meta', text: result.meta }) : null
        ],
        on: {
          click: () => selectResult(result, option)
        }
      });
      return option;
    });

    replaceChildren(resultList, items.length ? items : [
      createElement('p', { className: 'gw-search-surface__empty', text: 'Keine Treffer' })
    ]);
    resultList.hidden = false;
    announceOpen();
  }

  input.addEventListener('focus', announceOpen);
  input.addEventListener('input', () => {
    const query = input.value.trim();
    if (query.length < minimumQueryLength) {
      results = [];
      resultList.hidden = true;
      return;
    }
    if (typeof onQuery === 'function') onQuery(query, api);
  });

  input.addEventListener('keydown', (event) => {
    const options = [...resultList.querySelectorAll('[role="option"]')];
    if (event.key === 'ArrowDown' && options.length) {
      event.preventDefault();
      options[0].focus();
    } else if (event.key === 'Escape') {
      event.preventDefault();
      close({ reason: 'escape' });
    }
  });

  resultList.addEventListener('keydown', (event) => {
    const options = [...resultList.querySelectorAll('[role="option"]')];
    const index = options.indexOf(event.target);
    if (event.key === 'ArrowDown' && index >= 0) {
      event.preventDefault();
      (options[index + 1] ?? options[0])?.focus();
    } else if (event.key === 'ArrowUp' && index >= 0) {
      event.preventDefault();
      if (index === 0) input.focus({ preventScroll: true });
      else options[index - 1]?.focus();
    } else if (event.key === 'Escape') {
      event.preventDefault();
      close({ reason: 'escape' });
      input.focus({ preventScroll: true });
    }
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const query = input.value.trim();
    dispatchDashboardEvent(form, DashboardEvent.SEARCH_SUBMITTED, { query }, { source });
    if (typeof onQuery === 'function') onQuery(query, api);
  });

  const api = Object.freeze({
    element: form,
    input,
    resultList,
    focus() {
      input.focus({ preventScroll: true });
    },
    open() {
      announceOpen();
      if (results.length) resultList.hidden = false;
      input.focus({ preventScroll: true });
    },
    close,
    setResults(nextResults = []) {
      results = nextResults.map(normalizeResult);
      renderResults();
    },
    clearResults() {
      results = [];
      replaceChildren(resultList, []);
      resultList.hidden = true;
    },
    get value() {
      return input.value;
    },
    set value(value) {
      input.value = String(value ?? '');
    }
  });

  return api;
}
