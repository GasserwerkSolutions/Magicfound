# Kundschaft · Seitenvertrag

Status: **Zur Freigabe – Listen-/Karteivertrag konsolidiert, Datenumfang und Datenschutz integrationsrelevant**  
Verantwortlicher Bereich: `Kundschaft`  
Direkter Referenzpfad: `/dashboard/pages/kundschaft/`  
Abhängige gemeinsame Verträge: `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

Die Seite `Kundschaft` dient dazu, eine Person schnell zu finden, ihre Kundenkartei zu öffnen und aus diesem Kontext eine weitere Salonhandlung zu beginnen.

Primäre Arbeitsaufgaben:

- Kundschaft suchen und auswählen
- Kontaktdaten und relevante Salonhistorie prüfen
- zukünftige und vergangene Termine erkennen
- einen neuen Termin aus dem Kundenkontext beginnen

Die Kundenkartei ist ein Detailzustand derselben Seite und keine eigene Navigationsroute.

Nicht Bestandteil dieser V1:

- produktives Dubletten-Merging
- Marketingkampagnen
- Datenexport
- rechtliche Löschprozesse
- frei definierbare CRM-Automationen

## 2. Eingabedaten

Datenquellenmethoden:

```js
getSessionContext()
listCustomers(query)
getCustomer(id)
```

Query:

```js
{
  text,
  tags,
  hasUpcomingAppointment,
  sort,
  cursor,
  pageSize
}
```

Erforderliche Listenfelder:

- stabile `id`
- `displayName`
- mindestens ein verfügbares Kontaktlabel oder explizit `kein Kontakt hinterlegt`

Optionale Listenfelder:

- Telefon
- E-Mail
- nächster Termin
- letzter Besuch
- Tags

Erforderliche Detailfelder:

```js
{
  id,
  displayName,
  contact,
  notes,
  tags,
  nextAppointments,
  visitHistory,
  summary
}
```

Alle Felder ausser `id` und `displayName` können abhängig von Backend und Capability fehlen. Die UI erfindet keine Kontaktdaten oder Salonhistorie.

Capabilities:

- Liste und Basiskartei: `customer:view`
- vertrauliche Notizen: `customer:view-sensitive-notes`
- spätere Bearbeitung: `customer:edit`
- Termin aus Kartei: `day-plan:create-appointment`

## 3. Fachliches View-Model

```js
{
  query: {
    text,
    tags,
    sort
  },
  customers: [
    {
      id,
      displayName,
      initials,
      primaryContactLabel,
      secondaryLabel,
      nextAppointmentLabel,
      tags,
      isSelected
    }
  ],
  selectedCustomer: null | {
    id,
    displayName,
    initials,
    contactRows,
    tags,
    notes,
    summaryCards,
    nextAppointments,
    visitHistory,
    actions
  },
  pagination: {
    cursor,
    nextCursor,
    totalCount
  }
}
```

Invarianten:

- Die Kundenliste ist der Eintrittszustand.
- Auswahl verändert nicht automatisch die globale Navigation.
- `selectedCustomer` wird nur mit erlaubten Feldern befüllt.
- Kontaktinformationen bleiben strukturierte Werte; die Darstellung darf sie formatieren, aber nicht semantisch verändern.
- Besuchshistorie ist absteigend nach Datum sortiert, sofern kein anderer fachlicher Grund vorliegt.
- Zukünftige und vergangene Termine bleiben getrennte Gruppen.
- `Laufkundschaft` darf als provisorischer Terminkontext vorkommen, ist aber nicht automatisch eine dauerhafte Kundenkartei.

## 4. Ausgehende Ereignisse

### Suche oder Filter ändern

```js
{
  type: "customer:query-changed",
  payload: { text, tags, sort }
}
```

### Kundenkartei öffnen

```js
{
  type: "customer:selected",
  payload: { customerId, source: "customer-list", originRowId }
}
```

### Kundenkartei schliessen

```js
{
  type: "customer:detail-closed",
  payload: { customerId, returnQuery, returnScrollPosition }
}
```

### Termin aus Kundenkontext beginnen

```js
{
  type: "customer:appointment-create-requested",
  payload: {
    customerId,
    source: "customer-detail"
  }
}
```

### Spätere Bearbeitung

```js
{
  type: "customer:edit-requested",
  payload: { customerId, section }
}
```

Dieser Event ist dokumentiert, wird aber erst emittiert, wenn Bearbeitung Teil des freigegebenen Umfangs ist.

## 5. Ladezustand

### Liste lädt

- Produktschale und Suchfeld bleiben sichtbar.
- Die Listenfläche erhält Skeleton-Zeilen.
- Es wird keine leere Kundenkartei gezeigt.
- Sucheingaben dürfen gepuffert werden; die Seite zeigt den aktiven Suchbegriff.

### Detail lädt

- Die ausgewählte Listenzeile bleibt markiert.
- Detailfläche zeigt strukturelle Skeletons.
- Die Liste bleibt auf Desktop sichtbar.
- Auf Mobil bleibt eine Rückkehrmöglichkeit erhalten.
- Fokus bleibt im Detailkontext und springt nicht in die Liste zurück, bevor das Laden abgeschlossen oder abgebrochen wurde.

## 6. Leerzustand

Es gibt getrennte Zustände:

### Noch keine Kundschaft

- erklärt, dass Kartei und Historie erst mit Kundinnen beziehungsweise Terminen entstehen
- bietet nur fachlich erlaubte nächste Handlungen
- ein neuer Termin darf auch mit neuem Kundenkontext begonnen werden, sofern die Buchungskomponente dies unterstützt

### Keine Suchtreffer

- zeigt den Suchbegriff
- bietet `Suche zurücksetzen`
- darf nicht behaupten, es gebe keine Kundschaft

### Leere Historie einer bestehenden Kartei

- Kundenkontakt bleibt sichtbar
- Historiebereich erklärt `Noch keine abgeschlossenen Besuche`
- zukünftige Termine bleiben unabhängig davon sichtbar

## 7. Fehlerzustand

Kernladefehler:

- Suchfeld, Seitentitel und erneute Ladeaktion bleiben sichtbar.
- Fehler wird nicht als leere Liste dargestellt.

Detailfehler:

- Liste bleibt nutzbar.
- Die ausgewählte Zeile bleibt erkennbar.
- Detailfläche zeigt Retry und Schliessen.

Teilfehler:

- fehlende Historie darf Kontaktdaten nicht verdecken.
- fehlende Zusatzfelder werden ausgelassen, nicht mit Platzhalterwerten erfunden.

Offline/Stale:

- vorhandene Liste und Kartei bleiben sichtbar.
- Aktualität wird gekennzeichnet.
- Bearbeitungs- oder Terminaktionen dürfen nicht als erfolgreich gelten, solange keine Bestätigung vorliegt.

## 8. Berechtigungszustände

- Ohne `customer:view` erscheint ein vollständiger Forbidden-Zustand.
- Ohne `customer:view-sensitive-notes` werden entsprechende Notizen weder geladen noch als gesperrter Text angedeutet.
- Ohne `customer:edit` entfallen Bearbeitungsaktionen.
- Ohne `day-plan:create-appointment` entfällt die Terminaktion aus der Kartei.
- Telefonnummern und E-Mails können capability- oder konfigurationsabhängig sein; die UI zeigt nur gelieferte Kontaktzeilen.
- Berechtigungswechsel während einer offenen Kartei entfernt nicht nur Buttons, sondern auch nicht mehr erlaubte Daten aus dem View-Model.

## 9. Desktopverhalten

- Sidebar und normaler Produktkopf bleiben sichtbar.
- Die Seite startet als Kundenliste.
- Nach Auswahl entsteht eine Split-Ansicht aus Liste und Kundenkartei.
- Die Liste besitzt einen eigenen Scroll-Owner; die Kartei besitzt bei Bedarf einen eigenen vertikalen Scroll-Owner.
- Auswahl ist in der Liste klar erkennbar, aber nicht allein durch Farbe.
- Schliessen der Kartei kehrt zur vorherigen Listenposition zurück.
- Auf 14-Zoll-Viewports wird die Liste relativ schmal, die Kartei erhält den grösseren Inhaltsanteil.
- Haupttext bleibt mindestens 14 px; Kontaktdaten und Sekundärangaben bleiben mindestens 11–12 px.

## 10. Mobilverhalten

- Die Seite startet als vollständige vertikale Kundenliste.
- Eine Auswahl ersetzt den Inhaltsbereich durch die vollständige Kundenkartei.
- Liste und Detail werden nicht gleichzeitig in zwei schmalen Spalten gezeigt.
- Eine klare Rückkehraktion führt zur Liste und stellt Suche sowie Scrollposition wieder her.
- Terminaktion und andere Hauptaktionen bleiben im Daumenbereich beziehungsweise in gut erreichbaren Kopf-/Footerbereichen.
- Lange Kontakt- oder Historieninhalte scrollen vertikal.
- Es gibt keinen horizontalen Seitenüberlauf.

## 11. Tastatur und Fokus

- Das Suchfeld ist früh in der Fokusreihenfolge erreichbar.
- Kundenzeilen sind als Buttons oder gleichwertige Aktivierungselemente umgesetzt.
- `Enter` oder Leertaste öffnet die Kartei.
- Nach dem Öffnen liegt der Fokus auf der Detailüberschrift oder Rückkehraktion, nicht auf einem zufälligen Datenfeld.
- `Escape` schliesst die Kartei, sofern kein höheres Overlay offen ist.
- Schliessen stellt den Fokus an die ursprüngliche Kundenzeile zurück.
- Wird eine Kundenzeile durch eine neue Suche entfernt, geht der Fokus auf das Suchfeld und die Änderung wird angekündigt.
- Statusmeldungen für Lade-, Treffer- und Fehlerzustände verwenden eine Live-Region.

## 12. Abnahmekriterien

- Seite ist direkt aufrufbar und benötigt keinen vorgelagerten Tagesplan.
- Listen-, Detail-, Lade-, Leer-, Such-ohne-Treffer-, Fehler-, Offline-, Stale- und Forbidden-Zustände sind vorhanden.
- Liste ist auf Desktop und Mobil der Eintrittszustand.
- Desktop-Split und mobiles Vollflächendetail zeigen dieselbe fachliche Kartei.
- Schliessen stellt Suchbegriff, Scrollposition und Fokus wieder her.
- Vertrauliche Daten werden bei fehlender Capability nicht gerendert.
- Fehlende optionale Felder erzeugen keine erfundenen Platzhalterinhalte.
- Termin aus Kundenkontext übergibt die stabile Kunden-ID.
- 14-Zoll-Dichte, Standard-Desktop, Mobil und Tablet sind geprüft.
- Keine Gesamtseite läuft horizontal über.
- Kundeninformationen bleiben auch ohne Farbe eindeutig strukturiert.

## 13. Integrationshinweise

- Offene Fragen: `Q-002`, `Q-003`, `Q-005`, `Q-006`, `Q-008`, `Q-CUS-001` bis `Q-CUS-004`, `Q-APT-003`.
- Der Produktionsadapter entscheidet, welche optionalen Kundenfelder verfügbar und erlaubt sind.
- Suchdebounce und serverseitige Pagination sind Implementierungsdetails; Query und Ereignisvertrag bleiben stabil.
- Kundenhistorie soll über normalisierte Termin-/Besuchsreferenzen geliefert werden, nicht durch UI-seitige Verknüpfung über Namen.
- Datenschutz, Löschung und Dubletten-Merge werden nicht durch die Referenz simuliert.
