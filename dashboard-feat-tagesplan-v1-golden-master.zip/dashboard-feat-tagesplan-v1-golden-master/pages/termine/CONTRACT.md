# Termine · Seitenvertrag

Status: **Zur Freigabe – Register- und Detailvertrag konsolidiert, Backendübergänge integrationsrelevant**  
Verantwortlicher Bereich: `Salonbetrieb`  
Direkter Referenzpfad: `/dashboard/pages/termine/`  
Abhängige gemeinsame Verträge: `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

Die Seite `Termine` ist das durchsuch- und filterbare Terminregister des Salons.

Primäre Arbeitsaufgabe:

- einen Termin unabhängig von seiner Position im Tagesplan finden
- seinen fachlichen Zustand erkennen
- ihn im gemeinsamen Terminpanel öffnen
- einen neuen Termin beginnen

Die Seite ist kein zweiter Tagesplan und stellt Termine nicht primär räumlich auf einer Zeitachse dar.

Nicht Bestandteil dieser V1:

- Massenbearbeitung
- Export
- Abrechnung
- direkte Status- oder Terminmanipulation innerhalb der Tabellenzeile

## 2. Eingabedaten

Datenquellenmethoden:

```js
getSessionContext()
listAppointments(query)
getAppointment(id)
listStaff()
listServices()
```

Query:

```js
{
  dateFrom,
  dateTo,
  statuses,
  staffIds,
  serviceIds,
  customerQuery,
  sort,
  cursor,
  pageSize
}
```

Erforderliche Zeilenfelder:

- `id`
- `date`
- `startMinute`
- `durationMinutes`
- `customer.displayName`
- `service.displayName`
- `staff.displayName`
- `status`

Optionale Felder:

- Telefonlabel
- Preis
- Notizindikator
- Bestätigungs- oder Kommunikationsstatus, sofern später geliefert

Capabilities:

- Register: `appointment:view`
- neuen Termin beginnen: `day-plan:create-appointment`
- bearbeiten: `appointment:edit`
- Status ändern: `appointment:change-status`

## 3. Fachliches View-Model

```js
{
  query: {
    dateFrom,
    dateTo,
    statuses,
    staffIds,
    serviceIds,
    customerQuery,
    sort
  },
  filters: {
    availableStatuses,
    staffOptions,
    serviceOptions
  },
  rows: [
    {
      id,
      date,
      dateLabel,
      startMinute,
      timeLabel,
      durationMinutes,
      customer,
      service,
      staff,
      status,
      statusLabel,
      priceLabel,
      canOpen,
      canEdit
    }
  ],
  pagination: {
    cursor,
    nextCursor,
    totalCount
  }
}
```

Invarianten:

- Filterwerte werden als fachliche IDs geführt, nicht als sichtbare Labels.
- Statuslabel und Statuscode bleiben getrennt.
- Sortierung ist deterministisch; Standard ist Datum und Startzeit aufsteigend für kommende beziehungsweise ausgewählte Zeiträume.
- `cancelled` und `no-show` bleiben unterscheidbare Zustände.
- Ein fehlender Preis verhindert nicht das Anzeigen oder Öffnen eines Termins.

## 4. Ausgehende Ereignisse

### Filter ändern

```js
{
  type: "appointments:query-changed",
  payload: { query }
}
```

Die Referenz darf lokal filtern; die Produktionsintegration entscheidet über server- oder clientseitige Abfrage.

### Termin öffnen

```js
{
  type: "appointment:selected",
  payload: {
    appointmentId,
    source: "appointments-register",
    originRowId
  }
}
```

### Termin beginnen

```js
{
  type: "appointment:create-requested",
  payload: {
    date: selectedDate || null,
    staffId: selectedStaffId || null,
    source: "appointments-register"
  }
}
```

### Statusänderung aus Detailpanel

```js
{
  type: "appointment:status-change-requested",
  payload: { appointmentId, fromStatus, toStatus, reason: null | string }
}
```

Die Tabelle selbst führt in V1 keine direkte Statusmutation aus.

## 5. Ladezustand

- Produktschale, Seitentitel, Suche und primäre Terminaktion bleiben sichtbar.
- Filter bleiben sichtbar, sofern ihre Optionen bereits vorliegen.
- Tabellenkopf beziehungsweise mobile Registerstruktur bleiben als Skeleton erhalten.
- Vorhandene Ergebnisse dürfen bei einer Filterneuladung sichtbar bleiben und als aktualisierend markiert werden.
- Der Fokus bleibt auf dem auslösenden Filter.

## 6. Leerzustand

Es gibt zwei getrennte Leerzustände:

### Keine Termine im gewählten Zeitraum

- erklärt den Zeitraum
- bietet `Termin eintragen`, sofern erlaubt
- verändert Filter nicht automatisch

### Keine Treffer für aktive Filter oder Suche

- zeigt aktive Filter verständlich
- bietet `Filter zurücksetzen`
- darf nicht behaupten, der Salon habe keine Termine

Eine alpine Illustration ist hier nur klein und sekundär zulässig; die Registeraufgabe bleibt dominant.

## 7. Fehlerzustand

Kernladefehler:

- Filter und Seitengerüst bleiben sichtbar.
- Es gibt eine erneute Ladeaktion.
- Ein Fehler wird nicht als leeres Register dargestellt.

Teilfehler:

- fehlende Filteroptionen dürfen die vorhandene Liste nicht verdecken.
- ein einzelner nicht ladbarer Detaildatensatz erzeugt einen Fehler im Panel, nicht auf der gesamten Seite.

Offline/Stale:

- vorhandene Zeilen bleiben sichtbar und werden als möglicherweise veraltet markiert.
- Statusänderungen oder Bearbeitung werden nicht als erfolgreich angenommen, solange keine Bestätigung vorliegt.

## 8. Berechtigungszustände

- Ohne `appointment:view` erscheint ein vollständiger Forbidden-Zustand.
- Ohne `day-plan:create-appointment` entfällt die primäre Erstellaktion.
- Ohne `appointment:edit` kann der Termin geöffnet, aber nicht bearbeitet werden.
- Ohne `appointment:change-status` werden Statusaktionen im Panel nicht geliefert.
- Kundentelefon und Notizen werden nur geliefert, wenn die erforderlichen Kunden-Capabilities vorliegen.

## 9. Desktopverhalten

- Sidebar und normaler Produktkopf bleiben bestehen.
- Filter bilden eine kompakte Zeile oberhalb der Registerfläche.
- Das Register verwendet eine Tabelle mit klaren Spalten für Datum/Zeit, Kundschaft, Dienstleistung, Person und Status.
- Die Registerfläche besitzt den inneren Scroll-Owner; die Seite selbst darf nicht horizontal überlaufen.
- Auf 14-Zoll-Viewports werden Zeilen und Abstände verdichtet, Hauptinformationen bleiben mindestens 14 px lesbar.
- Terminöffnung erfolgt im gemeinsamen seitlichen Kontextpanel.
- Schliessen stellt Zeile, Scrollposition und Tastaturfokus wieder her.

## 10. Mobilverhalten

- Die Desktoptabelle wird nicht einfach horizontal verkleinert.
- Termine erscheinen als vertikale Registerzeilen mit Zeit, Kundschaft, Dienstleistung und Status.
- Weniger wichtige Metadaten werden im Detailpanel gezeigt.
- Filter können umbrechen oder als kompakte Filterfläche geöffnet werden; aktive Filter bleiben erkennbar.
- Das Terminpanel erscheint als unteres Sheet.
- Die Gesamtseite scrollt vertikal; keine Gesamtseite darf horizontal überlaufen.

## 11. Tastatur und Fokus

- Filter sind in logischer Reihenfolge erreichbar.
- Tabellen- beziehungsweise Registerzeilen sind echte Buttons oder besitzen äquivalente Aktivierung.
- `Enter` oder Leertaste öffnet den Termin.
- Das Panel hält den Fokus und gibt ihn an die ursprüngliche Zeile zurück.
- Nach einer erfolgreichen Änderung bleibt der Fokus auf derselben fachlichen Zeile, sofern sie noch im Filter enthalten ist.
- Fällt die Zeile durch die Änderung aus dem Filter, wird der Fokus auf eine verständliche Nachbarposition oder den Registertitel gesetzt und die Änderung angekündigt.

## 12. Abnahmekriterien

- Register ist direkt aufrufbar und ohne Tagesplan funktionsfähig.
- Normal-, Lade-, Leer-, Filter-ohne-Treffer-, Fehler-, Offline-, Stale- und Forbidden-Zustände sind vorhanden.
- Filter verwenden Codes/IDs und sichtbare Labels getrennt.
- Desktoptabelle und mobiles Register zeigen dieselbe fachliche Wahrheit.
- Terminpanel ist eine gemeinsame Komponente und keine lokale Kopie.
- Zeilenöffnung und Fokuswiederherstellung funktionieren per Tastatur.
- 14-Zoll-Dichte zeigt mehr Zeilen ohne unlesbare Schrift.
- Keine Gesamtseite überläuft horizontal.
- Status ist nicht ausschliesslich durch Farbe erkennbar.
- Unbekannte Preise oder Zusatzdaten beschädigen die Kernanzeige nicht.
- Keine Backendmutation wird ohne Bestätigung als abgeschlossen dargestellt.

## 13. Integrationshinweise

- Offene Fragen: `Q-002`, `Q-003`, `Q-005`, `Q-006`, `Q-APT-001`, `Q-APT-002`, `Q-APT-003`, `Q-CUS-002`.
- Pagination, Suche und Filterung können server- oder clientseitig implementiert werden; der Seitenvertrag bleibt identisch.
- Der Adapter normalisiert Zeit und Statuscodes.
- Erlaubte Statusübergänge kommen aus Domainlogik beziehungsweise Backend, nicht aus einer hart codierten UI-Liste.
- Die Tabelle darf keine Kundendaten anfordern, die sie nicht darstellt oder für eine erlaubte Aktion benötigt.
