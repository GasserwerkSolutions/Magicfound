# Tagesplan v1.0 · Referenzvertrag

Status: **Release Candidate**

## 1. Primäre Aufgabe

Der Tagesplan macht den laufenden Salonbetrieb räumlich und zeitlich verständlich:

- wer arbeitet;
- was jetzt läuft;
- wie lange Arbeit dauert;
- welche freie Zeit besteht;
- was unmittelbar als Nächstes relevant ist.

## 2. Räumliche Grammatik

- Zeit läuft von oben nach unten.
- Mitarbeitende liegen als Spalten nebeneinander.
- Der Arbeitstag umfasst `08:00–18:00`.
- Das Raster verwendet 15-, 30- und 60-Minuten-Linien.
- `09:00`, `12:00`, `15:00` und `18:00` sind starke Zeitanker.
- Kalenderkopf und Raster bilden genau eine zusammenhängende Kalenderfläche.
- Auf unterstützten Desktopflächen ist der vollständige Tag ohne Seiten- oder Kalenderscroll sichtbar.
- Auf Mobilgeräten besitzt der Kalender genau einen zweidimensionalen Viewport: vertikal für Zeit und horizontal für Mitarbeitende.

## 3. Zeitwahrheit

- Position entspricht Beginn.
- Höhe entspricht Dauer.
- Die vergangene Tagesfläche ist eine globale Schicht.
- Die Jetzt-Linie liegt hinter Terminkarten und vor dem Raster.
- Statusfarbe beschreibt den fachlichen Zustand, nicht Vergangenheit oder Zukunft.
- Auf vergangenen und zukünftigen Tagen erscheint keine falsche Jetzt-Semantik.

## 4. Terminkarten

Informationsstufen werden aus dem real verfügbaren Raum abgeleitet:

1. vollständig: Zeit, Name, Leistung;
2. verdichtet: Zeit und Name;
3. kompakt: Name;
4. minimal: Initialen oder Leistungssymbol.

Karten dürfen fachliche Wahrheit nie zugunsten besserer Optik verfälschen.

## 5. Agenda „Als Nächstes“

- Die Agenda ist ein nicht-modales Kopfzeilen-Popover.
- Sie verändert die Kalendergeometrie nicht.
- Sie verwendet dieselben Terminobjekte wie der Kalender.
- Sie gliedert chronologisch in `Davor`, `Jetzt` und `Danach`.
- Verborgene Einträge werden ausdrücklich als weitere Einträge offengelegt.
- Schliessen ist über Auslöser, Schliessen-Aktion, Aussenklick und `Escape` möglich.
- Der Fokus kehrt zum Ursprung zurück.

## 6. Personenfokus

- Der Fokus erzeugt keine neue Seite und keinen neuen Kalender.
- Alle fünf Spalten bleiben vorhanden.
- Die fokussierte Person bleibt im normalen Kontrast.
- Kontextspalten werden zurückgenommen, bleiben aber bedienbar.
- Auswahl, Datum, Scrollposition und offener Kontext bleiben erhalten.

## 7. Interaktion und Accessibility

- Personenüberschriften, Termine, Aufgaben, Pausen und freie Zeit sind echte Bedienelemente.
- Vollständige Zeit, Dauer, Kundschaft, Leistung, Person und Zustand stehen im zugänglichen Namen.
- Die Jetzt-Linie ist informativ und nicht fokussierbar.
- Tastaturfokus ist jederzeit sichtbar.
- `Escape` schliesst den jeweils obersten lokalen Kontext.
- Reduzierte Bewegung bleibt vollständig verständlich.
- Es gibt keine verschachtelten Modalketten.

## 8. Responsive-Vertrag

### Desktop ab 960 CSS-Pixel Breite

- vollständiger Arbeitstag sichtbar;
- fünf Mitarbeitende gleichzeitig sichtbar;
- kein horizontaler Gesamtseitenüberlauf;
- kein vertikaler Seiten-, Panel- oder Kalenderüberlauf;
- Agenda nur als Overlay.

### Mobil und schmales Tablet

- genau ein vertikales Kalenderscrollsystem;
- funktionale horizontale Mitarbeitendenbewegung;
- sticky Mitarbeitendenkopf;
- sticky Zeitachse;
- kein zusätzlicher Dokument-Scroll;
- Agenda als temporäre Kontextfläche.

## 9. Wirkung

Primär: `gegenwärtig`, `atmend`, `im Fluss`.

Unterstützend: `aufmerksam`, `beseelt`.

Das Wirkungsprofil darf ausschliesslich Raumrhythmus, Materialtiefe, Bewegungstempo, Aufmerksamkeitsstärke und Illustrationspräsenz beeinflussen. Status, Fokus, Suche und Datenbedeutung bleiben fachlich unverändert.

## 10. Alpine Welt

- regulärer Arbeitstag: 0–5 Prozent, grundsätzlich keine Szene;
- leerer Tagesplan: 15–22 Prozent Habitat-Zone;
- Funktion und Raster werden zuerst erkannt;
- das Master-Murmeltier ist stiller Bewohner, kein Assistent und kein Funktionsträger;
- keine alpine Illustration bei Fehler, Berechtigungsgrenze, Offlinewarnung oder Sicherheitsproblem.

## 11. Nicht Bestandteil von v1.0

- produktive Authentifizierung;
- echte Backendendpunkte;
- persistente Mutationen;
- Drag-and-drop und Resize von Terminen;
- endgültige Frameworkentscheidung;
- vollständige Produktionsintegration.

## 12. Freigabesatz

> Innerhalb weniger Sekunden ist erkennbar, wer arbeitet, was jetzt läuft und was als Nächstes relevant ist.
