const INITIAL_POSITION_MAX_ATTEMPTS = 24;
const INITIAL_POSITION_RETRY_MS = 50;

function bindCalendarViewport(viewport) {
  if (viewport.dataset.precisionBound === '1') return;
  viewport.dataset.precisionBound = '1';
  const markManual = () => { if (!state.programmaticScroll) state.userMovedCalendar = true; };
  viewport.addEventListener('pointerdown', markManual, { passive: true });
  viewport.addEventListener('touchstart', markManual, { passive: true });
  viewport.addEventListener('wheel', markManual, { passive: true });
  viewport.addEventListener('keydown', (event) => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'PageUp', 'PageDown', 'Home', 'End', ' '].includes(event.key)) markManual();
  });
  viewport.addEventListener('scroll', () => {
    state.scrollTop = viewport.scrollTop;
    state.scrollLeft = viewport.scrollLeft;
    updateScrollDiagnostics(viewport);
    syncTimeRailLayer(viewport);
  }, { passive: true });
  syncTimeRailLayer(viewport);
}

function syncTimeRailLayer(viewport) {
  if (!root) return;
  const scrollLeft = viewport?.scrollLeft ?? 0;
  root.dataset.tpTimeRailLayer = scrollLeft > 1 ? 'sticky' : 'surface';
  const grid = viewport?.querySelector('.va-calendar-grid');
  const rail = viewport?.querySelector('.va-time-rail');
  if (!grid || !rail) return;
  grid.style.setProperty('--va-time-label-offset', `${scrollLeft}px`);
  const railRight = rail.getBoundingClientRect().right;
  grid.querySelectorAll('.va-staff-track').forEach((track) => {
    const rect = track.getBoundingClientRect();
    const clipLeft = Math.max(0, Math.min(rect.width, railRight - rect.left));
    track.style.setProperty('--va-sticky-rail-track-clip-left', `${clipLeft}px`);
  });
  grid.querySelectorAll('.va-appointment, .va-operational').forEach((card) => {
    const rect = card.getBoundingClientRect();
    const clipLeft = Math.max(0, Math.min(rect.width, railRight - rect.left));
    card.style.setProperty('--va-sticky-rail-card-clip-left', `${clipLeft}px`);
  });
}

function scheduleInitialCalendarPosition(viewport, attempt = 0) {
  if (!viewport?.isConnected || state.userMovedCalendar || !isToday() || !isCompactCalendar()) return;
  if (attempt === 0) {
    if (viewport.dataset.initialPositionState === 'pending' || viewport.dataset.initialPositionState === 'done') return;
    viewport.dataset.initialPositionState = 'pending';
    if (root) root.dataset.calendarInitialNowPositioned = '0';
  }

  if (jumpCalendarToNow({ force: true, behavior: 'auto' })) {
    viewport.dataset.initialPositionState = 'done';
    maybeVerifyHorizontalScroll(viewport);
    return;
  }

  if (attempt >= INITIAL_POSITION_MAX_ATTEMPTS) {
    viewport.dataset.initialPositionState = 'failed';
    if (root) root.dataset.calendarInitialNowPositioned = '0';
    return;
  }
  window.setTimeout(() => scheduleInitialCalendarPosition(viewport, attempt + 1), INITIAL_POSITION_RETRY_MS);
}

function restoreOrPositionCalendar(viewport) {
  if (!viewport.isConnected) return;
  const positionKey = `${state.currentDate}|${isCompactCalendar() ? 'compact' : 'full'}`;
  if (state.initialPositionKey !== positionKey) {
    state.initialPositionKey = positionKey;
    state.userMovedCalendar = false;
    viewport.dataset.initialPositionState = '';
    if (root) delete root.dataset.calendarInitialNowPositioned;
    if (isToday() && isCompactCalendar()) scheduleInitialCalendarPosition(viewport);
    else scrollCalendar(viewport, 0, 0, 'auto');
    return;
  }

  if (isToday() && isCompactCalendar() && !state.userMovedCalendar && root?.dataset.calendarInitialNowPositioned !== '1') {
    scheduleInitialCalendarPosition(viewport);
    return;
  }
  scrollCalendar(viewport, state.scrollTop, state.scrollLeft, 'auto');
}

function scrollCalendar(viewport, top, left, behavior = 'auto') {
  state.programmaticScroll = true;
  viewport.scrollTo({ top, left, behavior });
  state.scrollTop = viewport.scrollTop;
  state.scrollLeft = viewport.scrollLeft;
  updateScrollDiagnostics(viewport);
  requestAnimationFrame(() => {
    state.scrollTop = viewport.scrollTop;
    state.scrollLeft = viewport.scrollLeft;
    state.programmaticScroll = false;
    updateScrollDiagnostics(viewport);
  });
}

function jumpCalendarToNow({ force = false, behavior = 'smooth' } = {}) {
  const viewport = state.viewport ?? enhanceCalendarStructure();
  const grid = viewport?.querySelector('.va-calendar-grid');
  if (!viewport || !grid || !isToday()) return false;
  if (!force && state.userMovedCalendar) return false;

  const maxTop = Math.max(0, viewport.scrollHeight - viewport.clientHeight);
  if (grid.offsetHeight < 100 || viewport.clientHeight < 80 || maxTop <= 2) return false;

  const minute = clamp(currentMinute(), OPEN_MINUTE, CLOSE_MINUTE);
  const lineOffset = grid.offsetTop + minutePercent(minute) / 100 * grid.offsetHeight;
  const target = clamp(lineOffset - viewport.clientHeight * NOW_ANCHOR_RATIO, 0, maxTop);
  scrollCalendar(viewport, target, viewport.scrollLeft, behavior);
  if (root) root.dataset.calendarInitialNowPositioned = '1';
  return true;
}

function maybeVerifyHorizontalScroll(viewport) {
  if (query.get('verifyStaffScroll') !== '1' || !isPortraitCompact() || !root || !viewport?.isConnected) return;
  if (root.dataset.mobileHorizontalScrollFunctional === '1') return;

  const maxLeft = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
  if (maxLeft <= 2) {
    root.dataset.mobileHorizontalScrollRequested = '0';
    root.dataset.mobileHorizontalScrollFunctional = '0';
    root.dataset.mobileHorizontalScrollDelta = '0';
    return;
  }

  const before = viewport.scrollLeft;
  const target = clamp(before + PORTRAIT_STAFF_WIDTH, 0, maxLeft);
  if (target <= before + 2) return;

  root.dataset.mobileHorizontalScrollRequested = '1';
  state.programmaticScroll = true;
  viewport.scrollLeft = target;
  state.scrollLeft = viewport.scrollLeft;
  state.programmaticScroll = false;

  const delta = Math.round(viewport.scrollLeft - before);
  root.dataset.mobileHorizontalScrollDelta = String(delta);
  root.dataset.mobileHorizontalScrollFunctional = delta > 2 ? '1' : '0';
  updateScrollDiagnostics(viewport);
}

function updateScrollDiagnostics(viewport) {
  if (!root || !viewport) return;
  const grid = viewport.querySelector('.va-calendar-grid');
  const overflowY = Math.max(0, viewport.scrollHeight - viewport.clientHeight);
  const overflowX = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
  root.dataset.calendarScrollTop = String(Math.round(viewport.scrollTop));
  root.dataset.calendarScrollLeft = String(Math.round(viewport.scrollLeft));
  root.dataset.calendarScrollableY = String(overflowY > 2 ? 1 : 0);
  root.dataset.calendarYOverflow = String(Math.round(overflowY));
  root.dataset.calendarXOverflow = String(Math.round(overflowX));
  root.dataset.calendarClientHeight = String(Math.round(viewport.clientHeight));
  root.dataset.calendarScrollHeight = String(Math.round(viewport.scrollHeight));
  root.dataset.calendarClientWidth = String(Math.round(viewport.clientWidth));
  root.dataset.calendarScrollWidth = String(Math.round(viewport.scrollWidth));
  root.dataset.mobileHorizontalScrollable = String(isPortraitCompact() && overflowX > 2 ? 1 : 0);
  root.dataset.mobileStaffColumnMin = String(isPortraitCompact() ? PORTRAIT_STAFF_WIDTH : 0);
  if (grid) root.dataset.calendarGridWidth = String(Math.round(grid.getBoundingClientRect().width));
  syncTimeRailLayer(viewport);
}

function ensureNowLabel(timeLabelLayer, minute) {
  if (!timeLabelLayer) return;
  let label = timeLabelLayer.querySelector('.va-now-label');
  if (!label) {
    label = document.createElement('span');
    label.className = 'va-now-label';
    label.setAttribute('aria-hidden', 'true');
    timeLabelLayer.append(label);
  }
  label.style.top = `${minutePercent(minute)}%`;
  setText(label, formatTime(minute));
}
