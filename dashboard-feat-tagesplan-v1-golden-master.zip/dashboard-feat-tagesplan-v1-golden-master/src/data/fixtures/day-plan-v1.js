import { AppointmentStatus, OperationalKind } from '../contracts/domain-values.js';

const staff = Object.freeze([
  { id: 'melanie', displayName: 'Melanie Schneider', initials: 'MS', professionalRoleLabel: 'Top Stylistin', availabilitySummary: '08:00–18:00', isActive: true },
  { id: 'sofia', displayName: 'Sofia Keller', initials: 'SK', professionalRoleLabel: 'Stylistin', availabilitySummary: '08:00–17:30', isActive: true },
  { id: 'lea', displayName: 'Lea Bianchi', initials: 'LB', professionalRoleLabel: 'Stylistin', availabilitySummary: '08:00–18:00', isActive: true },
  { id: 'nina', displayName: 'Nina Frei', initials: 'NF', professionalRoleLabel: 'Stylistin', availabilitySummary: '09:00–18:00', isActive: true },
  { id: 'jasmin', displayName: 'Jasmin Rüfenacht', initials: 'JR', professionalRoleLabel: 'Top Stylistin', availabilitySummary: '08:30–18:00', isActive: true }
]);

const appointmentSeed = Object.freeze([
  ['a1', 'melanie', 510, 90, 'Mia Frei', 'Schnitt & Föhnen', AppointmentStatus.COMPLETED, 'Feines Haar, kinnlanger Bob', 118],
  ['a2', 'sofia', 540, 60, 'Lara Baumann', 'Farbberatung', AppointmentStatus.COMPLETED, 'Neukundin', 45],
  ['a3', 'lea', 525, 90, 'Lynn Schneider', 'Schnitt & Föhnen', AppointmentStatus.COMPLETED, 'Keine Duftprodukte', 104],
  ['a4', 'nina', 570, 120, 'Sabrina Lutz', 'Balayage & Glossing', AppointmentStatus.COMPLETED, 'Ansatz weich verblenden', 248],
  ['a5', 'jasmin', 555, 120, 'Petra Hofer', 'Balayage', AppointmentStatus.COMPLETED, 'Kühle Nuance', 226],
  ['a6', 'melanie', 630, 90, 'Anna Keller', 'Schnitt & Föhnen', AppointmentStatus.ARRIVED, 'Termin vorziehen, falls möglich', 118],
  ['a7', 'sofia', 600, 90, 'Julia Schmid', 'Farbe & Pflege', AppointmentStatus.ARRIVED, 'Farbrezeptur 7.1 / 7.13', 172],
  ['a8', 'lea', 615, 90, 'Chiara Bianchi', 'Farbe', AppointmentStatus.ARRIVED, 'Kopfhaut empfindlich', 160],
  ['a9', 'nina', 660, 90, 'Vanessa Meier', 'Farbe', AppointmentStatus.ARRIVED, 'Glossing nach Einwirkzeit', 160],
  ['a10', 'jasmin', 660, 90, 'Corinne Zbinden', 'Farbe', AppointmentStatus.ARRIVED, 'Kontakt nur per SMS', 168],
  ['a11', 'melanie', 780, 105, 'Céline Rufer', 'Balayage', AppointmentStatus.CONFIRMED, 'Lange Haare', 238],
  ['a12', 'sofia', 750, 60, 'Sara Vogel', 'Schnitt', AppointmentStatus.PENDING, 'Fransen nachschneiden', 86],
  ['a13', 'lea', 720, 75, 'Elena Weber', 'Lockenschnitt', AppointmentStatus.CONFIRMED, 'Naturlocken', 104],
  ['a14', 'nina', 840, 60, 'Eva Ziegler', 'Schnitt', AppointmentStatus.CONFIRMED, 'Fransen und Kontur', 86],
  ['a15', 'jasmin', 780, 75, 'Reto Gfeller', 'Schnitt', AppointmentStatus.PENDING, 'Bartkontur ergänzen', 94],
  ['a16', 'melanie', 900, 75, 'Daria Meier', 'Schnitt & Föhnen', AppointmentStatus.CONFIRMED, 'Volumen am Oberkopf', 118],
  ['a17', 'sofia', 855, 105, 'Mara Gerber', 'Farbe & Pflege', AppointmentStatus.CONFIRMED, 'Ansatz und Längenausgleich', 172],
  ['a18', 'lea', 840, 150, 'Nina Baumann', 'Balayage & Glossing', AppointmentStatus.CONFIRMED, 'Helles Beige', 248],
  ['a19', 'nina', 915, 120, 'Tina Bachmann', 'Balayage', AppointmentStatus.CONFIRMED, 'Natürliches Blond', 226],
  ['a20', 'jasmin', 870, 90, 'Sandra Aebi', 'Farbe & Pflege', AppointmentStatus.CONFIRMED, 'Warmer Braunton', 172],
  ['a21', 'melanie', 990, 60, 'Helen Moser', 'Schnitt', AppointmentStatus.PENDING, 'Bestätigung offen', 94],
  ['a22', 'sofia', 975, 60, 'Aline Roth', 'Schnitt', AppointmentStatus.CONFIRMED, 'Längen auffrischen', 86],
  ['a23', 'jasmin', 975, 75, 'Nadja Kunz', 'Schnitt & Föhnen', AppointmentStatus.CONFIRMED, 'Schulterlange Form', 104]
]);

const operationalSeed = Object.freeze([
  { id: 'op-1', kind: OperationalKind.TASK, staffId: 'melanie', startMinute: 735, durationMinutes: 30, label: 'Farbrezepturen vorbereiten', note: 'Interne Vorbereitung' },
  { id: 'op-2', kind: OperationalKind.BREAK, staffId: 'sofia', startMinute: 810, durationMinutes: 30, label: 'Pause', note: '' },
  { id: 'op-3', kind: OperationalKind.TASK, staffId: 'lea', startMinute: 1020, durationMinutes: 30, label: 'Arbeitsplatz abschliessen', note: '' }
]);

function appointmentFromSeed(seed, date) {
  const [id, staffId, startMinute, durationMinutes, customerName, serviceName, status, note, price] = seed;
  return Object.freeze({
    id,
    kind: 'appointment',
    date,
    startMinute,
    durationMinutes,
    customer: Object.freeze({ id: `customer-${id}`, displayName: customerName, phoneLabel: '079 000 00 00' }),
    service: Object.freeze({ id: `service-${serviceName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`, displayName: serviceName }),
    staff: Object.freeze({ id: staffId, displayName: staff.find((member) => member.id === staffId)?.displayName ?? 'Unbekannt' }),
    status,
    note,
    price: Object.freeze({ amount: price, currency: 'CHF' })
  });
}

function operationalFromSeed(seed, date) {
  return Object.freeze({
    id: seed.id,
    kind: seed.kind,
    date,
    startMinute: seed.startMinute,
    durationMinutes: seed.durationMinutes,
    staff: Object.freeze({ id: seed.staffId, displayName: staff.find((member) => member.id === seed.staffId)?.displayName ?? 'Unbekannt' }),
    label: seed.label,
    note: seed.note
  });
}

export function createDayPlanFixture(date) {
  const appointments = appointmentSeed.map((seed) => appointmentFromSeed(seed, date));
  const operationalBlocks = operationalSeed.map((seed) => operationalFromSeed(seed, date));
  return Object.freeze({
    date,
    salon: Object.freeze({
      id: 'salon-sonnegg',
      locationId: 'location-zuerich-enge',
      name: 'Coiffure Sonnegg',
      locationLabel: 'Zürich Enge',
      timeZone: 'Europe/Zurich',
      openingMinute: 480,
      closingMinute: 1080
    }),
    staff,
    appointments: Object.freeze(appointments),
    operationalBlocks: Object.freeze(operationalBlocks)
  });
}

export const DAY_PLAN_STAFF_FIXTURE = staff;
