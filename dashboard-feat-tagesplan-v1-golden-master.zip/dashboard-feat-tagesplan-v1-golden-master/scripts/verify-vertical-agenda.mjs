import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const root = process.cwd();
const files = Object.freeze({
  adr4: 'docs/decisions/ADR-004-vertical-day-agenda.md',
  adr5: 'docs/decisions/ADR-005-collapsible-header-agenda.md',
  adr6: 'docs/decisions/ADR-006-day-plan-precision-pass.md',
  html: 'experiments/tagesplan-vertical-agenda/index.html',
  page: 'experiments/tagesplan-vertical-agenda/page.js',
  pageCss: 'experiments/tagesplan-vertical-agenda/page.css',
  agenda: 'experiments/tagesplan-vertical-agenda/header-agenda.js',
  agendaCss: 'experiments/tagesplan-vertical-agenda/header-agenda.css',
  precisionParts: Array.from({ length: 6 }, (_, index) => `experiments/tagesplan-vertical-agenda/precision-controller-0${index + 1}.js`),
  precisionCssParts: [
    'experiments/tagesplan-vertical-agenda/precision-01.css',
    'experiments/tagesplan-vertical-agenda/precision-02.css'
  ],
  clock: 'experiments/tagesplan-vertical-agenda/reference-clock-sync.js',
  readme: 'experiments/tagesplan-vertical-agenda/README.md'
});

const failures = [];
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

const requiredFiles = Object.values(files).flatMap((value) => Array.isArray(value) ? value : [value]);
for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(root, file))) failures.push(`Fehlende Datei: ${file}`);
}

if (!failures.length) {
  const source = Object.fromEntries(Object.entries(files).filter(([, file]) => !Array.isArray(file)).map(([key, file]) => [key, read(file)]));
  source.precision = files.precisionParts.map(read).join('\n');
  source.precisionCss = files.precisionCssParts.map(read).join('\n');

  for (const key of ['page', 'agenda', 'clock']) {
    try {
      new vm.SourceTextModule(source[key], { identifier: files[key] });
    } catch (error) {
      failures.push(`${files[key]}: JavaScript-Syntaxfehler: ${error.message}`);
    }
  }
  for (const file of files.precisionParts) {
    try {
      new vm.Script(read(file), { filename: file });
    } catch (error) {
      failures.push(`${file}: JavaScript-Syntaxfehler: ${error.message}`);
    }
  }

  const requiredPageTerms = [
    'globalAgendaModel',
    'nextFreeGap',
    'va-past-shade',
    'va-now-line',
    'data-start-minute',
    'data-end-minute',
    'data-focus-staff',
    'data-agenda-appointment-id',
    "query.get('referenceNow')"
  ];
  for (const term of requiredPageTerms) {
    if (!source.page.includes(term)) failures.push(`Tagesplanbasis enthält nicht: ${term}`);
  }

  const requiredPrecisionTerms = [
    'PORTRAIT_STAFF_WIDTH = 132',
    'NOW_ANCHOR_RATIO = 0.36',
    'enhanceCalendarStructure',
    'jumpCalendarToNow',
    'userMovedCalendar',
    'ResizeObserver',
    'personNameVariants',
    'serviceVariant',
    'contentTier',
    'weitere laufen',
    'weitere danach',
    "document.addEventListener('visibilitychange'",
    'Europe/Zurich',
    'Name, Termin oder freie Zeit suchen',
    'Ctrl K',
    'TAGESPLAN',
    'nowLineBehindCards',
    'mobileHorizontalScrollable',
    'calendarInitialNowPositioned'
  ];
  for (const term of requiredPrecisionTerms) {
    if (!source.precision.includes(term)) failures.push(`Präzisionscontroller enthält nicht: ${term}`);
  }

  const requiredPrecisionCssTerms = [
    '--va-mobile-staff-column: 132px',
    '.va-now-line',
    'z-index: 3 !important',
    '.va-appointment.is-running-now::after',
    '.va-calendar-viewport',
    'scroll-snap-type: x proximity',
    'position: sticky !important',
    ".va-appointment[data-content-tier='initials']",
    '.va-agenda-more',
    '.va-agenda-status.is-current',
    '.va-search-toggle',
    'minmax(280px, 320px)',
    'safe-area-inset-bottom',
    '@media (min-width: 761px)',
    'display: none !important'
  ];
  for (const term of requiredPrecisionCssTerms) {
    if (!source.precisionCss.includes(term)) failures.push(`Präzisions-CSS enthält nicht: ${term}`);
  }

  const forbiddenPrecisionTerms = [
    '.va-appointment.is-before',
    '.va-appointment.is-current',
    '.va-appointment.is-next',
    'is-sequence-before',
    'is-sequence-current',
    'is-sequence-next'
  ];
  for (const term of forbiddenPrecisionTerms) {
    if (source.precisionCss.includes(term) || source.precision.includes(term)) {
      failures.push(`Unzulässige zeitliche Kartenklassifikation verbleibt: ${term}`);
    }
  }

  for (const term of [
    './precision-01.css',
    './precision-02.css',
    './precision-controller-01.js',
    './precision-controller-06.js',
    './header-agenda.css',
    './header-agenda.js'
  ]) {
    if (!source.html.includes(term)) failures.push(`Experiment lädt nicht: ${term}`);
  }

  for (const term of [
    'Status: **Akzeptiert',
    'Ebenenordnung der aktuellen Zeit',
    'Ein gemeinsamer Kalender-Viewport',
    'Initiale Positionierung auf kompakter Fläche',
    'Horizontale Mitarbeitendenbewegung auf 390 Pixel',
    'Semantische Kartenverdichtung',
    'Explizite Agenda-Verdichtung',
    '132 Pixel',
    '36 Prozent',
    'archive/vertical-agenda-before-precision-2026-08-24'
  ]) {
    if (!source.adr6.includes(term)) failures.push(`ADR-006 enthält nicht: ${term}`);
  }

  for (const term of [
    'Mia Frei` → `Mia F.` → `Mia` → `MF',
    '3 weitere laufen',
    '?referenceNow=11:22&agenda=open',
    '1512 × 982',
    'keine produktive Persistenz'
  ]) {
    if (!source.readme.includes(term)) failures.push(`README dokumentiert nicht: ${term}`);
  }

  if (!source.adr4.includes('Status: **Akzeptiert')) failures.push('ADR-004 ist nicht akzeptiert.');
  if (!source.adr5.includes('Status: **Akzeptiert')) failures.push('ADR-005 ist nicht akzeptiert.');
}

if (failures.length) {
  console.error('Präzisionsprüfung der vertikalen Tagesfläche fehlgeschlagen:');
  failures.forEach((failure) => console.error(`- ${failure}`));
  process.exit(1);
}

console.log('Vertikale Tagesfläche, Kopfzeilenagenda und Präzisionsregeln sind statisch konsistent.');
