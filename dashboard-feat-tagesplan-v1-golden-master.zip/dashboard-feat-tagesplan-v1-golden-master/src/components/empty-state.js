import { createElement } from '../lib/dom.js';
import { createButton } from './button.js';

export function createEmptyState(options = {}) {
  const {
    eyebrow = '',
    title,
    description = '',
    action = null,
    compact = false,
    className = ''
  } = options;

  if (!title) throw new TypeError('empty state title is required');

  const actionElement = action?.nodeType
    ? action
    : action
      ? createButton({
          label: action.label,
          icon: action.icon,
          variant: action.variant ?? 'primary',
          compact: action.compact ?? compact,
          onClick: action.onClick,
          attributes: action.attributes
        })
      : null;

  return createElement('section', {
    className: [
      'gw-empty-state',
      compact ? 'gw-empty-state--compact' : '',
      className
    ].filter(Boolean).join(' '),
    children: [
      createElement('div', {
        className: 'gw-empty-state__copy',
        children: [
          eyebrow ? createElement('p', { className: 'gw-eyebrow', text: eyebrow }) : null,
          createElement('h2', { text: title }),
          description ? createElement('p', { text: description }) : null,
          actionElement ? createElement('div', { className: 'gw-empty-state__actions', children: actionElement }) : null
        ]
      })
    ]
  });
}
