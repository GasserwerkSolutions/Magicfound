# Tagesplan v1 · Gate Kalenderfläche und Zeitwahrheit R1

Stand: 26. August 2026

Status: **Flächen-Freigabekandidat – ausdrückliche Owner-Freigabe ausstehend**

Dieser Bericht belegt ausschließlich die Kalenderfläche und ihre Zeitwahrheit. Er erteilt keine Freigabe für das Terminkartensystem, die separate Produktseite `Termine`, alpine beziehungsweise atmosphärische Beseelung, Backend-Verknüpfung, Merge, Tag oder Deployment.

## Verbindlicher Prüfumfang

- genau eine globale Vergangenheitsschicht von `08:00` bis zur aktuellen Salonzeit;
- flache Tönung ohne Verlauf und ohne Blend-Modus;
- Zeitachse und alle fünf Mitarbeitendenspalten als eine gemeinsame Fläche;
- Jetzt-Linie oberhalb des Rasters und unterhalb von Terminen, Aufgaben und Pausen;
- unveränderte Statusfarben der Terminkarten;
- `Europe/Zurich` als gemeinsame Quelle für Analoguhr, digitale Zeit, Agenda, Vergangenheitsschicht und Jetzt-Linie;
- Synchronisation am Minutenwechsel und bei Wiederaufnahme des Tabs;
- Fokus- und Agenda-Invarianz auf Desktop und Mobil;
- projektweiter Scroll-Okklusionsvertrag: feststehende Achsen und Köpfe besitzen eine deckende, isolierte Farbebene; bewegter Text darf nie hineinmalen;
- vollständige Erreichbarkeit des Tagesendes und aller Termine bei 100, 110 und 125 Prozent Browserzoom;
- deterministischer Hauptzustand `referenceDate=2026-08-26&referenceNow=11:22`.

## Ebenenfolge

```text
Kalenderraster
globale Vergangenheitsschicht  z-index 2
Jetzt-Linie                    z-index 3
Termine, Aufgaben, Pausen      z-index 4+
Auswahl und Fokus              z-index 9+
```

Die aktuelle Owner-Anweisung und ADR-009 sind für diese Reihenfolge führend. Eine ältere, abweichende Formulierung in ADR-004 erteilt keine Freigabe für eine Linie über Karten.

## Maschinenlesbarer Hauptnachweis

Am Element `#dashboard-root` liegen bei `11:22` exakt folgende Werte vor:

```html
data-tp-time-source="Europe/Zurich"
data-tp-now-minute="682"
data-tp-past-progress="0.336667"
data-tp-past-layer-count="1"
data-tp-now-line-count="1"
data-tp-now-line-behind-cards="1"
data-tp-card-time-tone-count="0"
data-tp-time-sync-state="stable"
```

`0.336667` folgt aus `(682 − 480) / (1080 − 480) = 202 / 600`.

## Deterministische Zustände

| Zustand | Vergangenheitsschicht | Jetzt-Linie | Linie hinter Karten | Fortschritt | Bedeutung |
| --- | ---: | ---: | ---: | ---: | --- |
| `04:37`, heutiger Tag | 0 | 0 | 0 | `0.000000` | Vor Öffnung keine künstliche Zeitfläche |
| `11:22`, heutiger Tag | 1 | 1 | 1 | `0.336667` | Laufender Salontag |
| `18:31`, heutiger Tag | 1 | 0 | 0 | `1.000000` | Tag vollständig vergangen, keine Jetzt-Linie ausserhalb der Öffnungszeit |
| vergangener Tag | 0 | 0 | 0 | `0.000000` | Keine Live-Zeitbehauptung auf einem anderen Datum |
| zukünftiger Tag | 0 | 0 | 0 | `0.000000` | Keine Live-Zeitbehauptung auf einem anderen Datum |

Die mobile Prüfung bewegt die Mitarbeitendenfläche tatsächlich horizontal. Die einzige Vergangenheitsschicht und Jetzt-Linie bleiben dabei auch auf der sticky Zeitachse sichtbar; Karten werden vor der Achse geometrisch abgeschnitten und überlagern deren Beschriftung nicht. Der feste Kopf `Zeit` wird an sechs Scrollpositionen einschließlich Zwischenständen geprüft: Selbst wenn Mitarbeitendennamen geometrisch darunterliegen, bleibt seine eigene Farbebene vollständig deckend.

## Reproduzierbare Befehle und vollständige Ergebnisse

Voraussetzungen: Node.js 22 und ein sauberer Checkout. Ausgehend vom Repository-Root zuerst:

```text
npm ci
npx --no-install playwright install chromium
```

PowerShell:

```text
$env:SOURCE_DATE_EPOCH = (git show -s --format=%ct HEAD)
npm run build:tagesplan-v1
npm run verify:tagesplan-v1:time-surface
npm run verify:tagesplan-v1:zoom-reachability
```

Bash beziehungsweise GitHub Actions:

```text
export SOURCE_DATE_EPOCH="$(git show -s --format=%ct HEAD)"
npm run build:tagesplan-v1
npm run verify:tagesplan-v1:time-surface
npm run verify:tagesplan-v1:zoom-reachability
```

- [Ungekürzte Ausgabe 29/29](./evidence/time-surface-r1/verify-time-surface-29.txt)
- [Ungekürzte Ausgabe 48/48](./evidence/time-surface-r1/verify-zoom-reachability-48.txt)
- [Maschinenlesbare Zustands- und Geometriematrix](./evidence/time-surface-r1/matrix.json)
- [Maschinenlesbare Zoom- und Erreichbarkeitsmatrix](./evidence/time-surface-r1/zoom-reachability.json)

Die tatsächlichen GitHub-Actions-Lauf-IDs werden nach Eröffnung des Draft-PR als PR-Kommentar am unveränderten Head-SHA festgehalten. Vor dem Lauf werden keine IDs erfunden oder vorweggenommen.

Die 29er-Suite weist zusätzlich den Erhalt einer fokussierten, noch nicht gespeicherten Formulareingabe sowie eines geöffneten Agenda-Popovers mit Tastaturfokus über Minutenwechsel, Tab-Wiederaufnahme und BFCache-Rückkehr nach. Nach der BFCache-Rückkehr erzwingt sie auf `390 × 844` einen weiteren Vollrender und beweist erneut Viewport, Jetzt-Beschriftung, Layoutzustand, Scroll-Owner und Scroll-Okklusion. Beim fachlichen Agenda-Wechsel `11:59 → 12:00` fällt der Fokus einer verschwindenden Zeile deterministisch auf den Schliessen-Knopf statt auf den Dokumentkörper. Die 48er-Suite bewegt und fokussiert jeden Termin, jede Aufgabe und jede Pause einzeln und prüft alle vier Sichtkanten gegen Kalenderkopf, Zeitachse und Viewport.

## Visuelle Evidence

Hauptgrössen bei `referenceNow=11:22`:

- [1512 × 982](./evidence/time-surface-r1/reference-now-1122-1512x982.png)
- [1366 × 768](./evidence/time-surface-r1/reference-now-1122-1366x768.png)
- [390 × 844](./evidence/time-surface-r1/reference-now-1122-390x844.png)
- [844 × 390](./evidence/time-surface-r1/reference-now-1122-844x390.png)
- [390 × 844 nach horizontaler Mitarbeitendenbewegung](./evidence/time-surface-r1/reference-now-1122-mobile-horizontal-390x844.png)
- [Personenfokus](./evidence/time-surface-r1/reference-now-1122-focus-1512x982.png)
- [Agenda geöffnet](./evidence/time-surface-r1/reference-now-1122-agenda-1512x982.png)

Zeit- und Datumszustände:

- [04:37 vor Öffnung](./evidence/time-surface-r1/state-pre-opening-0437-1512x982.png)
- [11:22 im Betrieb](./evidence/time-surface-r1/state-live-1122-1512x982.png)
- [18:31 nach Schliessung](./evidence/time-surface-r1/state-after-close-1831-1512x982.png)
- [vergangener Tag](./evidence/time-surface-r1/state-past-date-1122-1512x982.png)
- [zukünftiger Tag](./evidence/time-surface-r1/state-future-date-1122-1512x982.png)

## Zusagenmatrix

| Versprechen | Geltungsbereich | Wahrheitsquelle | Durchsetzung | Negativbeweis | Sichtbarkeit | Reparatur | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| R1: Terminkarten behalten Objekt- und Statuswahrheit | Kalenderfläche | bestehende Termin- und Statusdaten | Zeitfortschritt liegt ausschließlich auf der Fläche | Kartenstile bei `04:37` und `11:22` bytegleich ausgewertet; `data-tp-card-time-tone-count="0"` | 29/29-Rohlog und Matrix | Zeitprovider oder Flächenprojektion korrigieren, niemals Kartenstatus aus Uhrzeit ableiten | bewiesen |
| R4: Uhrzeit erzeugt keinen Terminstatus | Kalenderfläche und Agenda | `Europe/Zurich`-Provider plus bestehender fachlicher Status | keine `is-running-now`-Kartenklasse, keine zeitliche Statusfarbe | DOM- und CSS-Prüfung; Karten liegen nur räumlich über der Linie | 29/29 und 48/48 | fehlerhafte zeitliche Kartenmutation entfernen | bewiesen |
| R6: Zeitbild nennt Quelle und Sync-Zustand | gesamte Tagesplanreferenz | ein gemeinsamer Provider | `data-tp-time-source`, Minute, Fortschritt und Sync-Zustand | Minutenkante und Tab-Wiederaufnahme simuliert | maschinenlesbare Attribute und Rohlog | Provider neu synchronisieren; Zustand bleibt bis dahin `pending` statt plausible Gewissheit zu zeigen | bewiesen |
| R7: Sitzung und Rollenprojektion | Backend- und Produktionsintegration | spätere serverseitige Sitzung | in diesem statischen Referenzschnitt keine neue Datenladung oder Schreiboperation | keine Backend-Verknüpfung und keine Persistenz hinzugefügt | im Gate-Bericht ausdrücklich abgegrenzt | vor Produktionsintegration gegen Backend-Mapping beweisen | nicht anwendbar |
| E1/E2 | Slot-Gleichstand und Geldwahrheit | Regelkern | außerhalb dieses Flächenschnitts | keine entsprechende Logik geändert | nicht sichtbar | im zuständigen Produktschnitt prüfen | nicht anwendbar |

## Bewusst nicht begonnen

- vollständiges Terminkartensystem;
- separate Produktseite `Termine`;
- alpine oder atmosphärische Beseelung;
- Backend-Verknüpfung oder Produktionsintegration;
- Merge, Tag, Pages-Veröffentlichung oder Deployment.

Der nächste Produktschritt beginnt erst nach der ausdrücklichen Freigabe der Kalenderfläche im führenden Chat.
