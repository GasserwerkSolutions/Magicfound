import { existsSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const root = process.cwd();
const outputDirectory = resolve(root, 'artifacts/tagesplan-vertical-agenda');
const port = 4176;
const baseUrl = `http://127.0.0.1:${port}/experiments/tagesplan-vertical-agenda/`;
const closedUrl = `${baseUrl}?referenceNow=11:22`;
const openUrl = `${baseUrl}?referenceNow=11:22&verify=1`;
const focusUrl = `${baseUrl}?referenceNow=11:22&focus=melanie&verify=1`;
const focusClosedUrl = `${baseUrl}?referenceNow=11:22&focus=melanie`;
const errors = [];

function findChrome() {
  const candidates = [
    process.env.CHROME_BIN,
    'google-chrome',
    'google-chrome-stable',
    'chromium',
    'chromium-browser'
  ].filter(Boolean);
  for (const candidate of candidates) {
    const probe = spawnSync('bash', ['-lc', `command -v ${candidate}`], { encoding: 'utf8' });
    if (probe.status === 0 && probe.stdout.trim()) return probe.stdout.trim();
  }
  return null;
}

function chromeRun(chrome, args, virtualTimeBudget = 4600) {
  return spawnSync(chrome, [
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--disable-dev-shm-usage',
    '--hide-scrollbars',
    '--run-all-compositor-stages-before-draw',
    `--virtual-time-budget=${virtualTimeBudget}`,
    ...args
  ], {
    cwd: root,
    encoding: 'utf8',
    maxBuffer: 30 * 1024 * 1024
  });
}

async function waitForServer() {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(openUrl);
      if (response.ok) return;
    } catch {
      // Server is still starting.
    }
    await delay(125);
  }
  throw new Error(`Lokaler Referenzserver antwortet nicht auf ${openUrl}`);
}

function requireDom(dom, term, label) {
  if (!dom.includes(term)) errors.push(`Gerenderter DOM enthält nicht: ${label}`);
}

function forbidDom(dom, term, label) {
  if (dom.includes(term)) errors.push(`Gerenderter DOM enthält verworfenen Inhalt: ${label}`);
}

function datasetNumber(dom, name) {
  const match = dom.match(new RegExp(`data-${name}="(-?\\d+(?:\\.\\d+)?)"`));
  return match ? Number(match[1]) : null;
}

rmSync(outputDirectory, { recursive: true, force: true });
mkdirSync(outputDirectory, { recursive: true });

const server = spawn('python3', ['-m', 'http.server', String(port), '--bind', '127.0.0.1'], {
  cwd: root,
  stdio: ['ignore', 'pipe', 'pipe']
});

try {
  await waitForServer();
  const chrome = findChrome();
  if (!chrome) throw new Error('Kein Chrome-/Chromium-Binary für Browserprüfung gefunden');

  const openDomResult = chromeRun(chrome, ['--window-size=1512,982', '--dump-dom', openUrl]);
  if (openDomResult.status !== 0) {
    errors.push(`Chrome DOM-Prüfung der geöffneten Agenda fehlgeschlagen:\n${openDomResult.stderr.trim()}`);
  } else {
    const dom = openDomResult.stdout;
    writeFileSync(resolve(outputDirectory, 'rendered-dom-open.html'), dom);
    requireDom(dom, 'va-calendar-panel', 'vertikale Kalenderfläche');
    requireDom(dom, 'va-past-shade', 'globale vergangene Zeitfläche');
    requireDom(dom, 'va-now-line', 'horizontale Jetzt-Linie');
    requireDom(dom, '>09:00<', 'Hauptanker 09:00');
    requireDom(dom, '>12:00<', 'Hauptanker 12:00');
    requireDom(dom, '>15:00<', 'Hauptanker 15:00');
    requireDom(dom, '>18:00<', 'Hauptanker 18:00');
    requireDom(dom, 'data-visible-staff-count="5"', 'fünf sichtbare Mitarbeitende');
    requireDom(dom, 'data-document-overflow-x="0"', 'kein horizontaler Gesamtseitenüberlauf');
    requireDom(dom, 'data-visible-staff-tracks="5"', 'fünf gerenderte Mitarbeitendenspuren');
    requireDom(dom, 'data-visible-agenda-panels="1"', 'genau ein sichtbares Agenda-Popover');
    requireDom(dom, 'data-permanent-agenda-container-count="0"', 'keine permanente Agenda-Fläche');
    requireDom(dom, 'data-legacy-header-context-count="0"', 'alter Kopfzeilenkontext vollständig ersetzt');
    requireDom(dom, 'data-header-agenda-toggle', 'Kopfzeilenauslöser Als Nächstes');
    requireDom(dom, 'data-header-agenda-popover', 'aufklappbares Agenda-Popover');
    requireDom(dom, 'va-agenda-section is-before', 'Dreiton-Gruppe Davor');
    requireDom(dom, 'va-agenda-section is-current', 'Dreiton-Gruppe Jetzt');
    requireDom(dom, 'va-agenda-section is-next', 'Dreiton-Gruppe Danach');
    requireDom(dom, '11:30–12:30', 'erste reale freie Lücke statt fälschlich freiem Resttag');
    forbidDom(dom, 'Zürich Enge · 08:00–18:00', 'redundanter Standort- und Öffnungszeittext im Kopf');

    const pastShadeCount = datasetNumber(dom, 'past-shade-count');
    const visibleCardTimes = datasetNumber(dom, 'visible-card-time-count');
    const prohibitedSequence = datasetNumber(dom, 'prohibited-sequence-class-count');
    if (pastShadeCount !== 1) errors.push(`Erwartet genau eine vergangene Zeitfläche, gefunden ${pastShadeCount}`);
    if (!(visibleCardTimes >= 8)) errors.push(`Zu wenige sichtbare Start-/Endzeiten: ${visibleCardTimes}`);
    if (prohibitedSequence !== 0) errors.push(`Veraltete Dreiton-Klassen im Kalender-DOM: ${prohibitedSequence}`);

    if (!/<strong[^>]*data-clock-digital[^>]*>11:22<\/strong>/.test(dom)) {
      errors.push('Analoge Arbeitsuhr und Tagesplanzeit sind nicht auf 11:22 synchronisiert.');
    }
  }

  const closedDomResult = chromeRun(chrome, ['--window-size=1512,982', '--dump-dom', closedUrl]);
  if (closedDomResult.status !== 0) {
    errors.push(`Chrome DOM-Prüfung der geschlossenen Agenda fehlgeschlagen:\n${closedDomResult.stderr.trim()}`);
  } else {
    const dom = closedDomResult.stdout;
    writeFileSync(resolve(outputDirectory, 'rendered-dom-closed.html'), dom);
    requireDom(dom, 'data-header-agenda-toggle', 'geschlossener Kopfzeilenauslöser');
    requireDom(dom, 'aria-expanded="false"', 'geschlossener Agenda-Zustand');
    requireDom(dom, 'data-visible-agenda-panels="0"', 'keine sichtbare Agenda im Standardzustand');
    forbidDom(dom, 'data-header-agenda-popover', 'sichtbares oder vorbereitetes Popover im Standardzustand');
    forbidDom(dom, 'Zürich Enge · 08:00–18:00', 'alter Kopfzeilenkontext im Standardzustand');
  }

  const focusResult = chromeRun(chrome, ['--window-size=1512,982', '--dump-dom', focusUrl]);
  if (focusResult.status !== 0) {
    errors.push(`Fokus-DOM-Prüfung fehlgeschlagen:\n${focusResult.stderr.trim()}`);
  } else {
    const dom = focusResult.stdout;
    writeFileSync(resolve(outputDirectory, 'rendered-dom-focus.html'), dom);
    requireDom(dom, 'data-visible-staff-count="5"', 'Fokus behält fünf Mitarbeitende');
    requireDom(dom, 'aria-pressed="true"', 'fokussierter Personenkopf');
    requireDom(dom, 'data-visible-agenda-panels="1"', 'Agenda bleibt im Fokus aufklappbar');
    const contextualTracks = datasetNumber(dom, 'focus-context-count');
    if (contextualTracks !== 4) errors.push(`Fokus soll vier Kontextspalten dimmen, gefunden ${contextualTracks}`);
  }

  const mobileResult = chromeRun(chrome, ['--window-size=390,844', '--dump-dom', openUrl]);
  if (mobileResult.status !== 0) {
    errors.push(`Mobile Agenda-DOM-Prüfung fehlgeschlagen:\n${mobileResult.stderr.trim()}`);
  } else {
    const dom = mobileResult.stdout;
    writeFileSync(resolve(outputDirectory, 'rendered-dom-mobile-open.html'), dom);
    requireDom(dom, 'va-agenda-trigger-mobile', 'kompakter mobiler Agenda-Auslöser');
    requireDom(dom, 'data-visible-agenda-panels="1"', 'mobiles Agenda-Popover');
    requireDom(dom, 'data-document-overflow-x="0"', 'kein mobiler horizontaler Gesamtseitenüberlauf');
  }

  const viewports = [
    ['1366x768', 1366, 768],
    ['1440x900', 1440, 900],
    ['1512x982', 1512, 982],
    ['1920x1080', 1920, 1080],
    ['390x844', 390, 844],
    ['844x390', 844, 390]
  ];

  for (const [name, width, height] of viewports) {
    const target = resolve(outputDirectory, `tagesplan-vertical-agenda-${name}.png`);
    const result = chromeRun(chrome, [`--window-size=${width},${height}`, `--screenshot=${target}`, closedUrl]);
    if (result.status !== 0 || !existsSync(target)) {
      errors.push(`Screenshot ${name} konnte nicht erzeugt werden:\n${result.stderr.trim()}`);
    } else {
      console.log(`✓ Screenshot ${name}`);
    }
  }

  const openTarget = resolve(outputDirectory, 'tagesplan-vertical-agenda-1512x982-open.png');
  const openScreenshot = chromeRun(chrome, ['--window-size=1512,982', `--screenshot=${openTarget}`, openUrl]);
  if (openScreenshot.status !== 0 || !existsSync(openTarget)) errors.push('Geöffnete Kopfzeilenagenda konnte nicht erzeugt werden.');

  const focusTarget = resolve(outputDirectory, 'tagesplan-vertical-agenda-1512x982-focus.png');
  const focusScreenshot = chromeRun(chrome, ['--window-size=1512,982', `--screenshot=${focusTarget}`, focusClosedUrl]);
  if (focusScreenshot.status !== 0 || !existsSync(focusTarget)) errors.push('Fokusvergleich konnte nicht erzeugt werden.');
} catch (error) {
  errors.push(error.message);
} finally {
  server.kill('SIGTERM');
}

if (errors.length) {
  console.error(`\nBrowserprüfung fehlgeschlagen (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`\n✓ Vertikale Tagesfläche mit globaler Zeitlage und aufklappbarer Kopfzeilenagenda gerendert: ${openUrl}`);
