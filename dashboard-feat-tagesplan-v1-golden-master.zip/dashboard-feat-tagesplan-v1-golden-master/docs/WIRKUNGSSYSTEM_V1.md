# Gasserwerk · Wirkungssystem V1

Status: **Entwurf – erste systemische Fassung**  
Leitsatz: **Einfachheit mit Seele und Wirkung.**  
Geltungsbereich: alle Referenzseiten unter `pages/`, gemeinsame Produktschale unter `src/` sowie Lade-, Leer-, Erfolgs-, Fehler- und Kontextzustände.

## 1. Zweck

Dieses Dokument übersetzt qualitative Gestaltungsbegriffe in überprüfbare Regeln für die Produktoberfläche.

Es verhindert zwei gegensätzliche Fehler:

1. eine formal saubere, aber sterile Oberfläche ohne menschliche Bedeutung;
2. eine emotional aufgeladene Oberfläche, deren Wirkung auf Dekoration, Trend oder Zufall beruht.

Das Wirkungssystem ergänzt die funktionalen Verträge aus [`PRODUCT_SURFACE_V1.md`](./PRODUCT_SURFACE_V1.md), [`contracts/README.md`](./contracts/README.md) und den Seitenverträgen unter `pages/*/CONTRACT.md`. Es darf deren fachliche Semantik, Zustände, Capabilities, Datenwahrheit oder Bedienbarkeit nicht verändern.

Bis zur fachlichen Freigabe ist dieses Dokument eine Ausarbeitungsgrundlage. Nach Freigabe werden die Seitenprofile in die jeweilige Referenzimplementierung und ihre Abnahme übernommen.

## 2. Leitidee

### 2.1 Einfachheit

Einfachheit bedeutet nicht Leere und nicht möglichst wenige sichtbare Elemente.

Einfachheit bedeutet:

- Die primäre Arbeitsaufgabe ist unmittelbar erkennbar.
- Jede Fläche besitzt einen klaren Aufmerksamkeitsanker.
- Eine Handlung erscheint genau dort, wo ihr fachlicher Gegenstand liegt.
- Gleiche Bedeutungen werden gleich dargestellt.
- Doppelte Steuerungen, künstliche Modusleisten und dekorative Nebenmodule entfallen.
- Komplexität wird geordnet, nicht versteckt.

**Einfachheit reduziert Entscheidungen, nicht Bedeutung.**

### 2.2 Seele

Seele ist die spürbare menschliche und produktspezifische Bedeutung einer Fläche.

Sie entsteht durch:

- erkennbare Menschen, Tätigkeiten, Zeit und Beziehungen;
- warme, gepflegte Materialität;
- präzise Sprache aus dem Schweizer Salonalltag;
- kleine charaktervolle Details mit fachlichem oder emotionalem Grund;
- eine dosierte alpine Welt, die innerhalb der Produktoberfläche lebt;
- Zustände, die sich nicht nur korrekt, sondern angemessen anfühlen.

Seele ist kein aufgesetzter Schmuck. Ein Element ohne Aufgabe, Bedeutung oder klaren emotionalen Grund gehört nicht auf die Fläche.

### 2.3 Wirkung

Wirkung ist die Fähigkeit einer Fläche, Wahrnehmung und Handlung gezielt zu führen.

Sie entsteht durch:

- eindeutige Hierarchie;
- konzentrierten Kontrast;
- räumliche Kontinuität;
- sichtbare Gegenwart und Zustandsänderung;
- eine klare nächste Handlung;
- ruhige, aber bestimmte Rückmeldung.

Wirkung ist nicht Spektakel. Eine operative Arbeitsfläche darf eindrucksvoll sein, aber niemals überwältigend, nervös oder selbstbezogen.

## 3. Grundregel: Jeder Begriff braucht sichtbare Evidenz

Ein Wirkungsbegriff ist nur zulässig, wenn er auf der Fläche als Form, Verhalten oder Wahrnehmung nachweisbar ist.

Für jeden verwendeten Begriff müssen mindestens diese vier Fragen beantwortet werden:

1. **Was bedeutet der Begriff in diesem Produkt?**
2. **Welche sichtbare oder spürbare Konsequenz erzeugt er?**
3. **In welchen Zuständen gilt er?**
4. **Welche falsche Interpretation ist ausdrücklich ausgeschlossen?**

Ein Begriff darf nicht nur in einem Prompt, Reviewkommentar oder Konzepttext stehen. Er muss sich in mindestens zwei Übersetzungskanälen zeigen; ein primärer Seitenbegriff in mindestens drei.

## 4. Die vier Ebenen des Systems

### Ebene A · Handwerkliche Präzision

Diese Begriffe beschreiben nicht die Persönlichkeit einer Seite, sondern die Qualität ihrer Planung, Ausführung und Abnahme:

- minutiös
- akkurat
- haargenau
- penibel
- peinlich genau

Sie gelten für jede Seite und jeden Zustand.

### Ebene B · Produktkonstanten

Diese Eigenschaften tragen die gesamte Gasserwerk-Oberfläche:

- klar
- verlässlich
- gepflegt
- ruhig
- warm, aber nicht weichgespült
- eigenständig, aber nicht exzentrisch

Sie sorgen dafür, dass Seiten mit unterschiedlicher Aufgabe weiterhin wie ein zusammenhängendes Produkt wirken.

### Ebene C · Seitenspezifisches Wirkungsprofil

Jede dauerhafte Seite erhält höchstens:

- drei primäre Wirkungsbegriffe;
- zwei unterstützende Wirkungsbegriffe;
- drei ausdrücklich unerwünschte Wirkungen.

Die Begriffe werden aus der Arbeitsaufgabe abgeleitet, nicht aus persönlicher Tagesstimmung oder aktuellen UI-Trends.

### Ebene D · Zustandsmodifikatoren

Laden, Leere, Erfolg, Aufmerksamkeit, Fehler, fehlende Berechtigung und Offline-/Stale-Zustände verändern die emotionale Temperatur einer Seite. Der Zustandsmodifikator hat Vorrang vor dekorativer Seitenwirkung.

Beispiel: Eine beseelte Kundschaftsseite bleibt bei einem Datenschutzfehler ruhig, ehrlich und zurückhaltend. Sie verwendet in diesem Moment keine charmante Illustration.

## 5. Präzisionssystem

Die fünf Präzisionsbegriffe erhalten unterschiedliche Aufgaben. Sie sind keine beliebig austauschbaren Synonyme.

| Begriff | Aufgabe im Prozess | Sichtbare Konsequenz |
|---|---|---|
| **Minutiös** | Planung bis in den kleinsten relevanten Zustand | Jede Komponente besitzt definierte Normal-, Hover-, Fokus-, aktive, deaktivierte, Lade-, Fehler- und Responsive-Zustände. Mikroabstände, Baselines und Übergänge sind bewusst. |
| **Akkurat** | saubere, fehlerfreie Ausführung | Elemente sitzen korrekt, Linien schliessen, Texte brechen kontrolliert, Symbole sind optisch zentriert, keine Fläche wirkt zufällig. |
| **Haargenau** | Übereinstimmung von Darstellung und fachlicher Wahrheit | Zeit, Dauer, Reihenfolge, Status, Anzahl, Geometrie und Beschriftung entsprechen exakt dem View-Model. Die Oberfläche verschönert keine Datenabweichung. |
| **Penibel** | systematische Suche nach Inkonsistenzen | Wiederholte Objekte, Abstände, Zustände, Begriffe und Interaktionen werden seitenübergreifend verglichen; kleine Abweichungen werden nicht als harmlos durchgewinkt. |
| **Peinlich genau** | abschliessendes Regel- und Release-Gate | Kontrast, Fokus, Touch-Ziele, Zustandssemantik, Tokens, Verträge und Abnahmekriterien werden ohne stillschweigende Ausnahme eingehalten. |

Empfohlene Reihenfolge eines Qualitätsdurchgangs:

1. minutiös spezifizieren;
2. akkurat ausführen;
3. haargenau gegen Daten und Geometrie prüfen;
4. penibel mit dem System vergleichen;
5. peinlich genau freigeben.

## 6. Übersetzungskanäle

Jeder Wirkungsbegriff wird über dieselben Kanäle in Produktoberfläche übersetzt.

### 6.1 Informationshierarchie

- Was wird zuerst gesehen?
- Was ist primär, sekundär und nur bei Bedarf sichtbar?
- Welche Information erscheint erst durch Nähe, Fokus oder Entfaltung?

### 6.2 Raum und Rhythmus

- Dichte, Abstand und Gruppierung
- Verhältnis von Ruheflächen und Informationsflächen
- Wiederholung, Takt und Unterbrechung
- stabile räumliche Anker

### 6.3 Typografie und Sprache

- Gewicht, Grösse, Zeilenlänge und Kontrast
- Schweizer Begriffe und fachlich richtige Benennungen
- Tonalität von Führung, Bestätigung, Warnung und Fehler
- Vermeidung technischer oder generischer SaaS-Sprache

### 6.4 Farbe und Materialität

- warme helle Arbeitsfläche und dunkler grüner Rahmen
- Farbe bleibt semantisch; Statusfarbe wird nicht zur Stimmungskulisse
- Tiefe, Kante, Schatten und Oberflächenwechsel werden sparsam und gezielt verwendet
- Materialität darf die Lesbarkeit und Dichte nicht beeinträchtigen

### 6.5 Bewegung und räumliche Kontinuität

- Zustandswechsel entstehen aus ihrem Auslöser
- Bewegung erklärt, wohin sich die Fläche verändert
- keine Bewegung ohne Zustandsinformation
- reduzierte Bewegung bleibt vollständig verständlich

### 6.6 Mikrointeraktion und Rückmeldung

- Fokus, Auswahl, Erfolg, Konflikt und laufender Zustand
- direkte Rückmeldung am Gegenstand
- keine globale Erfolgs- oder Fehlershow für lokale Handlungen

### 6.7 Illustration und lebendige Welt

- Illustration besitzt eine konkrete Rolle: Orientierung, Ruhe, Erwartung, Abschluss oder Entdeckung
- die Welt lebt in der Produktfläche, nicht als austauschbarer Hintergrund ausserhalb der Software
- Funktion wird zuerst erkannt; die lebendige Welt wird danach entdeckt

## 7. Kanonisches Wirkungsvokabular

Die folgenden Begriffe bilden den ersten kontrollierten Wortschatz. Neue Begriffe dürfen ergänzt werden, müssen aber nach demselben Muster definiert werden.

| Begriff | Bedeutung im Produkt | Erwartete Evidenz | Nicht gemeint |
|---|---|---|---|
| **atmend** | hohe Dichte besitzt rhythmische Ruhe und klare Zwischenräume | wechselnde Dichte statt pauschal grosser Abstände; Gruppen können visuell ein- und ausatmen | leer, weitläufig oder informationsarm |
| **gegenwärtig** | die Fläche macht den aktuellen fachlichen Moment spürbar | Jetzt-Linie, Salonzeit, laufende Zustände, zeitlich richtige Gruppierung, aktuelle nächste Handlung | blinkend, permanent animiert oder alarmierend |
| **im Fluss** | Arbeit und Zustände bilden eine nachvollziehbare Kontinuität | räumlich zusammenhängende Übergänge, erhaltener Kontext, keine unnötigen Seiten- oder Modussprünge | fliessende Dekoration oder dauernde Bewegung |
| **aufmerksam** | das Produkt erkennt, was als Nächstes relevant ist | kontextuelle nächste Handlung, proportionale Hinweise, klare Abweichungen, keine unnötige Meldung | bevormundend, proaktiv um jeden Preis oder aufdringlich |
| **beseelt** | die Oberfläche trägt menschliche und produktspezifische Bedeutung | echte Namen, Tätigkeiten, warme Details, dosierte alpine Welt, charaktervolle leere Zustände | niedlich um der Niedlichkeit willen |
| **warm** | die Fläche fühlt sich menschlich und willkommen an | warme neutrale Flächen, freundliche Sprache, weiche optische Übergänge, respektvolle Rückmeldung | kontrastarm, verschwommen oder sentimental |
| **zugewandt** | der Mensch und sein Anliegen stehen vor der Systemstruktur | personenzentrierte Benennung, hilfreiche Reihenfolge, verständliche Konsequenzen | geschwätzig, vertraulich ohne Grundlage oder übergriffig |
| **geführt** | ein nächster sinnvoller Schritt ist klar, ohne Freiheit zu entziehen | eine primäre Aktion, sichtbarer Fortschritt, lokale Erklärung von Blockern und Folgen | Wizard-Zwang, versteckte Rückwege oder Belehrung |
| **selbstverständlich** | Bedienung folgt der sichtbaren Sache und braucht wenig Erklärung | freie Zeit ist buchbar, Person ist fokussierbar, Karte trägt ihre Aktion, Rückkehr führt exakt zurück | unsichtbare Funktionen oder fehlende Beschriftung |
| **verlässlich** | Zustand, Position und Reaktion bleiben berechenbar | stabile Geometrie, konservative Rückmeldung, Fokuswiederherstellung, keine erfundene Erfolgsmeldung | starr oder langsam |
| **souverän** | die Fläche bleibt auch bei Komplexität ruhig und bestimmt | klare Hierarchie, wenige starke Entscheidungen, proportionale Warnungen, keine Rechtfertigungsrhetorik | kühl, autoritär oder distanziert |
| **gepflegt** | sichtbare handwerkliche Sorgfalt ohne Luxusinszenierung | präzise Typografie, saubere Kanten, kontrollierte Schatten, konsistente Details | glänzend, opulent oder dekorativ überarbeitet |
| **prägnant** | Bedeutung wird schnell und mit wenig visueller Last erfasst | klare Überschriften, kurze Statuslabels, konzentrierter Kontrast | laut, gross oder aggressiv |
| **still** | ein Zustand darf ruhig vorhanden sein, ohne leer oder tot zu wirken | zurückhaltende Fläche, wenige Signale, klare Möglichkeit zum Handeln | funktionslos oder passiv |
| **erwartungsvoll** | freie oder noch unvollständige Fläche trägt eine nächste Möglichkeit | offene, handlungsfähige Leere; leise Richtung; optional dosierte lebendige Welt | künstlicher Optimismus oder dekorative Platzhalter |

## 8. Intensität und Kombination

Wirkungsbegriffe werden pro Seite in vier Stufen geführt:

- `0` – nicht Teil des Profils
- `1` – leise Hintergrundwirkung
- `2` – tragende Wirkung
- `3` – dominante Wirkung

Regeln:

- Pro Seite darf höchstens ein Begriff die Intensität `3` erhalten.
- Höchstens fünf Begriffe dürfen gleichzeitig die Intensität `2` oder `3` tragen.
- Ein primärer Begriff muss in mindestens drei Übersetzungskanälen nachweisbar sein.
- Ein unterstützender Begriff muss in mindestens zwei Übersetzungskanälen nachweisbar sein.
- Unerwünschte Wirkungen werden ausdrücklich festgehalten und im Review aktiv gesucht.
- Begriffe wie `überwältigend`, `umwerfend`, `atemberaubend` oder `traumhaft` sind keine dauerhaften Arbeitsflächenprofile. Sie können als explorative Verstärker oder für seltene emotionale Spitzen dienen, dürfen aber nicht die alltägliche Bedienung beherrschen.

## 9. Seitenprofile V1

### 9.1 Übersicht

| Seite | Primäre Begriffe | Unterstützende Begriffe | Dichte | Tempo | Illustration |
|---|---|---|---|---|---|
| Login | ruhig, vertrauensvoll, einladend | beseelt, geborgen | niedrig | sehr ruhig | ca. 30–40 %, Karte bleibt primär |
| Onboarding | geführt, verständlich, ermutigend | fortschreitend, verlässlich | mittel | schrittweise | normal 0–8 %, Abschluss bis ca. 10–15 % |
| Tagesplan | gegenwärtig, atmend, im Fluss | aufmerksam, beseelt | hoch | lebend, ruhig nachgeführt | regulär 0–5 %, leer 15–22 %, Tagesabschluss 20–25 % |
| Termine | auffindbar, geordnet, verlässlich | präzise, ruhig | mittel bis hoch | direkt | regulär 0 %, leer höchstens 5–10 % |
| Kundschaft | zugewandt, vertraut, diskret | warm, respektvoll | mittel | ruhig | regulär 0–5 %, nur kontextuell |
| Team | menschlich, wertschätzend, übersichtlich | gemeinsam, verlässlich | mittel | ruhig | regulär 0–5 %, nur kontextuell |
| Angebot | verständlich, gepflegt, handwerklich | wertig, einladend | mittel | ruhig | regulär 0–5 %, nur kontextuell |
| Verwaltung | souverän, eindeutig, belastbar | ruhig, konsequent | mittel | bewusst langsam | 0 % in Normal- und Problemzuständen |

### 9.2 Login

**Primäre Aufgabe:** sicherer, kontrollierter Eintritt.

- **Aufmerksamkeitsanker:** Anmeldekarte und primäre Methode.
- **Seelenträger:** dosierte alpine Welt im unteren oder seitlichen Bereich; Produktidentität; ruhige Materialität.
- **Räumliche Wirkung:** wenig konkurrierende Elemente, klare Mitte, vollständig sichtbare Karte.
- **Bewegung:** langsam, sparsam, atmosphärisch; nie zwischen Benutzer und Formular.
- **Nicht erlaubt:** spektakulär, verspielt, geheimnisvoll, landschaftlich dominant.
- **Abnahmesatz:** Zuerst sieht man die sichere Anmeldung, danach entdeckt man die Welt des Produkts.

### 9.3 Onboarding

**Primäre Aufgabe:** einen Salon nachvollziehbar zu einem minimal buchbaren Zustand führen.

- **Aufmerksamkeitsanker:** aktueller Schritt und seine Auswirkung auf die Buchbarkeit.
- **Seelenträger:** sichtbarer Fortschritt, freundliche Konsequenzsprache, kleine Momente des Ankommens.
- **Räumliche Wirkung:** ein Schritt ist Gegenwart; erledigte und kommende Schritte bleiben als Orientierung erhalten.
- **Bewegung:** die Fläche entwickelt sich schrittweise aus derselben Grundfläche, nicht als Folge fremder Formulare.
- **Nicht erlaubt:** belehrend, gamifiziert, hektisch, künstlich belohnend.
- **Abnahmesatz:** Der Benutzer weiss stets, wo er ist, warum der Schritt nötig ist und was danach möglich wird.

### 9.4 Tagesplan

**Primäre Aufgabe:** den laufenden Salonbetrieb in Zeit, Personen und nächster Handlung erfassbar machen.

- **Aufmerksamkeitsanker:** aktueller Zeitpunkt beziehungsweise bewusst betrachteter Zeitabschnitt.
- **Seelenträger:** reale Salonzeit, Analoguhr, Menschen und Tätigkeiten, ruhige Arbeitsfolge, alpine Habitat-Zone nur in passenden freien Zuständen.
- **Räumliche Wirkung:** hohe Dichte mit sauberem Rhythmus; Zeit und Personen bleiben die tragende Geometrie.
- **Bewegung:** Live-Zeit wird weich nachgeführt; jede bewusste Interaktion pausiert die Nachführung; Kontext bleibt erhalten.
- **Nicht erlaubt:** dekorativ, dashboardhaft, nervös, schwebend, modisch überformt.
- **Abnahmesatz:** Innerhalb weniger Sekunden ist erkennbar, wer arbeitet, was jetzt läuft und was als Nächstes relevant ist.

### 9.5 Termine

**Primäre Aufgabe:** einen Termin unabhängig von seiner räumlichen Position schnell finden und öffnen.

- **Aufmerksamkeitsanker:** Suche, aktive Filter und relevante Ergebniszeile.
- **Seelenträger:** Personen- und Dienstleistungsnamen, klare Statussprache, ruhiger Listenrhythmus.
- **Räumliche Wirkung:** geordnete Verdichtung; Filter dienen der Auffindbarkeit und werden nicht selbst zur Hauptfläche.
- **Bewegung:** Auswahl führt aus der Ergebniszeile in das gemeinsame Terminpanel und exakt zurück.
- **Nicht erlaubt:** zweite Zeitachse, Tabellenkälte, Filterteppich, dekorative Karteninflation.
- **Abnahmesatz:** Ein konkreter Termin lässt sich ohne Kenntnis seines Tagesplans zuverlässig auffinden.

### 9.6 Kundschaft

**Primäre Aufgabe:** eine Person finden, verstehen und aus ihrem Kontext sinnvoll weiterarbeiten.

- **Aufmerksamkeitsanker:** ausgewählte Person und ihr aktueller Salonbezug.
- **Seelenträger:** Name, Beziehungsgeschichte, zukünftige und vergangene Termine, respektvoll behandelte Notizen.
- **Räumliche Wirkung:** Liste und Kartei bilden zwei Seiten derselben Fläche; die Person bleibt räumlich verankert.
- **Bewegung:** Auswahl entfaltet die Kartei aus der Liste; Schliessen stellt Suche, Scrollposition und Fokus wieder her.
- **Nicht erlaubt:** verkäuferisch, neugierig, CRM-kalt, datenhungrig oder vertraulich ohne Grundlage.
- **Abnahmesatz:** Die Fläche vermittelt Nähe, ohne Privatsphäre oder fachliche Distanz zu verletzen.

### 9.7 Team

**Primäre Aufgabe:** Salonpersonen, fachliche Rollen und Verfügbarkeit verständlich machen.

- **Aufmerksamkeitsanker:** Person und fachliche Einordnung.
- **Seelenträger:** Namen, Rollen, Arbeitsrhythmus, gemeinsame handwerkliche Verantwortung.
- **Räumliche Wirkung:** Personen sind gleichwertige, klar unterscheidbare Einheiten; Aktivstatus bleibt sichtbar, aber nicht wertend.
- **Bewegung:** Detail und Bearbeitung entstehen aus der Person; keine räumlich fremde Verwaltungswelt.
- **Nicht erlaubt:** Rangliste, Leistungsbewertung, HR-Bürokratie, übertriebene Personalisierung.
- **Abnahmesatz:** Das Team wirkt als menschlicher Teil des Salonbetriebs, nicht als Ressourcenliste.

### 9.8 Angebot

**Primäre Aufgabe:** Dienstleistungen, Dauer, Preisstatus und Zuordnung verständlich überblicken.

- **Aufmerksamkeitsanker:** Dienstleistung und ihre fachlichen Buchungsparameter.
- **Seelenträger:** handwerkliche Benennung, gepflegte Typografie, nachvollziehbare Dauer und Zuordnung.
- **Räumliche Wirkung:** Kategorien ordnen, ohne einen Online-Shop zu imitieren.
- **Bewegung:** Detail oder Bearbeitung entfalten sich aus der Dienstleistung.
- **Nicht erlaubt:** werblich, shopartig, luxuriös überladen, rabattorientiert oder künstlich begehrlich.
- **Abnahmesatz:** Das Angebot wirkt fachlich wertig und verständlich, nicht wie ein Verkaufskatalog.

### 9.9 Verwaltung

**Primäre Aufgabe:** seltenere Salon-, Konto- und Systemeinstellungen sicher und gezielt zugänglich machen.

- **Aufmerksamkeitsanker:** gewählter Verwaltungsbereich und sein tatsächlicher Zustand.
- **Seelenträger:** Ruhe, klare Besitz- und Berechtigungsgrenzen, ehrliche Systemrückmeldung.
- **Räumliche Wirkung:** feste Bereiche statt unstrukturiertem Gesamtformular; Konsequenz vor Charme.
- **Bewegung:** ein Bereich wendet oder entfaltet die vorhandene Fläche; Routineänderungen führen nicht in verschachtelte Modalketten.
- **Nicht erlaubt:** bürokratisch, technisch laut, verspielt, operativ vermischt oder scheinbar mächtig.
- **Abnahmesatz:** Auch komplexe Einstellungen wirken beherrschbar, nachvollziehbar und sicher.

## 10. Zustandsprofile

Zustände werden seitenübergreifend konsistent behandelt.

| Zustand | Tragende Begriffe | Verbindliche Wirkung |
|---|---|---|
| **loading** | ruhig, strukturiert, verlässlich | Skeletons spiegeln reale Geometrie; keine erfundenen Inhalte; bestehender Kontext bleibt sichtbar. |
| **empty** | still, erwartungsvoll, einladend | Leere bleibt handlungsfähig; genau eine sinnvolle nächste Handlung; alpine Welt nur nach Dosierungsregel. |
| **success** | erleichternd, warm, abgeschlossen | klare Bestätigung am Gegenstand; kein Konfetti und keine überlange Feier; nächster Zustand ist verständlich. |
| **attention** | aufmerksam, prägnant, proportional | konkrete Auswirkung und konkrete Handlung; Aufmerksamkeit entspricht der realen Bedeutung. |
| **error** | ehrlich, ruhig, lösungsorientiert | Arbeitsauswirkung statt Technikdetail; Retry oder sicherer Rückweg; keine charmante Ablenkung. |
| **forbidden** | respektvoll, eindeutig, transparent | fehlende Capability wird als Grenze erklärt; keine Scheinbedienung und keine Schuldzuweisung. |
| **offline / stale** | verlässlich, ehrlich, vorsichtig | letzte Daten bleiben lesbar; Aktualität und Änderbarkeit werden getrennt dargestellt; Erfolg wird nie simuliert. |

## 11. Räumliche Interaktionsgrammatik

Die Oberfläche verhält sich wie ein zusammenhängender Gegenstand.

### 11.1 Die Fläche bleibt vorhanden

- Der Benutzer verlässt seine Arbeitsfläche bei Routinehandlungen nicht mental.
- Kontextpanel, Detail, Bearbeitung und Auswahl entstehen aus dem sichtbaren Gegenstand.
- Der Ursprung bleibt erkennbar.
- Schliessen stellt räumlichen Kontext, Scrollposition, Auswahl und Fokus wieder her.

### 11.2 Bearbeitung ist eine Wendung, kein fremder Ort

- Karten, Zeilen und Abschnitte können ihre Rückseite, Tiefe oder erweiterte Fläche zeigen.
- Es gibt keinen abstrakten Wechsel in einen losgelösten „Editor“, wenn dieselbe Sache auf der vorhandenen Fläche bearbeitet werden kann.
- Verschachtelte Modalketten sind nicht zulässig.

### 11.3 Bewegung ersetzt Modusbeschriftung

- Bewegung erklärt den Übergang von Übersicht zu Detail, von Ansicht zu Bearbeitung und wieder zurück.
- Ein Modus wird nicht durch zusätzliche permanente Leisten erklärt, wenn die räumliche Veränderung selbst eindeutig ist.
- Bestehende Motion-Tokens aus `src/styles/tokens.css` bleiben Grundlage: schnell für direkte Rückmeldung, normal für Flächenwechsel, live für Zeitnachführung.
- `prefers-reduced-motion` erhält dieselbe Zustandslogik ohne räumlichen Informationsverlust.

### 11.4 Eine dominante Kontextfläche

- Zu einem Zeitpunkt gibt es genau eine dominante Kontextfläche.
- Popover dürfen lokale Auswahl unterstützen, aber keine zweite Bearbeitungsebene eröffnen.
- `Escape` und Rückkehr folgen einer stabilen, dokumentierten Reihenfolge.

## 12. Die alpine Welt als Seelenschicht

Die alpine Produktwelt ist kein Hintergrundthema, sondern eine dosierte zweite Bedeutungsebene innerhalb der Software.

Verbindliche Regeln:

- Erst sieht man die Funktion; dann entdeckt man, dass in der Produktfläche eine stille Welt lebt.
- Illustrationen beleben freie oder emotionale Zustände, nicht den gesamten regulären Arbeitstag.
- Das Master-Murmeltier, alpine Flora, warme helle Flächen und dunkles Waldgrün bleiben gestalterische Konstanten.
- Landschaftsmenge, Detaildichte, Bergkontrast, Blütenzahl und gleichzeitig sichtbare Motive bleiben reduziert.
- Illustration darf Raster, Daten, Eingaben, Status oder primäre Aktion nie schwächen.
- Fehler, Berechtigungsgrenzen, Billingprobleme und sicherheitsrelevante Warnungen verwenden keine verniedlichende Illustration.

Dosierung:

- Login: etwa 30–40 % illustrative Präsenz, Anmeldekarte bleibt dominant.
- Leerer Tagesplan: Habitat-Zone im unteren Bereich, etwa 15–22 % der Kalenderhöhe.
- Buchung erfolgreich: etwa 10–15 %.
- Tagesabschluss: etwa 20–25 %.
- Regulärer Arbeitstag: 0–5 %, meist keine Illustration.

## 13. Technischer Zielvertrag

Die erste Implementierung dieses Systems soll später aus zwei zentralen Schichten bestehen:

```text
src/experience/profiles.js       maschinenlesbare Seiten- und Zustandsprofile
src/styles/experience.css        Übersetzung der Profilachsen in gemeinsame Tokens
```

Vorgeschlagene Profilform:

```js
{
  id: "tagesplan",
  purpose: "laufenden Salonbetrieb erfassen und führen",
  primaryTerms: [
    { id: "present", intensity: 3 },
    { id: "breathing", intensity: 2 },
    { id: "flowing", intensity: 2 }
  ],
  supportingTerms: [
    { id: "attentive", intensity: 2 },
    { id: "ensouled", intensity: 1 }
  ],
  antiTerms: ["decorative", "nervous", "dashboard-like"],
  density: "high",
  tempo: "live-calm",
  attentionAnchor: "current-time-or-user-viewport",
  illustration: {
    normal: "0-5%",
    empty: "15-22%",
    dayEnd: "20-25%"
  }
}
```

Die Seitenwurzel soll das Profil und den Zustand explizit ausweisen:

```html
<body
  data-gw-page="tagesplan"
  data-gw-state="normal"
  data-gw-density="compact"
>
```

Harte Grenzen:

- Statusfarben aus `tokens.css` bleiben fachlich autoritativ.
- Ein Wirkungsprofil darf Status, Auswahl, Suche, Fokus oder Warnung nicht semantisch umfärben.
- `page.css` bleibt für seitenbezogene Geometrie zuständig; Stimmung wird nicht durch beliebige lokale Hardcodes erzeugt.
- Wirkungsprofile dürfen Lesbarkeit, Kontrast, Touch-Ziele, Datenwahrheit, Performance oder reduzierte Bewegung nie verschlechtern.
- Keine Seite erzeugt eine eigene alternative Produktschale.

## 14. Review- und Abnahmeverfahren

Jede Seite durchläuft dieselbe Reihenfolge.

### 14.1 Aufgabentest

Eine fachkundige Person muss innerhalb weniger Sekunden erkennen können:

- wo sie ist;
- was die Seite beantwortet;
- welches Element aktuell wichtig ist;
- welche nächste Handlung möglich ist.

### 14.2 Einfachheitsdurchgang

- doppelte Steuerungen entfernen;
- Nebeninformationen dem richtigen Kontext zuordnen;
- eine primäre Handlung festlegen;
- unnötige Modus- und Erklärungselemente entfernen;
- sicherstellen, dass Komplexität geordnet und nicht versteckt wurde.

### 14.3 Präzisionsdurchgang

- minutiös spezifizieren;
- akkurat ausführen;
- haargenau mit Daten und Geometrie abgleichen;
- penibel seitenübergreifend vergleichen;
- peinlich genau gegen Verträge, Accessibility und Viewports prüfen.

### 14.4 Seelendurchgang

Für jede Seite werden genau diese Fragen beantwortet:

- Was ist der menschliche Kern der Seite?
- Welches eine Element trägt ihre Seele im Normalzustand?
- Wie fühlt sich ihre Leere an?
- Wo darf die alpine Welt erscheinen?
- Welches Detail wäre charmant, aber bedeutungslos und muss deshalb entfallen?

### 14.5 Wirkungsdurchgang

- Gibt es genau einen klaren Aufmerksamkeitsanker?
- Ist die nächste Handlung sichtbar, ohne aufdringlich zu sein?
- Wird ein Zustand am Gegenstand statt global kommuniziert?
- Erklärt Bewegung den räumlichen Übergang?
- Bleibt die Wirkung nach fünf Arbeitstagen noch angenehm?

### 14.6 Evidenzwert

Jeder primäre Begriff wird pro Übersetzungskanal mit `0–3` bewertet:

- `0`: keine Evidenz
- `1`: angedeutet
- `2`: klar vorhanden
- `3`: systemisch integriert

Ein primärer Begriff gilt erst als erfüllt, wenn er in mindestens drei Kanälen mindestens `2` erreicht und in keinem Kanal seiner ausgeschlossenen Fehlinterpretation entspricht.

## 15. Umsetzungsreihenfolge

### Phase 1 · Systemvertrag

- dieses Dokument fachlich abnehmen;
- Begriffsvokabular schärfen;
- Seitenprofile und unerwünschte Wirkungen bestätigen;
- Wechselwirkung mit der alpinen Produktwelt bestätigen.

### Phase 2 · Maschinenlesbare Profile

- `src/experience/profiles.js` anlegen;
- Seiten- und Zustandsprofile validierbar machen;
- Profilattribute in Produktschale und Seitenwurzeln ausgeben;
- keine visuelle Veränderung ohne separaten Commit.

### Phase 3 · Gemeinsame Wirkungstokens

- `experience.css` ergänzen;
- Raumrhythmus, Materialtiefe, Bewegungstempo, Aufmerksamkeitsstärke und Illustrationspräsenz als semantische Kanäle modellieren;
- Status- und Interaktionstokens unangetastet lassen.

### Phase 4 · Tagesplan als Referenz

- Profil `gegenwärtig · atmend · im Fluss · aufmerksam · beseelt` umsetzen;
- Normal-, Live-, entkoppelten, leeren, Stale- und Fehlerzustand prüfen;
- Präzisions- und Wirkungsevidenz dokumentieren.

### Phase 5 · Übertragung auf die übrigen Seiten

1. Termine und Kundschaft
2. Team und Angebot
3. Verwaltung
4. Login und Onboarding

### Phase 6 · Regression

- alle Zielviewports aus `PRODUCT_SURFACE_V1.md` prüfen;
- Screenshotvergleich pro Seite und Zustand;
- Tastatur, Fokus, reduzierte Bewegung und Kontrast prüfen;
- unerwünschte Wirkungen aktiv reviewen.

## 16. Definition of Done

Das Wirkungssystem V1 ist umgesetzt, wenn:

- jede der acht Seiten ein freigegebenes Wirkungsprofil besitzt;
- jeder primäre Begriff sichtbare Evidenz in mindestens drei Kanälen hat;
- jede Seite einen klaren Aufmerksamkeitsanker und eine definierte unerwünschte Wirkung besitzt;
- Zustandsmodifikatoren seitenübergreifend konsistent sind;
- die räumliche Interaktionsgrammatik für Detail, Bearbeitung und Rückkehr eingehalten wird;
- die alpine Welt nach Dosierungsregel und niemals als Funktionsersatz eingesetzt wird;
- Status-, Fokus-, Such- und Warnsemantik unverändert korrekt bleibt;
- Accessibility, Datenwahrheit und Performance durch keinen Wirkungsbegriff geschwächt werden;
- die Oberfläche nach der Veredelung einfacher zu verstehen und nicht nur schöner anzusehen ist.
