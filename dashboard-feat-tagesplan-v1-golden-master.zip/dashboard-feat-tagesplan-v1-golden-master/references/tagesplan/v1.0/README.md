# Gasserwerk · Tagesplan v1.0 Golden Master

Status: **Release Candidate – noch nicht eingefroren**

## Rolle

`tagesplan-reference.html` ist die vollständig isolierte, ausführbare Sollreferenz des Gasserwerk-Tagesplans. Sie definiert sichtbare Struktur, Verhalten, Zustände, Responsive-Projektion, Accessibility und seitenspezifische Wirkung. Sie ist keine Produktionsarchitektur und enthält keine Backendpersistenz.

## Seitenspezifische Wirkung

Primär:

- gegenwärtig
- atmend
- im Fluss

Unterstützend:

- aufmerksam
- beseelt

Abnahme:

> Innerhalb weniger Sekunden ist erkennbar, wer arbeitet, was jetzt läuft und was als Nächstes relevant ist.

## Direkt öffnen

Die HTML-Datei benötigt keinen Server, keinen Buildschritt und keine externe Ressource. Sie kann direkt im Browser geöffnet werden.

Deterministische Beispiele:

```text
tagesplan-reference.html?referenceNow=11:22
tagesplan-reference.html?referenceNow=11:22&agenda=open
tagesplan-reference.html?referenceNow=11:22&focus=melanie
tagesplan-reference.html?referenceNow=11:22&selected=a6
tagesplan-reference.html?referenceNow=11:22&scenario=stress
tagesplan-reference.html?referenceNow=11:22&scenario=empty&state=empty
```

## Dateien

- `tagesplan-reference.html` – isolierter ausführbarer Golden Master
- `CONTRACT.md` – sichtbarer und interaktiver Seitenvertrag
- `STATES.md` – Zustandsmatrix
- `INTEGRATION.md` – Übergabevertrag an die Produktionslinie
- `RELEASE.md` – Freeze- und Verifikationsnachweis
- `evidence/README.md` – Browser- und Abnahmematrix

## Freeze-Regel

Nach dem Status `FROZEN` wird diese Version nicht mehr still verändert. Jede spätere visuelle, interaktive oder fachliche Änderung erzeugt mindestens `v1.1`.
