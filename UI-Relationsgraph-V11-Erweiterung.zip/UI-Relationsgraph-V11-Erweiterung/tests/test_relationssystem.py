#!/usr/bin/env python3
"""Unit and fixture checks. No external network, no undocumented success claims."""
import sys,unittest,json,copy,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def mod(filename,name):
 path=ROOT/'scripts'/filename;s=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(s);s.loader.exec_module(module);return module
identity=mod('stabile_identitaeten.py','identitaet')
impact=mod('folgen_graph.py','folgen')
css=mod('css_quellenkarte.py','css_quellen')
DATA=ROOT/'daten'
MEAS=ROOT/'eingaben'/'browser-messung.json'

def mkrec(index,id=None,par=None,tag='button',family='pill'):
 return {'index':index,'id':id,'parentIndex':par,'tag':tag,'classes':[family],'role':None,'aria':{},
 'rect':{'left':0,'top':0,'width':30,'height':30},'visibleInLayout':True,'styles':{},'attributes':{}}

def mock(scen,items):
 return {'meta':{'scenario':scen,'route':'calendar'},'records':items}

class Logic(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.measure=json.loads(MEAS.read_text());cls.ids=json.loads((DATA/'identitaeten.json').read_text());cls.mutations=json.loads((DATA/'token-mutationen.json').read_text());cls.graph=json.loads((DATA/'aenderungsfolgen-graph.json').read_text());cls.styles=json.loads((DATA/'css-quellenkarte.json').read_text())
 def test_sha_provenance(self):
  self.assertEqual(self.measure['source']['sha256'],self.ids['sourceSha256']);self.assertEqual(self.measure['source']['sha256'],self.graph['sourceSha256'])
 def test_declared_id_survives_reparenting(self):
  x={'schema':'browser-dom-measure/v2','source':{'sha256':'mock'},'scenarios':[
   mock('one',[mkrec(0,'fixed'),mkrec(1,par=0)]),
   mock('two',[mkrec(0,'new-parent'),mkrec(1,'fixed',par=0)])]}
  z=identity.identify(x)
  m=[m for m in z['crossStateMatches'] if m['identityKey']=='id:fixed']
  self.assertEqual(len(m),1);self.assertEqual(m[0]['classification'],'stable-declared')
 def test_path_matches_never_promoted(self):
  x={'schema':'browser-dom-measure/v2','source':{'sha256':'mock'},'scenarios':[mock('one',[mkrec(0)]),mock('two',[mkrec(0)])]}
  z=identity.identify(x)
  self.assertEqual(z['crossStateMatches'][0]['classification'],'candidate')
 def test_candidate_same_path_different_component_is_ambiguous(self):
  x={'schema':'browser-dom-measure/v2','source':{'sha256':'mock'},'scenarios':[mock('one',[mkrec(0,family='a')]),mock('two',[mkrec(0,family='b')])]}
  z=identity.identify(x)
  self.assertEqual(z['crossStateMatches'][0]['classification'],'ambiguous')
 def test_duplicate_id_detected_not_trusted(self):
  x={'schema':'browser-dom-measure/v2','source':{'sha256':'mock'},'scenarios':[mock('one',[mkrec(0,'duplicate'),mkrec(1,'duplicate')])]}
  z=identity.identify(x)
  self.assertTrue(any(e['kind']=='duplicate-html-id' for e in z['issues']))
  self.assertFalse(any(e['identityKey']=='id:duplicate' and e['certainty']=='declared' for e in z['records']))
 def test_observed_interventions_and_control(self):
  ev=self.mutations['interventions'];self.assertEqual(len(ev),20)
  self.assertTrue(all(e['status']=='MEASURED' and e['rollback']['returnedToBaseline'] for e in ev))
  self.assertTrue(all(e['affectedNodeCount']==0 for e in ev if e['mutationId']=='negative-unused-token'))
  self.assertTrue(all(e['affectedNodeCount']>0 for e in ev if e['cssVariable']=='--border'))
 def test_zero_runtime_does_not_mean_no_static_reference(self):
  self.assertEqual(self.graph['tokenSummary']['--radius']['observedNodeInterventions'],0)
  self.assertEqual(self.styles['tokens']['--radius']['references'],4)
 def test_css_refs_and_parse(self):
  self.assertEqual(len(self.styles['parseErrors']),0)
  self.assertEqual(self.styles['tokens']['--brand']['references'],39)
  self.assertEqual(self.styles['tokens']['--surface']['references'],52)
 def test_color_mutation_does_not_force_geometry_oracle(self):
  self.assertTrue(all(not entry['contractRecheckTargets'] for entry in self.graph['interventions']))
  self.assertTrue(any(entry['selectorIntersectionsNotNecessarilyRelevant'] for entry in self.graph['interventions']))
 def test_html_index_stable_for_impact(self):
  ix={(r['scenario'],r['index']):r for r in self.ids['records']}
  for event in self.graph['interventions']:
   for n in event['nodes']:
    self.assertIn((event['scenario'],n['index']),ix)
    self.assertEqual(n['identity'],ix[(event['scenario'],n['index'])]['identityKey'])

if __name__=='__main__':unittest.main(verbosity=2)
