# Angebot · Seitenvertrag

Status: **Zur Freigabe – Dienstleistungsdarstellung konsolidiert, Preis-/Variantenmodell integrationsrelevant**  
Verantwortlicher Bereich: `Angebot`  
Direkter Referenzpfad: `/dashboard/pages/angebot/`  
Abhängige gemeinsame Verträge: `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

Die Seite `Angebot` zeigt die buchbaren Dienstleistungen des Salons und deren grundlegende Buchungsparameter.

Primäre Arbeitsaufgaben:

- Dienstleistungen überblicken
- Dauer und Preis erkennen
- zugewiesene Mitarbeitende erkennen
- eine Dienstleistung öffnen
- mit entsprechender Berechtigung eine Dienstleistung anlegen oder bearbeiten

Die Seite beschreibt das Salonangebot. Sie ist weder Kasse noch Marketingkatalog und bestimmt nicht allein, ob ein Slot buchbar ist; dafür werden zusätzlich Teamverfügbarkeit, Öffnungszeiten und mögliche Ressourcen benötigt.

Nicht Bestandteil dieser V1:

- produktive Preisberechnung
- Gutscheine und Rabatte
- Lager-/Materialverwaltung
- komplexe Ressourcenplanung
- Online-Shop

## 2. Eingabedaten

Datenquellenmethoden:

```js
getSessionContext()
listServices(query)
getService(id)
listStaff()
```

Query:

```js
{
  activeOnly,
  staffIds,
  text,
  sort,
  locationIds
}
```

Erforderliche Listenfelder:

- stabile `id`
- `displayName`
- `durationMinutes`
- `isActive`

Optionale Felder:

- Preis
- Preislabel oder Preisbereich
- Beschreibung
- Kategorie
- zugewiesene Mitarbeitende
- Variantenhinweis
- Standortzuordnung

Capabilities:

- Anzeige: `service:view`
- Anlegen und Bearbeiten: `service:manage`
- Teamzuordnung anzeigen: zusätzlich `staff:view`

## 3. Fachliches View-Model

```js
{
  query: {
    activeOnly,
    staffIds,
    text,
    sort,
    locationIds
  },
  services: [
    {
      id,
      displayName,
      description,
      categoryLabel,
      durationMinutes,
      durationLabel,
      price,
      priceLabel,
      assignedStaff,
      locationLabels,
      isActive,
      actions
    }
  ],
  selectedService: null | {
    id,
    displayName,
    description,
    category,
    duration,
    price,
    assignedStaff,
    locations,
    variants,
    bookingRequirements,
    actions
  }
}
```

Invarianten:

- Dauer wird intern in Minuten geführt.
- Preis und Währung bleiben getrennte Werte.
- `priceLabel` darf `ab CHF …` oder einen Bereich anzeigen, wenn der Adapter dies explizit liefert; die UI erfindet keinen Preisbereich.
- Mitarbeitendenzuweisungen verwenden stabile IDs.
- Inaktive Dienstleistungen bleiben für historische Termine referenzierbar.
- Eine Dienstleistung ist nicht allein aufgrund ihrer Existenz buchbar.
- Kategorien sind fachliche Gruppierung, kein Pflichtfeld der V1.

## 4. Ausgehende Ereignisse

### Suche oder Filter ändern

```js
{
  type: "services:query-changed",
  payload: { query }
}
```

### Dienstleistung öffnen

```js
{
  type: "service:selected",
  payload: { serviceId, source: "offer-page", originCardId }
}
```

### Dienstleistung anlegen

```js
{
  type: "service:create-requested",
  payload: { locationId: null | string, source: "offer-page" }
}
```

### Dienstleistung bearbeiten

```js
{
  type: "service:edit-requested",
  payload: { serviceId, section }
}
```

### Aktivstatus ändern

```js
{
  type: "service:active-state-change-requested",
  payload: { serviceId, from, to }
}
```

Dieser Event wird erst aktiv, wenn historische Referenzen und Deaktivierungsregeln geklärt sind.

## 5. Ladezustand

- Produktschale, Seitentitel und erlaubte primäre Aktion bleiben sichtbar.
- Dienstleistungskarten erhalten strukturelle Skeletons.
- Filter bleiben sichtbar, sofern Optionen bekannt sind.
- Bei Detailladung bleibt die ausgewählte Karte markiert.
- Bereits sichtbare Dienstleistungen dürfen während einer Aktualisierung erhalten bleiben und werden als aktualisierend markiert.

## 6. Leerzustand

### Noch keine Dienstleistungen

- erklärt, dass ohne Dauer und Zuordnung keine Buchbarkeit entsteht
- bietet `Dienstleistung anlegen`, sofern erlaubt
- zeigt keine fiktiven Standarddienstleistungen

### Keine Treffer für Filter

- zeigt aktive Filter
- bietet `Filter zurücksetzen`
- unterscheidet sich klar von einem leeren Angebot

### Dienstleistung ohne Teamzuordnung

- bleibt sichtbar
- wird als nicht vollständig zugeordnet markiert
- darf nicht automatisch allen Mitarbeitenden zugewiesen werden

## 7. Fehlerzustand

Kernladefehler:

- Seite bleibt in der Produktschale.
- Retry bleibt verfügbar.
- Fehler wird nicht als leeres Angebot dargestellt.

Detailfehler:

- Angebotsübersicht bleibt nutzbar.
- Detailfläche zeigt Retry und Schliessen.

Teilfehler:

- fehlende Teamzuordnung verhindert nicht das Anzeigen von Name, Dauer oder Preis.
- fehlender Preis wird ausgelassen beziehungsweise als nicht hinterlegt bezeichnet, nicht als CHF 0 interpretiert.

Offline/Stale:

- vorhandene Dienstleistungen bleiben sichtbar.
- Änderungen werden nicht als gespeichert dargestellt, solange keine Bestätigung vorliegt.

## 8. Berechtigungszustände

- Ohne `service:view` erscheint ein vollständiger Forbidden-Zustand.
- Ohne `service:manage` bleibt die Seite lesbar, aber ohne Anlegen-, Bearbeiten- oder Aktivstatusaktionen.
- Ohne `staff:view` werden Mitarbeitendenzuweisungen nicht als Personendetails geliefert.
- Preisangaben können später capabilityabhängig werden; bis zu einer solchen Entscheidung gilt Sichtbarkeit wie vom Adapter geliefert.
- Fehlende Berechtigung darf keine vertraulichen Konfigurationsdetails in verstecktem DOM zurücklassen.

## 9. Desktopverhalten

- Sidebar und normaler Produktkopf bleiben sichtbar.
- Dienstleistungen erscheinen als responsive Kartenmatrix oder kompakte Liste, abhängig von Dichte und Informationsmenge.
- Name, Dauer und Preis beziehungsweise Preisstatus stehen visuell vor Beschreibung und Zuordnung.
- Teamzuordnung wird über kleine, klar beschriftete Personenreferenzen dargestellt.
- Detail und Bearbeitung verwenden die gemeinsame Kontextfläche.
- Auf 14-Zoll-Viewports werden Kartenabstände und Metadaten verdichtet, ohne Namen oder Preise unlesbar zu machen.
- Die Seite scrollt vertikal und besitzt keinen horizontalen Gesamtüberlauf.

## 10. Mobilverhalten

- Dienstleistungskarten werden einspaltig dargestellt.
- Name, Dauer und Preis stehen im oberen Kartenbereich.
- Lange Beschreibungen und Zuordnungen werden im Detail gezeigt.
- Detail/Bearbeitung öffnen als vollständige Inhaltsfläche oder unteres Sheet.
- Primäre Aktion bleibt mit sicherem Touch-Ziel erreichbar.
- Dieselben Aktiv-, Fehler- und Berechtigungszustände gelten wie auf Desktop.

## 11. Tastatur und Fokus

- Karten beziehungsweise Listenzeilen sind per Tastatur aktivierbar.
- `Enter` oder Leertaste öffnet die Dienstleistung.
- Anlegen- und Bearbeitungsflächen halten den Fokus.
- `Escape` schliesst das oberste Overlay.
- Schliessen stellt den Fokus auf die ursprüngliche Karte zurück.
- Wird eine Dienstleistung deaktiviert und durch den Filter entfernt, wird der Fokus sinnvoll neu gesetzt und die Änderung angekündigt.
- Preis- und Aktivstatus werden textlich und nicht nur farblich kommuniziert.

## 12. Abnahmekriterien

- Seite ist direkt aufrufbar.
- Normal-, Lade-, Leer-, Filter-ohne-Treffer-, Fehler-, Offline-, Stale- und Forbidden-Zustände sind vorhanden.
- Dauer wird als Minutenwert normalisiert und korrekt formatiert.
- Fehlender Preis wird nicht als Nullpreis interpretiert.
- Inaktive Dienstleistungen bleiben für Historie referenzierbar.
- Teamzuweisungen verwenden stabile IDs.
- Lesemodus und Verwaltungsmodus reagieren korrekt auf Capabilities.
- Detail schliesst mit Fokuswiederherstellung.
- 14-Zoll, Standard-Desktop, Mobil und Tablet sind geprüft.
- Keine Gesamtseite läuft horizontal über.
- Die Seite behauptet nicht allein, dass eine Dienstleistung buchbar ist.

## 13. Integrationshinweise

- Offene Fragen: `Q-002`, `Q-003`, `Q-005`, `Q-006`, `Q-007`, `Q-SVC-001` bis `Q-SVC-003`, `Q-APT-003`, `Q-STAFF-001`.
- Der Produktionsadapter normalisiert Preis-, Dauer-, Varianten- und Zuordnungsdaten.
- Dienstleistungsphasen und Ressourcen werden nicht als UI-Erfindung ergänzt.
- Historische Termine müssen ihre Dienstleistungsbezeichnung auch nach Deaktivierung lesbar behalten.
- Mehrwertsteuer, Rabatte und Abrechnung gehören nicht in den Referenzvertrag dieser Seite.
