export const DashboardEvent = Object.freeze({
  SHELL_NAVIGATE_REQUESTED: 'shell:navigate-requested',

  SEARCH_OPENED: 'search:opened',
  SEARCH_CLOSED: 'search:closed',
  SEARCH_SUBMITTED: 'search:submitted',
  SEARCH_RESULT_SELECTED: 'search:result-selected',

  DAY_DATE_CHANGE_REQUESTED: 'day:date-change-requested',
  DAY_SCALE_CHANGE_REQUESTED: 'day:scale-change-requested',
  DAY_STAFF_FOCUS_REQUESTED: 'day:staff-focus-requested',
  DAY_STAFF_FOCUS_CLEARED: 'day:staff-focus-cleared',
  DAY_LIVE_FOLLOW_PAUSED: 'day:live-follow-paused',
  DAY_LIVE_FOLLOW_RESUME_REQUESTED: 'day:live-follow-resume-requested',

  APPOINTMENTS_QUERY_CHANGED: 'appointments:query-changed',
  APPOINTMENT_CREATE_REQUESTED: 'appointment:create-requested',
  APPOINTMENT_SELECTED: 'appointment:selected',
  APPOINTMENT_EDIT_REQUESTED: 'appointment:edit-requested',
  APPOINTMENT_STATUS_CHANGE_REQUESTED: 'appointment:status-change-requested',
  APPOINTMENT_CANCEL_REQUESTED: 'appointment:cancel-requested',

  CUSTOMER_QUERY_CHANGED: 'customer:query-changed',
  CUSTOMER_SELECTED: 'customer:selected',
  CUSTOMER_DETAIL_CLOSED: 'customer:detail-closed',
  CUSTOMER_APPOINTMENT_CREATE_REQUESTED: 'customer:appointment-create-requested',
  CUSTOMER_EDIT_REQUESTED: 'customer:edit-requested',

  STAFF_QUERY_CHANGED: 'staff:query-changed',
  STAFF_SELECTED: 'staff:selected',
  STAFF_CREATE_REQUESTED: 'staff:create-requested',
  STAFF_EDIT_REQUESTED: 'staff:edit-requested',
  STAFF_ACTIVE_STATE_CHANGE_REQUESTED: 'staff:active-state-change-requested',

  SERVICES_QUERY_CHANGED: 'services:query-changed',
  SERVICE_SELECTED: 'service:selected',
  SERVICE_CREATE_REQUESTED: 'service:create-requested',
  SERVICE_EDIT_REQUESTED: 'service:edit-requested',
  SERVICE_ACTIVE_STATE_CHANGE_REQUESTED: 'service:active-state-change-requested',

  ADMINISTRATION_SECTION_OPENED: 'administration:section-opened',
  ADMINISTRATION_CHANGE_REQUESTED: 'administration:change-requested',
  PRODUCT_PREFERENCE_THEME_CHANGE_REQUESTED: 'product-preference:theme-change-requested',
  PRODUCT_INSTALL_REQUESTED: 'product-install:requested',

  AUTH_SIGN_IN_REQUESTED: 'auth:sign-in-requested',
  AUTH_MAGIC_LINK_REQUESTED: 'auth:magic-link-requested',
  AUTH_PASSWORD_RESET_REQUESTED: 'auth:password-reset-requested',
  AUTH_SIGN_OUT_REQUESTED: 'auth:sign-out-requested',

  ONBOARDING_STEP_CHANGE_REQUESTED: 'onboarding:step-change-requested',
  ONBOARDING_SAVE_AND_CONTINUE_REQUESTED: 'onboarding:save-and-continue-requested',
  ONBOARDING_COMPLETED: 'onboarding:completed'
});

export const ReservedPhase3Event = Object.freeze({
  APPOINTMENT_MOVE_REQUESTED: 'appointment:move-requested',
  APPOINTMENT_RESIZE_REQUESTED: 'appointment:resize-requested',
  APPOINTMENT_UNDO_REQUESTED: 'appointment:undo-requested'
});

export const DASHBOARD_EVENT_VALUES = Object.freeze(Object.values(DashboardEvent));
export const RESERVED_PHASE_3_EVENT_VALUES = Object.freeze(Object.values(ReservedPhase3Event));

export function createDashboardEvent(type, payload, options = {}) {
  if (!DASHBOARD_EVENT_VALUES.includes(type) && !RESERVED_PHASE_3_EVENT_VALUES.includes(type)) {
    throw new TypeError(`Unknown Gasserwerk dashboard event: ${type}`);
  }

  return Object.freeze({
    type,
    source: options.source ?? 'unknown',
    occurredAt: options.occurredAt ?? new Date().toISOString(),
    correlationId: options.correlationId ?? globalThis.crypto?.randomUUID?.() ?? `event-${Date.now()}`,
    payload: payload ?? {}
  });
}
