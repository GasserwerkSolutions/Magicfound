import { createElement, replaceChildren, assertElement } from '../lib/dom.js';
import { createFocusScope } from '../lib/focus.js';
import { createButton } from './button.js';

function normalizeContent(value) {
  if (value === null || value === undefined) return [];
  return Array.isArray(value) ? value.filter(Boolean) : [value];
}

export function createContextPanel(options = {}) {
  const {
    overlayRoot,
    id = 'context-panel',
    closeLabel = 'Kontext schliessen',
    onClose = null
  } = options;

  assertElement(overlayRoot, 'overlayRoot');
  let open = false;
  let title = '';

  const heading = createElement('h2', {
    className: 'gw-context-panel__title',
    attributes: { id: `${id}-title`, tabindex: '-1' }
  });
  const body = createElement('div', { className: 'gw-context-panel__body' });
  const footer = createElement('footer', { className: 'gw-context-panel__footer', attributes: { hidden: true } });
  const closeButton = createButton({
    label: closeLabel,
    icon: 'close',
    compact: true,
    iconOnly: true,
    className: 'gw-context-panel__close',
    attributes: { 'aria-label': closeLabel }
  });
  const panel = createElement('section', {
    className: 'gw-context-panel',
    attributes: {
      id,
      role: 'dialog',
      'aria-modal': 'true',
      'aria-labelledby': `${id}-title`,
      hidden: true,
      tabindex: '-1'
    },
    children: [
      createElement('header', {
        className: 'gw-context-panel__header',
        children: [heading, closeButton]
      }),
      body,
      footer
    ]
  });
  const backdrop = createElement('div', {
    className: 'gw-context-panel__backdrop',
    attributes: { hidden: true, 'aria-hidden': 'true' }
  });
  const focusScope = createFocusScope(panel, {
    initialFocus: () => heading,
    onEscape: () => close({ reason: 'escape' })
  });

  function close(options = {}) {
    if (!open) return false;
    open = false;
    panel.hidden = true;
    backdrop.hidden = true;
    panel.dataset.open = 'false';
    focusScope.deactivate({ returnFocus: options.returnFocus ?? true });
    if (typeof onClose === 'function') onClose({
      reason: options.reason ?? 'explicit',
      title
    });
    return true;
  }

  closeButton.addEventListener('click', () => close({ reason: 'button' }));
  backdrop.addEventListener('click', () => close({ reason: 'backdrop' }));
  overlayRoot.append(backdrop, panel);

  const api = Object.freeze({
    element: panel,
    backdrop,
    heading,
    body,
    footer,
    open(options = {}) {
      title = String(options.title ?? 'Kontext');
      heading.textContent = title;
      replaceChildren(body, normalizeContent(options.body));
      const footerContent = normalizeContent(options.footer);
      replaceChildren(footer, footerContent);
      footer.hidden = footerContent.length === 0;
      panel.hidden = false;
      backdrop.hidden = false;
      panel.dataset.open = 'true';
      open = true;
      focusScope.activate();
      return api;
    },
    close,
    setBody(content) {
      replaceChildren(body, normalizeContent(content));
    },
    setFooter(content) {
      const normalized = normalizeContent(content);
      replaceChildren(footer, normalized);
      footer.hidden = normalized.length === 0;
    },
    get isOpen() {
      return open;
    }
  });

  return api;
}
