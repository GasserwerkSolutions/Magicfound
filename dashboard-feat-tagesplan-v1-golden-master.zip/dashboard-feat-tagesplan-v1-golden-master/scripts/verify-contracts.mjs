import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { DashboardDataSource } from '../src/data/contracts/dashboard-data-source.js';
import {
  DashboardEvent,
  ReservedPhase3Event
} from '../src/data/contracts/events.js';
import { Capability } from '../src/data/contracts/capabilities.js';
import {
  AppointmentStatus,
  ContractStatus,
  OperationalKind,
  PageDataState
} from '../src/data/contracts/domain-values.js';

const root = process.cwd();
const errors = [];
const notes = [];

const pageNames = [
  'login',
  'onboarding',
  'tagesplan',
  'termine',
  'kundschaft',
  'team',
  'angebot',
  'verwaltung'
];

const requiredHeadings = [
  '## 1. Zweck und primäre Arbeitsaufgabe',
  '## 2. Eingabedaten',
  '## 3. Fachliches View-Model',
  '## 4. Ausgehende Ereignisse',
  '## 5. Ladezustand',
  '## 6. Leerzustand',
  '## 7. Fehlerzustand',
  '## 8. Berechtigungszustände',
  '## 9. Desktopverhalten',
  '## 10. Mobilverhalten',
  '## 11. Tastatur und Fokus',
  '## 12. Abnahmekriterien',
  '## 13. Integrationshinweise'
];

function read(path) {
  const absolute = resolve(root, path);
  if (!existsSync(absolute)) {
    errors.push(`Fehlende Datei: ${path}`);
    return '';
  }
  return readFileSync(absolute, 'utf8');
}

function assert(condition, message) {
  if (!condition) errors.push(message);
}

function sectionContent(document, heading, nextHeading) {
  const start = document.indexOf(heading);
  if (start < 0) return '';
  const contentStart = start + heading.length;
  const end = nextHeading ? document.indexOf(nextHeading, contentStart) : document.length;
  return document.slice(contentStart, end < 0 ? document.length : end).trim();
}

const productSurface = read('docs/PRODUCT_SURFACE_V1.md');
const sharedContract = read('docs/contracts/README.md');
const semanticReview = read('docs/contracts/SEMANTIC_REVIEW.md');
const openQuestions = read('docs/contracts/OPEN_QUESTIONS.md');
const pageIndex = read('pages/README.md');
const template = read('pages/CONTRACT_TEMPLATE.md');

assert(productSurface.includes('seitenbasiert unter `pages/` und `src/`'), 'Produktvertrag: seitenbasierte Primärquelle fehlt');
assert(!productSurface.includes('Die vollständige Produktoberfläche lebt in `index.html`'), 'Produktvertrag: index.html ist fälschlich noch als Primärquelle beschrieben');
assert(sharedContract.includes('DashboardDataSource'), 'Gemeinsamer Vertrag: DashboardDataSource fehlt');
assert(sharedContract.includes('getAuthenticationOptions()'), 'Gemeinsamer Vertrag: getAuthenticationOptions() fehlt');
assert(sharedContract.includes('Capability-Modell'), 'Gemeinsamer Vertrag: Capability-Modell fehlt');
assert(sharedContract.includes('Ereignisvertrag'), 'Gemeinsamer Vertrag: Ereignisvertrag fehlt');
assert(sharedContract.includes('Responsive- und Dichtevertrag'), 'Gemeinsamer Vertrag: Dichtevertrag fehlt');
assert(sharedContract.includes(`Status: **${ContractStatus.FOR_APPROVAL}`), 'Gemeinsamer Vertrag steht nicht auf Zur Freigabe');
assert(semanticReview.includes('Es existiert derzeit keine Frage der Klasse `B`'), 'Semantischer Durchgang: Referenzblockergebnis fehlt');
assert(semanticReview.includes('## 3. Seitenverantwortung'), 'Semantischer Durchgang: Seitenverantwortung fehlt');
assert(semanticReview.includes('## 5. Datenquellenverantwortung'), 'Semantischer Durchgang: Datenquellenverantwortung fehlt');
assert(semanticReview.includes('## 6. Eventverantwortung'), 'Semantischer Durchgang: Eventverantwortung fehlt');
assert(openQuestions.includes('Q-001'), 'Offene Fragen: übergreifende Fragen fehlen');
assert(openQuestions.includes('Q-DAY-001'), 'Offene Fragen: Tagesplanfragen fehlen');
assert(openQuestions.includes('Q-AUTH-001'), 'Offene Fragen: Authfragen fehlen');

const blockingQuestionCount = (openQuestions.match(/\*\*Klasse:\*\*\s*B\b/g) ?? []).length;
assert(blockingQuestionCount === 0, `Offene Fragen: ${blockingQuestionCount} Referenzblocker der Klasse B verhindern Zur Freigabe`);

const knownQuestionIds = new Set(openQuestions.match(/\bQ(?:-[A-Z]+)?-\d{3}\b/g) ?? []);
const knownEventValues = new Set([
  ...Object.values(DashboardEvent),
  ...Object.values(ReservedPhase3Event)
]);
const knownCapabilityValues = new Set(Object.values(Capability));
const knownContractTokens = new Set([...knownEventValues, ...knownCapabilityValues]);
const knownDataSourceMethods = new Set(
  Object.getOwnPropertyNames(DashboardDataSource.prototype)
    .filter((name) => name !== 'constructor')
);

const statusPattern = /Status:\s*\*\*(Entwurf|Zur Freigabe|Verbindlich|Implementiert|In Produktion abgebildet)(?:\s*[^*]*)?\*\*/;
const eventPattern = /type:\s*["']([a-z][a-z0-9-]*:[a-z][a-z0-9-]*)["']/g;
const contractTokenPattern = /\b([a-z][a-z0-9-]*:[a-z][a-z0-9-]*)\b/g;
const dataMethodPattern = /\b((?:get|list)[A-Z][A-Za-z0-9]*)\s*\(/g;
const questionPattern = /`(Q(?:-[A-Z]+)?-\d{3})`/g;

const allPageContracts = [];

for (const pageName of pageNames) {
  const path = `pages/${pageName}/CONTRACT.md`;
  const contract = read(path);
  if (!contract) continue;
  allPageContracts.push(contract);

  assert(contract.startsWith('# '), `${path}: Dokumenttitel fehlt`);
  const statusMatch = contract.match(statusPattern);
  assert(statusMatch, `${path}: gültiger Vertragsstatus fehlt`);
  if (statusMatch) {
    assert(statusMatch[1] === ContractStatus.FOR_APPROVAL, `${path}: erwartet Status Zur Freigabe, gefunden ${statusMatch[1]}`);
  }
  assert(contract.includes(`Direkter Referenzpfad: \`/dashboard/pages/${pageName}/\``), `${path}: direkter Referenzpfad fehlt oder stimmt nicht`);
  assert(pageIndex.includes(`./${pageName}/CONTRACT.md`), `pages/README.md: Link auf ${path} fehlt`);
  assert(semanticReview.includes(`| ${pageName === 'tagesplan' ? 'Tagesplan' : pageName === 'termine' ? 'Termine' : pageName === 'kundschaft' ? 'Kundschaft' : pageName === 'team' ? 'Team' : pageName === 'angebot' ? 'Angebot' : pageName === 'verwaltung' ? 'Verwaltung' : pageName === 'login' ? 'Login' : 'Onboarding'} |`), `Semantischer Durchgang: Seitenverantwortung für ${pageName} fehlt`);

  let previousPosition = -1;
  for (let index = 0; index < requiredHeadings.length; index += 1) {
    const heading = requiredHeadings[index];
    const position = contract.indexOf(heading);
    assert(position >= 0, `${path}: Pflichtabschnitt fehlt: ${heading}`);
    if (position >= 0) {
      assert(position > previousPosition, `${path}: Abschnitt steht nicht in verbindlicher Reihenfolge: ${heading}`);
      const content = sectionContent(contract, heading, requiredHeadings[index + 1]);
      assert(content.length >= 80, `${path}: Abschnitt ist zu knapp oder leer: ${heading}`);
      previousPosition = position;
    }
  }

  const numberedHeadings = contract.match(/^##\s+\d+\.\s+/gm) ?? [];
  assert(numberedHeadings.length === 13, `${path}: erwartet 13 nummerierte Pflichtabschnitte, gefunden ${numberedHeadings.length}`);

  const events = [...contract.matchAll(eventPattern)].map((match) => match[1]);
  assert(events.length > 0, `${path}: kein maschinenlesbares Event mit type-Feld dokumentiert`);
  for (const event of events) {
    assert(knownEventValues.has(event), `${path}: Event fehlt im ausführbaren Eventkatalog: ${event}`);
  }

  const contractTokens = [...contract.matchAll(contractTokenPattern)].map((match) => match[1]);
  for (const token of contractTokens) {
    assert(knownContractTokens.has(token), `${path}: unbekanntes Event oder Capability-Token: ${token}`);
  }

  const dataMethods = [...contract.matchAll(dataMethodPattern)].map((match) => match[1]);
  for (const method of dataMethods) {
    assert(knownDataSourceMethods.has(method), `${path}: Datenquellenmethode fehlt in DashboardDataSource: ${method}`);
  }

  const questionIds = [...contract.matchAll(questionPattern)].map((match) => match[1]);
  assert(questionIds.length > 0, `${path}: keine offenen Fragen referenziert`);
  for (const questionId of questionIds) {
    assert(knownQuestionIds.has(questionId), `${path}: unbekannte Frage referenziert: ${questionId}`);
  }

  assert(!/\b(TODO|TBD|FIXME)\b/i.test(contract), `${path}: enthält unkontrollierten Platzhalter TODO/TBD/FIXME`);
  notes.push(`${path}: Zur Freigabe, 13 Abschnitte, ${events.length} Eventbeispiele, ${new Set(questionIds).size} Fragenreferenzen`);
}

const completeContractCorpus = [sharedContract, ...allPageContracts].join('\n');

for (const event of knownEventValues) {
  assert(completeContractCorpus.includes(event), `Eventkatalog: Event ist in keinem Vertrag dokumentiert: ${event}`);
}

for (const capability of knownCapabilityValues) {
  assert(completeContractCorpus.includes(capability), `Capability-Katalog: Capability ist in keinem Vertrag dokumentiert: ${capability}`);
}

for (const status of Object.values(AppointmentStatus)) {
  assert(sharedContract.includes(status), `Domainwerte: Terminstatus fehlt im gemeinsamen Vertrag: ${status}`);
}

for (const kind of Object.values(OperationalKind)) {
  assert(sharedContract.includes(kind), `Domainwerte: operative Art fehlt im gemeinsamen Vertrag: ${kind}`);
}

for (const state of Object.values(PageDataState)) {
  assert(sharedContract.includes(`\`${state}\``), `Domainwerte: Seitenzustand fehlt im gemeinsamen Vertrag: ${state}`);
}

for (const method of knownDataSourceMethods) {
  assert(sharedContract.includes(`${method}(`), `Gemeinsamer Vertrag: Datenquellenmethode fehlt in der Dokumentation: ${method}`);
}

for (const heading of requiredHeadings) {
  assert(template.includes(heading), `pages/CONTRACT_TEMPLATE.md: Pflichtabschnitt fehlt: ${heading}`);
}

const approvalRows = pageIndex.match(/\| Zur Freigabe \|/g) ?? [];
assert(approvalRows.length === pageNames.length, `pages/README.md: erwartet ${pageNames.length} Statuszeilen Zur Freigabe, gefunden ${approvalRows.length}`);
assert(pageIndex.includes('Vertragsstatus'), 'pages/README.md: Vertragsstatusmatrix fehlt');
assert(pageIndex.includes('Der erste vollständig zu implementierende Bereich ist `tagesplan/`'), 'pages/README.md: Tagesplan ist nicht als erste Implementierung festgelegt');

for (const note of notes) console.log(`✓ ${note}`);
console.log('✓ Semantischer Durchgang: keine Referenzblocker der Klasse B');

if (errors.length) {
  console.error(`\nVertragsprüfung fehlgeschlagen (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`\n✓ ${pageNames.length} Seitenverträge sind semantisch konsistent und bereit zur fachlichen Freigabe.`);
