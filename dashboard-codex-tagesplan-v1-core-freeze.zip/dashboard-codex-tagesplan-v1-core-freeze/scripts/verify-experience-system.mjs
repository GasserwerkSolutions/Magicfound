import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const root = process.cwd();
const files = Object.freeze({
  profiles: 'src/experience/profiles.js',
  css: 'src/styles/experience.css',
  shellCss: 'src/styles/dashboard-shell-v1.css',
  surfaceCss: 'experiments/tagesplan-vertical-agenda/surface-v1.css',
  surfaceJs: 'experiments/tagesplan-vertical-agenda/surface-v1.js',
  pageJs: 'experiments/tagesplan-vertical-agenda/page.js',
  html: 'experiments/tagesplan-vertical-agenda/index.html',
  contract: 'docs/TAGESPLAN_V1_EXECUTION_CONTRACT.md',
  adr: 'docs/decisions/ADR-007-tagesplan-v1-golden-master.md',
  freezePolicy: 'docs/TAGESPLAN_V1_FREEZE_POLICY.md',
  coreFreezeAdr: 'docs/decisions/ADR-008-technical-freeze-before-beseelung.md'
});

const failures = [];
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
for (const file of Object.values(files)) if (!fs.existsSync(path.join(root, file))) failures.push(`Fehlende Datei: ${file}`);

if (!failures.length) {
  const source = Object.fromEntries(Object.entries(files).map(([key, file]) => [key, read(file)]));
  try { new vm.Script(source.surfaceJs, { filename: files.surfaceJs }); }
  catch (error) { failures.push(`${files.surfaceJs}: JavaScript-Syntaxfehler: ${error.message}`); }

  let experienceModule;
  try {
    const encoded = Buffer.from(source.profiles, 'utf8').toString('base64');
    experienceModule = await import(`data:text/javascript;base64,${encoded}`);
  } catch (error) {
    failures.push(`${files.profiles}: Modul konnte nicht importiert werden: ${error.message}`);
  }

  if (experienceModule) {
    const { PAGE_EXPERIENCE_PROFILES, STATE_EXPERIENCE_MODIFIERS, EXPERIENCE_CONTRACT, validateExperienceRegistry } = experienceModule;
    const validation = validateExperienceRegistry();
    if (!validation.valid) validation.errors.forEach((error) => failures.push(`Wirkungsregister: ${error}`));
    for (const page of ['login', 'onboarding', 'tagesplan', 'termine', 'kundschaft', 'team', 'angebot', 'verwaltung']) {
      if (!PAGE_EXPERIENCE_PROFILES[page]) failures.push(`Fehlendes Seitenprofil: ${page}`);
    }
    for (const state of ['normal', 'loading', 'empty', 'success', 'attention', 'error', 'forbidden', 'offline', 'stale']) {
      if (!STATE_EXPERIENCE_MODIFIERS[state]) failures.push(`Fehlender Zustandsmodifikator: ${state}`);
    }
    const day = PAGE_EXPERIENCE_PROFILES.tagesplan;
    for (const id of ['present', 'breathing', 'flowing']) if (!day.primaryTerms.some((entry) => entry.id === id)) failures.push(`Tagesplan besitzt nicht: ${id}`);
    for (const id of ['attentive', 'ensouled']) if (!day.supportingTerms.some((entry) => entry.id === id)) failures.push(`Tagesplan unterstützt nicht: ${id}`);
    if (!day.antiTerms.includes('dashboard-like')) failures.push('Tagesplan schützt nicht gegen dashboardhafte Wirkung.');
    if (!day.acceptance.includes('wer arbeitet') || !day.acceptance.includes('was jetzt läuft')) failures.push('Tagesplan-Abnahmesatz ist nicht operativ genug.');
    if (!day.motion.includes('spatially stable') || !day.motion.includes('respect manual movement')) failures.push('Tagesplan-Motionregel ist unvollständig.');
    const expectedAxes = ['space-rhythm', 'material-depth', 'motion-tempo', 'attention-strength', 'illustration-presence'];
    if (JSON.stringify(EXPERIENCE_CONTRACT.controlledAxes) !== JSON.stringify(expectedAxes)) failures.push(`Unzulässige Wirkungsachsen: ${EXPERIENCE_CONTRACT.controlledAxes.join(', ')}`);
  }

  for (const forbidden of ['--va-status-confirmed', '--va-status-pending', '--va-status-arrived', '--gw-blue:', '[data-search', '.is-selected', '.status-']) {
    if (source.css.includes(forbidden)) failures.push(`Wirkungs-CSS greift in fachliche Semantik ein: ${forbidden}`);
  }
  for (const term of ["data-gw-page='tagesplan'", '--gw-experience-space-rhythm', '--gw-experience-material-depth', '--gw-experience-motion-live', '--gw-experience-illustration-presence']) {
    if (!source.css.includes(term)) failures.push(`Wirkungs-CSS enthält nicht: ${term}`);
  }
  for (const term of ['[data-gw-scroll-occluder]', 'isolation: isolate', 'contain: paint', '--gw-scroll-occluder-background']) {
    if (!source.shellCss.includes(term)) failures.push(`Projektweiter Scroll-Okklusionsvertrag enthält nicht: ${term}`);
  }
  if (!source.pageJs.includes('data-gw-scroll-occluder') || !source.surfaceCss.includes('--gw-scroll-occluder-background')) {
    failures.push('Tagesplan bindet den projektweiten Scroll-Okklusionsvertrag nicht vollständig ein.');
  }

  const surface = `${source.surfaceJs}\n${source.surfaceCss}`;
  for (const term of ['data-va-layout-regime', 'vaLayoutReady', 'calendarSurfaceClean', 'calendarVerticalOwnerCount', 'calendarGridBottomGap', 'MIN_DESKTOP_GRID_HEIGHT = 440', 'HOURS_VISIBLE = 10']) {
    if (!surface.includes(term)) failures.push(`Tagesplan-v1-Flächensystem enthält nicht: ${term}`);
  }
  for (const term of ['./surface-v1.css', './surface-v1.js', 'data-gw-page="tagesplan"', 'data-gw-core-path="surface-v1"', 'data-gw-beseelung="disabled"']) {
    if (!source.html.includes(term)) failures.push(`Tagesplan lädt oder markiert nicht: ${term}`);
  }
  for (const forbidden of ['experience.css', 'tagesplan-v1.css', 'tagesplan-v1.js']) {
    if (source.html.includes(forbidden)) failures.push(`Neutraler Tagesplan-Core bindet verbotene Ressource ein: ${forbidden}`);
  }
  if (surface.includes('--gw-experience-')) failures.push('Neutraler Tagesplan-Core konsumiert --gw-experience-* Wirkungsvariablen.');
  for (const term of ['Status: **Aktiv', 'technischer Freeze Candidate', 'Tagesplan v1.0', '44 Pixel pro Stunde', '90 %', '110 %', '125 %', 'Technischer Core Freeze', 'Beseelung beginnt erst', 'beginnt erst']) {
    if (!source.contract.includes(term)) failures.push(`Ausführungsvertrag enthält nicht: ${term}`);
  }
  for (const term of ['Status: **Accepted, amended by ADR-008**', 'feat/tagesplan-v1-golden-master', 'Geometrie', 'Technischer Core Freeze', 'Beseelungsexperimente', 'Golden-Master-Pipeline', 'Integration']) {
    if (!source.adr.includes(term)) failures.push(`ADR-007 enthält nicht: ${term}`);
  }
  for (const term of ['Status: **Verbindlich**', 'neutralen Core-Modus', 'optionale Beseelungskan\u00e4le deaktiviert', '"beseelung": "disabled"', 'finale SVG-Dienstleistungssymbole']) {
    if (!source.freezePolicy.includes(term)) failures.push(`Freeze-Richtlinie fehlt: ${term}`);
  }
  for (const term of ['Status: **Accepted**', 'Tagesplan v1.0 Core Freeze', 'keine aktivierte experimentelle Beseelungsschicht', 'neutral beziehungsweise deaktiviert', 'Core-Freeze-Tag', 'Beseelungsvarianten', 'Termine']) {
    if (!source.coreFreezeAdr.includes(term)) failures.push(`ADR-008 fehlt: ${term}`);
  }
}

if (failures.length) {
  console.error('Wirkungssystem- und Tagesplan-v1-Prüfung fehlgeschlagen:');
  failures.forEach((failure) => console.error(`- ${failure}`));
  process.exit(1);
}

console.log('✓ Wirkungssystem V1 and Tagesplan execution contract verified');
