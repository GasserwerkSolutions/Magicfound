# ADR-006 · Einfachheit mit Seele und Wirkung

Status: **Proposed**  
Datum: 2026-08-24  
Ausarbeitung: [`docs/WIRKUNGSSYSTEM_V1.md`](../WIRKUNGSSYSTEM_V1.md)

## Kontext

Die bestehende Referenzarchitektur definiert Seiten, Datenverträge, Zustände, Capabilities, Geometrie und Interaktionen bereits präzise. Sie beantwortet jedoch noch nicht systematisch, wie unterschiedliche Seiten trotz gemeinsamer Produktschale ihre jeweils angemessene menschliche, emotionale und operative Wirkung erhalten.

Qualitative Begriffe wie `atmend`, `gegenwärtig`, `beseelt`, `souverän` oder `geführt` erzeugen in Entwürfen eine grosse Wirkung. Ohne kontrollierte Definition besteht dabei das Risiko, dass:

- Begriffe nur als Promptverstärker verwendet werden;
- Seiten zufällig oder modisch auseinanderlaufen;
- dekorative Wirkung funktionale Klarheit verdrängt;
- dieselben Wörter in verschiedenen Durchgängen unterschiedliche Formen erzeugen;
- die alpine Produktwelt zu stark oder an falschen Stellen eingesetzt wird.

## Entscheidung

Gasserwerk führt ein zentrales Wirkungs- und Bedeutungssystem mit dem Leitsatz **„Einfachheit mit Seele und Wirkung.“** ein.

Das System besteht aus:

1. einer globalen handwerklichen Präzisionsschicht;
2. gemeinsamen Produktkonstanten;
3. einem begrenzten Wirkungsprofil je Seite;
4. seitenübergreifenden Zustandsmodifikatoren;
5. einer räumlichen Interaktionsgrammatik;
6. einer dosierten alpinen Seelenschicht;
7. überprüfbarer Evidenz pro Wirkungsbegriff.

Jeder Begriff muss als Form, Verhalten oder Wahrnehmung definiert sein. Primäre Seitenbegriffe müssen in mindestens drei Übersetzungskanälen sichtbar werden. Kein Wirkungsprofil darf fachliche Semantik, Accessibility, Datenwahrheit oder Performance verändern.

Die funktionale Wahrheitsreihenfolge aus den bestehenden Produkt- und Seitenverträgen bleibt bestehen. Das Wirkungssystem ist eine additive Übersetzungsschicht und darf bestehende Verträge nicht überschreiben.

## Konsequenzen

### Gewollt

- Unterschiedliche Seiten erhalten eine eigenständige, ihrer Aufgabe angemessene emotionale Temperatur.
- Die Produktschale bleibt konsistent, ohne alle Seiten gleichförmig zu machen.
- Qualitative Begriffe werden reproduzierbar und reviewbar.
- Seele entsteht aus Bedeutung, Materialität, Sprache, Bewegung und dosierter Illustration statt aus beliebiger Dekoration.
- Der Tagesplan kann als erste Referenz für eine lebende, gegenwärtige Arbeitsfläche dienen.

### In Kauf genommen

- Visuelle Verfeinerung benötigt einen zusätzlichen Reviewdurchgang.
- Begriffe und Profile müssen gepflegt und gegen Bedeutungsdrift geschützt werden.
- Nicht jede attraktive Exploration wird in das dauerhafte Produktprofil übernommen.
- Die spätere technische Umsetzung benötigt eine zentrale Profil- und Tokenebene.

## Nicht entschieden

Diese ADR entscheidet noch nicht:

- die endgültigen CSS-Werte der Wirkungskanäle;
- die konkrete Implementierung von `src/experience/profiles.js`;
- neue Illustrationen oder SVG-Assets;
- eine Änderung bestehender Statusfarben;
- die fachliche Freigabe einzelner Seitenprofile.

Diese Punkte folgen nach Abnahme von `WIRKUNGSSYSTEM_V1.md` in getrennten, überprüfbaren Schritten.
