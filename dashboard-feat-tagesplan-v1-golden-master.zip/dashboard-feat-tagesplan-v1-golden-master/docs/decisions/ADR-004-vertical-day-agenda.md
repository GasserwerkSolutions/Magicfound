# ADR-004 · Vertikale Team-Tagesfläche mit operativer Agenda

Status: **Akzeptiert – Umsetzung als direkt vergleichbare Referenzvariante**  
Datum: 2026-08-24  
Betroffene Bereiche: Tagesplan, Zeitdarstellung, Personenfokus, Agenda, responsive Projektion

## Kontext

ADR-003 führte eine vollständige horizontale Tageslandkarte ein. Der gesamte Arbeitstag war gleichzeitig sichtbar, die visuelle Prüfung zeigte jedoch keinen ausreichenden Gewinn an operativer Übersicht. Terminkarten wurden sehr schmal und die Fläche wirkte weniger ruhig als die frühere vertikale Zeitdarstellung.

Die vertikale Grammatik wird deshalb auf das gesamte Team übertragen: Zeit läuft von oben nach unten, Mitarbeitende stehen als Spalten nebeneinander und eine operative Agenda beantwortet die Reihenfolgefrage.

Ein erster Ansatz wollte den vorherigen, laufenden und nächsten Termin jeweils mit einem eigenen Kartenton markieren. Die genauere Prüfung ergibt eine sauberere Systemlösung: Nicht jede Karte erhält einen zusätzlichen Zeitstatus. Die Kalenderfläche selbst zeigt einheitlich, welcher Tagesanteil bereits vergangen ist. Statuskante und fachliche Terminfarbe bleiben dadurch von zeitlicher Lage getrennt.

## Entscheidung

### 1. Vertikale Team-Tagesfläche als primäre Geometrie

Der Tagesplan zeigt:

- Zeit von `08:00` bis `18:00` von oben nach unten,
- alle aktiven Mitarbeitenden als gleichwertige Spalten,
- eine gemeinsame linke Zeitachse,
- eine horizontale Jetzt-Linie über Zeitachse und Teamfläche,
- den vollständigen Arbeitstag ohne horizontalen Kalender-Scroll,
- zusätzliche Bahnen nur bei echten Überschneidungen.

Dauer wird über die reale Kartenhöhe kommuniziert. Karten werden weder künstlich verlängert noch unabhängig von der Dauer verkürzt.

### 2. Zeitachse als primäre Orientierung

Das Raster verwendet:

- 15 Minuten: feinste Linie,
- 30 Minuten: mittlere Linie,
- 60 Minuten: klare Stundenlinie.

`09:00`, `12:00`, `15:00` und `18:00` werden als Hauptanker hervorgehoben. `08:00` bleibt als Tagesbeginn sichtbar.

Auf ausreichend hohen Karten wird Start- und Endzeit sichtbar bestätigt. Kürzere Karten bewahren die vollständige Zeit im zugänglichen Namen, in der Agenda und im Kontextpanel.

### 3. Globale vergangene Zeitfläche statt Kartentönen

Auf dem heutigen Tag und nur innerhalb der Öffnungszeit liegt vom Tagesbeginn bis zur aktuellen Salonzeit eine einzige, gleichmässige vergangene Zeitfläche.

Verbindlich:

- keine Dreiteilung der Karten in `Davor`, `Jetzt` und `Danach`,
- kein Verlauf von stärkerer zu schwächerer Vergangenheit,
- ein einheitlicher neutraler Schatten mit exakter Abschlusskante,
- erster Kalibrierwert: **5 Prozent zusätzliche Dunkelheit**,
- zulässiger Prüfbereich: **4 bis 6 Prozent**,
- Werte über **8 Prozent sind nicht zulässig**,
- die Tönung läuft über Zeitachse und alle Mitarbeitendenspalten,
- Karten bleiben bedienbar und fachlich unverändert,
- die Jetzt-Linie markiert die exakte Grenze.

Der laufende Termin wird physisch verständlich, weil Vergangenheit, Jetzt-Grenze und Zukunft seine reale Kartenhöhe schneiden. Die Oberfläche beantwortet die Zeitlage; die Karte beantwortet Kundschaft, Leistung und fachlichen Status.

### 4. Ebenenordnung

Die visuelle Stapelung ist verbindlich:

1. Grundfläche und Zeitraster,
2. globale vergangene Zeitfläche,
3. Termine, Aufgaben und Pausen,
4. Fokusmaske auf nicht fokussierten Spalten,
5. Jetzt-Linie, Suchtreffer, Auswahl und Tastaturfokus.

Die Zeitfläche bleibt global. Personenfokus darf sie weder neu berechnen noch unterbrechen.

### 5. Operative Agenda „Als Nächstes“

Die Agenda verwendet dieselben normalisierten Terminobjekte wie der Kalender und keine eigene Datenquelle.

Sie zeigt:

1. den zuletzt beendeten relevanten Termin unter `Davor`,
2. alle laufenden relevanten Termine unter `Jetzt`,
3. die nächsten fünf Termine unter `Danach`,
4. optional die nächste freie Lücke von mindestens 30 Minuten.

Die Abschnitte sind textliche Orientierung und erhalten keine separaten Kartentöne. Eine Zeile zeigt Start und Ende, Kundschaft, Leistung, zuständige Person und nur handlungsrelevante Statushinweise.

Kalender und Agenda teilen Auswahl und Kontextpanel.

### 6. Personenfokus ohne Geometriewechsel

Personenfokus ist ein Aufmerksamkeitszustand derselben Teamfläche.

- Alle Mitarbeitendenspalten bleiben vorhanden.
- Die fokussierte Spalte bleibt in normalem Kontrast.
- Die übrigen Spalten erhalten eine neutrale Fokusmaske.
- Ausgangswert der Fokusmaske: **34 Prozent**.
- Zulässiger Prüfbereich: **30 bis 38 Prozent**.
- Keine pauschale `opacity` auf dem gesamten Spaltencontainer.
- Köpfe, Trefferflächen und Interaktion bleiben erhalten.
- Suchtreffer, Auswahl und Tastaturfokus durchbrechen die Maske.
- Öffnen eines Termins in einer anderen Spalte überträgt den Fokus auf diese Person.
- Klick auf denselben Personenkopf oder `Escape` hebt den Fokus auf.
- Es gibt keinen zweiten Einpersonen-Renderer.

### 7. Responsive Projektion

#### Desktop und 14 Zoll

- fünf Mitarbeitende und Agenda sind gleichzeitig sichtbar,
- Agenda ungefähr 270 bis 300 Pixel breit,
- kein horizontaler Gesamtseiten- oder Kalender-Scroll,
- der komplette Tag nutzt die verfügbare Höhe.

#### Schmaler Desktop und Tablet

- Kalender bleibt primär,
- Agenda darf unter den Kalender wandern,
- alle Mitarbeitendenspalten bleiben Teil derselben Fläche.

#### Mobil

- Agenda steht zuerst,
- danach folgt dieselbe vertikale Teamfläche,
- Personenköpfe werden auf Initialen verdichtet,
- Personenfokus dimmt Nachbarspalten, statt zu einem Einzelkalender zu wechseln,
- der Kalenderkörper darf intern vertikal scrollen,
- die Gesamtseite läuft horizontal nicht über.

## Invarianten

- Zeit, Raster, Karten, vergangene Fläche und Jetzt-Linie verwenden dieselbe Minutenachse.
- Statusfarbe und zeitliche Lage bleiben semantisch getrennt.
- Kalender und Agenda verwenden dieselben Terminobjekte.
- Interne Aufgaben und Pausen bleiben visuell eigenständig.
- Auf anderen Tagen gibt es keine vergangene Echtzeitfläche und keine Jetzt-Linie.
- Personenfokus ändert weder Spaltenzahl noch Geometrie.
- Backend-Endpunkte und Persistenz werden nicht vorweggenommen.
- Die horizontale Volltagsvariante bleibt archiviert.

## Abnahme

Die Variante wird bei `1366×768`, `1440×900`, `1512×982`, `1920×1080`, `390×844` und `844×390` geprüft.

Zusätzlich werden deterministisch geprüft:

- Salonzeit `11:22`,
- genau eine vergangene Zeitfläche,
- fünf sichtbare Mitarbeitendenspuren,
- vier Kontextspalten bei Fokus auf Melanie,
- sichtbare Start-/Endzeiten auf ausreichend hohen Karten,
- keine `is-sequence-before/current/next`-Klassen,
- kein horizontaler Gesamtseitenüberlauf,
- synchroner Auswahlzustand zwischen Kalender und Agenda.

## Ablösung

ADR-004 löst die horizontale Tagesplangeometrie aus ADR-003 ab. Aus ADR-003 bleiben Arbeitsuhr, vier globale Navigationsziele und integrierte card-first Verwaltung gültig.

## Nicht Bestandteil

- Drag-and-drop oder Resize,
- produktive Backendintegration,
- persistente Mutationen,
- endgültige Frameworkentscheidung,
- finaler SVG-Dienstleistungssatz.
