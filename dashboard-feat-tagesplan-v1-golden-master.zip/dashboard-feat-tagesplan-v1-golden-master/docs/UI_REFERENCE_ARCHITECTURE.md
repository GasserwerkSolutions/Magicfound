# Gasserwerk Dashboard · seitenbasierte UI-Referenzarchitektur

## Entscheidung

Solange das Backend noch in Arbeit ist, wird dieses Repository als **ausführbare Frontend-Referenz und Integrationsvorlage** geführt.

Die Navigationsziele werden als eigenständig startbare Seiten aufgebaut. Gemeinsame Produktschale, Komponenten, Tokens, Zustände und Mock-Daten werden jedoch **nicht pro Seite kopiert**, sondern zentral geteilt.

Die aktuelle vollständige `index.html` bleibt vorerst als Vergleichs- und Veröffentlichungsartefakt erhalten. Sie ist künftig nicht mehr die primäre Bearbeitungsquelle.

## Zielbild

Jede Seite soll später einzeln in die reale Anwendung übernommen werden können und dafür Folgendes liefern:

- eigenständig aufrufbare Referenzseite
- klar abgegrenzte Seitenlogik
- gemeinsame Komponenten statt lokaler Kopien
- dokumentierter Datenvertrag
- Mock-Daten für alle relevanten Zustände
- Responsive- und Tastaturverhalten
- visuelle Abnahmereferenzen
- definierte Ereignisse für die spätere Backend-Integration

## Repository-Struktur

```text
/
├── index.html                     # Vorschau-Startpunkt / später generiertes Gesamtartefakt
├── 404.html                       # GitHub-Pages-Fallback / generiertes Artefakt
├── pages/
│   ├── login/
│   │   ├── index.html
│   │   ├── page.js
│   │   ├── page.css
│   │   └── CONTRACT.md
│   ├── onboarding/
│   ├── tagesplan/
│   ├── termine/
│   ├── kundschaft/
│   ├── team/
│   ├── angebot/
│   └── verwaltung/
├── src/
│   ├── shell/
│   │   ├── app-shell.js
│   │   ├── sidebar.js
│   │   ├── product-header.js
│   │   └── mobile-navigation.js
│   ├── components/
│   │   ├── buttons.js
│   │   ├── date-picker.js
│   │   ├── search-surface.js
│   │   ├── context-panel.js
│   │   ├── status-chip.js
│   │   └── empty-state.js
│   ├── styles/
│   │   ├── tokens.css
│   │   ├── reset.css
│   │   ├── shell.css
│   │   ├── components.css
│   │   ├── density.css
│   │   └── responsive.css
│   ├── data/
│   │   ├── contracts/
│   │   ├── fixtures/
│   │   ├── mock-dashboard-data-source.js
│   │   └── dashboard-data-source.js
│   └── lib/
│       ├── dates.js
│       ├── time.js
│       ├── focus.js
│       └── dom.js
├── tests/
│   ├── smoke/
│   ├── interaction/
│   └── screenshots/
└── docs/
```

Die Struktur ist zunächst frameworkneutral. Semantisches HTML, CSS und ES-Module halten die Referenz direkt ausführbar. Sobald die Produktionsanwendung und ihr Framework verbindlich feststehen, können die Seitenmodule ohne vorherige Rückübersetzung in das Zielsystem überführt werden.

## Was eine Seite ist

Eine eigene Seite entspricht einem dauerhaften Navigationsziel:

1. Login
2. Onboarding
3. Tagesplan
4. Termine
5. Kundschaft
6. Team
7. Angebot
8. Verwaltung

## Was keine eigene Seite ist

Folgende Elemente bleiben Zustände oder Komponenten ihrer fachlichen Seite:

- Teamarbeitsfläche, Ganztagesmassstab und Personenfokus: Zustände des Tagesplans
- Datumsauswahl: gemeinsame Komponente
- mobile Suche: gemeinsame Komponente
- Termin eintragen: Kontextfläche
- Termin ansehen oder bearbeiten: Kontextfläche
- Kundenkartei: Detailzustand der Kundschaftsseite
- leere, geladene, fehlerhafte und konfliktbehaftete Zustände: Zustände der jeweiligen Seite

Dadurch wird die Navigation nicht mit technischen Varianten aufgebläht.

## Gemeinsame Produktschale

Sidebar, Produktkopf, mobile Navigation, Grundfarben, Dichte und Typografie werden nur einmal definiert.

Jede Seite liefert ausschließlich ihren Arbeitsbereich und ihre Seitenevents. So bleiben Navigation, Abstände und Produktidentität über alle Seiten konsistent.

Eine Seite darf gemeinsame Komponenten konfigurieren, aber nicht lokal nachbauen.

## Backend-unabhängige Datengrenze

Die Seiten greifen nicht direkt auf Mock-Objekte oder spätere HTTP-Endpunkte zu. Sie verwenden eine gemeinsame Datenquelle:

```js
export class DashboardDataSource {
  getDayPlan(date) {}
  listAppointments(filters) {}
  getAppointment(id) {}
  listCustomers(query) {}
  getCustomer(id) {}
  listStaff() {}
  listServices() {}
  getAdministrationSettings() {}
}
```

Während der Referenzphase liefert `mock-dashboard-data-source.js` die Daten. Später implementiert ein Produktionsadapter dieselben fachlichen Methoden gegen das echte Backend.

Die UI bleibt dadurch unabhängig von:

- API-URL
- Authentifizierungsverfahren
- Transportformat
- Ladebibliothek
- Backend-Releasezeitpunkt

## Seitenvertrag

Jede Seite erhält eine `CONTRACT.md` mit genau diesen Abschnitten:

1. Zweck und primäre Arbeitsaufgabe
2. Eingabedaten
3. fachliches View-Model
4. ausgehende Ereignisse
5. Ladezustand
6. Leerzustand
7. Fehlerzustand
8. Berechtigungszustände
9. Desktopverhalten
10. Mobilverhalten
11. Tastatur und Fokus
12. Abnahmekriterien
13. Integrationshinweise

Dieser Vertrag ist die eigentliche Übergabegrundlage für die spätere Implementierung im echten Programm.

## Ereignisse statt Backend-Aufrufe

Seiten melden fachliche Absichten:

```text
appointment:create-requested
appointment:selected
appointment:move-requested
customer:selected
staff:focus-requested
day:changed
search:submitted
```

Ob diese Ereignisse später einen API-Aufruf, eine Route, einen Store oder einen Server-Action auslösen, entscheidet die Produktionsanwendung.

## Migration der bestehenden Referenz

Die aktuelle Gesamtoberfläche wird nicht blind in mehrere vollständige HTML-Kopien zerlegt. Das würde Sidebar, Header, Komponenten und CSS achtfach duplizieren und später auseinanderlaufen lassen.

Stattdessen erfolgt die Migration in dieser Reihenfolge:

### 1. Gemeinsame Basis

- Designtokens
- Dichtevertrag
- Produktschale
- Navigation
- Header
- gemeinsame Overlays
- Mock-Datenquelle

### 2. Tagesplan

Der Tagesplan wird zuerst migriert, weil er die meisten gemeinsamen Regeln festlegt:

- horizontale Teamarbeitsfläche
- Live-Zeitcontroller und Jetzt-Anker
- 15-/30-/60-Minuten-Raster
- Ganztagesmassstab
- vertikaler Personenfokus
- Datumswechsel
- Buchungs- und Terminpanel

### 3. Kundschaft

- Liste
- Suche
- Kundenkartei als Detailzustand
- Termin aus Kundenkontext starten

### 4. Termine

- Register
- Filter
- Statusdarstellung
- Öffnen des gemeinsamen Terminpanels

### 5. Team, Angebot und Verwaltung

Diese Seiten verwenden anschliessend bereits etablierte Karten-, Listen-, Formular- und Berechtigungsmuster.

### 6. Login und Onboarding

Diese Flächen werden zuletzt in die neue gemeinsame Basis überführt, weil sie ausserhalb des normalen Arbeitsrahmens liegen.

## Ausführbare Referenz pro Seite

Jede Seite muss über GitHub Pages direkt erreichbar sein, beispielsweise:

```text
/dashboard/pages/tagesplan/
/dashboard/pages/kundschaft/
/dashboard/pages/team/
```

Relative Importe müssen deshalb von der Projektseitenbasis aus funktionieren. Absolute Root-Pfade werden vermieden.

## Umgang mit `index.html` und `404.html`

Während der Migration bleiben beide bestehenden Dateien unverändert funktionsfähig.

Nach Abschluss der seitenweisen Migration werden sie aus den modularen Quellen erzeugt oder auf die neue Vorschau verweisen. Sie werden dann als Release-Artefakte behandelt und nicht mehr von Hand gepflegt.

## Abnahme pro Seite

Eine Seite gilt erst als übergabefähig, wenn:

- sie direkt aufrufbar ist
- sie keine andere Seite zum Start benötigt
- alle gemeinsamen Komponenten importiert statt kopiert werden
- ihr Datenvertrag dokumentiert ist
- Mock-Daten Lade-, Leer-, Normal- und Fehlerzustände abdecken
- Desktop und Mobil geprüft sind
- Tastatur- und Fokusführung funktionieren
- keine Gesamtseite horizontal überläuft
- die 14-Zoll-Dichte geprüft ist
- Screenshots und Smoke-Tests vorhanden sind

## Nicht Bestandteil dieser Strukturphase

- echte Backend-Endpunkte
- produktive Authentifizierung
- persistente Mutationen
- Drag-and-drop von Terminen
- endgültige Frameworkentscheidung
- endgültiger Deploymentprozess der Produktionsanwendung

Diese Punkte werden erst auf der stabilen, seitenbasierten Referenz aufgebaut.
