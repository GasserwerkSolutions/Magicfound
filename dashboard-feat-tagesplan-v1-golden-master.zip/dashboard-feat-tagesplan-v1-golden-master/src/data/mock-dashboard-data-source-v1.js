import { DashboardDataSource } from './contracts/dashboard-data-source.js';
import { CAPABILITY_VALUES } from './contracts/capabilities.js';
import { createDayPlanFixture, DAY_PLAN_STAFF_FIXTURE } from './fixtures/day-plan-v1.js';

const DATE_FORMATTER = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Europe/Zurich',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit'
});

const CLOCK_FORMATTER = new Intl.DateTimeFormat('de-CH', {
  timeZone: 'Europe/Zurich',
  hour: '2-digit',
  minute: '2-digit',
  hour12: false
});

function partsToIsoDate(parts) {
  const map = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${map.year}-${map.month}-${map.day}`;
}

function minutesInSalonTime(instant) {
  const parts = Object.fromEntries(CLOCK_FORMATTER.formatToParts(instant).map((part) => [part.type, part.value]));
  return Number(parts.hour) * 60 + Number(parts.minute);
}

function clone(value) {
  return globalThis.structuredClone ? structuredClone(value) : JSON.parse(JSON.stringify(value));
}

function matchesQuery(value, query) {
  if (!query) return true;
  return value.toLocaleLowerCase('de-CH').includes(query.toLocaleLowerCase('de-CH'));
}

/**
 * Deterministic backend-independent adapter used by the modular page references.
 * It deliberately returns normalized UI view-model inputs rather than historical
 * single-file-demo objects.
 */
export class MockDashboardDataSourceV1 extends DashboardDataSource {
  constructor(options = {}) {
    super();
    this.nowProvider = options.nowProvider ?? (() => new Date());
    this.defaultDate = options.defaultDate ?? null;
  }

  getSessionContext() {
    return Promise.resolve(Object.freeze({
      account: Object.freeze({
        id: 'account-melanie',
        displayName: 'Melanie Schneider',
        initials: 'MS',
        productRoleLabel: 'Inhaberin'
      }),
      salon: Object.freeze({
        id: 'salon-sonnegg',
        name: 'Coiffure Sonnegg',
        locationId: 'location-zuerich-enge',
        locationLabel: 'Zürich Enge',
        timeZone: 'Europe/Zurich'
      }),
      capabilities: CAPABILITY_VALUES,
      locale: 'de-CH',
      currency: 'CHF'
    }));
  }

  getAuthenticationOptions() {
    return Promise.resolve(Object.freeze({ methods: ['password', 'magic-link'], passwordResetAvailable: true }));
  }

  getOnboardingState() {
    return Promise.resolve(Object.freeze({ currentStepId: 'complete', readiness: { isBookable: true, blockers: [], warnings: [] } }));
  }

  getDayPlan(query = {}) {
    const now = this.nowProvider();
    const today = partsToIsoDate(DATE_FORMATTER.formatToParts(now));
    const date = query.date ?? this.defaultDate ?? today;
    const fixture = createDayPlanFixture(date);
    return Promise.resolve(Object.freeze({
      ...clone(fixture),
      isToday: date === today,
      currentMinute: date === today ? minutesInSalonTime(now) : null,
      clockInstant: now.toISOString(),
      state: 'ready'
    }));
  }

  async listAppointments(query = {}) {
    const date = query.dateFrom ?? query.date ?? this.defaultDate ?? partsToIsoDate(DATE_FORMATTER.formatToParts(this.nowProvider()));
    const plan = await this.getDayPlan({ date });
    const queryText = query.customerQuery ?? query.text ?? '';
    return plan.appointments.filter((appointment) => {
      if (query.statuses?.length && !query.statuses.includes(appointment.status)) return false;
      if (query.staffIds?.length && !query.staffIds.includes(appointment.staff.id)) return false;
      return matchesQuery(`${appointment.customer.displayName} ${appointment.service.displayName} ${appointment.staff.displayName}`, queryText);
    });
  }

  async getAppointment(id) {
    const appointments = await this.listAppointments({});
    return appointments.find((appointment) => appointment.id === id) ?? null;
  }

  listCustomers(query = {}) {
    const text = query.text ?? '';
    const customers = createDayPlanFixture(this.defaultDate ?? partsToIsoDate(DATE_FORMATTER.formatToParts(this.nowProvider()))).appointments
      .map((appointment) => appointment.customer)
      .filter((customer, index, list) => list.findIndex((item) => item.id === customer.id) === index)
      .filter((customer) => matchesQuery(customer.displayName, text));
    return Promise.resolve(clone(customers));
  }

  async getCustomer(id) {
    const customers = await this.listCustomers({});
    return customers.find((customer) => customer.id === id) ?? null;
  }

  listStaff(query = {}) {
    const text = query.text ?? '';
    return Promise.resolve(clone(DAY_PLAN_STAFF_FIXTURE.filter((person) => matchesQuery(`${person.displayName} ${person.professionalRoleLabel}`, text))));
  }

  async getStaffMember(id) {
    const people = await this.listStaff({});
    return people.find((person) => person.id === id) ?? null;
  }

  listServices() {
    const services = createDayPlanFixture(this.defaultDate ?? partsToIsoDate(DATE_FORMATTER.formatToParts(this.nowProvider()))).appointments
      .map((appointment) => ({ ...appointment.service, durationMinutes: appointment.durationMinutes, price: appointment.price, isActive: true }))
      .filter((service, index, list) => list.findIndex((item) => item.id === service.id) === index);
    return Promise.resolve(clone(services));
  }

  async getService(id) {
    const services = await this.listServices({});
    return services.find((service) => service.id === id) ?? null;
  }

  getAdministrationSettings() {
    return Promise.resolve(Object.freeze({ sections: [], productPreferences: { themeMode: 'system', installAvailable: false } }));
  }
}

export function createMockDashboardDataSourceV1(options) {
  return new MockDashboardDataSourceV1(options);
}
