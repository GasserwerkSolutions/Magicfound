# Login · Seitenvertrag

Status: **Zur Freigabe – Oberflächen- und Ereignisvertrag konsolidiert, Authentifizierungsverfahren integrationsrelevant**  
Verantwortlicher Bereich: `Authentifizierung`  
Direkter Referenzpfad: `/dashboard/pages/login/`  
Abhängige gemeinsame Verträge: `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

Die Loginseite ermöglicht den kontrollierten Eintritt in das Gasserwerk Dashboard.

Primäre Arbeitsaufgabe:

- eine unterstützte Anmeldemethode wählen und eine Anmeldeabsicht auslösen

Die Seite bleibt produktbezogen und ruhig. Die alpine Welt lebt nur als dosierte Atmosphäre innerhalb der Fläche; die Anmeldekarte bleibt dominant.

Nicht Bestandteil der Referenz:

- echte Credentialprüfung
- Speicherung von Passwörtern
- endgültige Sessionverwaltung
- endgültige MFA- oder SSO-Entscheidung
- produktive Passwortzurücksetzung

## 2. Eingabedaten

Datenquellenmethoden beziehungsweise Integrationskontext:

```js
getSessionContext()
getAuthenticationOptions()
```

Normalisierter Eingang:

```js
{
  sessionState: "anonymous" | "authenticated" | "expired",
  product: {
    name,
    salonName,
    locationLabel
  },
  authenticationMethods: [
    "password" | "magic-link" | "sso" | "passkey"
  ],
  passwordResetAvailable,
  maintenanceMessage,
  returnTarget,
  capabilities: ["auth:sign-in"]
}
```

Die Referenz muss mindestens Passwort und Magic-Link als demonstrierbare Oberflächenzustände abbilden, ohne eine produktive Unterstützung zu behaupten.

## 3. Fachliches View-Model

```js
{
  heading,
  description,
  fields: [
    {
      id,
      type,
      label,
      autocomplete,
      required,
      value,
      error
    }
  ],
  methods: {
    password,
    magicLink,
    sso,
    passkey
  },
  actions: {
    submit,
    resetPassword,
    useMagicLink
  },
  submissionState: "idle" | "submitting" | "error" | "success",
  maintenanceMessage,
  returnTarget
}
```

Invarianten:

- Passwörter werden nie als voreingefüllte produktive Werte behandelt.
- Demo-Credentials müssen klar als Simulation gekennzeichnet sein und dürfen nicht übertragen werden.
- Authentifizierungsmethoden werden nur angezeigt, wenn sie im View-Model verfügbar sind.
- Der `returnTarget` darf nur auf einen validierten internen Produktpfad zeigen.
- Ein bereits authentifizierter Zustand leitet nicht stillschweigend auf eine externe URL.

## 4. Ausgehende Ereignisse

### Passwortanmeldung

```js
{
  type: "auth:sign-in-requested",
  payload: {
    method: "password",
    identifier,
    password,
    returnTarget
  }
}
```

Credentialwerte dürfen nicht in Logs, Analytics oder Fehlermeldungen landen.

### Magic Link

```js
{
  type: "auth:magic-link-requested",
  payload: { identifier, returnTarget }
}
```

### Passwort zurücksetzen

```js
{
  type: "auth:password-reset-requested",
  payload: { identifier }
}
```

### Spätere Methoden

```js
{
  type: "auth:sign-in-requested",
  payload: { method: "sso" | "passkey", providerId, returnTarget }
}
```

Diese Varianten werden nur emittiert, wenn sie vom Integrationskontext geliefert werden.

## 5. Ladezustand

- Produktidentität und Seitenrahmen bleiben sichtbar.
- Die Anmeldekarte zeigt einen klaren Ladezustand, während Methoden oder Sessionstatus ermittelt werden.
- Es werden keine Felder gezeigt, deren Verfügbarkeit noch unbekannt ist.
- Ein Sessioncheck darf die Seite nicht flackernd zwischen Login und Dashboard wechseln lassen.
- Fokus wird nach Abschluss des Ladens auf das erste erforderliche Feld oder die primäre Methode gesetzt.

## 6. Leerzustand

Ein fachlicher Leerzustand bedeutet: keine Anmeldemethode ist verfügbar.

- Es erscheint eine klare Meldung, dass Anmeldung derzeit nicht möglich ist.
- Ein Retry oder Supporthinweis kann angeboten werden.
- Es wird kein funktionsloses Formular angezeigt.
- Eine dekorative Illustration darf die Fehlersituation nicht verharmlosen.

## 7. Fehlerzustand

Validierungsfehler:

- stehen direkt am betroffenen Feld
- enthalten keine sensiblen technischen Details
- verschieben den Fokus zum ersten Fehler

Authentifizierungsfehler:

- verwenden eine neutrale Meldung, die keine Account-Existenz offenlegt, sofern der Authvertrag dies verlangt
- erhalten Eingabewerte ausser Passwort nach einer fehlgeschlagenen Anfrage, sofern sicher
- löschen oder schützen Passwortwerte gemäss Produktionsframework

Netzwerk-/Systemfehler:

- bieten Retry
- unterscheiden sich visuell und semantisch von falschen Zugangsdaten
- zeigen eine Korrelations-ID nur in nicht sensibler Form, wenn vorhanden

Abgelaufene Session:

- erklärt knapp, warum eine erneute Anmeldung nötig ist
- behält einen validierten internen Return-Target

## 8. Berechtigungszustände

Die Loginseite benötigt keine bestehende Produktrolle.

- `auth:sign-in` steuert, ob eine Anmeldung angeboten werden kann.
- Ein gesperrter oder nicht zugelassener Account wird durch einen Authentifizierungsstatus des Adapters dargestellt, nicht durch UI-seitige Rollenableitung.
- Berechtigungen innerhalb des Produkts werden erst nach erfolgreicher Session geladen.
- Es werden keine internen Salon- oder Kundendaten vor erfolgreicher Anmeldung in das View-Model aufgenommen.

## 9. Desktopverhalten

- Login verwendet eine auth-spezifische Schalenvariante ohne normale Sidebar.
- Produktidentität und Anmeldekarte bilden die primäre Komposition.
- Illustration beziehungsweise alpine Welt bleibt auf den unteren beziehungsweise seitlichen atmosphärischen Bereich begrenzt.
- Die Karte bleibt bei 14-Zoll-Dichte vollständig sichtbar und gut lesbar.
- Die Seite darf bei geringer Höhe vertikal scrollen, statt Felder unlesbar zu komprimieren.
- Hauptfelder und primäre Aktion besitzen klare, konsistente Breiten.

## 10. Mobilverhalten

- Markenfläche darf reduziert oder ausgeblendet werden; die Anmeldekarte bleibt vollständig.
- Die Seite verwendet die volle mobile Fläche ohne normale Bottom-Navigation.
- Bei eingeblendeter Bildschirmtastatur bleibt die primäre Aktion erreichbar.
- Formularinhalt scrollt vertikal, wenn die verfügbare Höhe nicht reicht.
- Touch-Ziele sind mindestens 44 × 44 CSS-Pixel.
- Autofill und Passwortmanager dürfen nicht durch ungewöhnliche DOM-Strukturen behindert werden.

## 11. Tastatur und Fokus

- Der Eintrittsfokus liegt auf dem ersten erforderlichen Eingabefeld beziehungsweise der primären Anmeldemethode.
- Labels sind programmatisch mit Feldern verbunden.
- `Enter` im Formular löst genau eine Anmeldeabsicht aus.
- Während `submitting` wird eine doppelte Übermittlung verhindert, ohne Fokus zu verlieren.
- Feldfehler werden über `aria-describedby` verknüpft.
- Statusänderungen werden über eine Live-Region angekündigt.
- Passwortanzeigen/-verbergen erhält einen klaren zugänglichen Namen, falls ergänzt.

## 12. Abnahmekriterien

- Seite ist direkt aufrufbar und benötigt keine Dashboardseite.
- Authentifizierungsoptionen werden ausschliesslich aus dem Integrationskontext gerendert.
- Demo-Zustand ist eindeutig als Simulation gekennzeichnet.
- Credentialwerte erscheinen nicht in Logs, URL oder sichtbaren Debugdaten.
- Lade-, keine-Methode-, Validierungs-, Auth-, Netzwerk-, Session-abgelaufen- und Erfolgszustände sind vorhanden.
- Desktop, 14-Zoll, Mobil Hochformat, Mobil Querformat und Bildschirmtastaturzustand sind geprüft.
- Formular ist mit Tastatur, Autofill und Passwortmanager nutzbar.
- Fokus- und Fehlermeldungslogik funktioniert.
- Keine normale Sidebar oder Bottom-Navigation erscheint im Loginzustand.
- Keine Gesamtseite läuft horizontal über.

## 13. Integrationshinweise

- Offene Fragen: `Q-001`, `Q-003`, `Q-005`, `Q-006`, `Q-AUTH-001` bis `Q-AUTH-003`.
- Der Produktionsadapter beziehungsweise das Authframework übernimmt Credentialtransport, Session, CSRF, MFA und sichere Fehlernormalisierung.
- Die Referenz bildet nur Anmeldeabsichten und sichtbare Zustände ab.
- Return-Targets müssen server- beziehungsweise frameworkseitig validiert werden.
- Keine Referenzfixture darf echte Zugangsdaten enthalten.
