#!/usr/bin/env python3
"""Static CSS evidence: token declaration and var-reference inventory in inline CSS.
This is potential impact only; use browser intervention for empirically observed impact.
"""
import argparse, collections, json, re
from pathlib import Path
from html.parser import HTMLParser
import tinycss2

RE_VAR=re.compile(r'var\(\s*(--[a-zA-Z0-9_-]+)')

class Capture(HTMLParser):
 def __init__(self): super().__init__(convert_charrefs=False);self.in_style=False;self.chunks=[];self.current=None
 def handle_starttag(self,tag,attrs):
  if tag=='style': self.in_style=True;self.current={'startLine':self.getpos()[0], 'text':'', 'kind':dict(attrs).get('id')}
 def handle_data(self,data):
  if self.in_style:self.current['text']+=data
 def handle_endtag(self,tag):
  if tag=='style' and self.in_style:self.chunks.append(self.current);self.current=None;self.in_style=False

def analysis(html):
 doc=Capture();doc.feed(html)
 usages=[]; declarations=[];alias_edges=[];parse_errors=[]
 def recur(rules,owner,ctx,style_idx,base_line):
  for rule in rules:
   if rule.type=='qualified-rule':
    selector=tinycss2.serialize(rule.prelude).strip()
    ds=tinycss2.parse_declaration_list(rule.content,skip_whitespace=True,skip_comments=True)
    for d in ds:
     if d.type=='declaration':
      name=d.name;v=tinycss2.serialize(d.value).strip()
      deps=RE_VAR.findall(v)
      loc={'selector':selector,'property':name,'value':v,'styleIndex':style_idx,
           'sourceLineApprox':base_line+rule.source_line-1,'context':ctx}
      if name.startswith('--'):declarations.append({'token':name,**loc})
      for x in deps:
       usages.append({'token':x,**loc})
       if name.startswith('--'):alias_edges.append({'fromToken':x,'toToken':name,'selector':selector,'context':ctx})
     elif d.type=='error': parse_errors.append({'styleIndex':style_idx,'message':d.message})
   elif rule.type=='at-rule' and rule.content is not None:
    new_ctx=ctx+[f"@{rule.at_keyword} {tinycss2.serialize(rule.prelude).strip()}"]
    if rule.at_keyword in ('media','supports','container','layer','scope','starting-style'):
     nested=tinycss2.parse_rule_list(rule.content,skip_whitespace=True,skip_comments=True)
     recur(nested,owner,new_ctx,style_idx,base_line)
    elif rule.at_keyword=='font-face':
     # Not a selector rule, keep at-rule context but no interactive source matching
     for d in tinycss2.parse_declaration_list(rule.content,skip_comments=True,skip_whitespace=True):
      if d.type=='declaration':
       v=tinycss2.serialize(d.value);deps=RE_VAR.findall(v)
       for x in deps:usages.append({'token':x,'selector':'@font-face','property':d.name,'value':v,'context':new_ctx,'styleIndex':style_idx,'sourceLineApprox':base_line+rule.source_line-1})
   elif rule.type=='error':parse_errors.append({'styleIndex':style_idx,'message':rule.message})
 for i,ch in enumerate(doc.chunks):
  rules=tinycss2.parse_stylesheet(ch['text'],skip_comments=True,skip_whitespace=True)
  recur(rules,None,[],i,ch['startLine'])
 tokens={}
 for tok in sorted(set([u['token'] for u in usages]+[d['token'] for d in declarations])):
  uu=[x for x in usages if x['token']==tok];dd=[x for x in declarations if x['token']==tok]
  tokens[tok]={'declarations':len(dd),'references':len(uu),'selectorRules':[f"{z['selector']} :: {z['property']}" for z in uu],
               'conditionalContexts':sorted(set(str(z['context']) for z in uu)),
               'sourceLines':sorted(set(z['sourceLineApprox'] for z in uu)),
               'aliasesInto':[x['toToken'] for x in alias_edges if x['fromToken']==tok]}
 return {'schema':'css-token-static-source-map/v1',
  'scope':'Only inline <style> blocks in the supplied HTML; JS-added styles and external CSS excluded',
  'meaning':'Source references are potential dependencies, not proof of computed effect',
  'styleBlockCount':len(doc.chunks),'tokenCount':len(tokens),'references':usages,'declarations':declarations,
  'aliasEdges':alias_edges,'parseErrors':parse_errors,'tokens':tokens}

def main():
 p=argparse.ArgumentParser();p.add_argument('--html',required=True);p.add_argument('--output',required=True);a=p.parse_args();d=analysis(Path(a.html).read_text())
 o=Path(a.output);o.parent.mkdir(parents=True,exist_ok=True);o.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 print('Stylesheets:',d['styleBlockCount'],'tokens:',d['tokenCount'],'references:',len(d['references']),'aliases:',len(d['aliasEdges']),'parserErrors:',len(d['parseErrors']))
 for t in ['--brand','--surface','--radius','--border']: print(t,d['tokens'].get(t,{}).get('references',0),'references')
if __name__=='__main__':main()
