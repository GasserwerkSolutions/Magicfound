import { readFileSync, existsSync } from 'node:fs';
import { extname, resolve } from 'node:path';

const root = process.cwd();
const errors = [];
const notes = [];

function read(path) {
  const absolute = resolve(root, path);
  if (!existsSync(absolute)) {
    errors.push(`Fehlende Datei: ${path}`);
    return '';
  }
  return readFileSync(absolute, 'utf8');
}

function assert(condition, message) {
  if (!condition) errors.push(message);
}

function compileInlineScripts(html, sourceName) {
  const scriptPattern = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
  let match;
  let checked = 0;

  while ((match = scriptPattern.exec(html))) {
    const attributes = match[1] ?? '';
    const code = match[2] ?? '';
    const type = attributes.match(/\btype=["']([^"']+)["']/i)?.[1]?.toLowerCase();
    const hasSource = /\bsrc=["']/i.test(attributes);

    if (hasSource || type === 'text/plain' || type === 'application/json' || !code.trim()) continue;

    try {
      // Syntaxprüfung ohne Ausführung im Browserkontext.
      // eslint-disable-next-line no-new-func
      new Function(code);
      checked += 1;
    } catch (error) {
      errors.push(`${sourceName}: ungültiges Inline-JavaScript (${error.message})`);
    }
  }

  notes.push(`${sourceName}: ${checked} ausführbare Inline-Skripte syntaktisch geprüft`);
}

function verifyRelativePath(path, label) {
  assert(typeof path === 'string' && path.length > 0, `${label}: Pfad fehlt`);
  if (typeof path !== 'string') return;
  assert(!path.startsWith('/'), `${label}: absoluter Root-Pfad ist auf einer GitHub-Pages-Projektseite unsicher (${path})`);
}

const index = read('index.html');
const fallback = read('404.html');
const manifestText = read('gasserwerk.webmanifest');
const serviceWorker = read('gasserwerk-sw.js');
const buildManifestText = read('build-manifest.json');

assert(index.startsWith('<!doctype html>'), 'index.html muss direkt mit <!doctype html> beginnen');
assert(fallback.trimStart().startsWith('<!doctype html>'), '404.html muss mit <!doctype html> beginnen');
assert(index.includes('<html lang="de-CH"'), 'index.html: Sprachdeklaration de-CH fehlt');
assert(index.includes('id="app-shell"'), 'index.html: App-Shell fehlt');
assert(index.includes('id="workspace-header"'), 'index.html: Workspace-Header fehlt');
assert(index.includes('id="workspace-body"'), 'index.html: Workspace-Body fehlt');
assert(index.includes('id="context-panel"'), 'index.html: Kontextpanel fehlt');
assert(index.includes('href="./gasserwerk.webmanifest"'), 'index.html: externes Webmanifest ist nicht relativ verlinkt');
assert(index.includes('gasserwerk-sw.js'), 'index.html: Service-Worker-Registrierung fehlt');

compileInlineScripts(index, 'index.html');
compileInlineScripts(fallback, '404.html');

const normalizeAppArtifact = (value) => value
  .replace(/\r\n?/g, '\n')
  .replace(/^\uFEFF?\s*/, '')
  .trimEnd();

assert(
  normalizeAppArtifact(index) === normalizeAppArtifact(fallback),
  'index.html und 404.html müssen nach Normalisierung von BOM, Zeilenenden und Randabständen denselben App-Stand enthalten'
);

let manifest;
try {
  manifest = JSON.parse(manifestText);
} catch (error) {
  errors.push(`gasserwerk.webmanifest: ungültiges JSON (${error.message})`);
}

if (manifest) {
  verifyRelativePath(manifest.id, 'Manifest id');
  verifyRelativePath(manifest.start_url, 'Manifest start_url');
  verifyRelativePath(manifest.scope, 'Manifest scope');
  assert(manifest.lang === 'de-CH', 'Manifest: lang muss de-CH sein');
  assert(manifest.display === 'standalone', 'Manifest: display muss standalone sein');

  for (const [index, icon] of (manifest.icons ?? []).entries()) {
    verifyRelativePath(icon.src, `Manifest icon ${index + 1}`);
    const localPath = icon.src.replace(/^\.\//, '');
    assert(existsSync(resolve(root, localPath)), `Manifest referenziert fehlendes Icon: ${icon.src}`);
  }

  for (const [index, shortcut] of (manifest.shortcuts ?? []).entries()) {
    verifyRelativePath(shortcut.url, `Manifest shortcut ${index + 1}`);
  }
}

try {
  // Syntaxprüfung; der Service Worker wird dabei nicht ausgeführt.
  // eslint-disable-next-line no-new-func
  new Function(serviceWorker);
  notes.push('gasserwerk-sw.js: Syntax geprüft');
} catch (error) {
  errors.push(`gasserwerk-sw.js: ungültiges JavaScript (${error.message})`);
}

let buildManifest;
try {
  buildManifest = JSON.parse(buildManifestText);
} catch (error) {
  errors.push(`build-manifest.json: ungültiges JSON (${error.message})`);
}

if (buildManifest?.files) {
  const referencedFiles = [];
  for (const value of Object.values(buildManifest.files)) {
    if (typeof value === 'string') referencedFiles.push(value);
    else if (value && typeof value === 'object') referencedFiles.push(...Object.values(value));
  }

  for (const path of referencedFiles) {
    if (typeof path !== 'string') continue;
    const localPath = path.replace(/^\//, '');
    assert(existsSync(resolve(root, localPath)), `build-manifest.json referenziert fehlende Datei: ${path}`);
  }
}

assert(extname('gasserwerk.webmanifest') === '.webmanifest', 'Interner Prüffehler beim Manifestpfad');

for (const note of notes) console.log(`✓ ${note}`);

if (errors.length) {
  console.error(`\nStatische Build-Prüfung fehlgeschlagen (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('\n✓ Gasserwerk Static Build ist konsistent.');
