import {
  APPOINTMENT_STATUS_LABELS,
  AppointmentStatus,
  OperationalKind
} from '../data/contracts/domain-values.js';
import { createElement } from '../lib/dom.js';

const OPERATIONAL_LABELS = Object.freeze({
  [OperationalKind.TASK]: 'Interne Aufgabe',
  [OperationalKind.BREAK]: 'Pause',
  [OperationalKind.ABSENCE]: 'Abwesenheit',
  [OperationalKind.CONFLICT]: 'Konflikt'
});

export function createStatusChip(options = {}) {
  const { status, label = APPOINTMENT_STATUS_LABELS[status] } = options;
  if (!Object.values(AppointmentStatus).includes(status)) {
    throw new RangeError(`unknown appointment status: ${status}`);
  }
  return createElement('span', {
    className: `gw-status-chip gw-status-chip--${status}`,
    attributes: { 'data-status': status },
    children: [
      createElement('span', { className: 'gw-status-chip__marker', attributes: { 'aria-hidden': 'true' } }),
      createElement('span', { text: label })
    ]
  });
}

export function createOperationalChip(options = {}) {
  const { kind, label = OPERATIONAL_LABELS[kind] } = options;
  if (!Object.values(OperationalKind).includes(kind)) {
    throw new RangeError(`unknown operational kind: ${kind}`);
  }
  return createElement('span', {
    className: `gw-status-chip gw-status-chip--operational gw-status-chip--${kind}`,
    attributes: { 'data-operational-kind': kind },
    children: [
      createElement('span', { className: 'gw-status-chip__marker', attributes: { 'aria-hidden': 'true' } }),
      createElement('span', { text: label })
    ]
  });
}
