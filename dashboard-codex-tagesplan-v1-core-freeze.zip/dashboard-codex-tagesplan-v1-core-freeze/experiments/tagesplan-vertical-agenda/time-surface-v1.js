(() => {
  'use strict';

  const TIME_ZONE = 'Europe/Zurich';
  const OPEN_MINUTE = 8 * 60;
  const CLOSE_MINUTE = 18 * 60;
  const query = new URLSearchParams(window.location.search);
  const listeners = new Set();
  let minuteTimer = 0;
  let snapshot = null;
  let destroyed = false;

  function validIsoDate(value) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value ?? '');
    if (!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const candidate = new Date(Date.UTC(year, month - 1, day, 12));
    if (
      candidate.getUTCFullYear() !== year
      || candidate.getUTCMonth() !== month - 1
      || candidate.getUTCDate() !== day
    ) return null;
    return value;
  }

  function dateIso(instant = new Date()) {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
      timeZone: TIME_ZONE,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).formatToParts(instant).map((part) => [part.type, part.value]));
    return `${parts.year}-${parts.month}-${parts.day}`;
  }

  function clockParts(instant = new Date()) {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
      timeZone: TIME_ZONE,
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23'
    }).formatToParts(instant).map((part) => [part.type, part.value]));
    return { hour: Number(parts.hour), minute: Number(parts.minute) };
  }

  function referenceMinute() {
    const value = query.get('referenceNow');
    if (!/^\d{1,2}:\d{2}$/.test(value ?? '')) return null;
    const [hour, minute] = value.split(':').map(Number);
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    return hour * 60 + minute;
  }

  function formatMinute(minute) {
    const normalized = Math.max(0, Math.min(1439, Math.round(minute)));
    return `${String(Math.floor(normalized / 60)).padStart(2, '0')}:${String(normalized % 60).padStart(2, '0')}`;
  }

  function addDays(value, amount) {
    const [year, month, day] = value.split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day + amount, 12));
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
  }

  function effectiveTodayIso() {
    return validIsoDate(query.get('referenceDate')) ?? dateIso();
  }

  function initialDate() {
    const today = effectiveTodayIso();
    const mode = query.get('dateMode');
    if (mode === 'past') return addDays(today, -1);
    if (mode === 'future') return addDays(today, 1);
    return today;
  }

  function buildSnapshot(reason) {
    const fixedMinute = referenceMinute();
    const parts = fixedMinute == null
      ? clockParts()
      : { hour: Math.floor(fixedMinute / 60), minute: fixedMinute % 60 };
    const minute = parts.hour * 60 + parts.minute;
    return Object.freeze({
      timeZone: TIME_ZONE,
      todayIso: effectiveTodayIso(),
      initialDate: initialDate(),
      hour: parts.hour,
      minutePart: parts.minute,
      minute,
      label: formatMinute(minute),
      mode: fixedMinute == null ? 'live' : 'reference',
      reason
    });
  }

  function publish(reason) {
    if (destroyed) return snapshot;
    snapshot = buildSnapshot(reason);
    const root = document.querySelector('#dashboard-root');
    if (root) {
      root.dataset.tpTimeSource = TIME_ZONE;
      root.dataset.tpNowMinute = String(snapshot.minute);
      root.dataset.tpTimeMode = snapshot.mode;
      root.dataset.tpTimeSyncState = 'pending';
      root.dataset.tpTimeSyncReason = reason;
    }
    let subscriberErrors = 0;
    listeners.forEach((listener) => {
      try {
        listener(snapshot);
      } catch (error) {
        subscriberErrors += 1;
        console.error('Salonzeit-Abonnement fehlgeschlagen.', error);
      }
    });
    if (root) root.dataset.tpTimeSubscriberErrors = String(subscriberErrors);
    window.dispatchEvent(new CustomEvent('gasserwerk:salon-time', { detail: snapshot }));
    return snapshot;
  }

  function scheduleMinuteBoundary() {
    clearTimeout(minuteTimer);
    if (destroyed) return;
    if (referenceMinute() != null) return;
    const now = new Date();
    const wait = (60 - now.getSeconds()) * 1000 - now.getMilliseconds() + 25;
    minuteTimer = window.setTimeout(() => {
      try {
        publish('minute-boundary');
      } finally {
        scheduleMinuteBoundary();
      }
    }, Math.max(250, wait));
  }

  function handleVisibilityChange() {
    if (document.visibilityState !== 'visible') return;
    publish('tab-resume');
    scheduleMinuteBoundary();
  }

  function subscribe(listener) {
    if (typeof listener !== 'function') throw new TypeError('Salonzeit-Abonnement benötigt eine Funktion.');
    listeners.add(listener);
    if (snapshot) {
      try {
        listener(snapshot);
      } catch (error) {
        const root = document.querySelector('#dashboard-root');
        if (root) root.dataset.tpTimeSubscriberErrors = String(Number(root.dataset.tpTimeSubscriberErrors ?? 0) + 1);
        console.error('Initiales Salonzeit-Abonnement fehlgeschlagen.', error);
      }
    }
    return () => listeners.delete(listener);
  }

  function handlePageHide(event) {
    clearTimeout(minuteTimer);
    minuteTimer = 0;
    if (event.persisted) return;
    destroyed = true;
    document.removeEventListener('visibilitychange', handleVisibilityChange);
    window.removeEventListener('pagehide', handlePageHide);
    window.removeEventListener('pageshow', handlePageShow);
    listeners.clear();
  }

  function handlePageShow(event) {
    if (!event.persisted || destroyed) return;
    publish('bfcache-restore');
    scheduleMinuteBoundary();
  }

  publish('initial');
  document.addEventListener('visibilitychange', handleVisibilityChange);
  window.addEventListener('pagehide', handlePageHide);
  window.addEventListener('pageshow', handlePageShow);
  scheduleMinuteBoundary();

  Object.defineProperty(window, '__gasserwerkSalonTime', {
    configurable: false,
    enumerable: false,
    value: Object.freeze({
      timeZone: TIME_ZONE,
      openMinute: OPEN_MINUTE,
      closeMinute: CLOSE_MINUTE,
      getSnapshot: () => snapshot,
      minute: () => snapshot.minute,
      todayIso: () => snapshot.todayIso,
      initialDate: () => snapshot.initialDate,
      isToday: (date) => date === snapshot.todayIso,
      formatMinute,
      referenceMinute,
      subscribe,
      sync: (reason = 'manual-proof') => publish(reason)
    })
  });
})();
