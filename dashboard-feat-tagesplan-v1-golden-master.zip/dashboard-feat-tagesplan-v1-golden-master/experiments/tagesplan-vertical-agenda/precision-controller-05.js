function syncTimeVisuals() {
  const minute = currentMinute();
  const withinDay = minute >= OPEN_MINUTE && minute <= CLOSE_MINUTE && isToday();
  const position = minutePercent(minute);
  const nowLine = root?.querySelector('.va-now-line');
  const shade = root?.querySelector('.va-past-shade');
  const timeRail = root?.querySelector('.va-time-rail');

  if (withinDay) {
    if (nowLine) nowLine.style.top = `${position}%`;
    if (shade) shade.style.height = `${position}%`;
    ensureNowLabel(timeRail, minute);
  } else {
    timeRail?.querySelector('.va-now-label')?.remove();
  }

  root?.querySelectorAll('.va-appointment').forEach((card) => {
    const start = Number(card.dataset.startMinute);
    const end = Number(card.dataset.endMinute);
    const running = withinDay && Number.isFinite(start) && Number.isFinite(end) && start <= minute && end > minute;
    card.classList.toggle('is-running-now', running);
    if (running) card.style.setProperty('--va-running-progress', `${clamp((minute - start) / Math.max(1, end - start) * 100, 0, 100)}%`);
    else card.style.removeProperty('--va-running-progress');
  });

  const digital = root?.querySelector('[data-clock-digital]');
  const face = root?.querySelector('.gw-clock-face');
  const clockButton = root?.querySelector('[data-work-clock]');
  const hour = Math.floor(minute / 60) % 24;
  const minutePart = minute % 60;
  if (referenceMinute() != null && face) {
    face.style.setProperty('--gw-clock-hour-angle', `${((hour % 12) + minutePart / 60) * 30}deg`);
    face.style.setProperty('--gw-clock-minute-angle', `${minutePart * 6}deg`);
  }
  setText(digital, formatTime(minute));
  clockButton?.setAttribute('aria-label', `Salonzeit ${formatTime(minute)}. Zum heutigen Tagesplan und zur aktuellen Zeit springen.`);

  const nowButton = root?.querySelector('.va-header-now');
  if (nowButton) {
    setText(nowButton, formatTime(minute));
    nowButton.setAttribute('aria-label', `Zu jetzt springen, ${formatTime(minute)}`);
  }
  if (root) root.dataset.nowLineBehindCards = '1';
}

function agendaLimits() {
  if (isLandscapeCompact()) return { current: 1, upcoming: 1 };
  if (isPortraitCompact()) return { current: 2, upcoming: 1 };
  return { current: Number.POSITIVE_INFINITY, upcoming: Number.POSITIVE_INFINITY };
}

function enhanceAgendaSection(section, role, limit) {
  const rowsContainer = section.querySelector(':scope > div');
  if (!rowsContainer) return 0;
  let rows = [...rowsContainer.querySelectorAll(':scope > .va-agenda-row')];
  if (role === 'current' && rows.length > 1) {
    const endMinute = (row) => {
      const value = row.querySelector('.va-agenda-time')?.textContent ?? '';
      const end = value.split('–')[1] ?? '';
      const [hour, minute] = end.trim().split(':').map(Number);
      return Number.isFinite(hour) && Number.isFinite(minute) ? hour * 60 + minute : Number.POSITIVE_INFINITY;
    };
    const sorted = [...rows].sort((left, right) => endMinute(left) - endMinute(right));
    if (sorted.some((row, index) => row !== rows[index])) {
      sorted.forEach((row) => rowsContainer.append(row));
      rows = sorted;
    }
  }
  const expanded = section.dataset.agendaExpanded === '1';
  const hiddenCount = Math.max(0, rows.length - limit);
  rows.forEach((row, index) => {
    const shouldHide = !expanded && index >= limit;
    if (row.hidden !== shouldHide) row.hidden = shouldHide;
  });

  let button = rowsContainer.querySelector(':scope > .va-agenda-more');
  if (!hiddenCount || !Number.isFinite(limit)) {
    button?.remove();
    return 0;
  }
  if (!button) {
    button = document.createElement('button');
    button.type = 'button';
    button.className = 'va-agenda-more';
    rowsContainer.append(button);
  }
  button.dataset.agendaMore = role;
  button.setAttribute('aria-expanded', String(expanded));
  const label = expanded
    ? 'Weniger anzeigen'
    : role === 'current'
      ? `${hiddenCount} weitere laufen`
      : `${hiddenCount} weitere danach`;
  setText(button, label);
  return hiddenCount;
}

function enhanceAgendas() {
  const limits = agendaLimits();
  let hiddenCurrent = 0;
  let hiddenUpcoming = 0;
  document.querySelectorAll('.va-agenda-panel').forEach((panel) => {
    const count = panel.querySelector('.va-agenda-count');
    if (count) {
      const value = count.textContent.trim();
      count.setAttribute('aria-label', `${value} aktuelle und nächste Termine`);
      count.title = `${value} aktuelle und nächste Termine`;
    }
    const current = panel.querySelector('.va-agenda-section.is-current');
    const upcoming = panel.querySelector('.va-agenda-section.is-next');
    if (current) hiddenCurrent = Math.max(hiddenCurrent, enhanceAgendaSection(current, 'current', limits.current));
    if (upcoming) hiddenUpcoming = Math.max(hiddenUpcoming, enhanceAgendaSection(upcoming, 'next', limits.upcoming));
  });
  if (root) {
    root.dataset.hiddenCurrentAgendaCount = String(hiddenCurrent);
    root.dataset.hiddenUpcomingAgendaCount = String(hiddenUpcoming);
    root.dataset.agendaHiddenCount = String(hiddenCurrent + hiddenUpcoming);
  }
}
