import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const root = process.cwd();
const requiredFiles = [
  'docs/decisions/ADR-003-two-period-day-map.md',
  'src/shell/dashboard-shell-v2.js',
  'src/styles/dashboard-shell-v2.css',
  'experiments/tagesplan-two-period/index.html',
  'experiments/tagesplan-two-period/page.js',
  'experiments/tagesplan-two-period/page.css',
  'experiments/tagesplan-two-period/time-hierarchy.css',
  'experiments/tagesplan-two-period/README.md'
];

const failures = [];
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(root, file))) failures.push(`Fehlende Datei: ${file}`);
}

if (!failures.length) {
  const shell = read('src/shell/dashboard-shell-v2.js');
  const page = read('experiments/tagesplan-two-period/page.js');
  const css = read('experiments/tagesplan-two-period/page.css');
  const timeHierarchy = read('experiments/tagesplan-two-period/time-hierarchy.css');
  const html = read('experiments/tagesplan-two-period/index.html');
  const readme = read('experiments/tagesplan-two-period/README.md');
  const adr = read('docs/decisions/ADR-003-two-period-day-map.md');

  for (const [file, source] of [['src/shell/dashboard-shell-v2.js', shell], ['experiments/tagesplan-two-period/page.js', page]]) {
    try {
      new vm.SourceTextModule(source, { identifier: file });
    } catch (error) {
      failures.push(`${file}: JavaScript-Syntaxfehler: ${error.message}`);
    }
  }

  const requiredShellTerms = ['Tagesplan', 'Termine', 'Kundschaft', 'Verwaltung', 'gw-work-clock', 'Salonzeit'];
  for (const term of requiredShellTerms) if (!shell.includes(term)) failures.push(`Shell V2 enthält nicht: ${term}`);

  const requiredPageTerms = ['Vormittag', 'Nachmittag', 'PERIOD_SPLIT_MINUTE', 'split-period-divider', 'split-now-cursor', 'data-focus-staff'];
  for (const term of requiredPageTerms) if (!page.includes(term) && !css.includes(term)) failures.push(`Tageslandkarte enthält nicht: ${term}`);

  const requiredGeometry = ['background-size: 10% 100%, 5% 100%, 2.5% 100%', 'split-mobile-periods', 'split-focus-view'];
  for (const term of requiredGeometry) if (!css.includes(term)) failures.push(`CSS-Vertrag fehlt: ${term}`);

  const requiredTimeHierarchy = [
    '.split-card-time',
    'display: none !important',
    '.split-ruler-label:nth-child(2)',
    '.split-ruler-label:nth-child(5)',
    '.split-ruler-label:nth-child(8)',
    '.split-ruler-label:nth-child(11)',
    '--split-anchor-line',
    '.split-focus-appointment > span:first-child',
    'overflow-x: hidden'
  ];
  for (const term of requiredTimeHierarchy) if (!timeHierarchy.includes(term)) failures.push(`Zeithierarchie fehlt: ${term}`);

  if (!html.includes('./time-hierarchy.css')) failures.push('Experiment lädt time-hierarchy.css nicht.');
  if (!readme.includes('09:00, 12:00, 15:00 und 18:00')) failures.push('README dokumentiert die vier Hauptanker nicht.');
  if (!readme.includes('keine redundant sichtbare Startzeit')) failures.push('README dokumentiert die entfernte Kartenzeit nicht.');

  const acceptedOrArchived = adr.includes('Status: **Akzeptiert') || adr.includes('Status: **Teilweise abgelöst durch ADR-004');
  if (!acceptedOrArchived) failures.push('ADR-003 ist weder als akzeptierte noch als teilweise abgelöste Referenz markiert.');
  if (!adr.includes('einzigen Zeitkoordinatenraum')) failures.push('ADR-003 beschreibt keinen kontinuierlichen Zeitkoordinatenraum.');
  if (!adr.includes('Die Zeitachse trägt das Wann')) failures.push('ADR-003 enthält die Zeithierarchie-Entscheidung nicht.');
  if (!adr.includes('09:00, 12:00, 15:00 und 18:00')) failures.push('ADR-003 enthält die vier Hauptanker nicht.');
}

if (failures.length) {
  console.error('Tageslandkarten-Prüfung fehlgeschlagen:');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log('Archivierte horizontale Tageslandkarte, Produktschale V2 und Zeithierarchie sind statisch konsistent.');
