(() => {
  const root = document.getElementById('dashboard-root');
  if (!root) return;

  const query = new URLSearchParams(location.search);
  const DIAGNOSTICS_VERSION = '1';
  const COMPACT_MAX_WIDTH = 760;
  const MIN_DESKTOP_GRID_HEIGHT = 440;
  const HOURS_VISIBLE = 10;
  const EPSILON = 2;
  const REQUIRED_STABLE_FRAMES = 2;
  const state = {
    frame: 0,
    retryTimer: 0,
    mutationObserver: null,
    lastSignature: '',
    stableFrames: 0
  };

  function select(selector, scope = document) { return scope?.querySelector(selector) ?? null; }

  function requiredNodes() {
    const workspace = select('.gw-workspace', root);
    const header = select('.gw-product-header', workspace);
    const pageHost = select('.gw-page-content.va-page-host', workspace);
    const page = select('.va-page', pageHost);
    const layout = select('.va-desktop-layout', page);
    const panel = select('.va-calendar-panel', layout);
    const viewport = select('.va-calendar-viewport', panel);
    const calendarHead = select('.va-calendar-head', viewport);
    const calendarScroll = select('.va-calendar-scroll', viewport);
    const grid = select('.va-calendar-grid', calendarScroll);
    return { workspace, header, pageHost, page, layout, panel, viewport, calendarHead, calendarScroll, grid };
  }

  const number = (value) => Number.isFinite(Number.parseFloat(value)) ? Number.parseFloat(value) : 0;
  const overflowAmount = (element, axis) => !element ? 0 : Math.max(0, Math.round(axis === 'x' ? element.scrollWidth - element.clientWidth : element.scrollHeight - element.clientHeight));

  function isScrollableY(element) {
    if (!element) return false;
    const overflow = getComputedStyle(element).overflowY;
    return (overflow === 'auto' || overflow === 'scroll') && overflowAmount(element, 'y') > EPSILON;
  }

  const unique = (elements) => [...new Set(elements.filter(Boolean))];

  function setExperienceAttributes() {
    const requestedState = query.get('state') || 'normal';
    document.body.dataset.gwPage = 'tagesplan';
    document.body.dataset.gwState = requestedState;
    document.body.dataset.gwExperienceProfile = 'tagesplan-v1';
    document.body.dataset.gwCorePath = 'surface-v1';
    document.body.dataset.gwBeseelung = 'disabled';
    root.dataset.gwPage = 'tagesplan';
    root.dataset.gwState = requestedState;
    root.dataset.gwExperienceProfile = 'tagesplan-v1';
    root.dataset.gwCorePath = 'surface-v1';
    root.dataset.gwBeseelung = 'disabled';
  }

  function densityForHourPixels(pixelsPerHour, compact) {
    if (compact) return 'dense';
    if (pixelsPerHour >= 60) return 'roomy';
    if (pixelsPerHour >= 48) return 'compact';
    return 'dense';
  }

  function renderedStaffCount(nodes) {
    const declaredCount = Number.parseInt(nodes.page?.dataset.visibleStaffCount ?? '', 10);
    if (!Number.isInteger(declaredCount) || declaredCount < 1) return 0;
    const staffHeadCount = nodes.calendarHead.querySelectorAll('.va-staff-head').length;
    const staffTrackCount = nodes.grid.querySelectorAll('.va-staff-track').length;
    return staffHeadCount === declaredCount && staffTrackCount === declaredCount ? declaredCount : 0;
  }

  function renderedNonCalendarState(nodes) {
    const statePage = select('.va-state-page', nodes.pageHost);
    if (!statePage) return null;

    const isLoading = statePage.getAttribute('aria-busy') === 'true';
    const requestedState = query.get('state') || query.get('scenario');
    if (isLoading && requestedState !== 'loading') return null;
    if (isLoading) return { kind: 'loading', node: statePage };
    if (select('[data-retry]', statePage)) return { kind: 'error', node: statePage };
    if (statePage.textContent.includes('nicht verfügbar')) return { kind: 'forbidden', node: statePage };
    return { kind: requestedState || 'state', node: statePage };
  }

  function readLayoutMetrics(nodes) {
    const viewportHeight = Math.max(0, nodes.viewport.getBoundingClientRect().height);
    const headHeight = Math.max(0, nodes.calendarHead.getBoundingClientRect().height);
    const availableGridHeight = Math.max(0, viewportHeight - headHeight);
    return {
      viewportHeight,
      headHeight,
      availableGridHeight,
      pixelsPerHour: availableGridHeight / HOURS_VISIBLE
    };
  }

  function regimeFor(metrics) {
    const compact = innerWidth <= COMPACT_MAX_WIDTH || metrics.availableGridHeight < MIN_DESKTOP_GRID_HEIGHT;
    if (compact) return innerWidth > innerHeight ? 'compact-landscape-scroll' : 'compact-portrait-scroll';
    return metrics.pixelsPerHour >= 54 ? 'desktop-full' : 'desktop-compact';
  }

  function applyLayoutAttributes(metrics, regime) {
    const compact = regime.startsWith('compact-');
    const density = densityForHourPixels(metrics.pixelsPerHour, compact);
    root.dataset.vaLayoutRegime = regime;
    root.dataset.vaAvailableGridHeight = String(Math.round(metrics.availableGridHeight));
    root.dataset.vaHourPixels = metrics.pixelsPerHour.toFixed(2);
    root.dataset.gwDensity = density;
    document.body.dataset.gwDensity = density;
  }

  const rounded = (value) => Math.round(value * 100) / 100;

  function layoutSignature(nodes, regime) {
    const viewportRect = nodes.viewport.getBoundingClientRect();
    const headRect = nodes.calendarHead.getBoundingClientRect();
    const gridRect = nodes.grid.getBoundingClientRect();
    const viewportStyle = getComputedStyle(nodes.viewport);
    const scrollStyle = getComputedStyle(nodes.calendarScroll);
    return [
      regime,
      innerWidth,
      innerHeight,
      rounded(viewportRect.width),
      rounded(viewportRect.height),
      rounded(headRect.height),
      rounded(gridRect.width),
      rounded(gridRect.height),
      nodes.viewport.scrollWidth,
      nodes.viewport.scrollHeight,
      nodes.calendarScroll.scrollWidth,
      nodes.calendarScroll.scrollHeight,
      viewportStyle.overflowX,
      viewportStyle.overflowY,
      scrollStyle.overflowY
    ].join('|');
  }

  function markPending(renderDirty) {
    root.dataset.tpDiagnosticsVersion = DIAGNOSTICS_VERSION;
    root.dataset.tpLayoutState = 'pending';
    delete root.dataset.tpLayoutFailure;
    root.dataset.vaLayoutReady = '0';
    if (renderDirty) root.dataset.tpRenderState = 'pending';
  }

  function queueNextFrame() {
    cancelAnimationFrame(state.frame);
    state.frame = requestAnimationFrame(stabilizeLayout);
  }

  function schedule(renderDirty = false) {
    setExperienceAttributes();
    state.lastSignature = '';
    state.stableFrames = 0;
    markPending(renderDirty);
    queueNextFrame();
  }

  function retryUntilRendered() {
    clearTimeout(state.retryTimer);
    state.retryTimer = window.setTimeout(() => schedule(false), 80);
  }

  function stabilizeNonCalendarState(renderedState) {
    const rect = renderedState.node.getBoundingClientRect();
    const signature = [
      'state',
      renderedState.kind,
      innerWidth,
      innerHeight,
      rounded(rect.width),
      rounded(rect.height),
      document.documentElement.scrollWidth,
      document.documentElement.scrollHeight
    ].join('|');

    if (signature !== state.lastSignature) {
      state.lastSignature = signature;
      state.stableFrames = 0;
      queueNextFrame();
      return;
    }

    state.stableFrames += 1;
    if (state.stableFrames < REQUIRED_STABLE_FRAMES) {
      queueNextFrame();
      return;
    }

    clearTimeout(state.retryTimer);
    const documentOverflowX = overflowAmount(document.documentElement, 'x');
    const documentOverflowY = overflowAmount(document.documentElement, 'y');
    root.dataset.vaLayoutRegime = 'state-' + renderedState.kind;
    root.dataset.vaAvailableGridHeight = '0';
    root.dataset.vaHourPixels = '0.00';
    root.dataset.documentOverflowX = String(documentOverflowX);
    root.dataset.documentOverflowY = String(documentOverflowY);
    root.dataset.pageOverflowY = '0';
    root.dataset.calendarSurfaceOverflowX = '0';
    root.dataset.calendarSurfaceOverflowY = '0';
    root.dataset.calendarVerticalOwnerCount = '0';
    root.dataset.calendarPrimaryScrollOwner = 'none';
    root.dataset.calendarGridBottomGap = '0';
    root.dataset.calendarSurfaceClean = 'not-applicable';
    root.dataset.calendarDesktopFit = '0';
    root.dataset.calendarCompactProjection = '0';
    root.dataset.visibleStaffCount = '0';
    root.dataset.visibleStaffTracks = '0';
    root.dataset.visibleAgendaPanels = '0';
    root.dataset.focusContextCount = '0';
    root.dataset.tpLayoutApplicability = 'not-applicable';
    root.dataset.tpDiagnosticsVersion = DIAGNOSTICS_VERSION;
    root.dataset.vaLayoutReady = '1';
    root.dataset.tpRenderState = 'ready';
    root.dataset.tpLayoutState = 'stable';
  }

  function stabilizeLayout() {
    state.frame = 0;
    const nodes = requiredNodes();
    const nonCalendarState = renderedNonCalendarState(nodes);
    if (nonCalendarState) {
      stabilizeNonCalendarState(nonCalendarState);
      return;
    }
    if (Object.values(nodes).some((node) => !node) || !renderedStaffCount(nodes)) {
      root.dataset.tpRenderState = 'pending';
      root.dataset.tpLayoutState = 'pending';
      root.dataset.vaLayoutReady = '0';
      retryUntilRendered();
      return;
    }

    root.dataset.tpRenderState = 'ready';
    const metrics = readLayoutMetrics(nodes);
    const regime = regimeFor(metrics);
    applyLayoutAttributes(metrics, regime);

    const signature = layoutSignature(nodes, regime);
    if (signature !== state.lastSignature) {
      state.lastSignature = signature;
      state.stableFrames = 0;
      queueNextFrame();
      return;
    }

    state.stableFrames += 1;
    if (state.stableFrames < REQUIRED_STABLE_FRAMES) {
      queueNextFrame();
      return;
    }

    clearTimeout(state.retryTimer);
    reportDiagnostics(nodes, regime, metrics);
  }

  function reportDiagnostics(nodes, regime, metrics) {
    const { pageHost, viewport, calendarScroll, grid } = nodes;
    if (!viewport.isConnected || !grid.isConnected) {
      schedule(true);
      return;
    }

    const compact = regime.startsWith('compact-');
    const desktopFit = regime === 'desktop-full' || regime === 'desktop-compact';
    const documentElement = document.documentElement;
    const scrollingElement = document.scrollingElement || documentElement;
    const verticalOwners = unique([scrollingElement, pageHost, viewport, calendarScroll]).filter(isScrollableY);

    const viewportRect = viewport.getBoundingClientRect();
    const gridRect = grid.getBoundingClientRect();
    const expectedGridBottom = viewportRect.bottom - number(getComputedStyle(viewport).borderBottomWidth);
    const gridBottomGap = Math.round(expectedGridBottom - gridRect.bottom);

    const documentOverflowX = overflowAmount(documentElement, 'x');
    const documentOverflowY = overflowAmount(documentElement, 'y');
    const pageOverflowY = overflowAmount(pageHost, 'y');
    const calendarOverflowX = overflowAmount(viewport, 'x');
    const calendarOverflowY = overflowAmount(viewport, 'y');
    const visibleStaffCount = renderedStaffCount(nodes);
    const visibleAgendaPanels = [...document.querySelectorAll('.va-agenda-panel')]
      .filter((node) => node.getClientRects().length).length;

    const cleanDesktop = desktopFit && documentOverflowX <= EPSILON && documentOverflowY <= EPSILON && pageOverflowY <= EPSILON && calendarOverflowX <= EPSILON && calendarOverflowY <= EPSILON && verticalOwners.length === 0 && Math.abs(gridBottomGap) <= EPSILON;
    const cleanCompact = compact && documentOverflowX <= EPSILON && documentOverflowY <= EPSILON && pageOverflowY <= EPSILON && verticalOwners.length === 1 && verticalOwners[0] === viewport && calendarOverflowY > EPSILON;
    const geometryConsistent = cleanDesktop || cleanCompact;

    root.dataset.vaAvailableGridHeight = String(Math.round(metrics.availableGridHeight));
    root.dataset.vaHourPixels = metrics.pixelsPerHour.toFixed(2);
    root.dataset.documentOverflowX = String(documentOverflowX);
    root.dataset.documentOverflowY = String(documentOverflowY);
    root.dataset.pageOverflowY = String(pageOverflowY);
    root.dataset.calendarSurfaceOverflowX = String(calendarOverflowX);
    root.dataset.calendarSurfaceOverflowY = String(calendarOverflowY);
    root.dataset.calendarVerticalOwnerCount = String(verticalOwners.length);
    root.dataset.calendarPrimaryScrollOwner = verticalOwners[0] === viewport ? 'calendar-viewport' : verticalOwners.length ? 'other' : 'none';
    root.dataset.calendarGridBottomGap = String(gridBottomGap);
    root.dataset.calendarSurfaceClean = geometryConsistent ? '1' : '0';
    root.dataset.calendarDesktopFit = desktopFit ? '1' : '0';
    root.dataset.calendarCompactProjection = compact ? '1' : '0';
    root.dataset.viewportCssWidth = String(Math.round(innerWidth));
    root.dataset.viewportCssHeight = String(Math.round(innerHeight));
    root.dataset.visibleStaffCount = String(visibleStaffCount);
    root.dataset.visibleStaffTracks = String(visibleStaffCount);
    root.dataset.visibleAgendaPanels = String(visibleAgendaPanels);
    root.dataset.focusContextCount = String(nodes.grid.querySelectorAll('.va-staff-track.is-context').length);
    root.dataset.tpLayoutApplicability = 'calendar';
    root.dataset.tpDiagnosticsVersion = DIAGNOSTICS_VERSION;
    root.dataset.tpRenderState = 'ready';
    if (geometryConsistent) {
      delete root.dataset.tpLayoutFailure;
      root.dataset.vaLayoutReady = '1';
      root.dataset.tpLayoutState = 'stable';
    } else {
      root.dataset.tpLayoutFailure = 'inconsistent-geometry';
      root.dataset.vaLayoutReady = '0';
      root.dataset.tpLayoutState = 'invalid';
    }
  }

  // Only external child-list changes invalidate the render contract. Attribute
  // writes made by this controller are deliberately outside the observed set.
  state.mutationObserver = new MutationObserver((records) => {
    if (records.some((record) => record.type === 'childList')) schedule(true);
  });
  state.mutationObserver.observe(root, { childList: true, subtree: true });

  window.addEventListener('resize', () => schedule(false), { passive: true });
  window.addEventListener('orientationchange', () => schedule(false));
  window.addEventListener('load', () => schedule(false), { once: true });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') schedule(false);
  });
  document.fonts?.ready.then(() => schedule(false));

  setExperienceAttributes();
  schedule(true);

  window.addEventListener('pagehide', (event) => {
    clearTimeout(state.retryTimer);
    cancelAnimationFrame(state.frame);
    if (!event.persisted) state.mutationObserver?.disconnect();
  });
  window.addEventListener('pageshow', (event) => {
    if (event.persisted) schedule(false);
  });
})();
