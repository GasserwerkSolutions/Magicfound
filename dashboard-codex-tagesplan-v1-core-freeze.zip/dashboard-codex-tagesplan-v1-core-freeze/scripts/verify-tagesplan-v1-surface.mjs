import { createReadStream, existsSync, mkdirSync, realpathSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { extname, resolve, sep } from 'node:path';
import { chromium } from 'playwright';

const root = process.cwd();
const realRoot = realpathSync(root);
const outputDirectory = resolve(root, 'artifacts/tagesplan-v1-surface');
const errors = [];
const evidence = [];
const DIAGNOSTICS_VERSION = '1';
const HANDSHAKE_TIMEOUT_MS = 15_000;

const DESKTOP_CASES = Object.freeze([
  { name: '1366x768', width: 1366, height: 768 },
  { name: '1440x810', width: 1440, height: 810 },
  { name: '1440x900', width: 1440, height: 900 },
  { name: '1512x982', width: 1512, height: 982 },
  { name: '1600x900', width: 1600, height: 900 },
  { name: '1920x1080', width: 1920, height: 1080 },
  { name: '1024x768', width: 1024, height: 768 },
  { name: '1512x982-z90', width: 1680, height: 1091 },
  { name: '1366x768-z90', width: 1518, height: 853 },
  { name: '1512x982-z110', width: 1375, height: 893 },
  { name: '1512x982-z125', width: 1210, height: 786 },
  { name: '1366x768-z110', width: 1242, height: 698 },
  { name: '1366x768-z125', width: 1093, height: 614 }
]);

const COMPACT_CASES = Object.freeze([
  { name: '390x844', width: 390, height: 844, orientation: 'portrait' },
  { name: '430x932', width: 430, height: 932, orientation: 'portrait' },
  { name: '844x390', width: 844, height: 390, orientation: 'landscape' },
  { name: '1093x471-wide-short', width: 1093, height: 471, orientation: 'landscape' }
]);

const CONTENT_TYPES = Object.freeze({
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.webp': 'image/webp'
});

const normalizedPath = (path) => process.platform === 'win32' ? path.toLowerCase() : path;
function isWithinRoot(path, rootPath) {
  const normalizedTarget = normalizedPath(path);
  const normalizedRoot = normalizedPath(rootPath);
  return normalizedTarget === normalizedRoot || normalizedTarget.startsWith(`${normalizedRoot}${sep}`);
}

function createStaticServer() {
  return createServer((request, response) => {
    try {
      const requestUrl = new URL(request.url ?? '/', 'http://127.0.0.1');
      if (requestUrl.pathname === '/favicon.ico') {
        response.writeHead(204, { 'Cache-Control': 'no-store' }).end();
        return;
      }
      const relativePath = decodeURIComponent(requestUrl.pathname).replace(/^\/+/, '') || 'index.html';
      let target = resolve(root, relativePath);
      if (!isWithinRoot(target, root)) {
        response.writeHead(403).end('Forbidden');
        return;
      }
      if (existsSync(target) && statSync(target).isDirectory()) target = resolve(target, 'index.html');
      if (!existsSync(target) || !statSync(target).isFile()) {
        response.writeHead(404).end('Not found');
        return;
      }
      target = realpathSync(target);
      if (!isWithinRoot(target, realRoot)) {
        response.writeHead(403).end('Forbidden');
        return;
      }
      response.writeHead(200, {
        'Cache-Control': 'no-store',
        'Content-Type': CONTENT_TYPES[extname(target).toLowerCase()] ?? 'application/octet-stream'
      });
      if (request.method === 'HEAD') response.end();
      else createReadStream(target).pipe(response);
    } catch (error) {
      response.writeHead(500).end(error.message);
    }
  });
}

async function listen(server) {
  await new Promise((resolvePromise, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolvePromise);
  });
  const address = server.address();
  if (!address || typeof address === 'string') throw new Error('Static server did not expose a TCP port');
  return `http://127.0.0.1:${address.port}/experiments/tagesplan-vertical-agenda/`;
}

const attributeValue = (snapshot, name) => snapshot?.attributes?.[`data-${name}`] ?? null;
const firstAttributeValue = (snapshot, names) => {
  for (const name of names) if (attributeValue(snapshot, name) != null) return attributeValue(snapshot, name);
  return null;
};
const attributeNumber = (snapshot, name) => {
  const value = attributeValue(snapshot, name);
  return value == null || value === '' ? null : Number(value);
};

function requireValue(snapshot, name, expected, label) {
  const value = attributeValue(snapshot, name);
  if (value !== String(expected)) errors.push(`${label}: data-${name} expected ${expected}, received ${value}`);
}

async function readSnapshot(page) {
  return page.locator('#dashboard-root').evaluate((element) => {
    const pageElement = element.querySelector('.va-page');
    const dataAttributes = (node) => Object.fromEntries(
      [...(node?.attributes ?? [])]
        .filter(({ name }) => name.startsWith('data-'))
        .map(({ name, value }) => [name, value])
    );
    const rootAttributes = dataAttributes(element);
    const pageAttributes = dataAttributes(pageElement);
    const isVisible = (node) => {
      if (!node?.getClientRects().length) return false;
      const style = getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
      const rect = node.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0
        && rect.right > 0 && rect.bottom > 0
        && rect.left < window.innerWidth && rect.top < window.innerHeight;
    };
    const rectData = (node) => {
      if (!node) return null;
      const rect = node.getBoundingClientRect();
      return {
        left: Math.round(rect.left * 100) / 100,
        top: Math.round(rect.top * 100) / 100,
        right: Math.round(rect.right * 100) / 100,
        bottom: Math.round(rect.bottom * 100) / 100,
        width: Math.round(rect.width * 100) / 100,
        height: Math.round(rect.height * 100) / 100
      };
    };
    const viewport = element.querySelector('.va-calendar-viewport');
    const calendarHead = element.querySelector('.va-calendar-head');
    const grid = element.querySelector('.va-calendar-grid');
    const viewportRect = viewport?.getBoundingClientRect();
    const staffHeads = [...element.querySelectorAll('.va-staff-head')].map((node) => {
      const rect = node.getBoundingClientRect();
      const visible = isVisible(node);
      const horizontallyClipped = !viewportRect || rect.left < viewportRect.left - 2 || rect.right > viewportRect.right + 2;
      return { label: node.textContent?.trim() ?? '', visible, horizontallyClipped, rect: rectData(node) };
    });
    const dateButton = element.querySelector('[data-open-date-picker]');
    const timeLabels = [...element.querySelectorAll('.va-time-label')];
    const visibleDayAnchors = ['08:00', '18:00'].filter((label) => (
      timeLabels.some((node) => node.textContent?.trim() === label && isVisible(node))
    ));
    return {
      attributes: { ...pageAttributes, ...rootAttributes },
      attributeSources: { root: rootAttributes, page: pageAttributes },
      viewport: { width: window.innerWidth, height: window.innerHeight },
      visibleDayAnchors,
      headerDate: dateButton?.querySelector('span')?.textContent?.trim() ?? null,
      headerDateAriaLabel: dateButton?.getAttribute('aria-label') ?? null,
      nowLineVisible: isVisible(element.querySelector('.va-now-line')),
      staffHeads,
      visibleStaffHeadCount: staffHeads.filter(({ visible }) => visible).length,
      clippedStaffHeadLabels: staffHeads.filter(({ horizontallyClipped }) => horizontallyClipped).map(({ label }) => label),
      sticky: {
        calendarHead: calendarHead ? getComputedStyle(calendarHead).position : null,
        timeCorner: element.querySelector('.va-time-corner') ? getComputedStyle(element.querySelector('.va-time-corner')).position : null,
        timeRail: element.querySelector('.va-time-rail') ? getComputedStyle(element.querySelector('.va-time-rail')).position : null
      },
      geometry: {
        viewport: rectData(viewport),
        calendarHead: rectData(calendarHead),
        grid: rectData(grid),
        viewportScrollWidth: viewport?.scrollWidth ?? null,
        viewportScrollHeight: viewport?.scrollHeight ?? null
      }
    };
  });
}

async function waitForStableDiagnostics(page, label) {
  try {
    await page.waitForFunction(
      ({ diagnosticsVersion }) => {
        const element = document.querySelector('#dashboard-root');
        const layoutState = element?.getAttribute('data-tp-layout-state');
        return element?.getAttribute('data-tp-render-state') === 'ready'
          && (layoutState === 'stable' || layoutState === 'invalid')
          && element.getAttribute('data-tp-diagnostics-version') === diagnosticsVersion;
      },
      { diagnosticsVersion: DIAGNOSTICS_VERSION },
      { timeout: HANDSHAKE_TIMEOUT_MS }
    );
    const layoutState = await page.locator('#dashboard-root').getAttribute('data-tp-layout-state');
    if (layoutState !== 'stable') {
      const failure = await page.locator('#dashboard-root').getAttribute('data-tp-layout-failure');
      throw new Error(`${label}: layout rejected as ${layoutState} (${failure ?? 'no failure code'})`);
    }
    await page.evaluate(() => new Promise((resolvePromise) => {
      requestAnimationFrame(() => requestAnimationFrame(resolvePromise));
    }));
  } catch (error) {
    let current = 'dashboard root unavailable';
    try {
      const snapshot = await readSnapshot(page);
      current = [
        `render=${attributeValue(snapshot, 'tp-render-state')}`,
        `layout=${attributeValue(snapshot, 'tp-layout-state')}`,
        `diagnostics=${attributeValue(snapshot, 'tp-diagnostics-version')}`
      ].join(', ');
    } catch {}
    throw new Error(`${label}: stable diagnostics handshake timed out (${current}): ${error.message}`);
  }
}

async function renderCase(browser, testCase, url) {
  const context = await browser.newContext({
    viewport: { width: testCase.width, height: testCase.height },
    deviceScaleFactor: 1,
    locale: 'de-CH',
    serviceWorkers: 'block',
    timezoneId: 'Europe/Zurich',
    hasTouch: Boolean(testCase.hasTouch)
  });
  const page = await context.newPage();
  const runtimeErrors = [];
  page.on('pageerror', (error) => {
    runtimeErrors.push(`pageerror: ${error.stack ?? error.message}`);
  });
  page.on('console', (message) => {
    const location = message.location();
    const source = location.url ? ` (${new URL(location.url).pathname}:${location.lineNumber}:${location.columnNumber})` : '';
    if (message.type() === 'error') runtimeErrors.push(`console.error: ${message.text()}${source}`);
  });
  await page.addInitScript(() => {
    globalThis.__tpUnhandledRejections = [];
    addEventListener('unhandledrejection', (event) => {
      let detail;
      if (event.reason instanceof Error) detail = `${event.reason.name}: ${event.reason.message}`;
      else if (typeof event.reason === 'string') detail = event.reason;
      else {
        try { detail = JSON.stringify(event.reason); }
        catch { detail = String(event.reason); }
      }
      globalThis.__tpUnhandledRejections.push(detail ?? 'unknown rejection');
    });
  });
  let snapshot = null;
  let actualViewport = null;

  console.log(`→ ${testCase.name} (${testCase.width}×${testCase.height} CSS px)`);
  try {
    await page.goto(url, { waitUntil: 'load', timeout: 30_000 });
    actualViewport = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
    if (actualViewport.width !== testCase.width || actualViewport.height !== testCase.height) {
      errors.push(
        `${testCase.name}: requested ${testCase.width}x${testCase.height} CSS px, received ${actualViewport.width}x${actualViewport.height}`
      );
    }
    await waitForStableDiagnostics(page, testCase.name);
    if (testCase.orientation) {
      await page.waitForFunction(
        () => document.querySelector('#dashboard-root')?.getAttribute('data-calendar-initial-now-positioned') === '1',
        undefined,
        { timeout: HANDSHAKE_TIMEOUT_MS }
      );
    }
    snapshot = await readSnapshot(page);
    requireValue(snapshot, 'tp-render-state', 'ready', testCase.name);
    requireValue(snapshot, 'tp-layout-state', 'stable', testCase.name);
    requireValue(snapshot, 'tp-diagnostics-version', DIAGNOSTICS_VERSION, testCase.name);
  } catch (error) {
    errors.push(error.message);
    try { snapshot = await readSnapshot(page); } catch {}
  } finally {
    try { writeFileSync(resolve(outputDirectory, `${testCase.name}.html`), await page.content()); }
    catch (error) { errors.push(`${testCase.name}: DOM evidence failed: ${error.message}`); }
    try { await page.screenshot({ path: resolve(outputDirectory, `${testCase.name}.png`) }); }
    catch (error) { errors.push(`${testCase.name}: screenshot failed: ${error.message}`); }
    try {
      const unhandledRejections = await page.evaluate(() => globalThis.__tpUnhandledRejections ?? []);
      for (const rejection of unhandledRejections) runtimeErrors.push(`unhandledrejection: ${rejection}`);
    } catch (error) {
      runtimeErrors.push(`unhandledrejection inspection failed: ${error.message}`);
    }
    const uniqueRuntimeErrors = [...new Set(runtimeErrors)];
    for (const runtimeError of uniqueRuntimeErrors) errors.push(`${testCase.name}: ${runtimeError}`);
    evidence.push({
      name: testCase.name,
      requestedViewport: { width: testCase.width, height: testCase.height, hasTouch: Boolean(testCase.hasTouch) },
      actualViewport: actualViewport ?? snapshot?.viewport ?? null,
      attributes: snapshot?.attributes ?? null,
      visibleDayAnchors: snapshot?.visibleDayAnchors ?? [],
      headerDate: snapshot?.headerDate ?? null,
      headerDateAriaLabel: snapshot?.headerDateAriaLabel ?? null,
      nowLineVisible: snapshot?.nowLineVisible ?? false,
      visibleStaffHeadCount: snapshot?.visibleStaffHeadCount ?? 0,
      clippedStaffHeadLabels: snapshot?.clippedStaffHeadLabels ?? [],
      sticky: snapshot?.sticky ?? null,
      geometry: snapshot?.geometry ?? null,
      runtimeErrors: uniqueRuntimeErrors
    });
    await context.close();
  }
  console.log(`← ${testCase.name}`);
  return snapshot;
}

function assertDesktop(snapshot, testCase) {
  requireValue(snapshot, 'va-layout-ready', '1', testCase.name);
  requireValue(snapshot, 'calendar-desktop-fit', '1', testCase.name);
  requireValue(snapshot, 'calendar-compact-projection', '0', testCase.name);
  requireValue(snapshot, 'calendar-surface-clean', '1', testCase.name);
  requireValue(snapshot, 'calendar-vertical-owner-count', '0', testCase.name);
  requireValue(snapshot, 'calendar-primary-scroll-owner', 'none', testCase.name);
  requireValue(snapshot, 'visible-staff-count', '5', testCase.name);
  for (const anchor of ['08:00', '18:00']) if (!snapshot.visibleDayAnchors?.includes(anchor)) {
    errors.push(`${testCase.name}: day anchor ${anchor} is not visibly rendered`);
  }
  for (const attribute of ['document-overflow-x', 'document-overflow-y', 'page-overflow-y', 'calendar-surface-overflow-x', 'calendar-surface-overflow-y']) {
    const value = attributeNumber(snapshot, attribute);
    if (!(value != null && value <= 2)) errors.push(`${testCase.name}: ${attribute} must be <=2, received ${value}`);
  }
  const gap = attributeNumber(snapshot, 'calendar-grid-bottom-gap');
  if (!(gap != null && Math.abs(gap) <= 2)) errors.push(`${testCase.name}: grid bottom gap must be <=2px, received ${gap}`);
  const hourPixels = attributeNumber(snapshot, 'va-hour-pixels');
  if (!(hourPixels != null && hourPixels >= 44)) errors.push(`${testCase.name}: full-day fit below 44px/hour: ${hourPixels}`);
  const regime = attributeValue(snapshot, 'va-layout-regime');
  if (!['desktop-full', 'desktop-compact'].includes(regime)) errors.push(`${testCase.name}: unexpected desktop regime ${regime}`);
  if (snapshot.visibleStaffHeadCount !== 5) errors.push(`${testCase.name}: expected five visibly rendered staff heads, received ${snapshot.visibleStaffHeadCount}`);
  if (snapshot.clippedStaffHeadLabels?.length) errors.push(`${testCase.name}: staff heads are horizontally clipped: ${snapshot.clippedStaffHeadLabels.join(', ')}`);
}

function assertCompact(snapshot, testCase) {
  requireValue(snapshot, 'va-layout-ready', '1', testCase.name);
  requireValue(snapshot, 'calendar-compact-projection', '1', testCase.name);
  requireValue(snapshot, 'calendar-surface-clean', '1', testCase.name);
  requireValue(snapshot, 'calendar-vertical-owner-count', '1', testCase.name);
  requireValue(snapshot, 'calendar-primary-scroll-owner', 'calendar-viewport', testCase.name);
  for (const attribute of ['document-overflow-x', 'document-overflow-y', 'page-overflow-y']) {
    const value = attributeNumber(snapshot, attribute);
    if (!(value != null && value <= 2)) errors.push(`${testCase.name}: ${attribute} must be <=2, received ${value}`);
  }
  const overflowY = attributeNumber(snapshot, 'calendar-surface-overflow-y');
  if (!(overflowY != null && overflowY > 2)) errors.push(`${testCase.name}: calendar must own vertical overflow, received ${overflowY}`);
  const expectedRegime = testCase.orientation === 'portrait' ? 'compact-portrait-scroll' : 'compact-landscape-scroll';
  if (attributeValue(snapshot, 'va-layout-regime') !== expectedRegime) {
    errors.push(`${testCase.name}: expected ${expectedRegime}, received ${attributeValue(snapshot, 'va-layout-regime')}`);
  }
  if (testCase.orientation === 'portrait' || testCase.width <= 900) {
    const overflowX = attributeNumber(snapshot, 'calendar-surface-overflow-x');
    if (!(overflowX != null && overflowX > 2)) errors.push(`${testCase.name}: staff columns must move horizontally, received ${overflowX}`);
  }
  const functional = firstAttributeValue(snapshot, ['mobile-horizontal-scroll-functional', 'tp-staff-scroll-functional']);
  const delta = firstAttributeValue(snapshot, ['mobile-horizontal-scroll-delta', 'tp-staff-scroll-delta']);
  if (testCase.orientation === 'portrait' && functional == null) {
    errors.push(`${testCase.name}: functional horizontal staff movement proof is missing`);
  }
  if (functional != null) {
    if (functional !== '1') errors.push(`${testCase.name}: functional horizontal staff movement failed (${functional})`);
    const numericDelta = delta == null || delta === '' ? null : Number(delta);
    if (!(numericDelta != null && numericDelta > 2)) {
      errors.push(`${testCase.name}: horizontal staff movement delta must be >2, received ${numericDelta}`);
    }
  }
  for (const [name, value] of Object.entries(snapshot.sticky ?? {})) {
    if (value !== 'sticky') errors.push(`${testCase.name}: ${name} must be computed sticky, received ${value}`);
  }
  requireValue(snapshot, 'calendar-initial-now-positioned', '1', testCase.name);
}

function assertGeometryParity(actual, expected, label) {
  if (!actual?.geometry || !expected?.geometry) {
    errors.push(`${label}: geometry snapshot missing`);
    return;
  }
  for (const section of ['viewport', 'calendarHead', 'grid']) {
    for (const field of ['left', 'top', 'width', 'height']) {
      const actualValue = actual.geometry[section]?.[field];
      const expectedValue = expected.geometry[section]?.[field];
      if (!(Number.isFinite(actualValue) && Number.isFinite(expectedValue) && Math.abs(actualValue - expectedValue) <= 2)) {
        errors.push(`${label}: ${section}.${field} changed from ${expectedValue} to ${actualValue}`);
      }
    }
  }
  for (const field of ['viewportScrollWidth', 'viewportScrollHeight']) {
    if (Math.abs((actual.geometry[field] ?? 0) - (expected.geometry[field] ?? 0)) > 2) {
      errors.push(`${label}: ${field} changed from ${expected.geometry[field]} to ${actual.geometry[field]}`);
    }
  }
}

rmSync(outputDirectory, { recursive: true, force: true });
mkdirSync(outputDirectory, { recursive: true });
const server = createStaticServer();
let browser;

try {
  const baseUrl = await listen(server);
  const referenceUrl = `${baseUrl}?referenceDate=2026-08-25&referenceNow=11:22`;
  browser = await chromium.launch({ channel: 'chromium', headless: true });

  const desktopSnapshots = new Map();
  for (const testCase of DESKTOP_CASES) {
    const snapshot = await renderCase(browser, testCase, referenceUrl);
    if (snapshot) {
      desktopSnapshots.set(testCase.name, snapshot);
      assertDesktop(snapshot, testCase);
    }
  }
  for (const testCase of COMPACT_CASES) {
    const url = testCase.orientation === 'portrait' ? `${referenceUrl}&verifyStaffScroll=1` : `${referenceUrl}&agenda=open`;
    const snapshot = await renderCase(browser, testCase, url);
    if (snapshot) assertCompact(snapshot, testCase);
  }

  const coarseCase = { name: '1024x768-coarse-touch', width: 1024, height: 768, hasTouch: true };
  const coarseSnapshot = await renderCase(browser, coarseCase, referenceUrl);
  if (coarseSnapshot) assertDesktop(coarseSnapshot, coarseCase);

  const baselineSnapshot = desktopSnapshots.get('1512x982');
  const agendaCase = { name: '1512x982-agenda-open', width: 1512, height: 982 };
  const agendaSnapshot = await renderCase(browser, agendaCase, `${referenceUrl}&agenda=open`);
  if (agendaSnapshot) {
    assertDesktop(agendaSnapshot, agendaCase);
    requireValue(agendaSnapshot, 'visible-agenda-panels', '1', agendaCase.name);
    assertGeometryParity(agendaSnapshot, baselineSnapshot, agendaCase.name);
  }

  const focusCase = { name: '1512x982-focus', width: 1512, height: 982 };
  const focusSnapshot = await renderCase(browser, focusCase, `${referenceUrl}&focus=melanie&verify=1`);
  if (focusSnapshot) {
    assertDesktop(focusSnapshot, focusCase);
    if (attributeNumber(focusSnapshot, 'focus-context-count') !== 4) errors.push(`${focusCase.name}: expected four context lanes`);
    assertGeometryParity(focusSnapshot, baselineSnapshot, focusCase.name);
  }

  const dateCase = { name: '1512x982-reference-date', width: 1512, height: 982 };
  const expectedHeaderDate = 'Montag, 24. August';
  const dateSnapshot = await renderCase(browser, dateCase, `${baseUrl}?referenceDate=2026-08-24&referenceNow=11:22`);
  if (dateSnapshot) {
    assertDesktop(dateSnapshot, dateCase);
    if (dateSnapshot.headerDate !== expectedHeaderDate) {
      errors.push(`${dateCase.name}: expected visible date ${expectedHeaderDate}, received ${dateSnapshot.headerDate}`);
    }
    if (dateSnapshot.headerDateAriaLabel !== `${expectedHeaderDate} wählen`) {
      errors.push(`${dateCase.name}: date control accessible name does not match the reference date`);
    }
    if (!dateSnapshot.nowLineVisible) errors.push(`${dateCase.name}: reference date is not treated as the current salon day`);
  }
} catch (error) {
  errors.push(error.message);
} finally {
  writeFileSync(resolve(outputDirectory, 'matrix.json'), `${JSON.stringify(evidence, null, 2)}\n`);
  if (browser) await browser.close();
  if (server.listening) await new Promise((resolvePromise) => server.close(resolvePromise));
}

if (errors.length) {
  console.error(`Tagesplan v1 surface verification failed (${errors.length}):`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log(
  `✓ Tagesplan v1 Chromium surface matrix verified (${DESKTOP_CASES.length} desktop/zoom cases, ${COMPACT_CASES.length} compact cases, 4 state/reference cases)`
);
