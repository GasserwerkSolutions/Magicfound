#!/usr/bin/env python3
"""Create offline inspection viewer and grounded Markdown evidence report."""
import base64,collections,html,json,re,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'daten';imp=json.loads((D/'aenderungsfolgen-graph.json').read_text());ident=json.loads((D/'identitaeten.json').read_text());mut=json.loads((D/'token-mutationen.json').read_text());styles=json.loads((D/'css-quellenkarte.json').read_text())
measure=json.loads((ROOT/'eingaben'/'browser-messung.json').read_text())
scs={s['meta']['scenario']:s for s in measure['scenarios']}
imgs={}
for scene in ['kalender-1440','kalender-390','heute-1440','betrieb-1440']:
 file=ROOT/'eingaben'/'screenshots'/(scene+'.png')
 if file.exists():imgs[scene]='data:image/png;base64,'+base64.b64encode(file.read_bytes()).decode()
oldzip=Path('/mnt/data/UI-Relationsgraph-V11-Paket.zip')
if oldzip.exists() and not imgs:
 with zipfile.ZipFile(oldzip) as z:
  for scene in ['kalender-1440','kalender-390','heute-1440','betrieb-1440']:
   raw=z.read(f'UI-Relationsgraph-V11/screenshots/{scene}.png')
   imgs[scene]='data:image/png;base64,'+base64.b64encode(raw).decode()
choices=[]
for event in imp['interventions']:
 if event['scenario'] not in imgs:continue
 m=next(z for z in mut['interventions'] if z['scenario']==event['scenario'] and z['mutationId']==event['mutationId'])
 records=scs[event['scenario']]['records']
 choices.append({'scenario':event['scenario'],'token':event['token'],'mutationId':event['mutationId'],
  'nodeCount':len(event['nodes']),'visibleCount':sum(n['visibleInLayout'] for n in event['nodes']),
  'onscreenCount':sum(n['visibleInLayout'] and n['viewportIntersection'] for n in event['nodes']),
  'nodes':[{'index':n['index'],'identity':n['identity'],'certainty':n['identityCertainty'],'family':n['family'],
            'visible':n['visibleInLayout'],'onscreen':n['viewportIntersection'],
            'rect':records[n['index']]['rect'],
            'changes':next(z['changedProperties'] for z in m['affectedNodes'] if z['index']==n['index']),
            'pseudo':n['pseudo']} for n in event['nodes']]})
view={'summary':ident['summary'],'tokens':imp['tokenSummary'],
 'sourceUsage':{n:styles['tokens'][n]['references'] for n in imp['tokenSummary']},
 'choices':choices,'images':imgs,
 'scenarios':{k:{'width':v['meta']['viewport']['width'],'height':v['meta']['viewport']['height']} for k,v in scs.items() if k in imgs}}

report=f'''# Stable UI-Identitäten und empirische Änderungsfolgen — V11

**Messbasis:** Original-HTML SHA-256 `{measure['source']['sha256']}`; 13 Chromium-Browserzustände aus dem vorangegangenen Relationsgraph-Pilot. Vier davon wurden für gezielte Tokenmutationen erneut in Chromium geöffnet. Die HTML-Quelldatei wurde nicht verändert.

## A. Automatische Identitätserkennung

- {ident['summary']['totalNodeObservations']:,} DOM-Beobachtungen über {ident['summary']['scenarioCount']} Zustände.
- {ident['summary']['declaredObservations']:,} Beobachtungen mit eindeutiger, expliziter DOM-ID oder `data-ui` (verbindliche DOM-Identität im Szenario); {ident['summary']['candidateObservations']:,} mit lediglich vorläufiger Strukturzuordnung.
- **{ident['summary']['stableDeclaredMatches']} zustandsübergreifende Identitäten** mit überprüfter deklarierter Kennung, **{ident['summary']['tentativeMatches']} Strukturpfad-Matches** (Kandidaten, nicht bestätigt).
- {ident['summary']['issues']} automatisch erkannte Identitätskollisionen in dieser Stichprobe. Das bestätigt keine generelle Kollisionsfreiheit auf anderen Seiten.

*Wichtige Einschränkung:* Eine stabile DOM-ID ist nicht automatisch die kanonische Identität einer Fachkomponente oder eines Datensatzes. Die Produktimplementierung sollte `data-ui`, `data-instance-key`, `data-slot`, `data-state` mit nicht-personenbezogenen, langlebigen Instanzschlüsseln bereitstellen. Dynamische Positionsnummern sind als stabile Identitäten nicht zuverlässig.

## B. Interventionsmessung in vier Browseransichten

| CSS Token | Statische `var(...)`-Referenzen im HTML-CSS | Betroffene DOM-Vorkommen über 4 Zustände | Sichtbare DOM-Vorkommen | Elemente im Viewport | Geometriemutationen |
|---|---:|---:|---:|---:|---:|
'''
for tok,data in imp['tokenSummary'].items():
 interventions=[x for x in imp['interventions'] if x['token']==tok]
 nvis=sum(y['visibleInLayout'] for x in interventions for y in x['nodes'])
 nin=sum(y['visibleInLayout'] and y['viewportIntersection'] for x in interventions for y in x['nodes'])
 ngeom=sum(bool(y['geometryDeltasPx']) for x in interventions for y in x['nodes'])
 report+=f"| `{tok}` | {styles['tokens'][tok]['references']} | {data['observedNodeInterventions']} | {nvis} | {nin} | {ngeom} |\n"
report+='''
**Negativkontrolle:** Eine absichtlich nicht verwendete CSS-Variable führte bei allen vier Ansichten zu 0 beobachteten CSS- oder Geometrieänderungen. Alle 20 Interventionen einschliesslich Kontrollläufen meldeten **MEASURED**; Rücknahme aller Änderungen war im ausgewerteten Eigenschaftenset exakt. Bei `--radius` findet die statische CSS-Auswertung vier Verwendungen, die aktuellen vier Ansichten zeigen aber keine beobachtete Wirkung auf die erfassten BODY-Elemente. Damit ist die Trennung zwischen potenzieller und realisierter Abhängigkeit messbar.

**Keine vorgetäuschte Vertragsabdeckung:** Die bisherigen V11-Regeln betreffen überwiegend Geometrie und Semantik. Reine Farbänderungen treffen zwar häufig deren Selektoren, verändern aber keine geprüften geometrischen Eingaben. Daher weist die neue Analyse **0 direkt erneut auszuführende bisherige Geometrie-Oracles** nach. Daraus folgt nicht, dass Kontrast und Wahrnehmung bestanden wären: Es fehlen ausdrücklich eigene Text-/UI-Kontrast-Oracles im selben Änderungszustand sowie Dark-/Theme-Messungen.

## C. Bedeutung des Änderungsgraphen

1. `observed-intervention-affects-node` — die Browserintervention hat gemessene CSS-Eigenschaften dieses Elements geändert; empirisch belegt, für den jeweiligen Zustand.
2. `possible-context-review` — der betroffene Knoten hat einen Elterncontainer; mögliche Prüfumgebung, **keine festgestellte Änderung des Elterncontainers**.
3. `selectorIntersectionsNotNecessarilyRelevant` — ein bestehender Test spricht denselben Knoten an, möglicherweise aber eine nicht veränderte Eigenschaft.
4. `contractRecheckTargets` — nur dann erforderlich, wenn die Mutation eine Eingabe des Oracles verändert (z. B. Geometrie bei Achsenregeln oder Outline-Werte bei Fokusregeln).
5. `recommendedChecks` — Vorschläge für noch nicht ausgeführte Prüfungen, **keine bestandenen Tests**.

## D. Als Nächstes zwingend nötig

- **Explizite, nicht-personenbezogene Instanzkennungen** aus der echten Komponentenquelle statt Klassen-/Positions-Heuristik.
- **CSS-Provenienz bis zur angewendeten Regel** über Browser-Cascade/CDP; `getComputedStyle` liefert Werte, aber nicht die Quelle ihrer Ableitung.
- **Theme-, Hover-, Focus-, Overlay-, Zoom- und Geräte-Matrix** für jede benannte Komponentengruppe; derzeit nur vier Interventionen pro Token und wenige Ansichten.
- **Farbpaare, effektive Hintergründe, Kontraste und Wahrnehmungsprüfungen** bei farbverändernden Eingriffen.
- **Tatsächliche Re-Runs von betroffenem Funktions- und Visuallayout** vor jeder Freigabe; der Impact-Graph plant nur die Prüfung.

## E. Reproduzierbarkeit

`python scripts/stabile_identitaeten.py --measurement eingaben/browser-messung.json --output daten/identitaeten.json`

`python scripts/css_quellenkarte.py --html eingaben/v11-original.html --output daten/css-quellenkarte.json`

`python scripts/token_folgen_browser.py --html eingaben/v11-original.html --config config/mutations.json --output daten/token-mutationen.json`

`python scripts/folgen_graph.py --measurement eingaben/browser-messung.json --identities daten/identitaeten.json --mutations daten/token-mutationen.json --contract eingaben/relationsvertrag-v11.json --output daten/aenderungsfolgen-graph.json`

`python tests/test_relationssystem.py`

Voraussetzungen: Python 3, `tinycss2`, `playwright`, Chromium-Browser. Bei der Browserausführung nur **vertrauenswürdiges HTML**, da dessen JavaScript ausgeführt wird. Die für Tests verfügbaren Messungen sind Stichproben, keine vollständige Erfassung aller Interaktionen oder Produktionsdaten.
'''
(ROOT/'berichte'/'FOLGENBERICHT.md').write_text(report,encoding='utf8')

serialized=json.dumps(view,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
page='''<!DOCTYPE html>
<html lang="de-CH"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>UI-Änderungsfolgen – gemessene Beziehungen</title>
<style>
:root{font-family:system-ui,-apple-system,sans-serif;color:#e8f3ef;background:#101b1a;font-size:14px}*{box-sizing:border-box}body{margin:0}.top{padding:24px clamp(16px,3vw,36px);border-bottom:1px solid #304743;background:#172523}h1{font-size:22px;margin:0 0 10px}p{margin:4px 0;line-height:1.5;color:#b5c9c3}.meta{font-size:12px}.cards{display:flex;flex-wrap:wrap;gap:12px;margin:16px 0}.card{border:1px solid #3a544e;border-radius:12px;padding:13px 17px;min-width:160px;background:#1d302c}.card strong{font-size:22px;display:block}.card span{color:#b7d0c7;font-size:11px}.app{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(330px,1fr);min-height:70vh}.preview{padding:24px;background:#111c1a;min-width:0}.panel{padding:24px;border-left:1px solid #324640;min-width:0}.controls{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 16px;align-items:center}button,select,input{font:inherit;color:#e8f3ef;background:#243732;border:1px solid #4a6c62;border-radius:8px;padding:9px 12px;min-height:40px}button{cursor:pointer}button[aria-pressed="true"]{background:#376c65;border-color:#8bd2ba}button:focus-visible,select:focus-visible,input:focus-visible{outline:3px solid #e0bc74;outline-offset:2px}label{font-size:12px;color:#c3d4cd}.image-frame{position:relative;background:#e7eee8;max-width:100%;border-radius:11px;overflow:hidden;border:1px solid #4d675f;line-height:0}.image-frame img{display:block;width:100%;height:auto}.mark{position:absolute;pointer-events:none;border:3px solid #d06533;background:rgba(232,117,65,.14);box-shadow:0 0 0 1px white inset;border-radius:3px}.legend{margin:12px 0;font-size:12px;color:#b5c9c3}.pill{display:inline-block;padding:3px 7px;border:1px solid #6b8077;border-radius:99px;font-size:11px}.pass{color:#80ddae}.muted{color:#9fb8af}.row{width:100%;display:flex;gap:8px;justify-content:space-between;align-items:center;margin:5px 0;text-align:left;overflow:hidden}.row span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.row small{flex:none;color:#9bbab1}.scroll{height:min(430px,60vh);overflow:auto;border:1px solid #334c45;padding:10px;border-radius:9px;margin-top:10px;background:#162420}.details{background:#1b2d29;padding:14px;border:1px solid #3a514a;border-radius:9px;margin-top:16px;min-height:90px;overflow:auto}code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;color:#d6e5df;font-size:12px;overflow-wrap:anywhere}h2{font-size:15px;margin:20px 0 10px}h3{font-size:13px;margin:10px 0}.highlight{color:#f3d39a}.tiny{font-size:12px}.status{background:#203b35;padding:3px 7px;border-radius:6px}@media(max-width:900px){.app{grid-template-columns:1fr}.panel{border-left:0;border-top:1px solid #324640}.preview,.panel{padding:16px}}
</style></head><body>
<header class="top"><h1>UI-Relationsgraph · Änderungsfolgen</h1><p>Gerenderte Browserrealität, stabile und vorläufige Identitäten, kontrollierte Tokenmutationen. Alle Bilder und Daten sind lokal eingebettet.</p><div id="summary" class="cards"></div><p class="meta">Werte sind gemessene Element-Vorkommen in angegebenen Zuständen, keine produktweite Vollständigkeitsgarantie.</p></header>
<main class="app"><section class="preview"><div class="controls"><label for="scenario">Browseransicht</label><select id="scenario"></select></div><div id="screen" class="image-frame"><img id="screenshot" alt="Browseraufnahme der ausgewählten Oberfläche"><div id="highlight"></div></div><p class="legend">Oranger Rahmen: ausgewähltes Element. Ohne sichtbares Rechteck gibt es keine Markierung. Screenshots zeigen die unveränderte Originalansicht, nicht den künstlich eingefärbten Mutationszustand.</p><h2>Token-Mutationen</h2><div id="mutations" class="controls"></div><p id="metric" class="tiny muted"></p></section><section class="panel"><label for="q">Betroffene Elemente suchen</label><input style="width:100%;margin-top:5px" id="q" placeholder="Klasse, Index oder Identität suchen"><h2>Direkt beobachtete Änderungen <span id="listCount" class="muted"></span></h2><p class="tiny muted">CSS-Änderungen sind gemessen; DOM-Pfad-Zuordnungen ohne ID bleiben Kandidaten.</p><div class="scroll" id="elements"></div><div class="details" id="details">Element auswählen, um die gemessenen CSS-Werte vor und nach der Intervention zu vergleichen.</div></section></main>
<script id="dataset" type="application/json">__DATA__</script>
<script>
'use strict';const D=JSON.parse(document.getElementById('dataset').textContent);let scenario='kalender-1440', token='--brand',selected=null;
const E=id=>document.getElementById(id);function esc(s){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;')};
function active(){return D.choices.find(x=>x.scenario===scenario&&x.token===token)};
const summary=D.summary;
E('summary').innerHTML=[['DOM-Beobachtungen',summary.totalNodeObservations],['Explizit identifizierbar',summary.declaredObservations],['Nur Kandidat',summary.candidateObservations],['Deklarierte Mehrfach-IDs',summary.stableDeclaredMatches]].map(([label,value])=>`<div class="card"><strong>${Number(value).toLocaleString('de-CH')}</strong><span>${esc(label)}</span></div>`).join('');
for(const s of Object.keys(D.images)){const o=document.createElement('option');o.value=s;o.textContent=s.replaceAll('-',' · ');E('scenario').append(o)}E('scenario').value=scenario;
E('scenario').addEventListener('change',e=>{scenario=e.target.value;selected=null;render()});E('q').addEventListener('input',renderElements);
function render(){E('screenshot').src=D.images[scenario];E('screenshot').alt='Unveränderte Chromium-Aufnahme '+scenario; E('mutations').innerHTML=Object.keys(D.tokens).map(t=>`<button type="button" aria-pressed="${t===token}" data-token="${esc(t)}">${esc(t)}</button>`).join('');
E('mutations').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{token=b.dataset.token;selected=null;render()})); const a=active();
E('metric').textContent=a?`${a.nodeCount} betroffene Elemente, ${a.visibleCount} mit sichtbarem Layout, ${a.onscreenCount} im Viewport · ${D.sourceUsage[token]??0} statische CSS-Referenzen für diesen Token insgesamt`: 'Keine Daten';
E('details').textContent='Element auswählen, um die gemessenen CSS-Werte vor und nach der Intervention zu vergleichen.';E('highlight').replaceChildren();renderElements()}
function renderElements(){const a=active();let q=E('q').value.toLowerCase().trim();let rows=(a?.nodes||[]).filter(r=>(r.identity+' '+r.family+' '+r.index).toLowerCase().includes(q));E('listCount').textContent=`(${rows.length})`;
E('elements').innerHTML=rows.length?rows.map(r=>`<button type="button" class="row" data-index="${r.index}" aria-pressed="${selected===r.index}"><span>${esc(r.family)} <span class="muted">#${r.index}</span></span><small>${r.certainty==='declared'?'ID':'Kandidat'} · ${r.visible?'sichtbar':'verborgen'}</small></button>`).join(''):'<p>Keine beobachteten Änderungen für diese Auswahl.</p>';
E('elements').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{selected=Number(b.dataset.index);paint();renderElements()}));if(selected!==null)paint()}
function paint(){const a=active();const r=a?.nodes.find(n=>n.index===selected);E('highlight').replaceChildren();if(!r)return;
let markup=`<h3>${esc(r.family)} · DOM-Index ${r.index}</h3><p class="tiny">Identität: <code>${esc(r.identity)}</code><br>Gewissheit: ${r.certainty==='declared'?'eindeutige deklarierte DOM-Identität':'vorläufig, nur aus Struktur'}<br>Layout sichtbar: ${r.visible?'ja':'nein'}</p>`;
for(const [property,v] of Object.entries(r.changes)){markup+=`<p class="tiny"><strong>${esc(property)}</strong><br><code>${esc(v.was)} → <span class="highlight">${esc(v.now)}</span></code></p>`}if(!Object.keys(r.changes).length)markup+='<p class="muted">Pseudoelement oder Geometrieänderung</p>';E('details').innerHTML=markup;
if(r.visible&&r.onscreen){const v=D.scenarios[scenario],box=r.rect,div=document.createElement('div');div.className='mark';for(const [key,val] of Object.entries({left:box.left/v.width*100,top:box.top/v.height*100,width:box.width/v.width*100,height:box.height/v.height*100})){div.style[key]=Math.max(0,val)+'%'}E('highlight').append(div)}}
render();
</script></body></html>'''
(ROOT/'relations-inspektor.html').write_text(page.replace('__DATA__',serialized),encoding='utf8')
print('Report',len(report),'HTML viewer', (ROOT/'relations-inspektor.html').stat().st_size,'bytes')
