# Tagesplan v1.0 · Technische Freeze-Richtlinie

Status: **Verbindlich**  
Verantwortung: technische Bereitstellung und Abnahme  
Branch: `feat/tagesplan-v1-golden-master`  
Zieltag: `tagesplan-v1.0-core-freeze`

## 1. Zweck

Der Core Freeze ist die unveränderliche technische Ausgangsbasis für:

- sichere Beseelungsexperimente;
- reproduzierbare visuelle Vergleiche;
- die Integrationslinie;
- spätere Regressionstests;
- eine eindeutige Rückfallposition.

Er ist keine bloße Momentaufnahme und kein Screenshot-Stand. Er ist ein aus sauberem Quellstand reproduzierbares, eigenständig ausführbares und nachweisbar geprüftes Artefakt.

## 2. Was eingefroren wird

Der Freeze umfasst verbindlich:

### Fachliche Wahrheit

- Zeit, Dauer, Datum, Person, Leistung und Status;
- Salonzeit `Europe/Zurich`;
- vergangene Zeitfläche und Jetzt-Linie;
- Fokus-, Auswahl-, Such- und Agenda-Semantik;
- Aufgaben, Pausen, freie Zeit und Terminobjekte;
- Zustände `normal`, `stress`, `quiet`, `empty`, `loading`, `error`, `offline`, `stale`, `forbidden`, `before-opening`, `during-opening`, `after-closing`, `past-date`, `future-date`, `staff-focus`, `appointment-selected`, `agenda-open`, `search-active`.

### Räumliche Wahrheit

- Zeit vertikal und Mitarbeitende horizontal;
- `08:00–18:00` als ein kontinuierlicher Tag;
- eine zusammenhängende Kalenderfläche;
- vollständiger Tag ohne Desktop-Scroll, solange mindestens 44 Pixel pro Stunde verfügbar sind;
- genau ein vertikaler Scroll-Owner in kompakten Projektionen;
- horizontale Mitarbeitendenbewegung auf schmalen Flächen;
- keine Geometrieänderung durch Agenda oder Personenfokus.

### Interaktionswahrheit

- Tastatur-, Touch- und Pointer-Bedienung;
- sichtbarer Fokus;
- `Escape`-Hierarchie;
- Fokus- und Scrollwiederherstellung;
- keine verschachtelten Modalketten;
- Reduced-Motion-Parität;
- keine simulierte Persistenz.

## 3. Was noch nicht Teil des Freeze ist

Nicht aktiviert werden:

- alpine Szenen;
- emotionale Materialvarianten;
- experimentelle Mikroanimationen;
- alternative Sprachtemperaturen;
- finale SVG-Dienstleistungssymbole;
- dekorative oder atmosphärische Varianten.

Das Wirkungssystem darf als Vertrag und Anschlussstelle im Repository liegen. Die Freeze-Referenz verwendet jedoch einen neutralen Core-Modus, in dem optionale Beseelungskanäle deaktiviert sind.

## 4. Freeze-Artefakte

Der freigegebene Stand muss enthalten:

```text
references/tagesplan/v1.0/
├── tagesplan-reference.html
├── CONTRACT.md
├── STATES.md
├── INTEGRATION.md
├── ACCESSIBILITY.md
├── FREEZE_MANIFEST.json
├── CHECKSUMS.sha256
└── evidence/
```

### `tagesplan-reference.html`

- vollständig isoliert;
- HTML, CSS, JavaScript, Fixtures und erforderliche SVGs eingebettet;
- keine externe Laufzeitressource;
- keine Backendabhängigkeit;
- keine CDN-Abhängigkeit;
- keine Service-Worker-Installation erforderlich;
- direkt über `file://` und statisches HTTP ausführbar;
- deterministische Zustände über URL-Parameter.

### `FREEZE_MANIFEST.json`

Mindestens:

```json
{
  "name": "tagesplan-v1.0-core-freeze",
  "sourceCommit": "<sha>",
  "sourceTree": "<sha>",
  "builtAt": "<SOURCE_DATE_EPOCH-derived>",
  "nodeVersion": "22.x",
  "timezone": "Europe/Zurich",
  "referenceClock": "11:22",
  "artifacts": [],
  "tests": [],
  "beseelung": "disabled"
}
```

### `CHECKSUMS.sha256`

SHA-256 für:

- Single-HTML-Datei;
- Manifest;
- Vertragsdateien;
- Evidenzindex;
- optionales Release-ZIP.

## 5. Deterministischer Build

Der Build muss aus einem sauberen Checkout mit festem Commit reproduzierbar sein.

Verbindlich:

```text
SOURCE_DATE_EPOCH gesetzt
Node-Hauptversion festgelegt
keine zufälligen IDs
keine aktuelle Uhrzeit im Buildinhalt
stabile Dateireihenfolge
stabile JSON-Schlüsselreihenfolge
keine netzwerkabhängige Ressource
```

Zwei unmittelbar aufeinanderfolgende Builds desselben Commits müssen für die freigegebenen Artefakte identische SHA-256-Werte erzeugen.

## 6. Technische Gates

### Gate A · Geometrie

- alle vorgesehenen Layoutregime eindeutig aktiv;
- keine konkurrierenden Scroll-Owner;
- kein Doppelscroll;
- kein stiller Inhaltsschnitt;
- Rasterabschluss innerhalb von 2 Pixeln;
- Agenda und Fokus verändern die Kalendergeometrie nicht.

### Gate B · Funktion und Zustände

- alle Zustände aus Abschnitt 2 reproduzierbar;
- Kalender und Agenda verwenden dieselben Objekte;
- Datum, Zeit, Auswahl, Fokus und offene Kontexte verhalten sich konsistent;
- keine Konsolenfehler;
- keine unbehandelten Promise-Rejections.

### Gate C · Accessibility

- vollständige Tastaturbedienung;
- sichtbare Fokusführung;
- sinnvolle zugängliche Namen;
- Fokuswiederherstellung;
- Touchziele mindestens 44 × 44 CSS-Pixel, sofern sie nicht rein informativ sind;
- Reduced-Motion-Zustand funktional gleichwertig;
- keine Information ausschließlich über Farbe.

### Gate D · Browser, Viewport und Zoom

Mindestens:

```text
1366 × 768
1440 × 810
1440 × 900
1512 × 982
1600 × 900
1920 × 1080
1024 × 768
844 × 390
430 × 932
390 × 844
```

Zoomäquivalente:

```text
90 %
100 %
110 %
125 %
```

Browser:

```text
Chrome/Chromium current CI
Firefox current stable
WebKit/Safari-compatible run
```

Falls Firefox oder WebKit in der verfügbaren CI technisch noch nicht automatisiert werden können, bleibt der Freeze blockiert oder die fehlende Abdeckung wird ausdrücklich als freigabepflichtige Ausnahme dokumentiert; sie darf nicht still übergangen werden.

### Gate E · Resilienz und Integrität

- sauberer Checkout;
- vollständige Tests ohne Retry-Abhängigkeit;
- zweiter identischer Kontrolllauf;
- keine temporären Payload-, Patch- oder Diagnose-Dateien;
- keine doppelten konkurrierenden Implementationspfade;
- Release-Artefakt und Checksummen vorhanden;
- Commit, Tree, Manifest und Tag stimmen überein.

## 7. Git- und Release-Regeln

1. Der Freeze-Commit wird nach grüner Matrix nicht mehr verändert.
2. Der Tag `tagesplan-v1.0-core-freeze` zeigt dauerhaft auf genau diesen Commit.
3. Der Tag darf nicht force-updated werden.
4. Korrekturen erzeugen einen neuen Candidate, beispielsweise:
   - `tagesplan-v1.0-core-freeze-rc.2`
   - danach einen neuen finalen Core-Freeze-Tag.
5. Beseelungsbranches zweigen ausschließlich vom finalen Freeze-Tag ab.
6. Die kanonische Linie übernimmt den Freeze nur nach vollständigem Nachweis.
7. Die öffentliche Referenz wird erst nach kontrollierter Freigabe aktualisiert.

## 8. Beseelungsexperimente

Nach dem Freeze dürfen Varianten ausschließlich additive Wirkungskanäle verändern:

- Raumrhythmus innerhalb der eingefrorenen Geometrie;
- Materialtiefe;
- Bewegungstempo;
- Aufmerksamkeitsstärke;
- Illustrationspräsenz;
- sprachliche Temperatur, solange Bedeutung und Handlung unverändert bleiben.

Nicht zulässig:

- veränderte Terminpositionen oder -größen;
- andere Statusfarben;
- andere Fokus- oder Suchsemantik;
- neue permanente Controls;
- zusätzliche Scrollcontainer;
- geänderte Datenobjekte;
- veränderte Tastaturwege;
- stille Abweichung vom Freeze-Vertrag.

## 9. Freeze-Abnahme

Ein Freeze darf erst gemeldet werden, wenn gleichzeitig vorliegen:

- grüner CI-Gesamtstatus;
- vollständige Browser- und Zustandsmatrix;
- visuelle Evidenz;
- deterministischer Doppelbuild;
- Single-HTML-Referenz;
- Manifest und Prüfsummen;
- bereinigter Branch;
- unveränderlicher Tag;
- dokumentierter Integrationsübergang.

Bis dahin lautet der Status ausschließlich:

```text
Freeze Candidate – nicht freigegeben
```
