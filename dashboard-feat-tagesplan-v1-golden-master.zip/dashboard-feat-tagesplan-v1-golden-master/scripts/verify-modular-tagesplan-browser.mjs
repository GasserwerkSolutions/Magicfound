import { existsSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const root = process.cwd();
const outputDirectory = resolve(root, 'artifacts/tagesplan');
const port = 4173;
const url = `http://127.0.0.1:${port}/pages/tagesplan/?referenceNow=11:22`;
const errors = [];

function findChrome() {
  const candidates = [
    process.env.CHROME_BIN,
    'google-chrome',
    'google-chrome-stable',
    'chromium',
    'chromium-browser'
  ].filter(Boolean);

  for (const candidate of candidates) {
    const probe = spawnSync('bash', ['-lc', `command -v ${candidate}`], { encoding: 'utf8' });
    if (probe.status === 0 && probe.stdout.trim()) return probe.stdout.trim();
  }
  return null;
}

function chromeRun(chrome, args, options = {}) {
  return spawnSync(chrome, [
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--disable-dev-shm-usage',
    '--hide-scrollbars',
    '--run-all-compositor-stages-before-draw',
    '--virtual-time-budget=3500',
    ...args
  ], {
    cwd: root,
    encoding: options.encoding ?? 'utf8',
    maxBuffer: 20 * 1024 * 1024
  });
}

async function waitForServer() {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {
      // Server is still starting.
    }
    await delay(125);
  }
  throw new Error(`Lokaler Referenzserver antwortet nicht auf ${url}`);
}

rmSync(outputDirectory, { recursive: true, force: true });
mkdirSync(outputDirectory, { recursive: true });

const server = spawn('python3', ['-m', 'http.server', String(port), '--bind', '127.0.0.1'], {
  cwd: root,
  stdio: ['ignore', 'pipe', 'pipe']
});

try {
  await waitForServer();
  const chrome = findChrome();
  if (!chrome) throw new Error('Kein Chrome-/Chromium-Binary für Browserprüfung gefunden');

  const domResult = chromeRun(chrome, ['--window-size=1512,982', '--dump-dom', url]);
  if (domResult.status !== 0) {
    errors.push(`Chrome DOM-Prüfung fehlgeschlagen:\n${domResult.stderr.trim()}`);
  } else {
    const dom = domResult.stdout;
    writeFileSync(resolve(outputDirectory, 'rendered-dom.html'), dom);
    if (!dom.includes('data-day-view="work"')) errors.push('Gerenderter DOM enthält die operative Tagesplanfläche nicht');
    if (!dom.includes('day-scroll-viewport')) errors.push('Gerenderter DOM enthält den gemeinsamen Zeit-Viewport nicht');
    if (!dom.includes('day-now-line')) errors.push('Gerenderter heutiger Tagesplan enthält keine Jetzt-Linie');
    if (!dom.includes('11:22')) errors.push('Kontrollierte Referenzuhr wurde nicht als 11:22 gerendert');
    if (!dom.includes('data-focus-staff="melanie"')) errors.push('Personenfokus-Auslöser fehlt im gerenderten DOM');
    if (!dom.includes('data-appointment-id=')) errors.push('Mock-Termine wurden nicht gerendert');
    if (!dom.includes('data-desktop-visible-minutes="240"')) errors.push('240-Minuten-Desktopmassstab fehlt im gerenderten DOM');
    if (!dom.includes('data-desktop-past-minutes="45"')) errors.push('45-Minuten-Live-Vergangenheit fehlt im gerenderten DOM');
    if (!dom.includes('data-visible-minutes="240"')) errors.push('Operativer Viewport wurde nicht auf 240 Minuten kalibriert');
    if (!dom.includes('data-duration-minutes=')) errors.push('Termindauer ist nicht maschinenlesbar am Kartenobjekt hinterlegt');
  }

  const viewports = [
    ['1366x768', 1366, 768],
    ['1440x900', 1440, 900],
    ['1512x982', 1512, 982],
    ['1536x864', 1536, 864],
    ['1600x900', 1600, 900],
    ['1920x1080', 1920, 1080],
    ['390x844', 390, 844],
    ['430x932', 430, 932],
    ['844x390', 844, 390]
  ];

  for (const [name, width, height] of viewports) {
    const target = resolve(outputDirectory, `tagesplan-${name}.png`);
    const result = chromeRun(chrome, [`--window-size=${width},${height}`, `--screenshot=${target}`, url]);
    if (result.status !== 0 || !existsSync(target)) {
      errors.push(`Screenshot ${name} konnte nicht erzeugt werden:\n${result.stderr.trim()}`);
    } else {
      console.log(`✓ Screenshot ${name}`);
    }
  }
} catch (error) {
  errors.push(error.message);
} finally {
  server.kill('SIGTERM');
}

if (errors.length) {
  console.error(`\nBrowserprüfung fehlgeschlagen (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`\n✓ Modulare Tagesplanseite im echten Browser gerendert: ${url}`);
