import { createElement } from '../lib/dom.js';
import { createIcon } from '../shell/icons.js';

export function createButton(options = {}) {
  const {
    label,
    icon = null,
    variant = 'default',
    compact = false,
    iconOnly = false,
    type = 'button',
    disabled = false,
    className = '',
    attributes = {},
    onClick = null
  } = options;

  if (!label && !attributes['aria-label']) {
    throw new TypeError('button label or aria-label is required');
  }

  const classes = [
    'gw-button',
    `gw-button--${variant}`,
    compact ? 'gw-button--compact' : '',
    iconOnly ? 'gw-button--icon-only' : '',
    className
  ].filter(Boolean).join(' ');

  const button = createElement('button', {
    className: classes,
    attributes: {
      type,
      disabled: disabled ? true : null,
      ...attributes
    },
    children: [
      icon ? createElement('span', {
        className: 'gw-button__icon',
        attributes: { 'aria-hidden': 'true' },
        children: typeof icon === 'string' ? createIcon(icon) : icon
      }) : null,
      iconOnly ? null : createElement('span', { className: 'gw-button__label', text: label })
    ]
  });

  if (typeof onClick === 'function') button.addEventListener('click', onClick);
  return button;
}
