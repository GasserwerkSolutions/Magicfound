# Team · Seitenvertrag

Status: **Zur Freigabe – fachliche Teamverwaltung konsolidiert, Beschäftigungsmodell integrationsrelevant**  
Verantwortlicher Bereich: `Team`  
Direkter Referenzpfad: `/dashboard/pages/team/`  
Abhängige gemeinsame Verträge: `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

Die Seite `Team` zeigt die im Salon tätigen Personen und macht deren fachliche Einordnung, Aktivstatus und Verfügbarkeit verständlich.

Primäre Arbeitsaufgaben:

- Teamübersicht prüfen
- eine Person öffnen
- fachliche Rolle und Arbeitszeit-/Verfügbarkeitszusammenfassung erkennen
- mit entsprechender Berechtigung eine Person anlegen oder bearbeiten

Diese Seite verwaltet Salonpersonen. Sie ist nicht die Rollen- und Rechteverwaltung des Produkts. `Top Stylistin`, `Stylistin`, `Lernende` oder `Barber` sind fachliche Rollen; Zugriffsrechte werden separat über Capabilities geregelt.

Nicht Bestandteil dieser V1:

- Lohnabrechnung
- Zeiterfassung
- Feriengenehmigungsworkflow
- produktive Rechteverwaltung
- Schichtplanung mit Persistenz

## 2. Eingabedaten

Datenquellenmethoden:

```js
getSessionContext()
listStaff(query)
getStaffMember(id)
listServices()
```

Query:

```js
{
  activeOnly,
  professionalRoleIds,
  serviceIds,
  locationIds,
  text,
  sort
}
```

Erforderliche Listenfelder:

- stabile `id`
- `displayName`
- `initials`
- `professionalRoleLabel`
- `isActive`

Optionale Felder:

- reguläre Arbeitstage
- Arbeitszeit-/Verfügbarkeitszusammenfassung
- Standortzuordnung
- zugewiesene Dienstleistungen
- Kontakt- oder Profilinformationen, sofern erlaubt

Capabilities:

- Anzeige: `staff:view`
- Anlegen und Bearbeiten: `staff:manage`
- Dienstleistungszuordnung anzeigen: `service:view`
- Dienstleistungszuordnung ändern: zusätzlich `service:manage`

## 3. Fachliches View-Model

```js
{
  query: {
    activeOnly,
    professionalRoleIds,
    serviceIds,
    locationIds,
    text,
    sort
  },
  people: [
    {
      id,
      displayName,
      initials,
      professionalRoleLabel,
      isActive,
      availabilitySummary,
      weeklySchedule,
      assignedServices,
      locationLabels,
      actions
    }
  ],
  selectedStaffMember: null | {
    id,
    displayName,
    professionalRoleLabel,
    activeState,
    schedule,
    exceptions,
    assignedServices,
    locations,
    actions
  }
}
```

Invarianten:

- Fachliche Teamrolle und Produktberechtigungsrolle bleiben getrennt.
- Deaktivierte Personen bleiben für historische Referenzen identifizierbar.
- Die Teamreihenfolge ist deterministisch und kommt aus dem View-Model beziehungsweise einer expliziten Sortierung.
- Arbeitszeit und Salonöffnung sind getrennte Konzepte.
- Eine fehlende Arbeitszeit wird als unvollständig gekennzeichnet und nicht als freie Verfügbarkeit interpretiert.
- Dienstleistungszuweisungen verwenden stabile Service-IDs.

## 4. Ausgehende Ereignisse

### Suche oder Filter ändern

```js
{
  type: "staff:query-changed",
  payload: { query }
}
```

### Person öffnen

```js
{
  type: "staff:selected",
  payload: { staffId, source: "team-page", originCardId }
}
```

### Person anlegen

```js
{
  type: "staff:create-requested",
  payload: { locationId: null | string, source: "team-page" }
}
```

### Person bearbeiten

```js
{
  type: "staff:edit-requested",
  payload: { staffId, section }
}
```

### Aktivstatus ändern

```js
{
  type: "staff:active-state-change-requested",
  payload: { staffId, from, to }
}
```

Der Event ist erst aktiv, wenn die Deaktivierungs- und Historienregeln fachlich geklärt sind.

## 5. Ladezustand

- Produktschale, Seitentitel und erlaubte primäre Aktion bleiben sichtbar.
- Teamkarten beziehungsweise Listenzeilen erhalten strukturelle Skeletons.
- Filter bleiben nutzbar, sofern ihre Optionen bekannt sind.
- Bei Detailladung bleibt die ausgewählte Person markiert.
- Bestehende Teamdaten dürfen während einer Aktualisierung sichtbar bleiben und werden als aktualisierend markiert.

## 6. Leerzustand

### Kein Team erfasst

- erklärt, dass ohne Team keine personengebundene Buchbarkeit entsteht
- bietet `Person anlegen`, sofern erlaubt
- zeigt keine fiktiven Personen

### Keine Treffer für Filter

- zeigt aktive Filter
- bietet `Filter zurücksetzen`
- unterscheidet sich klar von einem leeren Salonteam

### Person ohne Arbeitszeiten oder Dienstleistungen

- Detail bleibt vorhanden
- fehlende Zuordnung wird konkret als unvollständig angezeigt
- es wird nicht stillschweigend eine Standardverfügbarkeit angenommen

## 7. Fehlerzustand

Kernladefehler:

- Seite bleibt in der Produktschale.
- erneute Ladeaktion ist verfügbar.
- Fehler wird nicht als leeres Team dargestellt.

Detailfehler:

- Teamübersicht bleibt nutzbar.
- Detailfläche zeigt Retry und Schliessen.

Teilfehler:

- fehlende Dienstleistungszuordnung verhindert nicht das Anzeigen der Person.
- fehlende Arbeitszeit wird als unbekannt beziehungsweise unvollständig gekennzeichnet.

Offline/Stale:

- vorhandene Teamdaten bleiben sichtbar.
- Änderungen werden nicht als erfolgreich markiert, solange keine Bestätigung vorliegt.

## 8. Berechtigungszustände

- Ohne `staff:view` erscheint ein vollständiger Forbidden-Zustand.
- Ohne `staff:manage` ist die Seite lesbar, aber ohne Anlegen-, Bearbeiten- oder Aktivstatusaktionen.
- Ohne `service:view` werden Dienstleistungszuweisungen nicht geliefert.
- Ohne `service:manage` können Zuordnungen nur gelesen werden.
- Produktberechtigungen einer Person werden auf dieser Seite nicht angezeigt, sofern nicht zusätzlich ein eigener Access-Management-Kontext und `administration:manage-access` vorliegen.

## 9. Desktopverhalten

- Sidebar und normaler Produktkopf bleiben sichtbar.
- Das Team wird als responsive Karten- oder Listenmatrix dargestellt.
- Karten zeigen Name, fachliche Rolle, Aktivstatus und kompakte Arbeitszeit-/Zuordnungsinformation.
- Detail oder Bearbeitung erscheint in einer gemeinsamen Kontextfläche, nicht als lokale zweite App-Schale.
- Auf 14-Zoll-Viewports wird die Kartenmatrix verdichtet, ohne Namen oder Rollen unlesbar zu machen.
- Kartenhöhe darf sich nach Inhalt unterscheiden, aber Hauptaktionen bleiben räumlich konsistent.
- Die Seite besitzt einen vertikalen Scroll-Owner und keinen horizontalen Gesamtüberlauf.

## 10. Mobilverhalten

- Teamkarten werden einspaltig dargestellt.
- Primäre Informationen stehen vor Wochenplan- oder Zuordnungsdetails.
- Detail und Bearbeitung öffnen als vollständige Inhaltsfläche oder unteres Sheet, abhängig vom Umfang.
- Lange Wochenpläne und Dienstleistungslisten scrollen vertikal.
- Erstellen und Bearbeiten bleiben mit sicheren Touch-Zielen erreichbar.
- Die mobile Seite verwendet dieselben fachlichen Rollen, Aktivstatus- und Fehlermodelle wie Desktop.

## 11. Tastatur und Fokus

- Teamkarten beziehungsweise Zeilen sind per Tastatur aktivierbar.
- `Enter` oder Leertaste öffnet die Person.
- Anlegen- und Bearbeitungsflächen halten den Fokus.
- `Escape` schliesst die oberste Kontextfläche.
- Schliessen stellt den Fokus auf die ursprüngliche Karte zurück.
- Wird eine Person deaktiviert und durch den aktiven Filter entfernt, wird der Fokus auf eine sinnvolle Nachbarposition oder den Seitentitel gesetzt und die Änderung angekündigt.
- Unvollständige Arbeitszeiten werden zusätzlich textlich und nicht nur farblich kommuniziert.

## 12. Abnahmekriterien

- Seite ist direkt aufrufbar.
- Normal-, Lade-, Leer-, Filter-ohne-Treffer-, Fehler-, Offline-, Stale- und Forbidden-Zustände sind vorhanden.
- Fachliche Rolle und Berechtigungsrolle werden in Datenmodell und UI nicht vermischt.
- Deaktivierte Personen können historisch referenziert bleiben.
- Fehlende Arbeitszeiten werden nicht als Verfügbarkeit interpretiert.
- Dienstleistungszuweisungen verwenden stabile IDs.
- Lesemodus und Verwaltungsmodus reagieren korrekt auf Capabilities.
- Detail schliesst mit Fokus- und Scrollwiederherstellung.
- 14-Zoll, Standard-Desktop, Mobil und Tablet sind geprüft.
- Keine Gesamtseite läuft horizontal über.
- Keine Änderung wird ohne Adapterbestätigung als gespeichert dargestellt.

## 13. Integrationshinweise

- Offene Fragen: `Q-002`, `Q-003`, `Q-005`, `Q-006`, `Q-007`, `Q-STAFF-001` bis `Q-STAFF-003`, `Q-SVC-002`.
- Arbeitszeiten, Ausnahmen und Abwesenheiten sollen getrennte Domainobjekte sein; die genaue Backendform bleibt offen.
- Historische Termine müssen eine Person auch nach Deaktivierung weiter lesbar referenzieren können.
- Produktberechtigungen gehören in die Verwaltung und werden nicht aus der fachlichen Rolle abgeleitet.
- Die Referenz darf Wochenpläne darstellen, aber keine nicht geklärten Arbeitszeitregeln persistieren.
