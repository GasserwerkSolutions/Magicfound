export const Capability = Object.freeze({
  DAY_PLAN_VIEW: 'day-plan:view',
  DAY_PLAN_CREATE_APPOINTMENT: 'day-plan:create-appointment',

  APPOINTMENT_VIEW: 'appointment:view',
  APPOINTMENT_EDIT: 'appointment:edit',
  APPOINTMENT_CHANGE_STATUS: 'appointment:change-status',

  CUSTOMER_VIEW: 'customer:view',
  CUSTOMER_VIEW_SENSITIVE_NOTES: 'customer:view-sensitive-notes',
  CUSTOMER_EDIT: 'customer:edit',

  STAFF_VIEW: 'staff:view',
  STAFF_MANAGE: 'staff:manage',

  SERVICE_VIEW: 'service:view',
  SERVICE_MANAGE: 'service:manage',

  ADMINISTRATION_VIEW: 'administration:view',
  ADMINISTRATION_MANAGE_SALON: 'administration:manage-salon',
  ADMINISTRATION_MANAGE_ACCESS: 'administration:manage-access',
  ADMINISTRATION_VIEW_BILLING: 'administration:view-billing',

  ONBOARDING_MANAGE: 'onboarding:manage',
  AUTH_SIGN_IN: 'auth:sign-in'
});

export const CAPABILITY_VALUES = Object.freeze(Object.values(Capability));

export function hasCapability(sessionContext, capability) {
  return Boolean(sessionContext?.capabilities?.includes(capability));
}

export function assertKnownCapabilities(capabilities = []) {
  const unknown = capabilities.filter((capability) => !CAPABILITY_VALUES.includes(capability));
  if (unknown.length) {
    throw new TypeError(`Unknown Gasserwerk capabilities: ${unknown.join(', ')}`);
  }
  return capabilities;
}
