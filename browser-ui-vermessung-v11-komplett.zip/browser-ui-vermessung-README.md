# Browser-Vermessung – Salon Flow V11

## Zweck
Ein echter Chromium-Browser lädt das lokale HTML, navigiert in definierte Ansichten
und exportiert die dort tatsächlich aufgelösten CSS-Werte und DOM-Rechtecke.

## Ausgeführt
- `kalender-desktop-1440`: 188 BODY-DOM-Elemente, 138 mit Layout, 3 sichtbare Kalenderspalten.
- `kalender-mobile-390`: 171 BODY-DOM-Elemente, 110 mit Layout, 1 sichtbare Kalenderspalte.
- `heute-desktop-1440`: 199 BODY-DOM-Elemente, 151 mit Layout.
- 43 CSS Custom Properties von `:root` in allen drei Szenarien.
- 0 JavaScript-Page-Errors in allen drei Szenarien.
- Voll-Export: für die meisten DOM-Elemente ca. 453 durch Chromium aufgelöste CSS-Eigenschaften, dazu Rechtecke, Semantik-/ARIA-Metadaten, DOM-Index und Elternbeziehungen.

## Benutzung (Playwright Python und Chromium erforderlich)
```
python browser-ui-vermessung.py \
  --html 'salon-flow-dashboard-agenda-v11(4).html' \
  --output messung.json \
  --full-css \
  --screenshot-dir screenshots
```

Standard ohne `--full-css`: ein kuratiertes CSS-Eigenschaftenset für schnellere Analysen.
Mit `--full-css`: alle via `getComputedStyle()` enumerierbaren Eigenschaftsnamen und
aufgelösten Werte für alle Elemente innerhalb des HTML-`body`.

## Präzision und Interpretationsgrenzen
- Die Daten stammen vom Browser (CSSOM `getComputedStyle`, Layout `getBoundingClientRect`), nicht aus einer Abschätzung der HTML-Quelle.
- Ein DOM-Element ist nicht automatisch ein semantisch identifiziertes Design-Atom; die Klassifikation und Beziehungsregeln benötigen einen eigenen Vertrag.
- Ein CSS computed value verrät nicht automatisch, aus welcher konkreten CSS-Regel oder Tokenquelle er stammt; dafür sind CSS-Quellanalyse bzw. Chrome DevTools Protocol (Matched Styles) nötig.
- Transparente Flächen, Stacking, tatsächliche Sichtbarkeit hinter Overlays, Rendering von Schrift/Glyphen und wahrgenommener Kontrast sind nicht allein durch Rechteck- und CSSOM-Werte überprüft.
- Positionen beziehen sich auf den Browserviewport zum Messzeitpunkt, nicht auf die Bildschirmpixel. `getBoundingClientRect()` misst CSS-Pixel und kann Bruchteile enthalten.
- Pseudoelemente `::before`/`::after` mit Content werden in Teilmetadaten ausgewiesen, nicht als eigene DOM-Elemente. Shadow DOM und iframes werden nicht durchlaufen.
- Dynamische Zustände sind nur in den drei festgelegten Szenarien erfasst; kein Nachweis von Hover, Fokus, Drag-and-drop, Dark Mode, Vergrösserung, weiteren Browsern usw.
- Produktionsdaten: DOM/Styles können vertrauliche Inhalte indirekt enthalten. Messdaten nicht unkontrolliert veröffentlichen.
- Sicherheitsgrenze: Nur vertrauenswürdige HTML-Dateien laden, da im Test Inline-JavaScript ausgeführt wird.

## Aufbau der Ergebnisse
- `browser-ui-vermessung-v11-vollstaendige-css.json`: Vollmessung aller drei Szenarien.
- `browser-ui-vermessung-v11.json`: kompakter Eigenschaftenauszug derselben Szenarien.
- `screenshots/`: Browserbilder zu den Szenarien.
- `browser-ui-vermessung.py`: ausführbarer Python-Playwright-Messablauf.

## Nächste Stufe
1. Komponentennamen bzw. stabile `data-ui`-IDs aus dem DOM bestimmen.
2. Beziehungen zwischen Komponententypen explizit oder geprüft heuristisch zuordnen.
3. Szenarienmatrix um Zustände, Viewports, Themes, Zoom und Eingaben erweitern.
4. Beziehungen und Toleranzen im Vertrag verankern; nach Änderungen im Browser erneut vermessen.
5. Regressionen, fachliche Abweichungen und noch nicht getestete Fälle getrennt melden.
