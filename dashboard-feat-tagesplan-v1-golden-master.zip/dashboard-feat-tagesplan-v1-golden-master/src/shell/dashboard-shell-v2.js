import { DashboardEvent, createDashboardEvent } from '../data/contracts/events.js';

export const DASHBOARD_NAVIGATION_V2 = Object.freeze([
  { id: 'tagesplan', label: 'Tagesplan', path: 'tagesplan/', icon: 'calendar' },
  { id: 'termine', label: 'Termine', path: 'termine/', icon: 'list' },
  { id: 'kundschaft', label: 'Kundschaft', path: 'kundschaft/', icon: 'customers' },
  { id: 'verwaltung', label: 'Verwaltung', path: 'verwaltung/', icon: 'settings' }
]);

const iconPaths = Object.freeze({
  calendar: '<path d="M4 6.5h16v13H4zM7 3v6M17 3v6M4 10h16"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
  customers: '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3.5 19c.5-4 2.3-6 5.5-6s5 2 5.5 6M14 14c3.4-.4 5.5 1.3 6 5"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  back: '<path d="m15 18-6-6 6-6"/>',
  clock: '<circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/>'
});

export function shellIconV2(name, className = '') {
  const path = iconPaths[name] ?? iconPaths.calendar;
  return `<svg class="${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
}

function normalizeBase(value) {
  return String(value || '..').replace(/\/$/, '');
}

function navigationHref(base, item) {
  return `${normalizeBase(base)}/${item.path}`;
}

function navigationMarkup(activePage, base, mobile = false) {
  const className = mobile ? 'gw-mobile-nav-link' : 'gw-nav-link';
  const iconClass = mobile ? 'gw-mobile-nav-icon' : 'gw-nav-icon';
  return DASHBOARD_NAVIGATION_V2.map((item) => `
    <a class="${className} ${item.id === activePage ? 'is-active' : ''}" href="${navigationHref(base, item)}" data-navigation-id="${item.id}" ${item.id === activePage ? 'aria-current="page"' : ''}>
      ${shellIconV2(item.icon, iconClass)}
      <span>${item.label}</span>
    </a>
  `).join('');
}

function emitShellEvent(target, type, payload) {
  target.dispatchEvent(new CustomEvent('gasserwerk:event', {
    bubbles: true,
    detail: createDashboardEvent(type, payload, { source: 'dashboard-shell-v2' })
  }));
}

function zurichClockParts(instant = new Date(), timeZone = 'Europe/Zurich') {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('de-CH', {
    timeZone,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).formatToParts(instant).map((part) => [part.type, part.value]));
  return { hour: Number(parts.hour), minute: Number(parts.minute) };
}

function updateClock(clock, digital, timeZone) {
  if (!clock || !digital) return;
  const { hour, minute } = zurichClockParts(new Date(), timeZone);
  const hourAngle = ((hour % 12) + minute / 60) * 30;
  const minuteAngle = minute * 6;
  clock.style.setProperty('--gw-clock-hour-angle', `${hourAngle}deg`);
  clock.style.setProperty('--gw-clock-minute-angle', `${minuteAngle}deg`);
  digital.textContent = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
  clock.setAttribute('aria-label', `Salonzeit ${digital.textContent}. Heutigen Tagesplan öffnen.`);
}

/**
 * Shared shell V2: compact work clock, four-item global navigation and
 * management as the home of team, offer, locations and availability.
 */
export function createDashboardShellV2(root, options = {}) {
  if (!(root instanceof HTMLElement)) throw new TypeError('createDashboardShellV2 requires a root HTMLElement');

  const activePage = options.activePage ?? 'tagesplan';
  const title = options.title ?? 'Gasserwerk';
  const kicker = options.kicker ?? 'Salonbetrieb';
  const context = options.context ?? '';
  const primaryActionLabel = options.primaryActionLabel ?? '';
  const searchable = options.searchable !== false;
  const navigationBase = options.navigationBase ?? '..';
  const timeZone = options.timeZone ?? 'Europe/Zurich';
  const todayHref = options.todayHref ?? navigationHref(navigationBase, DASHBOARD_NAVIGATION_V2[0]);

  root.innerHTML = `
    <div class="gw-app-shell gw-shell-v2">
      <aside class="gw-sidebar gw-sidebar-v2" aria-label="Produktnavigation">
        <div class="gw-product-signature"><span class="gw-product-mark">G</span><span>Gasserwerk</span></div>

        <button class="gw-work-clock" type="button" data-work-clock>
          <span class="gw-clock-face" aria-hidden="true">
            <span class="gw-clock-tick is-12">12</span><span class="gw-clock-tick is-3">3</span><span class="gw-clock-tick is-6">6</span><span class="gw-clock-tick is-9">9</span>
            <span class="gw-clock-hand is-hour"></span><span class="gw-clock-hand is-minute"></span><span class="gw-clock-pin"></span>
          </span>
          <span class="gw-clock-copy"><strong data-clock-digital>--:--</strong><small>Salonzeit</small></span>
        </button>

        <nav class="gw-primary-nav">${navigationMarkup(activePage, navigationBase)}</nav>
        <div class="gw-sidebar-spacer"></div>

        <section class="gw-business-card" aria-label="Aktiver Betrieb">
          <span>Betrieb</span>
          <strong>${options.salonName ?? 'Coiffure Sonnegg'}</strong>
          <small>${options.locationLabel ?? 'Zürich Enge'}</small>
        </section>
        <section class="gw-account-card"><span class="gw-account-avatar">${options.accountInitials ?? 'MS'}</span><span><strong>${options.accountName ?? 'Melanie Schneider'}</strong><small>${options.accountRole ?? 'Inhaberin'}</small></span></section>
      </aside>

      <section class="gw-workspace">
        <header class="gw-product-header">
          <div class="gw-heading-area">
            <span class="gw-page-kicker">${kicker}</span>
            <div class="gw-page-title-row">
              <h1 id="gw-page-title">${title}</h1>
              <span id="gw-page-context" class="gw-page-context">${context}</span>
            </div>
          </div>
          <div class="gw-header-search" ${searchable ? '' : 'hidden'}>
            ${shellIconV2('search', 'gw-search-icon')}
            <input id="gw-global-search" type="search" autocomplete="off" placeholder="Kundin, Termin oder freie Zeit suchen" aria-label="Suchen">
            <kbd>⌘K</kbd>
          </div>
          <div id="gw-header-actions" class="gw-header-actions">
            ${primaryActionLabel ? `<button id="gw-primary-action" class="gw-button gw-button-primary" type="button">${shellIconV2('plus')}<span>${primaryActionLabel}</span></button>` : ''}
          </div>
        </header>
        <main id="gw-page-content" class="gw-page-content" tabindex="-1"></main>
      </section>

      <nav class="gw-mobile-navigation gw-mobile-navigation-v2" aria-label="Mobile Produktnavigation">${navigationMarkup(activePage, navigationBase, true)}</nav>
      <div id="gw-shell-live-region" class="gw-visually-hidden" aria-live="polite" aria-atomic="true"></div>
    </div>
  `;

  const refs = Object.freeze({
    content: root.querySelector('#gw-page-content'),
    title: root.querySelector('#gw-page-title'),
    context: root.querySelector('#gw-page-context'),
    headerActions: root.querySelector('#gw-header-actions'),
    primaryAction: root.querySelector('#gw-primary-action'),
    searchInput: root.querySelector('#gw-global-search'),
    liveRegion: root.querySelector('#gw-shell-live-region'),
    clockButton: root.querySelector('[data-work-clock]'),
    clockFace: root.querySelector('.gw-clock-face'),
    clockDigital: root.querySelector('[data-clock-digital]')
  });

  root.querySelectorAll('[data-navigation-id]').forEach((link) => {
    link.addEventListener('click', () => {
      emitShellEvent(root, DashboardEvent.SHELL_NAVIGATE_REQUESTED, {
        pageId: link.dataset.navigationId,
        href: link.getAttribute('href')
      });
    });
  });

  const activateClock = () => {
    emitShellEvent(root, DashboardEvent.SHELL_NAVIGATE_REQUESTED, {
      pageId: 'tagesplan',
      href: todayHref,
      intent: 'today-now',
      source: 'work-clock'
    });
    if (typeof options.onClockActivate === 'function') options.onClockActivate();
    else location.href = todayHref;
  };

  refs.clockButton?.addEventListener('click', activateClock);
  refs.primaryAction?.addEventListener('click', () => options.onPrimaryAction?.());
  refs.searchInput?.addEventListener('focus', () => emitShellEvent(root, DashboardEvent.SEARCH_OPENED, { pageId: activePage }));
  refs.searchInput?.addEventListener('input', (event) => options.onSearch?.(event.target.value));
  refs.searchInput?.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    event.currentTarget.value = '';
    options.onSearch?.('');
    event.currentTarget.blur();
    emitShellEvent(root, DashboardEvent.SEARCH_CLOSED, { pageId: activePage });
  });

  const keyboardShortcut = (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k' && refs.searchInput) {
      event.preventDefault();
      refs.searchInput.focus();
    }
  };
  document.addEventListener('keydown', keyboardShortcut);

  updateClock(refs.clockFace, refs.clockDigital, timeZone);
  const clockTimer = window.setInterval(() => updateClock(refs.clockFace, refs.clockDigital, timeZone), 15_000);

  return Object.freeze({
    refs,
    setTitle(value) { refs.title.textContent = value; },
    setTitleContent(value) { refs.title.innerHTML = value; },
    setContext(value) { refs.context.textContent = value; },
    setContextContent(value) { refs.context.innerHTML = value; },
    setHeaderActions(markup) { refs.headerActions.innerHTML = markup; },
    refreshClock() { updateClock(refs.clockFace, refs.clockDigital, timeZone); },
    announce(message) {
      refs.liveRegion.textContent = '';
      requestAnimationFrame(() => { refs.liveRegion.textContent = message; });
    },
    destroy() {
      clearInterval(clockTimer);
      document.removeEventListener('keydown', keyboardShortcut);
    }
  });
}
