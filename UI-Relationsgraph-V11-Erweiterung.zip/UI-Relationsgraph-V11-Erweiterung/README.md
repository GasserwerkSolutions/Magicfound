# UI-Relationsgraph V11 — Schritt 2: Identitäten und experimentell gemessene Änderungsfolgen

**Datum:** 16. Oktober 2026 · **Status:** reproduzierbarer Forschungs-/Entwicklungspilot, kein vollständiger Produktqualitätstest und keine Freigabe der V11.

## Öffnen

- `relations-inspektor.html` — eigenständiger Offline-Inspektor mit realen Chromium-Screenshots und gemessenen Vorher-/Nachher-CSS-Eigenschaften. Keine Installation nötig.
- `berichte/FOLGENBERICHT.md` — Auswertung, Evidenzgrenzen und nächste Entwicklungsschritte.
- `berichte/inspektor-vorschau.png` — verifiziertes Rendering des Inspectors.

## Drei Nachweisschichten

1. **Deklarierte Identität:** Ein im jeweiligen DOM eindeutiges `id` oder ein explizites `data-ui` mit einem echten `data-instance-key`. Diese Zuordnung ist über die *untersuchten* Zustände nachvollziehbar. IDs gelten nicht automatisch als langfristige Domänenidentitäten.
2. **Kandidatenidentität:** DOM-Strukturpfad, Klassenfamilie und Tag. Der Prüfer darf diese Vorschläge anzeigen, aber **nie stillschweigend zu sicheren Identitäten hochstufen**. Dieselbe Position kann später eine andere Komponente enthalten.
3. **Empirische Token-Abhängigkeit:** Chromium misst nach kontrollierter CSS-Variablenänderung tatsächlich geänderte berechnete Eigenschaften. Statistische Quelltextverwendungen bleiben separate *potenzielle* Abhängigkeiten. Wirkungen der CSS-Kaskade und Vererbung sind im Messwert enthalten; exakte Stylesheet-Regelprovenienz noch nicht.

## Ergebnis der Original-V11

- 13 vorhandene dokumentierte Browserzustände, 2'320 DOM-Vorkommen, davon 365 Beobachtungen mit eindeutig deklarierter Kennung, 1'955 vorläufige Pfad-Zuordnungen.
- 33 zustandsübergreifende eindeutig deklarierte Identitäten; 455 zustandsübergreifende *Kandidaten*; 0 Konflikte in diesen Stichproben.
- Vier Tokenmutationen in vier Chromium-Browserzuständen plus ein Nichtreferenz-Token als Negativkontrolle; alle 20 Interventionen erfolgreich gemessen und jeweils zurückgerollt.
- **Gemessene geänderte DOM-Vorkommen über vier Ansichten:** `--border` 103, `--surface` 69, `--brand` 16, `--radius` 0. Diese Werte können dasselbe Element in verschiedenen Zuständen mehrfach zählen und umfassen teilweise aktuell versteckte DOM-Knoten.
- CSS-Quellenkarte: 51 Token-Namen und 671 `var(...)`-Referenzen innerhalb der **einen eingebetteten Stylesheet-Datei**; keinerlei XML-/CSS-Quelle aus externen Imports oder JS-generierten Stylesheets erfasst.
- Quellvergleichs-Kontrollfall: `--radius` hat vier CSS-Referenzen, aber keinerlei gemessene Wirkung in den vier Interventionszuständen. Das beweist nicht, dass der Token allgemein ungenutzt ist.
- 10/10 automatisierte Selbsttests der neuen Auswertungslogik. **Die bestehenden 83 PASS/16 FAIL** aus dem Vorgängerpaket bleiben unverändert; es wurden keine neuen vollständigen visuell-qualitativen Freigabetests vorgetäuscht.

## Dateien

| Datei | Zweck |
|---|---|
| `eingaben/v11-original.html` | unveränderte Ausgangsdatei und vertrauenswürdige Browserfixture |
| `eingaben/browser-messung.json` | alle 13 ursprünglichen Browserzustände als Rohmessung |
| `eingaben/relationsvertrag-v11.json` | bisherige 21 explizite Prüforacles |
| `config/mutations.json` | reproduzierbare gezielte Tokenänderungen |
| `scripts/browser_zustaende_sammeln.py` | Chromium-Messer, erweitert um `data-instance-key`, `data-slot` und `data-state` |
| `scripts/browser-ui-vermessung.py` | Browser-CSS-/DOM-Messfunktionen |
| `scripts/stabile_identitaeten.py` | ID-basierte und strukturell tentative Cross-State-Identitäten |
| `scripts/css_quellenkarte.py` | CSS-Deklarationen und `var(...)`-Verwendung mit Zeilen- und Selektorbezug |
| `scripts/token_folgen_browser.py` | kontrollierte Browsermutationen mit exaktem Rollback-Test |
| `scripts/folgen_graph.py` | beobachtete Impact-Kanten, hypothetische Nachbarschaften, mögliche Regel-Neuprüfungen |
| `scripts/bericht_und_viewer.py` | Bericht und offline verwendbaren Inspektor generieren |
| `daten/*.json` | vollständig maschinenlesbare Auswertungen |
| `tests/test_relationssystem.py` | interne negative und positive Testfälle |

## Lokal erneut ausführen

Voraussetzungen: **Python 3**, installiertes `playwright` und `tinycss2`, funktionierendes Chromium. Zum Beispiel `pip install playwright tinycss2` und `playwright install chromium`. Standardmässig erwartet das Messskript `/usr/bin/chromium`; auf anderen Systemen den eigenen Browserpfad mit `--chromium` angeben. **Nur vertrauenswürdige lokale HTML-Dateien öffnen**, da ihr JavaScript im Browser ausgeführt wird.

Im entpackten Projektordner:

```bash
python scripts/browser_zustaende_sammeln.py --html eingaben/v11-original.html --output eingaben/browser-messung-neu.json --measurer scripts/browser-ui-vermessung.py --chromium /usr/bin/chromium
python scripts/stabile_identitaeten.py --measurement eingaben/browser-messung.json --output daten/identitaeten.json
python scripts/css_quellenkarte.py --html eingaben/v11-original.html --output daten/css-quellenkarte.json
python scripts/token_folgen_browser.py --html eingaben/v11-original.html --config config/mutations.json --output daten/token-mutationen.json --chromium /usr/bin/chromium
python scripts/folgen_graph.py --measurement eingaben/browser-messung.json --identities daten/identitaeten.json --mutations daten/token-mutationen.json --contract eingaben/relationsvertrag-v11.json --output daten/aenderungsfolgen-graph.json
python tests/test_relationssystem.py
python scripts/bericht_und_viewer.py
```

**Hinweis zur Reproduktion:** Der Kameralauf kann neu datiert sein, CSS-Geometrie kann zwischen Chromium-Versionen abweichen, und der Browserzustand ist absichtlich nur ein kontrollierter Testpunkt. Für vergleichbare Ergebnisse dieselbe Version, dieselben Viewports und dieselbe Eingabedatei verwenden. Die HTML-SHA liegt in jedem Messergebnis.

## Praktischer Vertrag für neue Komponenten

```html
<!-- Beispiel: kein personenbezogener Schlüssel, keine Kundennamen -->
<section data-ui="calendar-column" data-instance-key="opaque-stable-ui-key"
         data-slot="primary-schedule" data-state="ready">
  ...
</section>
```

Das `data-instance-key` muss aus der echten UI-Instanz stammen, über Re-Render und relevante Zustandswechsel stabil bleiben und darf keine Namen, E-Mail-Adressen oder sonstigen vertraulichen Geschäftsdaten offenlegen. Bei Instanzen ohne solchen Schlüssel bleibt die Cross-State-Zuordnung vorläufig. Der Beispielwert ist **kein automatisch zu übernehmender Schlüsselgenerator**.

## Nicht bewiesen / offene Aufgaben

- Keine automatische Verifikation von 100 % der Design-Atome; HTML-DOM-Knoten und Design-System-Atoms sind nicht identisch.
- CSS-Provenienz bislang Quellreferenz + Intervention; CDP-Matched-Styles/Cascade und Token-Aliaskette bis zum konkret angewendeten Rule-Set fehlen.
- Browsermutationen messen keine echten Daten- und Synchronisationsereignisse, kein Shadow DOM, kein Screenreader-Urteil, keine SVG-/Canvas-Pixel vollständig, kein Netzwerk-/Backendverhalten.
- Originalbild-Screenshots sind keine Screenshots des veränderten Tokenzustands; die orange Markierung zeigt nur die Position eines empirisch betroffenen Knotens im Originalbild.
- Farb-/Kontrast-, Wahrnehmungs-, Dark-Mode-, Zoom-, Overlay- und Bedienablaufgates müssen für die Interventionszustände separat ergänzt werden.
- Impact Graph != fertiger Regressionstest: aus `recommendedChecks` darf kein `PASS` abgeleitet werden.
