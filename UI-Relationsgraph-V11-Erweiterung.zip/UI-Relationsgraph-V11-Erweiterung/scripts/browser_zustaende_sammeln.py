#!/usr/bin/env python3
"""Deterministische DOM-Messung mit echtem Chromium. Nur vertrauenswürdige lokale HTML-Dateien verwenden.

Der Parser liest reale Browser-Werte. Abgefragt werden zusätzlich semantische IDs,
Label-/ARIA-Kanten, Fokus und Control-Metadaten. Keine Bild-/UX-Qualitätsgarantie.
"""
import argparse, hashlib, importlib.util, json
from datetime import datetime, timezone
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE_PATH=Path(__file__).resolve().parent
DEFAULT_MEASURER=BASE_PATH/'browser-ui-vermessung.py'
EXTENDED_JS=r'''() => {
 const all=[...document.body.querySelectorAll('*')];
 return all.map((el,i)=>({index:i,attributes:{
   for:el.getAttribute('for'),name:el.getAttribute('name'),href:el.getAttribute('href'),
   ariaControls:el.getAttribute('aria-controls'),ariaLabelledby:el.getAttribute('aria-labelledby'),
   ariaDescribedby:el.getAttribute('aria-describedby'),ariaSelected:el.getAttribute('aria-selected'),
   ariaPressed:el.getAttribute('aria-pressed'),dataUi:el.getAttribute('data-ui'),dataInstanceKey:el.getAttribute('data-instance-key'),dataSlot:el.getAttribute('data-slot'),dataState:el.getAttribute('data-state'),
   disabled:el.hasAttribute('disabled'),tabIndex:el.tabIndex,
   focusable:el.matches('button,a[href],input,textarea,select,[tabindex]'),
   focused:el===document.activeElement
 }}));
}'''
SCENARIOS=[
    {'id':'kalender-320','route':'calendar','viewport':{'width':320,'height':800}},
    {'id':'kalender-390','route':'calendar','viewport':{'width':390,'height':844}},
    {'id':'kalender-720','route':'calendar','viewport':{'width':720,'height':900}},
    {'id':'kalender-768','route':'calendar','viewport':{'width':768,'height':900}},
    {'id':'kalender-960','route':'calendar','viewport':{'width':960,'height':900}},
    {'id':'kalender-1280','route':'calendar','viewport':{'width':1280,'height':900}},
    {'id':'kalender-1440','route':'calendar','viewport':{'width':1440,'height':900}},
    {'id':'heute-390','route':'today','viewport':{'width':390,'height':844}},
    {'id':'heute-1440','route':'today','viewport':{'width':1440,'height':900}},
    {'id':'betrieb-390','route':'business','viewport':{'width':390,'height':844}},
    {'id':'betrieb-1440','route':'business','viewport':{'width':1440,'height':900}},
    {'id':'kalender-hover-1440','route':'calendar','viewport':{'width':1440,'height':900},'action':{'type':'hover','selector':'.agenda-inside-tab:not(.active)'}},
    {'id':'kalender-focus-1440','route':'calendar','viewport':{'width':1440,'height':900},'action':{'type':'focus','selector':'.agenda-inside-tab:not(.active)'}},
]

def load_measurer(path):
    spec=importlib.util.spec_from_file_location('ui_browser_vermessung',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--html',required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--screenshot-dir')
    p.add_argument('--measurer',default=str(DEFAULT_MEASURER))
    p.add_argument('--chromium',default='/usr/bin/chromium')
    args=p.parse_args()
    html=Path(args.html).read_text(encoding='utf8')
    measure=load_measurer(args.measurer)
    if args.screenshot_dir:Path(args.screenshot_dir).mkdir(parents=True,exist_ok=True)
    scenarios=[]
    with sync_playwright() as pw:
      browser=pw.chromium.launch(headless=True,executable_path=args.chromium,args=['--no-sandbox','--disable-gpu'])
      try:
        for scene in SCENARIOS:
          page=browser.new_page(viewport=scene['viewport'],locale='de-CH',timezone_id='Europe/Zurich',reduced_motion='reduce',device_scale_factor=1)
          errors=[]
          page.on('pageerror',lambda error:errors.append(str(error)))
          try:
            page.set_content(html,wait_until='domcontentloaded',timeout=30000)
            page.evaluate('(route) => { if(typeof navigate === "function")navigate(route); }',scene['route'])
            page.evaluate('document.fonts.ready');page.wait_for_timeout(100)
            action=scene.get('action')
            if action:
              el=page.locator(action['selector']).first
              if action['type']=='focus':el.focus()
              if action['type']=='hover':el.hover()
              page.wait_for_timeout(100)
            result=page.evaluate(measure.JS,{'allCSS':False,'props':measure.STYLE_PROPS})
            attributes=page.evaluate(EXTENDED_JS)
            for row in attributes:
              result['records'][row['index']]['attributes']=row['attributes']
            result['meta'].update({'scenario':scene['id'],'route':scene['route'], 'pageErrors':errors,'action':action,'htmlTheme':page.get_attribute('html','data-mode')})
            if args.screenshot_dir:
              dest=Path(args.screenshot_dir)/(scene['id']+'.png')
              page.screenshot(path=str(dest),animations='disabled',full_page=False)
              result['meta']['screenshot']=dest.name
            scenarios.append(result)
            m=result['meta']
            print(scene['id'],m['domBodyElementCount'],m['visibleLayoutCount'],'DOM/layout',len(m['pageErrors']),'JS errors')
          finally:page.close()
      finally:browser.close()
      version=browser.version
    result={'schema':'browser-dom-measure/v2','source':{'sha256':hashlib.sha256(html.encode()).hexdigest(),'filename':Path(args.html).name},'browser':{'name':'Chromium','version':version},'capturedAtUtc':datetime.now(timezone.utc).isoformat(),'limits':['DOM only: no Shadow DOM, iframes or CSS pseudo-element boxes','only enumerated views/viewports/states','screenreader perception not measured','data from trusted local demo; no production state'], 'scenarios':scenarios}
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('SAVED',out)
if __name__=='__main__':main()
