import { Capability } from '../src/data/contracts/capabilities.js';
import { AppointmentStatus, OperationalKind } from '../src/data/contracts/domain-values.js';
import {
  MockDataSourceError,
  MockScenario,
  createMockDashboardDataSource
} from '../src/data/mock-dashboard-data-source.js';
import {
  REFERENCE_DATE,
  REFERENCE_INSTANT,
  referenceAppointments,
  referenceCustomers,
  referenceServices,
  referenceStaff
} from '../src/data/fixtures/reference-fixtures.js';

const errors = [];
const notes = [];

function assert(condition, message) { if (!condition) errors.push(message); }

async function assertRejects(action, code, message) {
  try {
    await action();
    errors.push(`${message}: erwarteter Fehler blieb aus`);
  } catch (error) {
    assert(error instanceof MockDataSourceError, `${message}: falscher Fehlertyp`);
    assert(error.code === code, `${message}: erwarteter Code ${code}, gefunden ${error.code}`);
  }
}

const ready = createMockDashboardDataSource();
const session = await ready.getSessionContext();
assert(session.salon.timeZone === 'Europe/Zurich', 'Session: Salonzeitzone fehlt');
assert(session.locale === 'de-CH' && session.currency === 'CHF', 'Session: Locale oder Währung falsch');
assert(session.capabilities.includes(Capability.DAY_PLAN_VIEW), 'Session: Tagesplan-Capability fehlt');

const auth = await ready.getAuthenticationOptions();
assert(auth.authenticationMethods.includes('password'), 'Auth: Passwortmethode fehlt');
assert(auth.authenticationMethods.includes('magic-link'), 'Auth: Magic-Link-Methode fehlt');
assert(!JSON.stringify(auth).toLowerCase().includes('prototyp'), 'Auth: Referenz enthält Demo-Passwort');

const day = await ready.getDayPlan({ date: REFERENCE_DATE });
const appointments = day.items.filter((item) => item.kind === 'appointment');
const blocks = day.items.filter((item) => item.kind !== 'appointment');
assert(day.staff.length === referenceStaff.length, 'Tagesplan: Teamanzahl weicht vom Fixture ab');
assert(appointments.length === referenceAppointments.length, 'Tagesplan: Terminanzahl weicht vom Fixture ab');
assert(blocks.some((item) => item.kind === OperationalKind.TASK), 'Tagesplan: interne Aufgabe fehlt');
assert(!day.items.some((item) => item.kind === 'blocked'), 'Tagesplan: historischer Sammelbegriff blocked ist nicht normalisiert');
assert(day.salon.currentInstant === REFERENCE_INSTANT, 'Tagesplan: kontrollierte Referenzzeit ist falsch');
assert(appointments.every((item) => item.customer.id && item.service.id && item.staff.id), 'Tagesplan: stabile Referenz-IDs fehlen');
assert(appointments.every((item) => Object.values(AppointmentStatus).includes(item.status)), 'Tagesplan: unbekannter Terminstatus');

const otherDay = await ready.getDayPlan({ date: '2026-08-21' });
assert(otherDay.items.length === 0, 'Tagesplan: anderer Referenztag muss leer sein');

const register = await ready.listAppointments({ statuses: [AppointmentStatus.ARRIVED], staffIds: ['melanie'] });
assert(register.items.length === 1 && register.items[0].id === 'a6', 'Terminregister: Status-/Personenfilter ist falsch');
const detail = await ready.getAppointment('a6');
assert(detail.item.customer.id === 'customer-anna', 'Termindetail: Kundenreferenz ist falsch');

const customerList = await ready.listCustomers({ text: 'Anna' });
assert(customerList.items.length === 1 && customerList.items[0].id === 'customer-anna', 'Kundschaft: Suche ist falsch');
const customerDetail = await ready.getCustomer('customer-anna');
assert(customerDetail.item.summary.appointmentCount > 0, 'Kundschaft: Historienzusammenfassung fehlt');

const staffList = await ready.listStaff({ activeOnly: true });
assert(staffList.items.length === referenceStaff.length, 'Team: aktive Personen fehlen');
const services = await ready.listServices({ staffIds: ['sofia'] });
assert(services.items.every((item) => item.assignedStaffIds.includes('sofia')), 'Angebot: Teamfilter ist falsch');
assert((await ready.getService(referenceServices[0].id)).item.durationMinutes > 0, 'Angebot: Dauer fehlt');

const onboarding = await ready.getOnboardingState();
assert(onboarding.readiness.isBookable === true, 'Onboarding: Referenzzustand ist nicht buchbar');
const administration = await ready.getAdministrationSettings();
assert(administration.sections.length === 7, 'Verwaltung: erwartet sieben Bereiche');

const empty = createMockDashboardDataSource({ scenario: MockScenario.EMPTY });
assert((await empty.getDayPlan({ date: REFERENCE_DATE })).items.length === 0, 'Empty: Tagesplan enthält Einträge');
assert((await empty.listCustomers()).items.length === 0, 'Empty: Kundschaft enthält Einträge');
assert((await empty.listStaff()).items.length === 0, 'Empty: Team enthält Einträge');
assert((await empty.listServices()).items.length === 0, 'Empty: Angebot enthält Einträge');
assert((await empty.getOnboardingState()).readiness.isBookable === false, 'Empty: Onboarding darf nicht buchbar sein');

const stress = createMockDashboardDataSource({ scenario: MockScenario.STRESS });
assert((await stress.listAppointments()).items.length > referenceAppointments.length, 'Stress: zusätzliche Termine fehlen');

const partial = createMockDashboardDataSource({ scenario: MockScenario.PARTIAL });
const partialAppointment = (await partial.listAppointments()).items[0];
assert(partialAppointment.price === null && partialAppointment.note === null, 'Partial: optionale Terminwerte wurden nicht entfernt');

const stale = createMockDashboardDataSource({ scenario: MockScenario.STALE });
assert((await stale.getDayPlan({ date: REFERENCE_DATE })).meta.isStale === true, 'Stale: Aktualitätsmarker fehlt');

const forbidden = createMockDashboardDataSource({ scenario: MockScenario.FORBIDDEN });
const forbiddenSession = await forbidden.getSessionContext();
assert(forbiddenSession.capabilities.length === 1 && forbiddenSession.capabilities[0] === Capability.AUTH_SIGN_IN, 'Forbidden: Capabilitysatz ist falsch');

const customCapabilities = createMockDashboardDataSource({ capabilities: [Capability.CUSTOMER_VIEW] });
assert((await customCapabilities.getSessionContext()).capabilities[0] === Capability.CUSTOMER_VIEW, 'Capabilities: explizite Überschreibung fehlt');

await assertRejects(() => createMockDashboardDataSource({ scenario: MockScenario.ERROR }).getDayPlan({ date: REFERENCE_DATE }), 'MOCK_ERROR', 'Error-Szenario');
await assertRejects(() => createMockDashboardDataSource({ scenario: MockScenario.OFFLINE }).listAppointments(), 'OFFLINE', 'Offline-Szenario');

assert(referenceCustomers.every((item) => item.id && item.displayName), 'Fixtures: Kunden-IDs oder Namen fehlen');
notes.push(`Ready: ${day.staff.length} Personen, ${appointments.length} Termine, ${blocks.length} operative Blöcke`);
notes.push(`Stress: ${(await stress.listAppointments()).items.length} Termine`);
notes.push(`Szenarien: ${Object.values(MockScenario).join(', ')}`);

for (const note of notes) console.log(`✓ ${note}`);

if (errors.length) {
  console.error(`\nMock-Datenprüfung fehlgeschlagen (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('\n✓ Mock-Datenquelle erfüllt den gemeinsamen Vertrag.');
