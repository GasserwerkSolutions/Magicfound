import { createDashboardShell, shellIcon } from '../../src/shell/dashboard-shell-v1.js';
import { createMockDashboardDataSourceV1 } from '../../src/data/mock-dashboard-data-source-v1.js';
import { Capability, hasCapability } from '../../src/data/contracts/capabilities.js';
import { DashboardEvent, createDashboardEvent } from '../../src/data/contracts/events.js';
import { AppointmentStatus, DayScale, LiveFollowState, OperationalKind } from '../../src/data/contracts/domain-values.js';

const OPEN_MINUTE = 480;
const CLOSE_MINUTE = 1080;
const DAY_DURATION = CLOSE_MINUTE - OPEN_MINUTE;
const OPERATIVE_VISIBLE_MINUTES_DESKTOP = 240;
const OPERATIVE_PAST_MINUTES_DESKTOP = 45;
const LIVE_ANCHOR_RATIO_DESKTOP = OPERATIVE_PAST_MINUTES_DESKTOP / OPERATIVE_VISIBLE_MINUTES_DESKTOP;
const LIVE_ANCHOR_RATIO_MOBILE = 0.22;
const LIVE_TICK_MS = 15_000;
const AUTO_RETURN_MS = 25_000;
const SCROLL_DURATION_MS = 260;

const STATUS_LABEL = Object.freeze({
  [AppointmentStatus.CONFIRMED]: 'Bestätigt',
  [AppointmentStatus.PENDING]: 'Angefragt',
  [AppointmentStatus.ARRIVED]: 'Im Salon',
  [AppointmentStatus.COMPLETED]: 'Abgeschlossen',
  [AppointmentStatus.CANCELLED]: 'Abgesagt',
  [AppointmentStatus.NO_SHOW]: 'Nicht erschienen'
});

const root = document.querySelector('#dashboard-root');
const dataSource = createMockDashboardDataSourceV1();

const state = {
  session: null,
  plan: null,
  date: null,
  scale: DayScale.WORK,
  focusedStaffId: null,
  selectedAppointmentId: null,
  search: '',
  liveFollow: LiveFollowState.ACTIVE,
  livePauseReason: null,
  lastUserActivityAt: Date.now(),
  scrollLeft: 0,
  operationalMinutePx: null,
  focusScrollTop: 0,
  overlay: null,
  overlayOrigin: null,
  programmaticScroll: false,
  loading: true,
  error: null
};

let liveTimer = 0;
let inactivityTimer = 0;
let renderFrame = 0;
let visibleContentFrame = 0;

const shell = createDashboardShell(root, {
  activePage: 'tagesplan',
  title: 'Tagesplan',
  kicker: 'Salonbetrieb',
  context: 'Zürich Enge',
  primaryActionLabel: 'Termin',
  onPrimaryAction: () => openBookingPanel({ source: 'day-plan-header' }),
  onSearch: (query) => {
    state.search = query.trim();
    pauseLiveFollow('search');
    scheduleRender({ preserveViewport: true });
  }
});

function emit(type, payload, source = 'tagesplan') {
  root.dispatchEvent(new CustomEvent('gasserwerk:event', {
    bubbles: true,
    detail: createDashboardEvent(type, payload, { source })
  }));
}

function zurichDateParts(instant = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Zurich',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(instant);
  return Object.fromEntries(parts.map((part) => [part.type, part.value]));
}

function todayIso() {
  const parts = zurichDateParts();
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function referenceMinuteOverride() {
  const value = new URLSearchParams(location.search).get('referenceNow');
  if (!value || !/^\d{1,2}:\d{2}$/.test(value)) return null;
  const [hour, minute] = value.split(':').map(Number);
  if (!Number.isInteger(hour) || !Number.isInteger(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  return hour * 60 + minute;
}

function currentSalonMinute(instant = new Date()) {
  const referenceMinute = referenceMinuteOverride();
  if (referenceMinute != null) return referenceMinute;
  const parts = Object.fromEntries(new Intl.DateTimeFormat('de-CH', {
    timeZone: 'Europe/Zurich',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).formatToParts(instant).map((part) => [part.type, part.value]));
  return Number(parts.hour) * 60 + Number(parts.minute);
}

function dateFromIso(value) {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day, 12));
}

function formatDate(value, compact = false) {
  return new Intl.DateTimeFormat('de-CH', compact
    ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'numeric' }
    : { timeZone: 'Europe/Zurich', weekday: 'long', day: 'numeric', month: 'long' }
  ).format(dateFromIso(value)).replace(/\.,\s*/, ' ');
}

function formatHeaderDate(value) {
  const options = isMobileLayout()
    ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'numeric' }
    : matchMedia('(max-width: 1450px)').matches
      ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'short' }
      : { timeZone: 'Europe/Zurich', weekday: 'long', day: 'numeric', month: 'long' };
  return new Intl.DateTimeFormat('de-CH', options).format(dateFromIso(value)).replace(/\.,\s*/, ' ');
}

function formatTime(minute) {
  const normalized = Math.max(0, Math.min(1439, Math.round(minute)));
  return `${String(Math.floor(normalized / 60)).padStart(2, '0')}:${String(normalized % 60).padStart(2, '0')}`;
}

function formatMoney(price) {
  if (!price || !Number.isFinite(price.amount)) return 'Nicht hinterlegt';
  return new Intl.NumberFormat('de-CH', { style: 'currency', currency: price.currency ?? 'CHF', maximumFractionDigits: 0 }).format(price.amount);
}

function isToday() {
  return state.date === todayIso();
}

function isMobileLayout() {
  return matchMedia('(max-width: 760px), (max-width: 900px) and (max-height: 600px), (pointer: coarse) and (max-height: 820px)').matches;
}

function cssMinutePixelWidth() {
  return Number.parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--day-minute-px')) || 7.5;
}

function staffRailWidth() {
  return Number.parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--day-staff-rail')) || 190;
}

function minutePixelWidth(viewport = document.querySelector('#day-scroll-viewport')) {
  if (state.operationalMinutePx && Number.isFinite(state.operationalMinutePx)) return state.operationalMinutePx;
  if (!viewport || isMobileLayout()) return cssMinutePixelWidth();
  return Math.max(1, viewport.clientWidth - staffRailWidth()) / OPERATIVE_VISIBLE_MINUTES_DESKTOP;
}

function applyOperationalScale(viewport = document.querySelector('#day-scroll-viewport')) {
  if (!viewport) return;
  const previousMinutePx = state.operationalMinutePx ?? cssMinutePixelWidth();
  const visibleStart = OPEN_MINUTE + state.scrollLeft / Math.max(previousMinutePx, 0.01);
  let nextMinutePx;

  if (isMobileLayout()) {
    document.documentElement.style.removeProperty('--day-minute-px');
    nextMinutePx = cssMinutePixelWidth();
    viewport.dataset.visibleMinutes = 'responsive-mobile';
    delete viewport.dataset.pastMinutes;
  } else {
    const visibleTimelineWidth = Math.max(1, viewport.clientWidth - staffRailWidth());
    nextMinutePx = visibleTimelineWidth / OPERATIVE_VISIBLE_MINUTES_DESKTOP;
    document.documentElement.style.setProperty('--day-minute-px', `${nextMinutePx}px`);
    viewport.dataset.visibleMinutes = String(OPERATIVE_VISIBLE_MINUTES_DESKTOP);
    viewport.dataset.pastMinutes = String(OPERATIVE_PAST_MINUTES_DESKTOP);
  }

  state.operationalMinutePx = nextMinutePx;
  viewport.dataset.minutePixelWidth = nextMinutePx.toFixed(4);

  if (state.liveFollow !== LiveFollowState.ACTIVE) {
    state.scrollLeft = clamp(
      (visibleStart - OPEN_MINUTE) * nextMinutePx,
      0,
      Math.max(0, viewport.scrollWidth - viewport.clientWidth)
    );
  }
}

function can(capability) {
  return hasCapability(state.session, capability);
}

function currentMinuteForView() {
  return isToday() ? currentSalonMinute() : null;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function minuteOffset(minute) {
  return clamp(minute - OPEN_MINUTE, 0, DAY_DURATION);
}

function itemEnd(item) {
  return item.startMinute + item.durationMinutes;
}

function personById(id) {
  return state.plan?.staff.find((person) => person.id === id) ?? null;
}

function appointmentById(id) {
  return state.plan?.appointments.find((appointment) => appointment.id === id) ?? null;
}

function timelineItemsForStaff(staffId) {
  const appointments = state.plan.appointments.filter((item) => item.staff.id === staffId);
  const blocks = state.plan.operationalBlocks.filter((item) => item.staff.id === staffId);
  return [...appointments, ...blocks].sort((a, b) => a.startMinute - b.startMinute);
}

function layoutTimelineItems(items) {
  const laneEnds = [];
  const positionedItems = items.map((item) => {
    const laneIndex = laneEnds.findIndex((endMinute) => endMinute <= item.startMinute);
    const resolvedLaneIndex = laneIndex >= 0 ? laneIndex : laneEnds.length;
    laneEnds[resolvedLaneIndex] = itemEnd(item);
    return { item, laneIndex: resolvedLaneIndex };
  });
  return {
    items: positionedItems,
    laneCount: Math.max(1, laneEnds.length)
  };
}

function searchMatches(item) {
  if (!state.search) return true;
  const haystack = item.kind === 'appointment'
    ? `${item.customer.displayName} ${item.service.displayName} ${item.staff.displayName} ${item.note ?? ''}`
    : `${item.label} ${item.note ?? ''} ${item.staff.displayName}`;
  return haystack.toLocaleLowerCase('de-CH').includes(state.search.toLocaleLowerCase('de-CH'));
}

function headerScaleLabel() {
  return state.scale === DayScale.WORK ? 'Ganzer Tag' : 'Arbeitsfläche';
}

function renderHeader() {
  shell.setTitleContent(`
    <button class="day-header-date-button" type="button" data-open-date-picker aria-haspopup="dialog">
      <span>${formatHeaderDate(state.date)}</span>
      ${shellIcon('calendar')}
    </button>
  `);

  const scaleButton = state.focusedStaffId ? '' : `
    <button class="day-header-scale-button" type="button" data-toggle-scale aria-label="${headerScaleLabel()} anzeigen">
      ${shellIcon(state.scale === DayScale.WORK ? 'list' : 'calendar')}
      <span>${headerScaleLabel()}</span>
    </button>
  `;
  shell.setContextContent(`<span class="day-header-context-copy">Zürich Enge · 08:00–18:00</span>${scaleButton}`);

  const mobileScale = isMobileLayout() && !state.focusedStaffId ? `
    <button class="gw-button gw-button-quiet" type="button" data-toggle-scale aria-label="${headerScaleLabel()} anzeigen" title="${headerScaleLabel()}">
      ${shellIcon(state.scale === DayScale.WORK ? 'list' : 'calendar')}
    </button>
  ` : '';
  const liveState = state.liveFollow === LiveFollowState.ACTIVE && isToday() && state.scale === DayScale.WORK && !state.focusedStaffId
    ? '<span class="day-live-status">Live</span>'
    : '';
  const primary = can(Capability.DAY_PLAN_CREATE_APPOINTMENT) ? `
    <button class="gw-button gw-button-primary" type="button" data-create-appointment>
      ${shellIcon('plus')}<span>Termin</span>
    </button>
  ` : '';
  shell.setHeaderActions(`${liveState}${mobileScale}${primary}`);
}

function renderLoading() {
  shell.refs.content.innerHTML = `
    <section class="day-page is-loading" aria-busy="true">
      <div class="day-loading"><span class="day-loading-spinner" aria-hidden="true"></span><strong>Tagesplan wird geladen</strong><span>Team, Zeiten und Termine werden vorbereitet.</span></div>
    </section>
  `;
}

function renderError() {
  shell.refs.content.innerHTML = `
    <section class="day-page is-loading">
      <div class="day-error"><strong>Tagesplan konnte nicht geladen werden</strong><span>${state.error?.message ?? 'Unbekannter Fehler'}</span><button class="gw-button" type="button" data-retry>Erneut laden</button></div>
    </section>
  `;
}

function renderForbidden() {
  shell.refs.content.innerHTML = `
    <section class="day-page is-loading"><div class="day-forbidden"><strong>Tagesplan nicht verfügbar</strong><span>Für diese Arbeitsfläche fehlt die erforderliche Berechtigung.</span></div></section>
  `;
}

function rulerLabels() {
  const labels = [];
  for (let minute = OPEN_MINUTE; minute <= CLOSE_MINUTE; minute += 30) {
    if (minute % 60 !== 0 && minute !== CLOSE_MINUTE) continue;
    labels.push(`<span class="day-ruler-label" style="left:calc(var(--day-minute-px) * ${minuteOffset(minute)})">${formatTime(minute)}</span>`);
  }
  return labels.join('');
}

function appointmentInitials(displayName) {
  return displayName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toLocaleUpperCase('de-CH');
}

function appointmentMarkup(appointment, mode = 'work', laneIndex = 0) {
  const left = minuteOffset(appointment.startMinute);
  const width = clamp(appointment.durationMinutes, 15, DAY_DURATION - left);
  const selected = state.selectedAppointmentId === appointment.id;
  const matches = searchMatches(appointment);
  const densityClass = appointment.durationMinutes <= 30 ? 'is-micro' : appointment.durationMinutes < 60 ? 'is-compact' : '';
  if (mode === 'overview') {
    const top = minuteOffset(appointment.startMinute) / DAY_DURATION * 100;
    const height = Math.max(1.5, appointment.durationMinutes / DAY_DURATION * 100);
    return `<button class="day-overview-appointment status-${appointment.status} ${selected ? 'is-selected' : ''}" style="top:${top}%;height:${height}%" type="button" data-appointment-id="${appointment.id}" ${matches ? '' : 'hidden'}>${formatTime(appointment.startMinute)} · ${appointment.customer.displayName}</button>`;
  }
  if (mode === 'focus') {
    const top = minuteOffset(appointment.startMinute) / DAY_DURATION * 100;
    const height = Math.max(1.8, appointment.durationMinutes / DAY_DURATION * 100);
    return `
      <button class="day-focus-appointment status-${appointment.status} ${selected ? 'is-selected' : ''}" style="top:${top}%;height:${height}%" type="button" data-appointment-id="${appointment.id}" ${matches ? '' : 'hidden'}>
        <span class="day-focus-time">${formatTime(appointment.startMinute)}–${formatTime(itemEnd(appointment))}</span>
        <span class="day-focus-main"><strong>${appointment.customer.displayName}</strong><small>${appointment.service.displayName}</small></span>
        <span class="day-focus-status">${STATUS_LABEL[appointment.status]}</span>
      </button>
    `;
  }
  return `
    <button class="day-appointment status-${appointment.status} ${densityClass} ${selected ? 'is-selected' : ''}" style="--day-lane-index:${laneIndex};left:calc(var(--day-minute-px) * ${left} + 4px);width:calc(var(--day-minute-px) * ${width} - 8px)" type="button" data-appointment-id="${appointment.id}" data-duration-minutes="${appointment.durationMinutes}" aria-label="${formatTime(appointment.startMinute)} bis ${formatTime(itemEnd(appointment))}, ${appointment.customer.displayName}, ${appointment.service.displayName}" ${matches ? '' : 'hidden'}>
      <span class="day-appointment-initials" aria-hidden="true">${appointmentInitials(appointment.customer.displayName)}</span>
      <span class="day-appointment-time">${formatTime(appointment.startMinute)}</span>
      <strong class="day-appointment-name">${appointment.customer.displayName}</strong>
      <span class="day-appointment-service">${appointment.service.displayName}</span>
    </button>
  `;
}

function operationalMarkup(block, mode = 'work', laneIndex = 0) {
  const left = minuteOffset(block.startMinute);
  const width = clamp(block.durationMinutes, 15, DAY_DURATION - left);
  const matches = searchMatches(block);
  if (mode === 'overview') {
    const top = minuteOffset(block.startMinute) / DAY_DURATION * 100;
    const height = Math.max(1.5, block.durationMinutes / DAY_DURATION * 100);
    return `<button class="day-overview-appointment" style="top:${top}%;height:${height}%;border-style:dashed" type="button" data-operational-id="${block.id}" ${matches ? '' : 'hidden'}>${block.label}</button>`;
  }
  if (mode === 'focus') {
    const top = minuteOffset(block.startMinute) / DAY_DURATION * 100;
    const height = Math.max(1.8, block.durationMinutes / DAY_DURATION * 100);
    return `<button class="day-focus-operational" style="top:${top}%;height:${height}%" type="button" data-operational-id="${block.id}" ${matches ? '' : 'hidden'}>${block.label}</button>`;
  }
  return `<button class="day-operational-block" style="--day-lane-index:${laneIndex};left:calc(var(--day-minute-px) * ${left} + 4px);width:calc(var(--day-minute-px) * ${width} - 8px)" type="button" data-operational-id="${block.id}" ${matches ? '' : 'hidden'}><span class="day-operational-copy">${block.label}</span></button>`;
}

function nowLineMarkup(mode = 'work') {
  const minute = currentMinuteForView();
  if (minute == null || minute < OPEN_MINUTE || minute > CLOSE_MINUTE) return '';
  if (mode === 'overview') {
    const top = minuteOffset(minute) / DAY_DURATION * 100;
    return `<div class="day-overview-now" style="top:calc(44px + (100% - 44px) * ${top / 100})"></div>`;
  }
  if (mode === 'focus') {
    const top = minuteOffset(minute) / DAY_DURATION * 100;
    return `<div class="day-focus-now" style="top:${top}%"><span>${formatTime(minute)}</span></div>`;
  }
  return `<div class="day-now-line" style="left:calc(var(--day-staff-rail) + var(--day-minute-px) * ${minuteOffset(minute)})"><span class="day-now-label">${formatTime(minute)}</span></div>`;
}

function renderWorkView() {
  const rows = state.plan.staff.map((person) => {
    const layout = layoutTimelineItems(timelineItemsForStaff(person.id));
    const items = layout.items.map(({ item, laneIndex }) => item.kind === 'appointment'
      ? appointmentMarkup(item, 'work', laneIndex)
      : operationalMarkup(item, 'work', laneIndex)
    ).join('');
    return `
      <div class="day-staff-row ${layout.laneCount > 1 ? 'has-multiple-lanes' : ''}" style="--day-lane-count:${layout.laneCount}">
        <button class="day-staff-button" type="button" data-focus-staff="${person.id}" aria-label="Einzeltag von ${person.displayName} öffnen">
          <span class="day-staff-avatar">${person.initials}</span>
          <span class="day-staff-copy"><strong>${person.displayName}</strong><small>${person.professionalRoleLabel}</small></span>
        </button>
        <div class="day-track" data-free-track="${person.id}" tabindex="0" role="button" aria-label="Freie Zeit bei ${person.displayName} auswählen">${items}</div>
      </div>
    `;
  }).join('');

  shell.refs.content.innerHTML = `
    <section class="day-page" data-day-view="work" data-desktop-visible-minutes="${OPERATIVE_VISIBLE_MINUTES_DESKTOP}" data-desktop-past-minutes="${OPERATIVE_PAST_MINUTES_DESKTOP}">
      <span class="day-toolbarless-status" role="status">${state.plan.appointments.length} Termine · ${state.plan.staff.length} Mitarbeitende</span>
      <div class="day-board">
        <div id="day-scroll-viewport" class="day-scroll-viewport" tabindex="0" aria-label="Tagesplan horizontal untersuchen">
          <div class="day-timeline-canvas">
            <div class="day-timeline-header"><div class="day-corner">Team</div><div class="day-time-ruler">${rulerLabels()}</div></div>
            ${rows}
            ${nowLineMarkup('work')}
          </div>
          <button id="day-now-return" class="day-now-return is-left" type="button" hidden>← Jetzt</button>
        </div>
      </div>
    </section>
  `;
}

function overviewLabels() {
  const labels = [];
  for (let minute = OPEN_MINUTE; minute <= CLOSE_MINUTE; minute += 60) {
    const top = minuteOffset(minute) / DAY_DURATION * 100;
    labels.push(`<span class="day-overview-time-label" style="top:${top}%">${formatTime(minute)}</span>`);
  }
  return labels.join('');
}

function renderFullDayView() {
  const columns = state.plan.staff.map((person) => {
    const items = timelineItemsForStaff(person.id).map((item) => item.kind === 'appointment' ? appointmentMarkup(item, 'overview') : operationalMarkup(item, 'overview')).join('');
    return `
      <section class="day-overview-column">
        <button class="day-overview-staff" type="button" data-focus-staff="${person.id}"><span class="day-staff-avatar">${person.initials}</span><span>${person.displayName.split(' ')[0]}</span></button>
        <div class="day-overview-body">${items}</div>
      </section>
    `;
  }).join('');
  shell.refs.content.innerHTML = `
    <section class="day-page" data-day-view="full-day">
      <div class="day-full-overview">
        <div class="day-overview-grid" style="--overview-staff-count:${state.plan.staff.length}">
          <div class="day-overview-time-rail"><div class="day-overview-time-body">${overviewLabels()}</div></div>
          ${columns}
          ${nowLineMarkup('overview')}
        </div>
      </div>
    </section>
  `;
}

function focusLabels() {
  const labels = [];
  for (let minute = OPEN_MINUTE; minute <= CLOSE_MINUTE; minute += 60) {
    const top = minuteOffset(minute) / DAY_DURATION * 100;
    labels.push(`<span class="day-focus-time-label" style="top:${top}%">${formatTime(minute)}</span>`);
  }
  return labels.join('');
}

function renderStaffFocus() {
  const person = personById(state.focusedStaffId);
  if (!person) {
    state.focusedStaffId = null;
    render();
    return;
  }
  const items = timelineItemsForStaff(person.id).map((item) => item.kind === 'appointment' ? appointmentMarkup(item, 'focus') : operationalMarkup(item, 'focus')).join('');
  shell.refs.content.innerHTML = `
    <section class="day-page day-staff-focus" data-day-view="staff-focus">
      <header class="day-focus-context">
        <div class="day-focus-identity"><span class="day-staff-avatar">${person.initials}</span><div class="day-focus-copy"><strong>${person.displayName}</strong><span>·</span><span>${formatDate(state.date)}</span></div></div>
        <button class="day-focus-exit" type="button" data-clear-staff-focus aria-label="Zum Team zurück">×</button>
      </header>
      <div id="day-focus-scroll" class="day-focus-scroll">
        <div class="day-focus-grid">
          <div class="day-focus-time-rail">${focusLabels()}</div>
          <div class="day-focus-track" data-focus-free-track="${person.id}" tabindex="0" role="button" aria-label="Freie Zeit bei ${person.displayName} auswählen">${items}</div>
          ${nowLineMarkup('focus')}
        </div>
      </div>
    </section>
  `;
}

function render() {
  cancelAnimationFrame(renderFrame);
  renderFrame = requestAnimationFrame(() => {
    renderHeader();
    if (state.loading) {
      renderLoading();
      bindPageEvents();
      return;
    }
    if (state.error) {
      renderError();
      bindPageEvents();
      return;
    }
    if (!can(Capability.DAY_PLAN_VIEW)) {
      renderForbidden();
      bindPageEvents();
      return;
    }
    if (state.focusedStaffId) renderStaffFocus();
    else if (state.scale === DayScale.FULL_DAY) renderFullDayView();
    else renderWorkView();
    bindPageEvents();
    restoreSpatialState();
  });
}

function scheduleRender(options = {}) {
  if (!options.preserveViewport) state.scrollLeft = document.querySelector('#day-scroll-viewport')?.scrollLeft ?? state.scrollLeft;
  render();
}

function liveAnchorRatio() {
  return isMobileLayout() ? LIVE_ANCHOR_RATIO_MOBILE : LIVE_ANCHOR_RATIO_DESKTOP;
}

function targetScrollLeft(viewport, minute = currentMinuteForView()) {
  if (minute == null) return viewport.scrollLeft;
  const minutePx = minutePixelWidth(viewport);
  const staffRail = staffRailWidth();
  const visibleTimelineWidth = Math.max(1, viewport.clientWidth - staffRail);
  const nowContentX = staffRail + minuteOffset(minute) * minutePx;
  return clamp(nowContentX - staffRail - visibleTimelineWidth * liveAnchorRatio(), 0, viewport.scrollWidth - viewport.clientWidth);
}

function animateScroll(viewport, target, duration = SCROLL_DURATION_MS) {
  const start = viewport.scrollLeft;
  const distance = target - start;
  if (Math.abs(distance) < 1 || matchMedia('(prefers-reduced-motion: reduce)').matches) {
    state.programmaticScroll = true;
    viewport.scrollLeft = target;
    state.scrollLeft = target;
    requestAnimationFrame(() => { state.programmaticScroll = false; });
    return;
  }
  const started = performance.now();
  state.programmaticScroll = true;
  const step = (now) => {
    const progress = clamp((now - started) / duration, 0, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    viewport.scrollLeft = start + distance * eased;
    state.scrollLeft = viewport.scrollLeft;
    if (progress < 1) requestAnimationFrame(step);
    else requestAnimationFrame(() => { state.programmaticScroll = false; });
  };
  requestAnimationFrame(step);
}

function scrollToNow({ announce = true, smooth = true } = {}) {
  const viewport = document.querySelector('#day-scroll-viewport');
  if (!viewport || !isToday() || state.scale !== DayScale.WORK || state.focusedStaffId) return;
  state.liveFollow = LiveFollowState.ACTIVE;
  state.livePauseReason = null;
  const target = targetScrollLeft(viewport);
  if (smooth) animateScroll(viewport, target);
  else {
    state.programmaticScroll = true;
    viewport.scrollLeft = target;
    state.scrollLeft = target;
    requestAnimationFrame(() => { state.programmaticScroll = false; });
  }
  updateNowReturn(viewport);
  renderHeader();
  bindHeaderEvents();
  if (announce) shell.announce(`Aktuelle Zeit ${formatTime(currentMinuteForView())} ist wieder am Live-Anker.`);
}

function pauseLiveFollow(reason) {
  state.lastUserActivityAt = Date.now();
  if (!isToday() || state.scale !== DayScale.WORK || state.focusedStaffId) return;
  if (state.liveFollow !== LiveFollowState.PAUSED) {
    state.liveFollow = LiveFollowState.PAUSED;
    state.livePauseReason = reason;
    emit(DashboardEvent.DAY_LIVE_FOLLOW_PAUSED, { date: state.date, visibleStartMinute: visibleStartMinute(), reason });
    renderHeader();
    bindHeaderEvents();
  }
}

function visibleStartMinute() {
  const viewport = document.querySelector('#day-scroll-viewport');
  if (!viewport) return OPEN_MINUTE;
  return Math.round(OPEN_MINUTE + viewport.scrollLeft / minutePixelWidth(viewport));
}

function syncVisibleTimelineContent(viewport = document.querySelector('#day-scroll-viewport')) {
  if (!viewport) return;
  cancelAnimationFrame(visibleContentFrame);
  visibleContentFrame = requestAnimationFrame(() => {
    const viewportRect = viewport.getBoundingClientRect();
    const railRight = viewportRect.left + staffRailWidth();
    const viewportRight = viewportRect.right;

    document.querySelectorAll('.day-appointment, .day-operational-block').forEach((card) => {
      const rect = card.getBoundingClientRect();
      const visibleLeft = Math.max(rect.left, railRight);
      const visibleRight = Math.min(rect.right, viewportRight);
      const visibleWidth = Math.max(0, visibleRight - visibleLeft);
      const continuesBefore = rect.left < railRight - 0.5 && rect.right > railRight;
      const continuesAfter = rect.right > viewportRight + 0.5 && rect.left < viewportRight;
      const copyShift = continuesBefore
        ? clamp(railRight - rect.left + 7, 0, Math.max(0, rect.width - 4))
        : 0;

      card.style.setProperty('--day-copy-shift', `${copyShift}px`);
      card.classList.toggle('continues-before', continuesBefore);
      card.classList.toggle('continues-after', continuesAfter);
      card.classList.toggle('is-visible-fragment-compact', visibleWidth > 0 && visibleWidth < 150);
      card.classList.toggle('is-visible-fragment-micro', visibleWidth > 0 && visibleWidth < 64);
    });
  });
}

function updateNowReturn(viewport = document.querySelector('#day-scroll-viewport')) {
  const button = document.querySelector('#day-now-return');
  if (!button || !viewport || !isToday() || state.liveFollow === LiveFollowState.ACTIVE) {
    if (button) button.hidden = true;
    return;
  }
  const minute = currentMinuteForView();
  const minutePx = minutePixelWidth(viewport);
  const staffRail = staffRailWidth();
  const nowX = staffRail + minuteOffset(minute) * minutePx;
  const visibleLeft = viewport.scrollLeft + staffRail;
  const visibleRight = viewport.scrollLeft + viewport.clientWidth;
  const direction = nowX < visibleLeft ? 'left' : nowX > visibleRight ? 'right' : (viewport.scrollLeft > targetScrollLeft(viewport, minute) ? 'left' : 'right');
  button.classList.toggle('is-left', direction === 'left');
  button.classList.toggle('is-right', direction === 'right');
  button.textContent = direction === 'left' ? '← Jetzt' : 'Jetzt →';
  button.hidden = false;
}

function canAutoReturn() {
  if (!isToday() || state.liveFollow !== LiveFollowState.PAUSED || state.scale !== DayScale.WORK || state.focusedStaffId) return false;
  if (state.overlay || state.selectedAppointmentId) return false;
  if (document.hidden) return false;
  const active = document.activeElement;
  if (active?.matches('input, textarea, select, [contenteditable="true"]')) return false;
  return Date.now() - state.lastUserActivityAt >= AUTO_RETURN_MS;
}

function refreshLiveClock() {
  const minute = currentMinuteForView();
  const workLine = document.querySelector('.day-now-line');
  if (workLine && minute != null) {
    workLine.style.left = `calc(var(--day-staff-rail) + var(--day-minute-px) * ${minuteOffset(minute)})`;
    workLine.querySelector('.day-now-label').textContent = formatTime(minute);
  }
  const focusLine = document.querySelector('.day-focus-now');
  if (focusLine && minute != null) {
    focusLine.style.top = `${minuteOffset(minute) / DAY_DURATION * 100}%`;
    focusLine.querySelector('span').textContent = formatTime(minute);
  }
  if (state.liveFollow === LiveFollowState.ACTIVE) {
    const viewport = document.querySelector('#day-scroll-viewport');
    if (viewport) animateScroll(viewport, targetScrollLeft(viewport, minute), SCROLL_DURATION_MS);
  } else {
    updateNowReturn();
  }
}

function restoreSpatialState() {
  const viewport = document.querySelector('#day-scroll-viewport');
  if (viewport) {
    applyOperationalScale(viewport);
    requestAnimationFrame(() => {
      if (state.liveFollow === LiveFollowState.ACTIVE && isToday()) scrollToNow({ announce: false, smooth: false });
      else {
        state.programmaticScroll = true;
        viewport.scrollLeft = state.scrollLeft;
        requestAnimationFrame(() => {
          state.programmaticScroll = false;
          updateNowReturn(viewport);
          syncVisibleTimelineContent(viewport);
        });
      }
    });
  }
  const focusScroll = document.querySelector('#day-focus-scroll');
  if (focusScroll) requestAnimationFrame(() => { focusScroll.scrollTop = state.focusScrollTop; });
}

function focusableElements(container) {
  return [...container.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [href], [tabindex]:not([tabindex="-1"])')]
    .filter((element) => !element.hidden && getComputedStyle(element).display !== 'none');
}

function openOverlay(kind, content, origin = document.activeElement) {
  closeOverlay({ restoreFocus: false });
  state.overlay = kind;
  state.overlayOrigin = origin instanceof HTMLElement ? origin : null;
  pauseLiveFollow('panel');
  document.body.insertAdjacentHTML('beforeend', `
    <div class="day-dialog-backdrop" data-overlay-backdrop>
      <section class="day-dialog" role="dialog" aria-modal="true" aria-labelledby="day-dialog-title">
        ${content}
      </section>
    </div>
  `);
  const overlay = document.querySelector('[data-overlay-backdrop]');
  overlay.addEventListener('mousedown', (event) => {
    if (event.target === overlay) closeOverlay();
  });
  overlay.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      closeOverlay();
      return;
    }
    if (event.key !== 'Tab') return;
    const focusables = focusableElements(overlay);
    if (!focusables.length) return;
    const first = focusables[0];
    const last = focusables.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });
  overlay.querySelector('[data-close-overlay]')?.addEventListener('click', () => closeOverlay());
  requestAnimationFrame(() => focusableElements(overlay)[0]?.focus());
}

function closeOverlay({ restoreFocus = true } = {}) {
  document.querySelector('[data-overlay-backdrop]')?.remove();
  const origin = state.overlayOrigin;
  state.overlay = null;
  state.overlayOrigin = null;
  state.lastUserActivityAt = Date.now();
  if (restoreFocus) requestAnimationFrame(() => origin?.focus({ preventScroll: true }));
}

function openDatePicker(origin) {
  openOverlay('date-picker', `
    <header class="day-dialog-header"><h2 id="day-dialog-title">Datum wählen</h2><button class="day-dialog-close" type="button" data-close-overlay aria-label="Schliessen">×</button></header>
    <div class="day-dialog-body"><form class="day-date-form" data-date-form><label for="day-date-input">Tag</label><input id="day-date-input" name="date" type="date" value="${state.date}" required></form></div>
    <footer class="day-dialog-footer"><button class="gw-button" type="button" data-date-today>Heute</button><button class="gw-button gw-button-primary" type="button" data-date-apply>Öffnen</button></footer>
  `, origin);
  document.querySelector('[data-date-today]').addEventListener('click', () => applyDate(todayIso()));
  document.querySelector('[data-date-apply]').addEventListener('click', () => applyDate(document.querySelector('#day-date-input').value));
}

function applyDate(date) {
  if (!date) return;
  emit(DashboardEvent.DAY_DATE_CHANGE_REQUESTED, { date });
  closeOverlay({ restoreFocus: false });
  state.date = date;
  state.liveFollow = date === todayIso() ? LiveFollowState.ACTIVE : LiveFollowState.UNAVAILABLE;
  state.selectedAppointmentId = null;
  state.scrollLeft = 0;
  loadDay(date, { focusDateButton: true });
}

function openAppointmentPanel(id, origin) {
  const appointment = appointmentById(id);
  if (!appointment || !can(Capability.APPOINTMENT_VIEW)) return;
  state.selectedAppointmentId = id;
  emit(DashboardEvent.APPOINTMENT_SELECTED, { appointmentId: id, date: state.date, originGeometry: state.focusedStaffId ? 'staff-focus' : state.scale });
  scheduleRender({ preserveViewport: true });
  openOverlay('appointment', `
    <header class="day-dialog-header"><div><span class="day-live-status">${STATUS_LABEL[appointment.status]}</span><h2 id="day-dialog-title">${appointment.customer.displayName}</h2></div><button class="day-dialog-close" type="button" data-close-overlay aria-label="Schliessen">×</button></header>
    <div class="day-dialog-body">
      <div class="day-detail-grid">
        <div class="day-detail-card"><span>Zeit</span><strong>${formatTime(appointment.startMinute)}–${formatTime(itemEnd(appointment))}</strong></div>
        <div class="day-detail-card"><span>Person</span><strong>${appointment.staff.displayName}</strong></div>
        <div class="day-detail-card"><span>Dienstleistung</span><strong>${appointment.service.displayName}</strong></div>
        <div class="day-detail-card"><span>Preis</span><strong>${formatMoney(appointment.price)}</strong></div>
      </div>
      ${appointment.note ? `<div class="day-note"><strong>Salonnotiz</strong><div>${appointment.note}</div></div>` : ''}
    </div>
    <footer class="day-dialog-footer"><button class="gw-button" type="button" data-close-overlay>Schliessen</button>${can(Capability.APPOINTMENT_EDIT) ? '<button class="gw-button gw-button-primary" type="button" data-edit-appointment>Bearbeiten</button>' : ''}</footer>
  `, origin);
  document.querySelector('[data-edit-appointment]')?.addEventListener('click', () => {
    emit(DashboardEvent.APPOINTMENT_EDIT_REQUESTED, { appointmentId: id, source: 'day-plan-panel' });
    shell.announce('Bearbeitungsabsicht wurde ausgelöst. In der Referenz wird nichts gespeichert.');
  });
}

function openOperationalPanel(id, origin) {
  const block = state.plan.operationalBlocks.find((item) => item.id === id);
  if (!block) return;
  openOverlay('operational', `
    <header class="day-dialog-header"><h2 id="day-dialog-title">${block.label}</h2><button class="day-dialog-close" type="button" data-close-overlay aria-label="Schliessen">×</button></header>
    <div class="day-dialog-body"><div class="day-detail-grid"><div class="day-detail-card"><span>Zeit</span><strong>${formatTime(block.startMinute)}–${formatTime(itemEnd(block))}</strong></div><div class="day-detail-card"><span>Person</span><strong>${block.staff.displayName}</strong></div><div class="day-detail-card"><span>Art</span><strong>${block.kind === OperationalKind.TASK ? 'Interne Aufgabe' : block.kind}</strong></div></div>${block.note ? `<div class="day-note">${block.note}</div>` : ''}</div>
    <footer class="day-dialog-footer"><button class="gw-button" type="button" data-close-overlay>Schliessen</button></footer>
  `, origin);
}

function openBookingPanel(options = {}, origin = document.activeElement) {
  if (!can(Capability.DAY_PLAN_CREATE_APPOINTMENT)) return;
  const person = options.staffId ? personById(options.staffId) : null;
  const suggestedStartMinute = Number.isFinite(options.startMinute) ? options.startMinute : null;
  openOverlay('booking', `
    <header class="day-dialog-header"><h2 id="day-dialog-title">Termin eintragen</h2><button class="day-dialog-close" type="button" data-close-overlay aria-label="Schliessen">×</button></header>
    <div class="day-dialog-body">
      <div class="day-detail-grid">
        <div class="day-detail-card"><span>Datum</span><strong>${formatDate(state.date)}</strong></div>
        <div class="day-detail-card"><span>Zeit</span><strong>${suggestedStartMinute == null ? 'Noch offen' : formatTime(suggestedStartMinute)}</strong></div>
        <div class="day-detail-card"><span>Person</span><strong>${person?.displayName ?? 'Noch offen'}</strong></div>
        <div class="day-detail-card"><span>Quelle</span><strong>${options.source === 'day-plan-free-space' ? 'Freie Zeit' : 'Tagesplan'}</strong></div>
      </div>
      <p>Diese Referenz übergibt nur die Buchungsabsicht. Verfügbarkeit und Speicherung entscheidet später die Produktionsintegration.</p>
    </div>
    <footer class="day-dialog-footer"><button class="gw-button" type="button" data-close-overlay>Abbrechen</button><button class="gw-button gw-button-primary" type="button" data-confirm-booking>Absicht auslösen</button></footer>
  `, origin);
  document.querySelector('[data-confirm-booking]').addEventListener('click', () => {
    emit(DashboardEvent.APPOINTMENT_CREATE_REQUESTED, {
      date: state.date,
      staffId: person?.id ?? null,
      suggestedStartMinute,
      source: options.source ?? 'day-plan-header'
    });
    shell.announce('Buchungsabsicht ausgelöst. Die Referenz speichert keinen Termin.');
    closeOverlay();
  });
}

function minuteFromTrackPointer(track, event, vertical = false) {
  const rect = track.getBoundingClientRect();
  const ratio = vertical
    ? clamp((event.clientY - rect.top) / rect.height, 0, 1)
    : clamp((event.clientX - rect.left) / rect.width, 0, 1);
  return clamp(Math.round((OPEN_MINUTE + ratio * DAY_DURATION) / 15) * 15, OPEN_MINUTE, CLOSE_MINUTE - 15);
}

function toggleScale(origin) {
  if (state.focusedStaffId) return;
  state.scale = state.scale === DayScale.WORK ? DayScale.FULL_DAY : DayScale.WORK;
  emit(DashboardEvent.DAY_SCALE_CHANGE_REQUESTED, {
    scale: state.scale,
    date: state.date,
    selectedAppointmentId: state.selectedAppointmentId,
    focusedStaffId: null,
    visibleStartMinute: visibleStartMinute()
  });
  pauseLiveFollow('selection');
  render();
  requestAnimationFrame(() => document.querySelector('[data-toggle-scale]')?.focus({ preventScroll: true }) ?? origin?.focus?.());
}

function focusStaff(staffId, origin) {
  state.scrollLeft = document.querySelector('#day-scroll-viewport')?.scrollLeft ?? state.scrollLeft;
  state.focusedStaffId = staffId;
  state.overlayOrigin = origin;
  pauseLiveFollow('selection');
  emit(DashboardEvent.DAY_STAFF_FOCUS_REQUESTED, { staffId, date: state.date, originScale: state.scale });
  render();
  requestAnimationFrame(() => document.querySelector('[data-clear-staff-focus]')?.focus({ preventScroll: true }));
}

function clearStaffFocus() {
  const previous = state.focusedStaffId;
  state.focusedStaffId = null;
  emit(DashboardEvent.DAY_STAFF_FOCUS_CLEARED, { staffId: previous, date: state.date, returnScale: state.scale });
  render();
  requestAnimationFrame(() => document.querySelector(`[data-focus-staff="${previous}"]`)?.focus({ preventScroll: true }));
}

function bindHeaderEvents() {
  document.querySelectorAll('[data-open-date-picker]').forEach((button) => button.addEventListener('click', () => openDatePicker(button)));
  document.querySelectorAll('[data-toggle-scale]').forEach((button) => button.addEventListener('click', () => toggleScale(button)));
  document.querySelectorAll('[data-create-appointment]').forEach((button) => button.addEventListener('click', () => openBookingPanel({ source: 'day-plan-header' }, button)));
}

function bindPageEvents() {
  bindHeaderEvents();
  document.querySelector('[data-retry]')?.addEventListener('click', () => loadDay(state.date));

  document.querySelectorAll('[data-appointment-id]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.stopPropagation();
      openAppointmentPanel(button.dataset.appointmentId, button);
    });
  });
  document.querySelectorAll('[data-operational-id]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.stopPropagation();
      openOperationalPanel(button.dataset.operationalId, button);
    });
  });
  document.querySelectorAll('[data-focus-staff]').forEach((button) => button.addEventListener('click', () => focusStaff(button.dataset.focusStaff, button)));
  document.querySelector('[data-clear-staff-focus]')?.addEventListener('click', clearStaffFocus);

  document.querySelectorAll('[data-free-track]').forEach((track) => {
    track.addEventListener('click', (event) => {
      if (event.target.closest('[data-appointment-id], [data-operational-id]')) return;
      openBookingPanel({ staffId: track.dataset.freeTrack, startMinute: minuteFromTrackPointer(track, event), source: 'day-plan-free-space' }, track);
    });
    track.addEventListener('keydown', (event) => {
      if (!['Enter', ' '].includes(event.key)) return;
      event.preventDefault();
      const suggested = isToday() ? clamp(Math.ceil((currentMinuteForView() + 15) / 15) * 15, OPEN_MINUTE, CLOSE_MINUTE - 15) : OPEN_MINUTE;
      openBookingPanel({ staffId: track.dataset.freeTrack, startMinute: suggested, source: 'day-plan-free-space' }, track);
    });
  });

  document.querySelector('[data-focus-free-track]')?.addEventListener('click', (event) => {
    if (event.target.closest('[data-appointment-id], [data-operational-id]')) return;
    const track = event.currentTarget;
    openBookingPanel({ staffId: track.dataset.focusFreeTrack, startMinute: minuteFromTrackPointer(track, event, true), source: 'day-plan-free-space' }, track);
  });

  const focusTrack = document.querySelector('[data-focus-free-track]');
  focusTrack?.addEventListener('keydown', (event) => {
    if (!['Enter', ' '].includes(event.key)) return;
    event.preventDefault();
    const suggested = isToday() ? clamp(Math.ceil((currentMinuteForView() + 15) / 15) * 15, OPEN_MINUTE, CLOSE_MINUTE - 15) : OPEN_MINUTE;
    openBookingPanel({ staffId: focusTrack.dataset.focusFreeTrack, startMinute: suggested, source: 'day-plan-free-space' }, focusTrack);
  });

  const viewport = document.querySelector('#day-scroll-viewport');
  if (viewport) {
    viewport.addEventListener('pointerdown', () => pauseLiveFollow('pointer'), { passive: true });
    viewport.addEventListener('wheel', () => pauseLiveFollow('scroll'), { passive: true });
    viewport.addEventListener('touchstart', () => pauseLiveFollow('pointer'), { passive: true });
    viewport.addEventListener('scroll', () => {
      state.scrollLeft = viewport.scrollLeft;
      if (!state.programmaticScroll) pauseLiveFollow('scroll');
      updateNowReturn(viewport);
      syncVisibleTimelineContent(viewport);
    }, { passive: true });
    viewport.addEventListener('keydown', (event) => {
      if (!['ArrowLeft', 'ArrowRight', 'PageUp', 'PageDown', 'Home', 'End'].includes(event.key)) return;
      pauseLiveFollow('keyboard');
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault();
        const minutePx = minutePixelWidth(viewport);
        viewport.scrollBy({ left: (event.key === 'ArrowLeft' ? -1 : 1) * minutePx * 15, behavior: 'smooth' });
      }
    });
  }
  document.querySelector('#day-now-return')?.addEventListener('click', () => {
    emit(DashboardEvent.DAY_LIVE_FOLLOW_RESUME_REQUESTED, { date: state.date });
    scrollToNow();
  });

  const focusScroll = document.querySelector('#day-focus-scroll');
  focusScroll?.addEventListener('scroll', () => { state.focusScrollTop = focusScroll.scrollTop; }, { passive: true });
}

async function loadDay(date, options = {}) {
  state.loading = true;
  state.error = null;
  render();
  try {
    state.plan = await dataSource.getDayPlan({ date });
    state.date = state.plan.date;
    state.loading = false;
    state.liveFollow = state.plan.isToday ? LiveFollowState.ACTIVE : LiveFollowState.UNAVAILABLE;
    render();
    if (options.focusDateButton) requestAnimationFrame(() => document.querySelector('[data-open-date-picker]')?.focus({ preventScroll: true }));
  } catch (error) {
    state.error = error;
    state.loading = false;
    render();
  }
}

function startTimers() {
  clearInterval(liveTimer);
  clearInterval(inactivityTimer);
  liveTimer = window.setInterval(refreshLiveClock, LIVE_TICK_MS);
  inactivityTimer = window.setInterval(() => {
    if (canAutoReturn()) scrollToNow({ announce: true, smooth: true });
  }, 1000);
}

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  if (state.overlay) {
    event.preventDefault();
    closeOverlay();
  } else if (state.focusedStaffId) {
    event.preventDefault();
    clearStaffFocus();
  }
});

window.addEventListener('resize', () => {
  const viewport = document.querySelector('#day-scroll-viewport');
  if (!viewport) return;
  state.scrollLeft = viewport.scrollLeft;
  applyOperationalScale(viewport);
  requestAnimationFrame(() => {
    if (state.liveFollow === LiveFollowState.ACTIVE) scrollToNow({ announce: false, smooth: false });
    else {
      state.programmaticScroll = true;
      viewport.scrollLeft = state.scrollLeft;
      requestAnimationFrame(() => {
        state.programmaticScroll = false;
        updateNowReturn(viewport);
        syncVisibleTimelineContent(viewport);
      });
    }
  });
}, { passive: true });

document.addEventListener('visibilitychange', () => {
  state.lastUserActivityAt = Date.now();
  if (!document.hidden && state.liveFollow === LiveFollowState.ACTIVE) refreshLiveClock();
});

async function initialize() {
  try {
    state.session = await dataSource.getSessionContext();
    state.date = todayIso();
    await loadDay(state.date);
    startTimers();
  } catch (error) {
    state.error = error;
    state.loading = false;
    render();
  }
}

initialize();
