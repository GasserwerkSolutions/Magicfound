# [Seitenname] · Seitenvertrag

Status: **Entwurf**  
Verantwortlicher Bereich: `[Bereich]`  
Direkter Referenzpfad: `/dashboard/pages/[pfad]/`  
Abhängige gemeinsame Verträge: `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

- Welches fachliche Problem löst die Seite?
- Was ist die eine primäre Arbeitsaufgabe?
- Was ist ausdrücklich kein Bestandteil dieser Seite?

## 2. Eingabedaten

- Datenquellenmethoden
- Query-/Kontextwerte
- erforderliche Felder
- optionale Felder
- Capabilities
- Uhr-, Datums- oder Standortkontext

Keine API- oder Datenbankdetails eintragen.

## 3. Fachliches View-Model

```js
{
  // normalisierte, UI-nahe Struktur
}
```

- abgeleitete Werte
- Sortierung
- Gruppierung
- fachliche Invarianten

## 4. Ausgehende Ereignisse

Für jedes Event dokumentieren:

```js
{
  type,
  payload
}
```

- Auslöser
- erforderliche Payload-Felder
- erwartete sichtbare Reaktion
- keine direkte Persistenzannahme

## 5. Ladezustand

- was bleibt sichtbar?
- welche Inhalte erhalten Skeletons?
- welche Aktionen sind verfügbar?
- Fokusverhalten

## 6. Leerzustand

- fachliche Bedeutung von „leer“
- primäre nächste Handlung
- Unterschied zu Filter-ohne-Treffer
- zulässige Illustration

## 7. Fehlerzustand

- Kernladefehler
- Teilfehler
- retryable/nicht retryable
- offline/stale
- Fokus und Fehlermeldung

## 8. Berechtigungszustände

- benötigte Capabilities pro Ansicht und Aktion
- verstecken versus deaktivieren
- vertrauliche Felder
- forbidden-Zustand

## 9. Desktopverhalten

- Produktschale
- Seitengeometrie
- Scroll-Owner
- Detailzustände
- 14-Zoll-Dichte

## 10. Mobilverhalten

- räumliche Umordnung
- Navigation
- Listen/Tabellen/Details
- Sheets und Overlays
- Touch-Ziele

Die Fachlogik MUSS der Desktopseite entsprechen.

## 11. Tastatur und Fokus

- Eintrittsfokus
- Tab-Reihenfolge
- direkte Aktivierungen
- Escape-Verhalten
- Fokuswiederherstellung
- Live-Regionen

## 12. Abnahmekriterien

- funktionale Kriterien
- visuelle Kriterien
- responsive Kriterien
- Zustandsabdeckung
- Accessibility
- Regression

## 13. Integrationshinweise

- Adaptergrenze
- stabile IDs
- Eventbindung
- offene Fragen mit IDs aus `OPEN_QUESTIONS.md`
- ausdrücklich nicht angenommene Backenddetails
