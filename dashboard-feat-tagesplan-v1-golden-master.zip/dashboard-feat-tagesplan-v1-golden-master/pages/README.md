# Seitenkatalog

Dieses Verzeichnis enthält die eigenständig ausführbaren Referenzseiten des Gasserwerk Dashboards.

## Arbeitsphase

Der vollständige Vertragsdurchgang und die semantische Konsolidierung sind abgeschlossen. Alle bekannten offenen Punkte sind als integrationsrelevant oder spätere Verfeinerung klassifiziert; es existiert derzeit kein Referenzblocker der Klasse `B`.

Reihenfolge ab jetzt:

1. gemeinsame Modulbasis implementieren
2. Tokens, Dichte und Produktschale extrahieren
3. Mock-Datenquelle und normalisierte Fixtures bereitstellen
4. Tagesplan als erste eigenständig ausführbare Seite bauen
5. Kundschaft und Termine
6. Team, Angebot und Verwaltung
7. Login und Onboarding
8. Screenshot- und Interaktionsregression

Gemeinsame Regeln: [`docs/contracts/README.md`](../docs/contracts/README.md)  
Semantischer Durchgang: [`docs/contracts/SEMANTIC_REVIEW.md`](../docs/contracts/SEMANTIC_REVIEW.md)  
Wirkungs- und Bedeutungssystem: [`docs/WIRKUNGSSYSTEM_V1.md`](../docs/WIRKUNGSSYSTEM_V1.md)  
Offene Fragen: [`docs/contracts/OPEN_QUESTIONS.md`](../docs/contracts/OPEN_QUESTIONS.md)  
Vorlage: [`CONTRACT_TEMPLATE.md`](./CONTRACT_TEMPLATE.md)

## Vertragsstatus

| Seite | Vertrag | Status | Erste Implementierung |
|---|---|---|---|
| Login | [`login/CONTRACT.md`](./login/CONTRACT.md) | Zur Freigabe | nach Produktschale |
| Onboarding | [`onboarding/CONTRACT.md`](./onboarding/CONTRACT.md) | Zur Freigabe | nach Login/Verwaltungsmustern |
| Tagesplan | [`tagesplan/CONTRACT.md`](./tagesplan/CONTRACT.md) | Zur Freigabe | zuerst |
| Termine | [`termine/CONTRACT.md`](./termine/CONTRACT.md) | Zur Freigabe | nach Tagesplan |
| Kundschaft | [`kundschaft/CONTRACT.md`](./kundschaft/CONTRACT.md) | Zur Freigabe | nach Tagesplan |
| Team | [`team/CONTRACT.md`](./team/CONTRACT.md) | Zur Freigabe | nach gemeinsamer Karten-/Detailstruktur |
| Angebot | [`angebot/CONTRACT.md`](./angebot/CONTRACT.md) | Zur Freigabe | nach Team |
| Verwaltung | [`verwaltung/CONTRACT.md`](./verwaltung/CONTRACT.md) | Zur Freigabe | nach gemeinsamer Karten-/Formstruktur |

`Zur Freigabe` bedeutet: Der Vertrag enthält alle bekannten Produktentscheidungen, offene Backendfragen sind explizit klassifiziert und die Referenzimplementierung kann ohne erfundene Backendwahrheit beginnen. `Verbindlich` wird erst nach fachlicher Abnahme gesetzt.

## Navigationsseiten

- `login/`
- `onboarding/`
- `tagesplan/`
- `termine/`
- `kundschaft/`
- `team/`
- `angebot/`
- `verwaltung/`

Jede Seite besteht nach ihrer Implementierung aus:

```text
index.html   direkter Einstieg
page.js      Seitenzustand und Ereignisse
page.css     ausschließlich seitenbezogene Geometrie
CONTRACT.md  Daten-, Zustands- und Integrationsvertrag
```

Gemeinsame Produktschale, Komponenten, Stile und Datenadapter werden aus `src/` importiert und dürfen nicht pro Seite kopiert werden.

## Zustände, keine zusätzlichen Seiten

- Tagesplan: Teamarbeitsfläche, Ganztagesmassstab und Personenfokus
- Kundschaft: Liste und Kundenkartei
- Termin: Eintragen, Ansehen und Bearbeiten als Kontextflächen
- Datumsauswahl und Suche als gemeinsame Komponenten

## Freigabe einer Seite

Eine Seite wechselt von `Zur Freigabe` zu `Verbindlich`, wenn:

- die fachliche Abnahme erfolgt ist
- keine neue Frage der Klasse `B` offen ist
- Datenfelder, Events und Capabilities akzeptiert sind
- Desktop-, Mobil-, Tastatur- und Fokusverhalten akzeptiert sind
- Abweichungen gegenüber `docs/PRODUCT_SURFACE_V1.md` ausdrücklich dokumentiert sind

Nach `Verbindlich` darf die modulare Referenzimplementierung fachlich nicht stillschweigend vom Vertrag abweichen.

Der erste vollständig zu implementierende Bereich ist `tagesplan/`. Er definiert die gemeinsame Zeit-, Fokus-, Panel- und Responsive-Grammatik für die übrigen Seiten.
