export const AppointmentStatus = Object.freeze({
  CONFIRMED: 'confirmed',
  PENDING: 'pending',
  ARRIVED: 'arrived',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
  NO_SHOW: 'no-show'
});

export const APPOINTMENT_STATUS_LABELS = Object.freeze({
  [AppointmentStatus.CONFIRMED]: 'Bestätigt',
  [AppointmentStatus.PENDING]: 'Angefragt',
  [AppointmentStatus.ARRIVED]: 'Im Salon',
  [AppointmentStatus.COMPLETED]: 'Abgeschlossen',
  [AppointmentStatus.CANCELLED]: 'Abgesagt',
  [AppointmentStatus.NO_SHOW]: 'Nicht erschienen'
});

export const OperationalKind = Object.freeze({
  TASK: 'task',
  BREAK: 'break',
  ABSENCE: 'absence',
  CONFLICT: 'conflict'
});

export const PageDataState = Object.freeze({
  INITIAL: 'initial',
  LOADING: 'loading',
  READY: 'ready',
  EMPTY: 'empty',
  PARTIAL: 'partial',
  SAVING: 'saving',
  ERROR: 'error',
  FORBIDDEN: 'forbidden',
  OFFLINE: 'offline',
  STALE: 'stale'
});

export const DayScale = Object.freeze({
  WORK: 'work',
  FULL_DAY: 'full-day'
});

export const LiveFollowState = Object.freeze({
  ACTIVE: 'active',
  PAUSED: 'paused',
  UNAVAILABLE: 'unavailable'
});

export const ContractStatus = Object.freeze({
  DRAFT: 'Entwurf',
  FOR_APPROVAL: 'Zur Freigabe',
  BINDING: 'Verbindlich',
  IMPLEMENTED: 'Implementiert',
  PRODUCTION_MAPPED: 'In Produktion abgebildet'
});

export const APPOINTMENT_STATUS_VALUES = Object.freeze(Object.values(AppointmentStatus));
export const OPERATIONAL_KIND_VALUES = Object.freeze(Object.values(OperationalKind));
export const PAGE_DATA_STATE_VALUES = Object.freeze(Object.values(PageDataState));
