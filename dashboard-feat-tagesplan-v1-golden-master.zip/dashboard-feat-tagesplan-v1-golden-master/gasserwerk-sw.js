const BUILD_ID = "github-singlefile-20260822-1";
const SHELL_CACHE = `gasserwerk-shell-${BUILD_ID}`;
const BASE_PATH = new URL("./", self.registration.scope).pathname.replace(/\/$/, "");
const scoped = path => `${BASE_PATH}${path}` || path;
const PRECACHE = [
  "/index.html",
  "/gasserwerk.webmanifest",
  "/icons/gasserwerk-192.png",
  "/icons/gasserwerk-512.png",
  "/icons/gasserwerk-maskable-512.png"
].map(scoped);

self.addEventListener("install", event => {
  event.waitUntil(caches.open(SHELL_CACHE).then(cache => cache.addAll(PRECACHE)));
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith("gasserwerk-") && key !== SHELL_CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("message", event => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
});

async function networkFirst(request) {
  try {
    const response = await fetch(request);
    if (response.ok && request.mode === "navigate") {
      const cache = await caches.open(SHELL_CACHE);
      await cache.put(scoped("/index.html"), response.clone());
    }
    return response;
  } catch (error) {
    return (await caches.match(request)) || (request.mode === "navigate" ? caches.match(scoped("/index.html")) : Promise.reject(error));
  }
}

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  const localPath = BASE_PATH && url.pathname.startsWith(BASE_PATH)
    ? (url.pathname.slice(BASE_PATH.length) || "/")
    : BASE_PATH ? null : url.pathname;
  if (localPath == null || localPath.startsWith("/api/")) return;
  if (request.mode === "navigate") event.respondWith(networkFirst(request));
});
