(() => {
  'use strict';

  const root = document.getElementById('dashboard-root');
  if (!root) return;

  const query = new URLSearchParams(location.search);
  const DESKTOP = '(min-width: 960px)';
  const EMPTY_IMAGE = '../../assets/alpine/kantenblick.8375fcb60e.webp';
  const state = { frame: 0, observer: null, resizeObserver: null };

  document.body.dataset.gwPage = 'tagesplan';
  document.body.dataset.gwState = query.get('state') || (query.get('scenario') === 'empty' ? 'empty' : 'normal');
  document.body.dataset.gwDensity = density();

  function density() {
    if (innerWidth < 600 || innerHeight < 520) return 'touch-compact';
    if (innerWidth < 960) return 'touch';
    if (innerHeight < 720 || innerWidth < 1200) return 'compact';
    return 'standard';
  }

  function schedule() {
    cancelAnimationFrame(state.frame);
    state.frame = requestAnimationFrame(sync);
  }

  function sync() {
    state.frame = 0;
    const desktop = matchMedia(DESKTOP).matches;
    root.dataset.tpV1Layout = desktop ? 'desktop' : 'mobile';
    document.body.dataset.gwDensity = density();
    applyPhase();
    addServiceIcons();
    addEmptyHabitat();
    if (desktop) fitDesktop();
    else releaseDesktopFit();
    updateDiagnostics();
    verifyMobileScroll();
  }

  function elements() {
    const workspace = root.querySelector('.gw-workspace');
    const pageHost = root.querySelector('.gw-page-content.va-page-host');
    const viewport = root.querySelector('.va-calendar-viewport');
    const head = root.querySelector('.va-calendar-head');
    const scroll = root.querySelector('.va-calendar-scroll');
    const grid = root.querySelector('.va-calendar-grid');
    return { workspace, pageHost, viewport, head, scroll, grid };
  }

  function fitDesktop() {
    const { workspace, pageHost, viewport, head, scroll, grid } = elements();
    if (!workspace || !pageHost || !viewport || !head || !scroll || !grid) return;

    const hostTop = pageHost.getBoundingClientRect().top;
    const workspaceStyle = getComputedStyle(workspace);
    const bottomPadding = Number.parseFloat(workspaceStyle.paddingBottom || '0') || 0;
    const available = Math.max(360, Math.floor(innerHeight - hostTop - bottomPadding));
    root.style.setProperty('--tp-v1-page-height', `${available}px`);

    pageHost.style.height = `${available}px`;
    pageHost.style.maxHeight = `${available}px`;

    const viewportHeight = Math.max(300, Math.floor(viewport.getBoundingClientRect().height));
    const headHeight = Math.ceil(head.getBoundingClientRect().height);
    const gridHeight = Math.max(240, viewportHeight - headHeight);
    root.style.setProperty('--tp-v1-grid-height', `${gridHeight}px`);
    scroll.style.height = `${gridHeight}px`;
    grid.style.height = `${gridHeight}px`;
  }

  function releaseDesktopFit() {
    root.style.removeProperty('--tp-v1-page-height');
    root.style.removeProperty('--tp-v1-grid-height');
    const { pageHost, scroll, grid } = elements();
    if (pageHost) { pageHost.style.removeProperty('height'); pageHost.style.removeProperty('max-height'); }
    scroll?.style.removeProperty('height');
    grid?.style.removeProperty('height');
  }

  function serviceSvg(service) {
    const value = String(service || '').toLowerCase();
    let paths;
    if (value.includes('balayage')) paths = '<path d="M5 19c4-8 7-11 14-14M8 20c3-7 6-10 12-13M5 14c4 .5 7 2 9 5"/>';
    else if (value.includes('farbe') || value.includes('farb')) paths = '<path d="M5 15h14l-2 5H7l-2-5ZM8 15l2-9h4l2 9M12 4V2M9 7h6"/>';
    else if (value.includes('gloss')) paths = '<path d="M12 3c3 4 5 6.5 5 10a5 5 0 0 1-10 0c0-3.5 2-6 5-10Z"/><path d="m18 4 .6 1.4L20 6l-1.4.6L18 8l-.6-1.4L16 6l1.4-.6L18 4Z" fill="currentColor" stroke="none"/>';
    else if (value.includes('pflege')) paths = '<path d="M12 3c3 4 5 6.5 5 10a5 5 0 0 1-10 0c0-3.5 2-6 5-10Z"/><path d="M9.5 14.5c1.2 1 3.1 1 4.3 0"/>';
    else if (value.includes('schnitt')) paths = '<circle cx="6.5" cy="17.5" r="3"/><circle cx="17.5" cy="17.5" r="3"/><path d="m8.8 15.6 8.9-11M15.2 15.6 6.3 4.6M10.1 12h3.8"/>';
    else paths = '<path d="M4 5h16v11H9l-5 4V5Z"/><path d="M8 9h8M8 12h5"/>';
    return `<svg class="tp-v1-service-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
  }

  function addServiceIcons() {
    root.querySelectorAll('.va-appointment').forEach((card) => {
      if (card.querySelector('.tp-v1-service-icon')) return;
      const service = card.dataset.fullServiceName || card.querySelector('.va-card-copy small')?.textContent || '';
      const copy = card.querySelector('.va-card-copy');
      if (!copy) return;
      copy.insertAdjacentHTML('beforebegin', serviceSvg(service));
    });
  }

  function addEmptyHabitat() {
    const grid = root.querySelector('.va-calendar-grid');
    if (!grid) return;
    const empty = root.querySelectorAll('.va-appointment').length === 0 && document.body.dataset.gwState !== 'loading';
    const current = grid.querySelector('.tp-v1-empty-habitat');
    if (!empty) { current?.remove(); return; }
    if (current) return;
    grid.insertAdjacentHTML('beforeend', `<div class="tp-v1-empty-habitat" aria-label="Leerer Tagesplan"><div class="tp-v1-empty-copy"><strong>Heute ist es noch erstaunlich ruhig.</strong><small>Freie Zeit bleibt direkt in der Kalenderfläche buchbar.</small></div><img src="${EMPTY_IMAGE}" alt=""></div>`);
  }

  function applyPhase() {
    const value = query.get('referenceNow');
    if (!value || !/^\d{1,2}:\d{2}$/.test(value)) { root.dataset.tpV1Phase = 'during'; return; }
    const [hour, minute] = value.split(':').map(Number);
    const total = hour * 60 + minute;
    root.dataset.tpV1Phase = total < 480 ? 'before' : total > 1080 ? 'after' : 'during';
  }

  function updateDiagnostics() {
    const { pageHost, viewport, scroll } = elements();
    const desktop = matchMedia(DESKTOP).matches;
    const documentX = Math.max(0, document.documentElement.scrollWidth - document.documentElement.clientWidth);
    const documentY = Math.max(0, document.documentElement.scrollHeight - document.documentElement.clientHeight);
    const pageY = pageHost ? Math.max(0, pageHost.scrollHeight - pageHost.clientHeight) : 0;
    const viewportX = viewport ? Math.max(0, viewport.scrollWidth - viewport.clientWidth) : 0;
    const viewportY = viewport ? Math.max(0, viewport.scrollHeight - viewport.clientHeight) : 0;
    const innerCalendarY = scroll ? Math.max(0, scroll.scrollHeight - scroll.clientHeight) : 0;

    root.dataset.tpDocumentOverflowX = String(Math.round(documentX));
    root.dataset.tpDocumentOverflowY = String(Math.round(documentY));
    root.dataset.tpPageOverflowY = String(Math.round(pageY));
    root.dataset.tpViewportOverflowX = String(Math.round(viewportX));
    root.dataset.tpViewportOverflowY = String(Math.round(viewportY));
    root.dataset.tpCalendarOverflowY = String(Math.round(innerCalendarY));
    root.dataset.tpCompleteDayVisible = String(desktop && documentY <= 2 && pageY <= 2 && viewportY <= 2 && innerCalendarY <= 2 ? 1 : 0);
    root.dataset.tpVerticalScrollSystems = String(!desktop && viewportY > 2 ? 1 : 0);
    root.dataset.tpHorizontalStaffScrollable = String(!desktop && viewportX > 2 ? 1 : 0);
    root.dataset.tpCalendarSurface = 'single';
    root.dataset.tpReferenceVersion = '1.0.0';
  }

  function verifyMobileScroll() {
    if (query.get('verifyStaffScroll') !== '1' || matchMedia(DESKTOP).matches) return;
    const { viewport } = elements();
    if (!viewport || root.dataset.tpStaffScrollFunctional === '1') return;
    const max = Math.max(0, viewport.scrollWidth - viewport.clientWidth);
    const before = viewport.scrollLeft;
    viewport.scrollLeft = Math.min(max, before + 132);
    const delta = Math.round(viewport.scrollLeft - before);
    root.dataset.tpStaffScrollDelta = String(delta);
    root.dataset.tpStaffScrollFunctional = delta > 2 ? '1' : '0';
  }

  state.observer = new MutationObserver(schedule);
  state.observer.observe(root, { childList: true, subtree: true });
  if ('ResizeObserver' in window) {
    state.resizeObserver = new ResizeObserver(schedule);
    state.resizeObserver.observe(document.body);
    state.resizeObserver.observe(root);
  }
  window.addEventListener('resize', schedule, { passive: true });
  window.addEventListener('orientationchange', schedule);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') schedule(); });
  schedule();
  setTimeout(schedule, 100);
  setTimeout(schedule, 320);
  window.addEventListener('pagehide', () => {
    state.observer?.disconnect();
    state.resizeObserver?.disconnect();
    cancelAnimationFrame(state.frame);
  }, { once: true });
})();
