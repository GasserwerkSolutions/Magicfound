import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
import { assertAutonomousDocument } from './tagesplan-v1-autonomy.mjs';

const root = process.cwd();
const referencePath = resolve(root, 'references/tagesplan/v1.0/tagesplan-reference.html');
const experimentIndexPath = resolve(root, 'experiments/tagesplan-vertical-agenda/index.html');
const outputDirectory = resolve(root, 'artifacts/tagesplan-v1');
const errors = [];
const evidence = [];
const EPSILON = 2;
const HANDSHAKE_TIMEOUT_MS = 15_000;
const DIAGNOSTICS_VERSION = '1';

const CASES = Object.freeze([
  { name: 'golden-desktop-1512x982', width: 1512, height: 982, kind: 'desktop', parameters: 'referenceDate=2026-08-25&referenceNow=11:22' },
  { name: 'golden-compact-390x844', width: 390, height: 844, kind: 'compact', hasTouch: true, parameters: 'referenceDate=2026-08-25&referenceNow=11:22&verifyStaffScroll=1' },
  { name: 'golden-coarse-1024x768', width: 1024, height: 768, kind: 'desktop', hasTouch: true, parameters: 'referenceDate=2026-08-25&referenceNow=11:22' },
  { name: 'golden-agenda-1512x982', width: 1512, height: 982, kind: 'agenda', parameters: 'referenceDate=2026-08-25&referenceNow=11:22&agenda=open' },
  { name: 'golden-focus-1512x982', width: 1512, height: 982, kind: 'focus', parameters: 'referenceDate=2026-08-25&referenceNow=11:22&focus=melanie' },
  { name: 'golden-reference-date-1512x982', width: 1512, height: 982, kind: 'date', parameters: 'referenceDate=2026-08-24&referenceNow=11:22' }
]);

const attributeValue = (snapshot, name) => snapshot?.attributes?.[`data-${name}`] ?? null;
const attributeNumber = (snapshot, name) => {
  const value = attributeValue(snapshot, name);
  return value == null || value === '' ? null : Number(value);
};

function requireValue(snapshot, name, expected, label) {
  const value = attributeValue(snapshot, name);
  if (value !== String(expected)) errors.push(`${label}: data-${name} expected ${expected}, received ${value}`);
}

function requireStatic(source, text, label) {
  if (!source.includes(text)) errors.push(`Static core contract missing: ${label}`);
}

function assertGeometryParity(actual, expected, label) {
  if (!actual?.geometry || !expected?.geometry) {
    errors.push(`${label}: geometry snapshot missing`);
    return;
  }
  for (const section of ['viewport', 'calendarHead', 'grid']) {
    for (const field of ['left', 'top', 'width', 'height']) {
      const actualValue = actual.geometry[section]?.[field];
      const expectedValue = expected.geometry[section]?.[field];
      if (!(Number.isFinite(actualValue) && Number.isFinite(expectedValue) && Math.abs(actualValue - expectedValue) <= EPSILON)) {
        errors.push(`${label}: ${section}.${field} changed from ${expectedValue} to ${actualValue}`);
      }
    }
  }
  for (const field of ['viewportScrollWidth', 'viewportScrollHeight']) {
    if (Math.abs((actual.geometry[field] ?? 0) - (expected.geometry[field] ?? 0)) > EPSILON) {
      errors.push(`${label}: ${field} changed from ${expected.geometry[field]} to ${actual.geometry[field]}`);
    }
  }
}

async function readSnapshot(page) {
  return page.locator('#dashboard-root').evaluate((element) => {
    const dataAttributes = (node) => Object.fromEntries(
      [...(node?.attributes ?? [])]
        .filter(({ name }) => name.startsWith('data-'))
        .map(({ name, value }) => [name, value])
    );
    const isVisible = (node) => {
      if (!node?.getClientRects().length) return false;
      const style = getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
      const rect = node.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0
        && rect.right > 0 && rect.bottom > 0
        && rect.left < innerWidth && rect.top < innerHeight;
    };
    const rectData = (node) => {
      if (!node) return null;
      const rect = node.getBoundingClientRect();
      return Object.fromEntries(['left', 'top', 'right', 'bottom', 'width', 'height'].map((key) => [key, Math.round(rect[key] * 100) / 100]));
    };
    const pageElement = element.querySelector('.va-page');
    const viewport = element.querySelector('.va-calendar-viewport');
    const calendarHead = element.querySelector('.va-calendar-head');
    const grid = element.querySelector('.va-calendar-grid');
    const viewportRect = viewport?.getBoundingClientRect();
    const staffHeads = [...element.querySelectorAll('.va-staff-head')].map((node) => {
      const rect = node.getBoundingClientRect();
      return {
        label: node.textContent?.trim() ?? '',
        visible: isVisible(node),
        horizontallyClipped: !viewportRect || rect.left < viewportRect.left - 2 || rect.right > viewportRect.right + 2,
        rect: rectData(node)
      };
    });
    const dateButton = element.querySelector('[data-open-date-picker]');
    const timeLabels = [...element.querySelectorAll('.va-time-label')];
    return {
      attributes: { ...dataAttributes(pageElement), ...dataAttributes(element) },
      documentCorePath: document.documentElement.dataset.gwCorePath ?? null,
      documentBeseelung: document.documentElement.dataset.gwBeseelung ?? null,
      headerDate: dateButton?.querySelector('span')?.textContent?.trim() ?? null,
      headerDateAriaLabel: dateButton?.getAttribute('aria-label') ?? null,
      nowLineVisible: isVisible(element.querySelector('.va-now-line')),
      visibleDayAnchors: ['08:00', '18:00'].filter((label) => timeLabels.some((node) => node.textContent?.trim() === label && isVisible(node))),
      visibleStaffHeadCount: staffHeads.filter(({ visible }) => visible).length,
      clippedStaffHeadLabels: staffHeads.filter(({ horizontallyClipped }) => horizontallyClipped).map(({ label }) => label),
      sticky: {
        calendarHead: calendarHead ? getComputedStyle(calendarHead).position : null,
        timeCorner: element.querySelector('.va-time-corner') ? getComputedStyle(element.querySelector('.va-time-corner')).position : null,
        timeRail: element.querySelector('.va-time-rail') ? getComputedStyle(element.querySelector('.va-time-rail')).position : null
      },
      geometry: {
        viewport: rectData(viewport),
        calendarHead: rectData(calendarHead),
        grid: rectData(grid),
        viewportScrollWidth: viewport?.scrollWidth ?? null,
        viewportScrollHeight: viewport?.scrollHeight ?? null
      }
    };
  });
}

async function waitForLayout(page, label, compact) {
  await page.waitForFunction(
    ({ diagnosticsVersion }) => {
      const root = document.querySelector('#dashboard-root');
      const state = root?.getAttribute('data-tp-layout-state');
      return root?.getAttribute('data-tp-render-state') === 'ready'
        && (state === 'stable' || state === 'invalid')
        && root.getAttribute('data-tp-diagnostics-version') === diagnosticsVersion;
    },
    { diagnosticsVersion: DIAGNOSTICS_VERSION },
    { timeout: HANDSHAKE_TIMEOUT_MS }
  );
  const state = await page.locator('#dashboard-root').getAttribute('data-tp-layout-state');
  if (state !== 'stable') {
    const failure = await page.locator('#dashboard-root').getAttribute('data-tp-layout-failure');
    throw new Error(`${label}: layout rejected as ${state} (${failure ?? 'no failure code'})`);
  }
  if (compact) {
    await page.waitForFunction(
      () => document.querySelector('#dashboard-root')?.getAttribute('data-calendar-initial-now-positioned') === '1',
      undefined,
      { timeout: HANDSHAKE_TIMEOUT_MS }
    );
  }
  await page.evaluate(() => new Promise((resolvePromise) => requestAnimationFrame(() => requestAnimationFrame(resolvePromise))));
}

function assertDesktop(snapshot, label) {
  for (const [name, expected] of [
    ['tp-render-state', 'ready'], ['tp-layout-state', 'stable'], ['va-layout-ready', '1'],
    ['calendar-desktop-fit', '1'], ['calendar-compact-projection', '0'], ['calendar-surface-clean', '1'],
    ['calendar-vertical-owner-count', '0'], ['calendar-primary-scroll-owner', 'none'], ['visible-staff-count', '5']
  ]) requireValue(snapshot, name, expected, label);
  for (const name of ['document-overflow-x', 'document-overflow-y', 'page-overflow-y', 'calendar-surface-overflow-x', 'calendar-surface-overflow-y']) {
    const value = attributeNumber(snapshot, name);
    if (!(value != null && value <= EPSILON)) errors.push(`${label}: ${name} must be <=${EPSILON}, received ${value}`);
  }
  const gap = attributeNumber(snapshot, 'calendar-grid-bottom-gap');
  if (!(gap != null && Math.abs(gap) <= EPSILON)) errors.push(`${label}: calendar-grid-bottom-gap must be <=${EPSILON}, received ${gap}`);
  const hourPixels = attributeNumber(snapshot, 'va-hour-pixels');
  if (!(hourPixels != null && hourPixels >= 44)) errors.push(`${label}: full-day fit below 44px/hour: ${hourPixels}`);
  const regime = attributeValue(snapshot, 'va-layout-regime');
  if (!['desktop-full', 'desktop-compact'].includes(regime)) errors.push(`${label}: unexpected desktop regime ${regime}`);
  if (snapshot.visibleStaffHeadCount !== 5) errors.push(`${label}: expected five visibly rendered staff heads, received ${snapshot.visibleStaffHeadCount}`);
  if (snapshot.clippedStaffHeadLabels.length) errors.push(`${label}: clipped staff heads: ${snapshot.clippedStaffHeadLabels.join(', ')}`);
  for (const anchor of ['08:00', '18:00']) if (!snapshot.visibleDayAnchors.includes(anchor)) errors.push(`${label}: day anchor ${anchor} is not visible`);
}

function assertCompact(snapshot, label) {
  for (const [name, expected] of [
    ['tp-render-state', 'ready'], ['tp-layout-state', 'stable'], ['va-layout-ready', '1'],
    ['calendar-compact-projection', '1'], ['calendar-surface-clean', '1'],
    ['calendar-vertical-owner-count', '1'], ['calendar-primary-scroll-owner', 'calendar-viewport'],
    ['calendar-initial-now-positioned', '1']
  ]) requireValue(snapshot, name, expected, label);
  for (const name of ['document-overflow-x', 'document-overflow-y', 'page-overflow-y']) {
    const value = attributeNumber(snapshot, name);
    if (!(value != null && value <= EPSILON)) errors.push(`${label}: ${name} must be <=${EPSILON}, received ${value}`);
  }
  if (!(attributeNumber(snapshot, 'calendar-surface-overflow-y') > EPSILON)) errors.push(`${label}: calendar viewport does not own vertical overflow`);
  const expectedRegime = snapshot.geometry?.viewport?.width > snapshot.geometry?.viewport?.height
    ? 'compact-landscape-scroll'
    : 'compact-portrait-scroll';
  if (attributeValue(snapshot, 'va-layout-regime') !== expectedRegime) {
    errors.push(`${label}: expected ${expectedRegime}, received ${attributeValue(snapshot, 'va-layout-regime')}`);
  }
  if (attributeValue(snapshot, 'mobile-horizontal-scroll-functional') !== '1' || !(attributeNumber(snapshot, 'mobile-horizontal-scroll-delta') > EPSILON)) {
    errors.push(`${label}: functional horizontal staff movement proof missing`);
  }
  for (const [name, value] of Object.entries(snapshot.sticky)) if (value !== 'sticky') errors.push(`${label}: ${name} must be computed sticky, received ${value}`);
}

if (!existsSync(referencePath)) errors.push(`Generated reference missing: ${referencePath}`);
if (!existsSync(experimentIndexPath)) errors.push(`Experiment index missing: ${experimentIndexPath}`);

let referenceSource = '';
let experimentSource = '';
if (!errors.length) {
  referenceSource = readFileSync(referencePath, 'utf8');
  experimentSource = readFileSync(experimentIndexPath, 'utf8');
  try {
    assertAutonomousDocument(referenceSource, 'Golden-Master-Browserquelle');
  } catch (error) {
    errors.push(error.message);
  }
  for (const [pattern, label] of [
    [/@import\b/i, 'remaining CSS @import'],
    [/<link\b[^>]*\brel=["']?stylesheet/i, 'external stylesheet link'],
    [/<script\b[^>]*\bsrc=/i, 'external script'],
    [/url\(["']?(?:https?:|\/\/|file:)/i, 'remote or absolute CSS resource']
  ]) if (pattern.test(referenceSource)) errors.push(`Generated reference is not autonomous: ${label}`);
  for (const [text, label] of [
    ['data-gw-core-path="surface-v1"', 'surface-v1 document identity'],
    ['data-gw-beseelung="disabled"', 'disabled experience layer'],
    ['/* experiments/tagesplan-vertical-agenda/surface-v1.css */', 'surface-v1 CSS source'],
    ['/* experiments/tagesplan-vertical-agenda/surface-v1.js */', 'surface-v1 JS source']
  ]) requireStatic(referenceSource, text, label);
  for (const [text, label] of [
    ['./surface-v1.css', 'experiment surface-v1 CSS'],
    ['./surface-v1.js', 'experiment surface-v1 JS'],
    ['data-gw-core-path="surface-v1"', 'experiment surface identity']
  ]) requireStatic(experimentSource, text, label);
  if (/tagesplan-v1\.(?:css|js)/i.test(experimentSource)) errors.push('Experiment still loads the removed legacy V1 path');
}

rmSync(outputDirectory, { recursive: true, force: true });
mkdirSync(outputDirectory, { recursive: true });

let browser;
if (!errors.length) {
  try {
    browser = await chromium.launch({ channel: 'chromium', headless: true });
    const baseUrl = pathToFileURL(referencePath).href;
    let baseline = null;

    for (const testCase of CASES) {
      const context = await browser.newContext({
        viewport: { width: testCase.width, height: testCase.height },
        deviceScaleFactor: 1,
        locale: 'de-CH',
        timezoneId: 'Europe/Zurich',
        serviceWorkers: 'block',
        hasTouch: Boolean(testCase.hasTouch)
      });
      const page = await context.newPage();
      const runtimeErrors = [];
      const unexpectedRequests = [];
      const targetUrl = `${baseUrl}?${testCase.parameters}`;
      const targetPath = new URL(targetUrl).pathname;
      page.on('pageerror', (error) => runtimeErrors.push(`pageerror: ${error.stack ?? error.message}`));
      page.on('console', (message) => { if (message.type() === 'error') runtimeErrors.push(`console.error: ${message.text()}`); });
      page.on('requestfailed', (request) => runtimeErrors.push(`requestfailed: ${request.url()} (${request.failure()?.errorText ?? 'unknown'})`));
      page.on('request', (request) => {
        const requestUrl = request.url();
        if (request.isNavigationRequest() && new URL(requestUrl).protocol === 'file:' && new URL(requestUrl).pathname === targetPath) return;
        if (!requestUrl.startsWith('data:') && !requestUrl.startsWith('blob:')) unexpectedRequests.push(requestUrl);
      });

      let snapshot = null;
      try {
        await page.goto(targetUrl, { waitUntil: 'load', timeout: 30_000 });
        await waitForLayout(page, testCase.name, testCase.kind === 'compact');
        snapshot = await readSnapshot(page);
        requireValue(snapshot, 'tp-diagnostics-version', DIAGNOSTICS_VERSION, testCase.name);
        requireValue(snapshot, 'gw-core-path', 'surface-v1', testCase.name);
        requireValue(snapshot, 'gw-beseelung', 'disabled', testCase.name);
        if (snapshot.documentCorePath !== 'surface-v1' || snapshot.documentBeseelung !== 'disabled') {
          errors.push(`${testCase.name}: document core identity mismatch`);
        }

        if (testCase.kind === 'compact') assertCompact(snapshot, testCase.name);
        else assertDesktop(snapshot, testCase.name);

        if (testCase.name === 'golden-desktop-1512x982') baseline = snapshot;
        if (testCase.kind === 'agenda') {
          requireValue(snapshot, 'visible-agenda-panels', '1', testCase.name);
          assertGeometryParity(snapshot, baseline, testCase.name);
        }
        if (testCase.kind === 'focus') {
          requireValue(snapshot, 'focus-context-count', '4', testCase.name);
          assertGeometryParity(snapshot, baseline, testCase.name);
        }
        if (testCase.kind === 'date') {
          const expected = 'Montag, 24. August';
          if (snapshot.headerDate !== expected || snapshot.headerDateAriaLabel !== `${expected} wählen`) {
            errors.push(`${testCase.name}: visible/reference date semantics mismatch (${snapshot.headerDate}; ${snapshot.headerDateAriaLabel})`);
          }
          if (!snapshot.nowLineVisible) errors.push(`${testCase.name}: reference date is not treated as current salon day`);
        }
      } catch (error) {
        errors.push(`${testCase.name}: ${error.message}`);
      } finally {
        for (const error of [...new Set(runtimeErrors)]) errors.push(`${testCase.name}: ${error}`);
        for (const request of [...new Set(unexpectedRequests)]) errors.push(`${testCase.name}: non-autonomous runtime request ${request}`);
        try { writeFileSync(resolve(outputDirectory, `${testCase.name}.html`), await page.content()); } catch (error) { errors.push(`${testCase.name}: DOM evidence failed: ${error.message}`); }
        try { await page.screenshot({ path: resolve(outputDirectory, `${testCase.name}.png`) }); } catch (error) { errors.push(`${testCase.name}: screenshot failed: ${error.message}`); }
        evidence.push({ name: testCase.name, kind: testCase.kind, viewport: { width: testCase.width, height: testCase.height, hasTouch: Boolean(testCase.hasTouch) }, snapshot, runtimeErrors, unexpectedRequests });
        await context.close();
      }
    }
  } catch (error) {
    errors.push(error.message);
  } finally {
    if (browser) await browser.close();
  }
}

writeFileSync(resolve(outputDirectory, 'matrix.json'), `${JSON.stringify(evidence, null, 2)}\n`);

if (errors.length) {
  console.error(`Tagesplan-v1 Golden-Master Chromium verification failed (${errors.length}):`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`✓ Generated Tagesplan v1 core verified autonomously via file:// in pinned Playwright Chromium (${CASES.length} cases, surface-v1 parity).`);