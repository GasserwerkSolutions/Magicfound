import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const root = process.cwd();
const outputDirectory = resolve(root, 'artifacts/tagesplan-v1-surface');
const profileDirectory = mkdtempSync(resolve(tmpdir(), 'gasserwerk-tagesplan-v1-'));
const port = 4177;
const baseUrl = `http://127.0.0.1:${port}/experiments/tagesplan-vertical-agenda/`;
const referenceUrl = `${baseUrl}?referenceNow=11:22`;
const errors = [];

const DESKTOP_CASES = Object.freeze([
  { name: '1366x768', width: 1366, height: 768 },
  { name: '1440x810', width: 1440, height: 810 },
  { name: '1440x900', width: 1440, height: 900 },
  { name: '1512x982', width: 1512, height: 982 },
  { name: '1600x900', width: 1600, height: 900 },
  { name: '1920x1080', width: 1920, height: 1080 },
  { name: '1024x768', width: 1024, height: 768 },
  { name: '1512x982-z90', width: 1680, height: 1091 },
  { name: '1512x982-z110', width: 1375, height: 893 },
  { name: '1512x982-z125', width: 1210, height: 786 },
  { name: '1366x768-z110', width: 1242, height: 698 },
  { name: '1366x768-z125', width: 1093, height: 614 }
]);

const COMPACT_CASES = Object.freeze([
  { name: '390x844', width: 390, height: 844, orientation: 'portrait' },
  { name: '430x932', width: 430, height: 932, orientation: 'portrait' },
  { name: '844x390', width: 844, height: 390, orientation: 'landscape' }
]);

function findChrome() {
  for (const candidate of [process.env.CHROME_BIN, 'google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser'].filter(Boolean)) {
    const probe = spawnSync('bash', ['-lc', `command -v ${candidate}`], { encoding: 'utf8' });
    if (probe.status === 0 && probe.stdout.trim()) return probe.stdout.trim();
  }
  return null;
}

function chromeRun(chrome, label, args, virtualTimeBudget = 4200) {
  const started = Date.now();
  console.log(`→ ${label}`);
  const result = spawnSync('timeout', [
    '--signal=TERM', '--kill-after=3s', '45s', chrome,
    '--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage',
    '--disable-background-networking', '--disable-background-timer-throttling', '--disable-component-update',
    '--disable-default-apps', '--disable-extensions', '--disable-sync',
    '--disable-features=MediaRouter,OptimizationHints,Translate', '--no-first-run', '--no-default-browser-check',
    '--hide-scrollbars', '--run-all-compositor-stages-before-draw', `--user-data-dir=${profileDirectory}`,
    `--virtual-time-budget=${virtualTimeBudget}`, ...args
  ], { cwd: root, encoding: 'utf8', maxBuffer: 50 * 1024 * 1024 });
  console.log(`← ${label}: status=${result.status} ${Date.now() - started}ms`);
  if ([124, 137, 143].includes(result.status)) throw new Error(`${label}: Chrome timed out after 45 seconds`);
  if (result.error) throw result.error;
  return result;
}

async function waitForServer() {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    try { const response = await fetch(referenceUrl); if (response.ok) return; } catch {}
    await delay(100);
  }
  throw new Error(`Local reference server did not answer: ${referenceUrl}`);
}

const datasetValue = (dom, name) => dom.match(new RegExp(`data-${name}="([^"]*)"`))?.[1] ?? null;
const datasetNumber = (dom, name) => { const value = datasetValue(dom, name); return value == null || value === '' ? null : Number(value); };
function requireValue(dom, name, expected, label) {
  const value = datasetValue(dom, name);
  if (value !== String(expected)) errors.push(`${label}: data-${name} expected ${expected}, received ${value}`);
}

function dumpDom(chrome, testCase, url = referenceUrl) {
  const result = chromeRun(chrome, `DOM ${testCase.name}`, [`--window-size=${testCase.width},${testCase.height}`, '--dump-dom', url]);
  if (result.status !== 0) { errors.push(`${testCase.name}: DOM render failed: ${result.stderr.trim()}`); return ''; }
  writeFileSync(resolve(outputDirectory, `${testCase.name}.html`), result.stdout);
  return result.stdout;
}

function screenshot(chrome, testCase, url = referenceUrl) {
  const target = resolve(outputDirectory, `${testCase.name}.png`);
  const result = chromeRun(chrome, `Screenshot ${testCase.name}`, [`--window-size=${testCase.width},${testCase.height}`, `--screenshot=${target}`, url]);
  if (result.status !== 0 || !existsSync(target)) errors.push(`${testCase.name}: screenshot failed: ${result.stderr.trim()}`);
}

function assertDesktop(dom, testCase) {
  requireValue(dom, 'va-layout-ready', '1', testCase.name);
  requireValue(dom, 'calendar-desktop-fit', '1', testCase.name);
  requireValue(dom, 'calendar-compact-projection', '0', testCase.name);
  requireValue(dom, 'calendar-surface-clean', '1', testCase.name);
  requireValue(dom, 'calendar-vertical-owner-count', '0', testCase.name);
  requireValue(dom, 'calendar-primary-scroll-owner', 'none', testCase.name);
  for (const attribute of ['document-overflow-x', 'document-overflow-y', 'page-overflow-y', 'calendar-surface-overflow-y']) {
    const value = datasetNumber(dom, attribute);
    if (!(value != null && value <= 2)) errors.push(`${testCase.name}: ${attribute} must be <=2, received ${value}`);
  }
  const gap = datasetNumber(dom, 'calendar-grid-bottom-gap');
  if (!(gap != null && Math.abs(gap) <= 2)) errors.push(`${testCase.name}: grid bottom gap must be <=2px, received ${gap}`);
  const hourPixels = datasetNumber(dom, 'va-hour-pixels');
  if (!(hourPixels != null && hourPixels >= 44)) errors.push(`${testCase.name}: full-day fit below 44px/hour: ${hourPixels}`);
  const regime = datasetValue(dom, 'va-layout-regime');
  if (!['desktop-full', 'desktop-compact'].includes(regime)) errors.push(`${testCase.name}: unexpected desktop regime ${regime}`);
}

function assertCompact(dom, testCase) {
  requireValue(dom, 'va-layout-ready', '1', testCase.name);
  requireValue(dom, 'calendar-compact-projection', '1', testCase.name);
  requireValue(dom, 'calendar-surface-clean', '1', testCase.name);
  requireValue(dom, 'calendar-vertical-owner-count', '1', testCase.name);
  requireValue(dom, 'calendar-primary-scroll-owner', 'calendar-viewport', testCase.name);
  for (const attribute of ['document-overflow-x', 'document-overflow-y', 'page-overflow-y']) {
    const value = datasetNumber(dom, attribute);
    if (!(value != null && value <= 2)) errors.push(`${testCase.name}: ${attribute} must be <=2, received ${value}`);
  }
  const overflowY = datasetNumber(dom, 'calendar-surface-overflow-y');
  if (!(overflowY != null && overflowY > 2)) errors.push(`${testCase.name}: calendar must own vertical overflow, received ${overflowY}`);
  const expectedRegime = testCase.orientation === 'portrait' ? 'compact-portrait-scroll' : 'compact-landscape-scroll';
  if (datasetValue(dom, 'va-layout-regime') !== expectedRegime) errors.push(`${testCase.name}: expected ${expectedRegime}, received ${datasetValue(dom, 'va-layout-regime')}`);
  if (testCase.orientation === 'portrait') {
    const overflowX = datasetNumber(dom, 'calendar-surface-overflow-x');
    if (!(overflowX != null && overflowX > 2)) errors.push(`${testCase.name}: staff columns must move horizontally, received ${overflowX}`);
  }
}

rmSync(outputDirectory, { recursive: true, force: true });
mkdirSync(outputDirectory, { recursive: true });
const server = spawn('python3', ['-m', 'http.server', String(port), '--bind', '127.0.0.1'], { cwd: root, stdio: 'ignore' });

try {
  await waitForServer();
  const chrome = findChrome();
  if (!chrome) throw new Error('No Chrome/Chromium binary found');
  const warmup = chromeRun(chrome, 'Chrome warm-up', ['--dump-dom', 'about:blank'], 800);
  if (warmup.status !== 0) throw new Error(`Chrome warm-up failed: ${warmup.stderr.trim()}`);

  for (const testCase of DESKTOP_CASES) {
    const dom = dumpDom(chrome, testCase);
    if (dom) assertDesktop(dom, testCase);
    screenshot(chrome, testCase);
  }
  for (const testCase of COMPACT_CASES) {
    const url = testCase.orientation === 'portrait' ? `${referenceUrl}&verifyStaffScroll=1` : `${referenceUrl}&agenda=open`;
    const dom = dumpDom(chrome, testCase, url);
    if (dom) assertCompact(dom, testCase);
    screenshot(chrome, testCase, url);
  }

  const agendaCase = { name: '1512x982-agenda-open', width: 1512, height: 982 };
  const agendaDom = dumpDom(chrome, agendaCase, `${referenceUrl}&agenda=open`);
  if (agendaDom) {
    requireValue(agendaDom, 'calendar-surface-clean', '1', agendaCase.name);
    requireValue(agendaDom, 'calendar-vertical-owner-count', '0', agendaCase.name);
    requireValue(agendaDom, 'visible-agenda-panels', '1', agendaCase.name);
  }
  screenshot(chrome, agendaCase, `${referenceUrl}&agenda=open`);

  const focusCase = { name: '1512x982-focus', width: 1512, height: 982 };
  const focusDom = dumpDom(chrome, focusCase, `${referenceUrl}&focus=melanie&verify=1`);
  if (focusDom) {
    requireValue(focusDom, 'calendar-surface-clean', '1', focusCase.name);
    requireValue(focusDom, 'visible-staff-count', '5', focusCase.name);
    if (datasetNumber(focusDom, 'focus-context-count') !== 4) errors.push(`${focusCase.name}: expected four context lanes`);
  }
  screenshot(chrome, focusCase, `${referenceUrl}&focus=melanie&verify=1`);
} catch (error) {
  errors.push(error.message);
} finally {
  server.kill('SIGTERM');
  rmSync(profileDirectory, { recursive: true, force: true });
}

if (errors.length) {
  console.error(`Tagesplan v1 surface verification failed (${errors.length}):`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`✓ Tagesplan v1 surface matrix verified (${DESKTOP_CASES.length} desktop/zoom cases, ${COMPACT_CASES.length} compact cases)`);
