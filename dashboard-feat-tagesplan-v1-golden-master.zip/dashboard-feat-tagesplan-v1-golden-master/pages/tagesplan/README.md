# Modulare Referenzseite · Tagesplan

Direkter GitHub-Pages-Pfad:

```text
/dashboard/pages/tagesplan/
```

Diese Seite ist die erste eigenständig ausführbare Referenzseite der modularen Dashboard-Architektur. Sie verwendet keine produktiven Backend-Endpunkte und persistiert keine Änderung.

## Enthaltene Zustände

- operative Teamarbeitsfläche mit horizontaler Zeit
- sticky Teamspalte
- gemeinsamer Scrollzustand für Zeitkopf, Raster, Termine, Aufgaben und Jetzt-Linie
- 15-/30-/60-Minuten-Raster
- 240-Minuten-Desktopausschnitt mit 45 Minuten Vergangenheit und 195 Minuten Zukunft
- Live-Follow am exakten 18,75-%-Desktop- beziehungsweise 22-%-Mobilanker
- kompakte, nicht künstlich gestreckte Personenzeilen
- Zeilen wachsen nur bei realen Überschneidungen um zusätzliche Bahnen
- sofortige Entkopplung bei manueller Kalenderinteraktion
- richtungsabhängige Jetzt-Rückkehr
- kontrollierte automatische Rückkehr nach 25 Sekunden echter Inaktivität
- Ganztagesmassstab
- vertikaler Personenfokus
- Datumsauswahl
- Termin- und Buchungskontextflächen
- Suche
- 14-Zoll-Dichte und mobile Anordnung

## Daten und Events

Die Seite konsumiert:

```text
src/data/mock-dashboard-data-source-v1.js
```

Der Adapter implementiert die gemeinsame `DashboardDataSource`. Die Seite meldet fachliche Absichten als `gasserwerk:event` und verwendet den kanonischen Eventkatalog unter `src/data/contracts/events.js`.

## Keine simulierte Persistenz

- Termin eintragen löst nur `appointment:create-requested` aus.
- Bearbeiten löst nur `appointment:edit-requested` aus.
- Datum, Massstab, Personenfokus und Live-Follow sind lokale Referenzzustände.
- Konfliktprüfung, Speichern und Statusübergänge bleiben Verantwortung der späteren Produktionsintegration.

## Prüfung

```bash
node scripts/verify-modular-tagesplan.mjs
```

Der Vertrag bleibt in `CONTRACT.md`. Der Status wechselt erst nach visueller und interaktiver Browserabnahme auf `Implementiert`.
