# Gasserwerk Dashboard · semantischer Vertragsdurchgang

Status: **abgeschlossen · bereit zur fachlichen Freigabe**  
Stand: 2026-08-24

## 1. Ergebnis

Die gemeinsame Vertragsgrundlage und alle acht Seitenverträge wurden auf Begriffe, Zuständigkeiten, Datenquellen, Events, Capabilities, Seitenzustände und offene Fragen abgeglichen.

Ergebnis:

- Es existiert **kein offener Punkt der Klasse B**, der die Referenzimplementierung blockiert.
- Alle verbleibenden Fragen sind integrationsrelevant (`I`) oder spätere Verfeinerung (`V`).
- Die Referenz darf deshalb modular implementiert werden, ohne Backendentscheidungen vorwegzunehmen.
- Die Verträge wechseln von `Entwurf` zu `Zur Freigabe`; `Verbindlich` wird erst nach fachlicher Abnahme gesetzt.

## 2. Verbindliche Wahrheitsreihenfolge

Bei Widersprüchen gilt ab jetzt:

1. akzeptierte Produktentscheidungen in `docs/PRODUCT_SURFACE_V1.md`
2. gemeinsamer Vertrag in `docs/contracts/README.md`
3. jeweiliger Seitenvertrag unter `pages/*/CONTRACT.md`
4. modulare Referenzimplementierung unter `pages/` und `src/`
5. bestehende Gesamtvorschau in `index.html` und `404.html`
6. technische Implementierungsdetails

`index.html` und `404.html` bleiben während der Migration ausführbare Vergleichs- und Releaseartefakte. Sie sind nicht mehr die primäre Bearbeitungsquelle neuer Seiten.

## 3. Seitenverantwortung

| Seite | Besitzt | Besitzt ausdrücklich nicht |
|---|---|---|
| Login | Eintritt, verfügbare Authmethoden, Anmeldeabsichten | Session- oder Credentialimplementierung |
| Onboarding | Weg zum minimal buchbaren Salon, Readinessdarstellung | Backendvalidierung oder endgültige Pflicht-/Skip-Regeln |
| Tagesplan | Datum, operative Zeitfläche, Live-Follow, Ganztagesmassstab, Personenfokus, freie Zeit | Terminregister, Kasse oder Drag-and-drop in V1 |
| Termine | Suche, Filter, Register, Öffnen des gemeinsamen Terminpanels | zweite Zeitachse oder eigener Tagesplan |
| Kundschaft | Liste, Kundenkartei als Detailzustand, Termin aus Kundenkontext | eigene Navigationsroute pro Kartei oder CRM-Automation |
| Team | fachliche Salonpersonen, Arbeitszeit-/Zuordnungsübersicht | Produktrollen- und Rechteverwaltung |
| Angebot | Dienstleistungen, Dauer, Preisstatus, Teamzuordnung | vollständige Buchbarkeitsentscheidung oder Abrechnung |
| Verwaltung | Salon-, Konto-, Integrations-, Access-, Billing- und Produktpräferenzbereiche | operative Salonaktionen |

## 4. Gemeinsame Komponentenverantwortung

Folgende Flächen werden einmal in `src/` implementiert und von Seiten konfiguriert:

- Produktschale
- Desktop-Sidebar
- mobile Navigation
- Produktkopf
- Suche
- Datumsauswahl
- Kontextpanel beziehungsweise mobiles Sheet
- Statusdarstellung
- Lade-, Leer-, Fehler-, Offline-, Stale- und Forbidden-Grundmuster
- Fokuswiederherstellung und Live-Region

Eine Seite darf diese Komponenten konfigurieren, aber nicht lokal kopieren oder visuell neu definieren.

## 5. Datenquellenverantwortung

| Methode | Primärer Konsument | Hinweis |
|---|---|---|
| `getSessionContext()` | Produktschale und alle Seiten | liefert Locale, Währung, Salonkontext und Capabilities |
| `getAuthenticationOptions()` | Login | keine Authmethode wird von der UI erfunden |
| `getOnboardingState()` | Onboarding | Readiness kommt vom Adapter |
| `getDayPlan()` | Tagesplan | autoritative Tageswahrheit für Team, Termine und operative Blöcke |
| `listAppointments()` | Termine | Registerquery, keine Zeitflächengeometrie |
| `getAppointment()` | gemeinsames Terminpanel | von Tagesplan und Register aus nutzbar |
| `listCustomers()` / `getCustomer()` | Kundschaft | Detail bleibt Zustand derselben Seite |
| `listStaff()` / `getStaffMember()` | Team | Tagesplan erhält seine Staff-Sicht über `getDayPlan()` |
| `listServices()` / `getService()` | Angebot | Buchbarkeit wird nicht allein daraus abgeleitet |
| `getAdministrationSettings()` | Verwaltung und Onboardingzusammenfassung | Bereiche bleiben normalisiert und capabilitybasiert |

Seiten kennen keine API-URL, HTTP-Methode, Datenbanktabelle, Authentifizierungstoken oder Framework-Store.

## 6. Eventverantwortung

- `shell:*` wird ausschliesslich von der gemeinsamen Produktschale emittiert.
- `search:*` gehört zur gemeinsamen Suchkomponente.
- `day:*` gehört ausschliesslich zum Tagesplan.
- `day:staff-focus-*` beschreibt den räumlichen Fokus im Tagesplan und ist nicht dasselbe wie `staff:selected` auf der Teamseite.
- `appointment:*` beschreibt Terminabsichten aus Tagesplan, Register oder gemeinsamem Terminpanel; `source` unterscheidet den Ursprung.
- `customer:*`, `staff:*`, `service:*`, `administration:*`, `auth:*` und `onboarding:*` gehören zu ihren jeweiligen fachlichen Seiten.
- `appointment:move-requested`, `appointment:resize-requested` und `appointment:undo-requested` bleiben bis Phase 3 reserviert.

Ein Event meldet eine fachliche Absicht. Erfolg, Persistenz und Konfliktentscheidung werden erst durch die Produktionsintegration bestätigt.

## 7. Geklärte semantische Grenzfälle

### Heute und Jetzt

- `Heute` setzt das Datum.
- `Jetzt` positioniert die aktuelle Uhrzeit.
- `Heute` ist keine eigene Seite.

### Termin und operativer Block

- Kundentermine verwenden `AppointmentSummary`.
- Aufgabe, Pause, Abwesenheit und Konflikt verwenden `OperationalBlock`.
- Operative Blöcke dürfen nicht als Kundentermine serialisiert oder über `appointment:selected` geöffnet werden.

### Teamrolle und Produktrolle

- `professionalRoleLabel` beschreibt die Tätigkeit im Salon.
- `productRoleLabel` beziehungsweise Capabilities beschreiben den Produktzugriff.
- Beide Werte dürfen weder im Adapter noch in der UI voneinander abgeleitet werden.

### Kundenkartei

- Die Liste ist der Eintrittszustand.
- Die Kartei ist ein Detailzustand derselben Seite.
- Desktop darf Liste und Detail gleichzeitig zeigen; Mobil zeigt jeweils eine vollständige Fläche.

### Tagesplanmassstäbe

- Arbeitsfläche, Ganztagesmassstab und Personenfokus sind räumliche Zustände einer Seite.
- Datum, Auswahl, Personenbezug, Zeitkontext und offenes Panel bleiben beim Wechsel erhalten.

### Referenzzeit

- Fixtures dürfen eine kontrollierbare Uhr liefern.
- Eine historische Fixture-Zeit darf nicht als reale Systemzeit ausgegeben werden.
- Die Produktionsintegration liefert Salonzeitzone und autoritative Zeitquelle.

## 8. Offene Fragen

Der Fragenkatalog enthält aktuell ausschliesslich:

- Klasse `I`: blockiert erst Produktionsintegration
- Klasse `V`: spätere Verfeinerung

Es existiert derzeit keine Frage der Klasse `B`.

Neue Fragen der Klasse `B` setzen den betroffenen Seitenvertrag automatisch zurück auf `Entwurf` und blockieren dessen Implementierung, bis die Frage entschieden oder korrekt umklassifiziert ist.

## 9. Freigabestatus

Alle acht Seitenverträge erfüllen die Voraussetzungen für `Zur Freigabe`:

- 13 Pflichtabschnitte vorhanden
- Datenfelder erforderlich, optional oder offen eingeordnet
- Events und Payloads beschrieben
- Lade-, Leer-, Fehler-, Offline-, Stale- und Berechtigungszustände vorhanden
- Desktop-, Mobil-, Tastatur- und Fokusverhalten beschrieben
- offene Fragen referenziert
- keine stillschweigende Backend- oder Frameworkannahme

`Zur Freigabe` bedeutet nicht, dass Backendfragen entschieden sind. Es bedeutet, dass die Referenzimplementierung ohne erfundene Backendwahrheit beginnen kann.

## 10. Nächste Implementierungsreihenfolge

1. gemeinsame Tokens, Dichte und Grundreset
2. Datums-, Zeit-, DOM- und Fokusutilities
3. Produktschale, Navigation und Produktkopf
4. gemeinsame Suche, Datumsauswahl und Kontextfläche
5. Mock-Datenquelle und normalisierte Fixtures
6. `pages/tagesplan/` als erste direkt aufrufbare Seite
7. Kundschaft und Termine
8. Team, Angebot und Verwaltung
9. Login und Onboarding
10. Screenshot- und Interaktionsregression

`main`, `index.html` und `404.html` bleiben geschützt, bis der modulare Tagesplan direkt aufrufbar, funktional geprüft und visuell abgenommen ist.
