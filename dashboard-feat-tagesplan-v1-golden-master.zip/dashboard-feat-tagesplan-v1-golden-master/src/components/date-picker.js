import { DashboardEvent } from '../data/contracts/events.js';
import {
  addDays,
  formatIsoDate,
  isIsoDate,
  parseIsoDate,
  todayInTimeZone
} from '../lib/dates.js';
import { createElement, replaceChildren } from '../lib/dom.js';
import { dispatchDashboardEvent } from '../lib/dashboard-events.js';
import { createButton } from './button.js';

const WEEKDAY_LABELS = Object.freeze(['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So']);

function monthStart(value) {
  const { year, month } = parseIsoDate(value);
  return formatIsoDate({ year, month, day: 1 });
}

function shiftMonth(value, amount) {
  const { year, month, day } = parseIsoDate(value);
  const target = new Date(Date.UTC(year, month - 1 + amount, 1, 12));
  const maximumDay = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0, 12)).getUTCDate();
  return formatIsoDate({
    year: target.getUTCFullYear(),
    month: target.getUTCMonth() + 1,
    day: Math.min(day, maximumDay)
  });
}

function mondayOffset(value) {
  const { year, month, day } = parseIsoDate(value);
  const weekday = new Date(Date.UTC(year, month - 1, day, 12)).getUTCDay();
  return (weekday + 6) % 7;
}

function formatMonthLabel(value, locale) {
  const { year, month } = parseIsoDate(value);
  return new Intl.DateTimeFormat(locale, {
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC'
  }).format(new Date(Date.UTC(year, month - 1, 1, 12)));
}

function formatAccessibleDate(value, locale) {
  const { year, month, day } = parseIsoDate(value);
  return new Intl.DateTimeFormat(locale, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC'
  }).format(new Date(Date.UTC(year, month - 1, day, 12)));
}

export function createDatePicker(options = {}) {
  const {
    id = 'date-picker',
    selectedDate: initialSelectedDate,
    todayDate: initialTodayDate = null,
    locale = 'de-CH',
    timeZone = 'Europe/Zurich',
    source = 'date-picker',
    onSelect = null,
    onClose = null
  } = options;

  if (!isIsoDate(initialSelectedDate)) {
    throw new TypeError('selectedDate must use YYYY-MM-DD');
  }

  let selectedDate = initialSelectedDate;
  let focusDate = initialSelectedDate;
  let visibleMonth = monthStart(initialSelectedDate);
  let todayDate = initialTodayDate ?? todayInTimeZone(timeZone);

  const monthHeading = createElement('strong', {
    className: 'gw-date-picker__month-label',
    attributes: { id: `${id}-month` }
  });
  const grid = createElement('div', {
    className: 'gw-date-picker__grid',
    attributes: {
      role: 'grid',
      'aria-labelledby': `${id}-month`
    }
  });
  const previousButton = createButton({
    label: 'Vorheriger Monat',
    icon: 'back',
    compact: true,
    iconOnly: true,
    attributes: { 'aria-label': 'Vorheriger Monat' }
  });
  const nextButton = createButton({
    label: 'Nächster Monat',
    icon: 'next',
    compact: true,
    iconOnly: true,
    attributes: { 'aria-label': 'Nächster Monat' }
  });
  const closeButton = createButton({
    label: 'Kalender schliessen',
    icon: 'close',
    compact: true,
    iconOnly: true,
    attributes: { 'aria-label': 'Kalender schliessen' }
  });
  const todayButton = createButton({
    label: 'Heute',
    compact: true,
    variant: 'ghost'
  });
  const footer = createElement('footer', {
    className: 'gw-date-picker__footer',
    children: todayButton
  });

  const element = createElement('section', {
    className: 'gw-date-picker',
    attributes: {
      id,
      role: 'dialog',
      'aria-modal': 'true',
      'aria-labelledby': `${id}-month`,
      'data-event-source': source
    },
    children: [
      createElement('header', {
        className: 'gw-date-picker__header',
        children: [previousButton, monthHeading, nextButton, closeButton]
      }),
      createElement('div', {
        className: 'gw-date-picker__weekdays',
        attributes: { 'aria-hidden': 'true' },
        children: WEEKDAY_LABELS.map((label) => createElement('span', { text: label }))
      }),
      grid,
      footer
    ]
  });

  function selectDate(date, origin) {
    const detail = dispatchDashboardEvent(element, DashboardEvent.DAY_DATE_CHANGE_REQUESTED, {
      date
    }, { source });
    if (typeof onSelect === 'function') onSelect({ date, origin, event: detail });
  }

  function focusRenderedDate(date) {
    const schedule = globalThis.requestAnimationFrame ?? ((callback) => setTimeout(callback, 0));
    schedule(() => {
      grid.querySelector(`[data-date="${date}"]`)?.focus({ preventScroll: true });
    });
  }

  function render() {
    monthHeading.textContent = formatMonthLabel(visibleMonth, locale);
    const start = addDays(visibleMonth, -mondayOffset(visibleMonth));
    const visibleMonthNumber = parseIsoDate(visibleMonth).month;
    const cells = Array.from({ length: 42 }, (_, index) => {
      const date = addDays(start, index);
      const outside = parseIsoDate(date).month !== visibleMonthNumber;
      const selected = date === selectedDate;
      const today = date === todayDate;
      const focused = date === focusDate;
      return createElement('button', {
        className: [
          'gw-date-picker__day',
          outside ? 'is-outside' : '',
          selected ? 'is-selected' : '',
          today ? 'is-today' : ''
        ].filter(Boolean).join(' '),
        attributes: {
          type: 'button',
          role: 'gridcell',
          tabindex: focused ? '0' : '-1',
          'data-date': date,
          'aria-selected': selected ? 'true' : 'false',
          'aria-current': today ? 'date' : null,
          'aria-label': `${formatAccessibleDate(date, locale)}${today ? ', heute' : ''}`
        },
        text: parseIsoDate(date).day,
        on: {
          click: (event) => selectDate(date, event.currentTarget)
        }
      });
    });
    replaceChildren(grid, cells);
    footer.hidden = selectedDate === todayDate;
  }

  function moveFocus(date) {
    focusDate = date;
    const nextMonth = monthStart(date);
    if (nextMonth !== visibleMonth) visibleMonth = nextMonth;
    render();
    focusRenderedDate(date);
  }

  previousButton.addEventListener('click', () => {
    focusDate = shiftMonth(focusDate, -1);
    visibleMonth = monthStart(focusDate);
    render();
    focusRenderedDate(focusDate);
  });
  nextButton.addEventListener('click', () => {
    focusDate = shiftMonth(focusDate, 1);
    visibleMonth = monthStart(focusDate);
    render();
    focusRenderedDate(focusDate);
  });
  closeButton.addEventListener('click', () => onClose?.({ reason: 'button' }));
  todayButton.addEventListener('click', () => selectDate(todayDate, todayButton));

  grid.addEventListener('keydown', (event) => {
    const activeDate = event.target?.dataset?.date;
    if (!activeDate) return;
    let nextDate = null;
    if (event.key === 'ArrowLeft') nextDate = addDays(activeDate, -1);
    if (event.key === 'ArrowRight') nextDate = addDays(activeDate, 1);
    if (event.key === 'ArrowUp') nextDate = addDays(activeDate, -7);
    if (event.key === 'ArrowDown') nextDate = addDays(activeDate, 7);
    if (event.key === 'Home') nextDate = addDays(activeDate, -mondayOffset(activeDate));
    if (event.key === 'End') nextDate = addDays(activeDate, 6 - mondayOffset(activeDate));
    if (event.key === 'PageUp') nextDate = shiftMonth(activeDate, event.shiftKey ? -12 : -1);
    if (event.key === 'PageDown') nextDate = shiftMonth(activeDate, event.shiftKey ? 12 : 1);
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      selectDate(activeDate, event.target);
      return;
    }
    if (event.key === 'Escape') {
      event.preventDefault();
      onClose?.({ reason: 'escape' });
      return;
    }
    if (nextDate) {
      event.preventDefault();
      moveFocus(nextDate);
    }
  });

  render();

  return Object.freeze({
    element,
    grid,
    setSelectedDate(date) {
      if (!isIsoDate(date)) throw new TypeError('selectedDate must use YYYY-MM-DD');
      selectedDate = date;
      focusDate = date;
      visibleMonth = monthStart(date);
      render();
    },
    setTodayDate(date) {
      if (!isIsoDate(date)) throw new TypeError('todayDate must use YYYY-MM-DD');
      todayDate = date;
      render();
    },
    showMonth(date) {
      if (!isIsoDate(date)) throw new TypeError('month date must use YYYY-MM-DD');
      focusDate = date;
      visibleMonth = monthStart(date);
      render();
    },
    focusSelected() {
      focusDate = selectedDate;
      visibleMonth = monthStart(selectedDate);
      render();
      focusRenderedDate(selectedDate);
    },
    get selectedDate() {
      return selectedDate;
    },
    get visibleMonth() {
      return visibleMonth;
    }
  });
}
