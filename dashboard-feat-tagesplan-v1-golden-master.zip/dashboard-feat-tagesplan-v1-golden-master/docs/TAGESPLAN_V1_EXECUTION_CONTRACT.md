# Gasserwerk · Tagesplan v1.0 · Ausführungsvertrag

Status: **Aktiv – technischer Freeze Candidate**  
Branch: `feat/tagesplan-v1-golden-master`  
Grundlage: [`WIRKUNGSSYSTEM_V1.md`](./WIRKUNGSSYSTEM_V1.md), [`TAGESPLAN_V1_FREEZE_POLICY.md`](./TAGESPLAN_V1_FREEZE_POLICY.md), [`ADR-004`](./decisions/ADR-004-vertical-day-agenda.md), [`ADR-005`](./decisions/ADR-005-collapsible-header-agenda.md), [`ADR-007`](./decisions/ADR-007-tagesplan-v1-golden-master.md), [`ADR-008`](./decisions/ADR-008-technical-freeze-before-beseelung.md)

## 1. Unveränderliche Produktaufgabe

Der Tagesplan beantwortet innerhalb weniger Sekunden:

> **Was geschieht jetzt, bei wem und was kommt unmittelbar danach?**

Er ist eine operative Salonfläche und kein Analyse-Dashboard, kein Terminregister und keine dekorative Übersicht.

## 2. Verbindliches Wirkungsprofil

Das Wirkungsprofil ist bereits fachlich definiert, wird im technischen Core Freeze aber noch nicht als experimentelle Beseelungsschicht aktiviert.

### Primär

```text
gegenwärtig · atmend · im Fluss
```

### Unterstützend

```text
aufmerksam · beseelt
```

### Unerwünscht

```text
dekorativ · nervös · dashboardhaft
```

Die spätere Wirkung darf nur über Raumrhythmus, Materialtiefe, Bewegungstempo, Aufmerksamkeitsstärke und Illustrationspräsenz gesteuert werden. Statusfarbe, Fokussemantik, Suche, Warnstärke und Datenbedeutung bleiben fachlich autoritativ.

## 3. Verbindliche Reihenfolge

```text
Gate A  Geometrie
Gate B  Funktion und Zustände
Gate C  Accessibility und Resilienz
Gate D  deterministischer Single-HTML-Build
Gate E  Core-Freeze-Abnahme und unveränderlicher Tag
Gate F  Beseelungsexperimente
Gate G  Erfahrungsfreigabe und Integrationsparität
```

Beseelung beginnt erst nach dem finalen Core-Freeze-Tag.

## 4. Nicht zulässig

- konkurrierende Ansichtsentscheidungen;
- doppelte Zeitinformationen ohne operative Funktion;
- permanente Nebenflächen ohne laufenden Nutzen;
- Panel-in-Panel-Geometrie;
- stille Inhaltsverluste;
- zufällige Ellipsen;
- mehr als ein primärer vertikaler Scrollcontainer;
- Desktop-Scroll, solange der vollständige Arbeitstag mit mindestens 44 Pixel pro Stunde lesbar passt;
- experimentelle Material-, Bewegungs- oder Illustrationsschichten vor dem Core Freeze;
- dekorative Elemente, die Zeit, Personen, Termine oder die nächste Handlung verdrängen.

## 5. Räumliche Grundgrammatik

```text
Zeit vertikal
Mitarbeitende horizontal
08:00–18:00 als ein kontinuierlicher Tag
Teamfläche bleibt bei Fokus vollständig erhalten
Als Nächstes als temporäre Kopfzeilenagenda
```

### Desktop

- Der vollständige Tag ist gleichzeitig sichtbar, wenn mindestens 44 Pixel pro Stunde verfügbar sind.
- Seite, Arbeitsfläche und Kalender besitzen keinen vertikalen Scroll.
- Das Raster füllt die Kalenderfläche exakt bis `18:00`.
- Kalenderkopf und Raster bilden eine einzige Surface.
- Die Mitarbeitendenspalten teilen die verbleibende Breite gleichmäßig.
- Die Agenda verändert weder Kalenderbreite noch Kalenderhöhe.

### Kompakte Projektion

Wenn der vollständige Tag nicht mit mindestens 44 Pixel pro Stunde passt oder Mitarbeitendenspalten nicht sinnvoll lesbar bleiben:

- besitzt der Kalender genau einen primären vertikalen Scroll;
- bleibt die Zeitachse links sticky;
- bleiben Mitarbeitendenköpfe oben sticky;
- bewegen sich Mitarbeitende horizontal;
- bleibt die Seite selbst ohne zusätzlichen Scroll;
- startet die Zeitfläche beim heutigen Datum in der Nähe von Jetzt und respektiert danach jede manuelle Bewegung.

## 6. Responsive Regime

Die Projektion wird aus tatsächlich verfügbarer Breite und Höhe abgeleitet, nicht aus Gerätenamen.

### Regime A · Desktop Full

```text
mindestens 54 px/Stunde
vollständiger Karteninhalt, wo Breite und Höhe reichen
kein Scroll
```

### Regime B · Desktop Compact

```text
44–53.99 px/Stunde
vollständiger Tag
kein Scroll
semantische Kartenverdichtung
```

### Regime C · Compact Scroll

```text
unter 44 px/Stunde oder mobile Mitarbeitendenbreite erforderlich
Kalender als einziger vertikaler Scrollowner
horizontale Mitarbeitendenbewegung
```

Browserzoom ist eine veränderte CSS-Viewportgeometrie. Es gibt keine zoomspezifischen Sonderstile.

## 7. Informationsstufen der Terminkarten

```text
full:       Zeit · Name · Leistung
time-name:  Zeit · Name
name:       Name
first:      Vorname beziehungsweise kurzer fachlich sicherer Name
initials:   Initialen oder später Leistungssymbol
```

Die Stufe wird aus realer Kartenbreite und Kartenhöhe bestimmt. Schrift wird nicht beliebig verkleinert. Vollständige Information bleibt im zugänglichen Namen, Kontextpanel und Agenda erhalten.

## 8. Zeitmodell

- Eine globale vergangene Tagesfläche reicht exakt von Öffnung bis Jetzt.
- Die Jetzt-Linie liegt hinter Terminkarten.
- Auf vergangenem oder zukünftigem Datum gibt es keine Jetzt-Linie.
- Außerhalb der Öffnungszeit gibt es keine Linie innerhalb des Rasters.
- Salonzeit, Jetzt-Linie und Agenda verwenden dieselbe Zeitquelle `Europe/Zurich`.
- Desktop-Volltag bleibt räumlich stabil; dort bewegt sich nur die Jetzt-Markierung.
- Kompakte Projektionen positionieren initial zu Jetzt und pausieren jede automatische Orientierung nach bewusster Nutzerbewegung.

## 9. Personenfokus

- Klick auf einen Namen setzt Fokus.
- Klick auf denselben Namen löst Fokus.
- Klick auf eine andere Person überträgt Fokus.
- Alle fünf Spalten bleiben bestehen.
- Nicht fokussierte Spalten werden über eine neutrale Maske zurückgenommen.
- Eine gedimmte Spalte bleibt bedienbar.
- Suchtreffer, Auswahl und Tastaturfokus dürfen die Maske durchbrechen.
- Die globale Zeitlage bleibt unverändert.
- Es gibt keinen separaten Einpersonen-Renderer.

## 10. Agenda „Als Nächstes“

- Die Agenda ist standardmäßig geschlossen.
- Sie lebt in der Kopfzeile und öffnet ein nicht-modales Popover.
- Sie besitzt keine eigene Datenquelle.
- Sie zeigt `Davor`, `Jetzt`, `Danach` und die nächste freie Lücke.
- Ausgeblendete Einträge werden explizit als `x weitere` offengelegt.
- Auswahl synchronisiert Agenda, Kalender und Kontextpanel.
- Schließen stellt Ursprung und Fokus wieder her.
- Die Agenda darf die Kalendergeometrie nicht verändern.

## 11. Zustandsinventar

Vor Core-Freeze-Freigabe sind definiert und geprüft:

```text
normal
stress
quiet
empty
loading
error
offline
stale
forbidden
before-opening
during-opening
after-closing
past-date
future-date
staff-focus
appointment-selected
agenda-open
search-active
```

## 12. Core-Freeze-Abnahmematrix

### Desktop und Laptop

```text
1366 × 768
1440 × 810
1440 × 900
1512 × 982  Desktop-Master
1600 × 900
1920 × 1080
```

### Kompakt

```text
1024 × 768
844 × 390
430 × 932
390 × 844
```

### Zoom

Mindestens auf `1512 × 982` und `1366 × 768`:

```text
90 %
100 %
110 %
125 %
```

### Harte Desktop-Assertions

```text
documentOverflowX = 0
documentOverflowY = 0
pageOverflowY = 0
calendarOverflowY = 0
calendarVerticalOwnerCount = 0
calendarGridBottomGap <= 2 px
full day visible
no double scroll
agenda does not change calendar geometry
```

### Harte kompakte Assertions

```text
documentOverflowX = 0
documentOverflowY = 0
pageOverflowY = 0
calendarVerticalOwnerCount = 1
calendarPrimaryScrollOwner = calendar viewport
horizontal staff movement > 0
sticky time rail
sticky staff head
initial position near now on today
```

Zusätzlich gelten die deterministische Build-, Browser-, Accessibility-, Bereinigungs- und Prüfsummenregeln aus `TAGESPLAN_V1_FREEZE_POLICY.md`.

## 13. Technischer Core Freeze

Nach bestandenen Gates A bis D entsteht:

```text
references/tagesplan/v1.0/
├── tagesplan-reference.html
├── CONTRACT.md
├── STATES.md
├── INTEGRATION.md
├── ACCESSIBILITY.md
├── FREEZE_MANIFEST.json
├── CHECKSUMS.sha256
└── evidence/
```

`tagesplan-reference.html` enthält HTML, CSS, JavaScript, Fixtures und erforderliche SVGs vollständig eingebettet. Keine externe Laufzeitressource, kein erforderlicher Buildschritt und keine Backendabhängigkeit sind zulässig.

Der Freeze wird durch den unveränderlichen Tag `tagesplan-v1.0-core-freeze` identifiziert. Der Tag darf nicht verschoben werden.

## 14. Beseelung nach dem Freeze

Erst nach dem Core Freeze werden mehrere Varianten sicher getestet.

| Begriff | Späterer Nachweis im Tagesplan |
|---|---|
| gegenwärtig | Salonzeit, globale Zeitlage, Jetzt-Linie und aktuelle Arbeitsfolge |
| atmend | hohe Dichte mit rhythmischer Ruhe; keine tote Restfläche und keine künstlich großen Abstände |
| im Fluss | stabile Fläche, erhaltener Kontext, Zustände entstehen aus ihrem sichtbaren Ursprung |
| aufmerksam | nächste relevante Handlung und proportionale Abweichungen |
| beseelt | Menschen, Tätigkeiten, warme gepflegte Materialität und dosierte alpine Welt in passenden Zuständen |

Illustrationsdosierung für spätere Varianten:

```text
regulärer Arbeitstag: 0–5 %
leerer Tagesplan: 15–22 %
Tagesabschluss: 20–25 %
```

Fehler, Berechtigungsgrenzen, Billing- und Sicherheitszustände verwenden keine verniedlichende Illustration.

Beseelungsbranches zweigen vom Core-Freeze-Tag ab und dürfen die eingefrorene Geometrie, Datenwahrheit, Statussemantik oder Bedienlogik nicht verändern.

## 15. Übergabe an die Integrationslinie

Die Integrationslinie erhält:

- Core Freeze und später die ausgewählte Erfahrungsfassung;
- Seitenvertrag;
- Zustandsmatrix;
- Datenmapping;
- Eventmapping;
- Capability-Matrix;
- Responsive-Regeln;
- Browser-, Zoom-, Zustands-, Accessibility- und Integritätsnachweise.

Die Produktionsimplementierung darf technisch anders aufgebaut sein, muss aber sichtbare, funktionale und zugängliche Parität nachweisen.

## 16. Stop-Regeln

- `Termine` beginnt erst nach der vollständigen Tagesplanfreigabe.
- Beseelung beginnt erst nach dem Tag `tagesplan-v1.0-core-freeze`.
- SVG-Service-Symbole werden erst nach stabiler Kartengeometrie und dürfen den Core Freeze nicht nachträglich verändern.
- Der Core Freeze wird erst nach visueller, funktionaler, technischer und integritätsbezogener Freigabe erzeugt.
- Das kanonische Produktbranch und die Live-Referenz werden erst nach kontrollierter Abnahme aktualisiert.
- Ein fehlgeschlagener Pflichtcheck blockiert den Freeze vollständig.
