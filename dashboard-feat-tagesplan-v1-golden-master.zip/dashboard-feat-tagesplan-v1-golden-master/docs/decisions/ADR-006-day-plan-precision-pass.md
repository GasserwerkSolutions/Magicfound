# ADR-006 · Präzisionsdurchgang für den vertikalen Tagesplan

Status: **Akzeptiert – Umsetzung und Regressionstest verbindlich**  
Datum: 2026-08-24  
Betroffene Bereiche: Zeitlage, kompakte Kalender, Mitarbeitendenbewegung, Karteninhalt, Suche, Kopfzeile, Agenda und mobile technische Ränder

## Ausgangspunkt

ADR-004 definiert die vertikale Team-Tagesfläche. ADR-005 verlegt `Als Nächstes` als temporäre Agenda in die Kopfzeile. Die visuelle Prüfung des daraus entstandenen Referenzstands bestätigt die Grundgeometrie, benennt jedoch vier Freigabeblocker und zehn Präzisionskorrekturen.

`1512 × 982` bleibt der Desktop-Master. Die Uhr, die Produktidentität, die Navigation und die Betriebsinformation der Seitenleiste bleiben unverändert in ihrer Hierarchie.

## Entscheidung

### 1. Ebenenordnung der aktuellen Zeit

Die verbindliche Reihenfolge lautet:

1. Kalenderraster,
2. vergangene Zeitfläche,
3. aktueller Zeitstrich,
4. Termine und operative Blöcke,
5. Fokusmaske,
6. Suchtreffer, Auswahl und Tastaturfokus.

Der Zeitstrich liegt damit hinter Terminkarten und kann keinen Karteninhalt durchstreichen. Ein laufender Termin erhält am Kartenrand einen kleinen roten Einschnitt an der tatsächlichen Fortschrittsposition.

### 2. Ein gemeinsamer Kalender-Viewport

Kopfzeile, Zeitachse und Teamspalten verwenden einen gemeinsamen Scroll-Viewport.

- Der Mitarbeitendenkopf bleibt beim vertikalen Scrollen sticky.
- Die Zeitachse bleibt beim horizontalen Scrollen sticky.
- Vertikale und horizontale Position werden bei kontrollierten Re-Renderings erhalten.
- Manuelle Bewegung wird als bewusste Untersuchung respektiert.
- Minutenwechsel bewegen Linie und Uhr, aber nicht den Viewport.

### 3. Initiale Positionierung auf kompakter Fläche

Ist der vollständige Arbeitstag nicht sichtbar, wird beim ersten Laden des heutigen Tages einmalig zur aktuellen Salonzeit positioniert. Die Jetzt-Linie liegt ungefähr bei 36 Prozent der sichtbaren Kalenderhöhe.

- Kein automatischer Rücksprung nach manueller Bewegung.
- Arbeitsuhr und kompakte Zeitsteuerung führen explizit zurück zu Jetzt.
- Datumswechsel setzt die initiale Positionierung zurück.
- Beim Wiederaufnehmen einer inaktiven App werden Uhr und Linie synchronisiert; nur ohne vorherige manuelle Bewegung darf der kompakte Ausschnitt erneut auf Jetzt ausgerichtet werden.

### 4. Horizontale Mitarbeitendenbewegung auf 390 Pixel

Im Hochformat werden fünf Spalten nicht mehr zusammengedrückt.

- Zeitachse: sticky links.
- Mitarbeitendenspalte: mindestens 132 Pixel.
- Sichtbar: ungefähr zwei vollständige Spalten und ein Teil der folgenden Spalte.
- Horizontale Bewegung: frei mit leichtem `scroll-snap-type: proximity`.
- Kein permanentes Mitarbeitenden-Auswahlfeld.
- Mitarbeitendenkopf bleibt sticky oben.

Im kompakten Querformat stehen mindestens 104 Pixel pro Person zur Verfügung; dort werden Vornamen statt nur Initialen gezeigt.

### 5. Semantische Kartenverdichtung

Karteninhalt richtet sich nach der tatsächlich gemessenen Kartenbreite und -höhe, nicht nur nach Viewport oder Dauer.

Die Stufen sind:

1. vollständiger Name, Zeit und Leistung,
2. semantisch verkürzter Name und Zeit,
3. semantisch verkürzter Name,
4. Vorname,
5. Initialen.

Namen werden niemals willkürlich mitten im Wort abgeschnitten. Beispiele: `Mia Frei` → `Mia F.` → `Mia` → `MF`. Leistungen werden sinnvoll reduziert, etwa `Balayage & Glossing` → `Balayage`.

Der zugängliche Name enthält weiterhin vollständigen Zeitraum, Kundschaft, Leistung, Person und Status.

### 6. Explizite Agenda-Verdichtung

Kompakte Agenda-Zustände dürfen Einträge reduzieren, aber niemals still verschweigen.

- Hochformat: zwei laufende Termine und ein folgender Termin.
- Kurzes Querformat: ein laufender und ein folgender Termin.
- Weitere Einträge werden als `x weitere laufen` beziehungsweise `x weitere danach` offengelegt.
- Die Offenlegung ist bedienbar und erweitert die jeweilige Gruppe.
- Desktop zeigt den vollständigen Popoverinhalt.

### 7. Zeitdarstellungen

Wenn die Desktop-Seitenleistenuhr sichtbar ist, entfällt die Zeitpille im Produktkopf. Auf Tablet und Mobilgerät bleibt sie als mindestens 44 × 44 Pixel große Steuerung erhalten.

Arbeitsuhr, digitale Zeit, Zeitpille, Jetzt-Linie und vergangene Fläche verwenden dieselbe Salonzeit in `Europe/Zurich`. Die Aktualisierung erfolgt am Minutenwechsel und bei `visibilitychange`.

### 8. Suche

- Desktop: bestehendes Suchfeld.
- Kompaktes Querformat: Suchfeld mit ungefähr 280–320 Pixel Breite.
- Hochformat: 44-Pixel-Suchschaltfläche; Aktivierung öffnet das bestehende Suchfeld temporär.
- Suchtext: `Name, Termin oder freie Zeit suchen`.
- Tastaturhinweis: `⌘K` auf Apple-Plattformen, `Ctrl K` auf Windows und Linux.

### 9. Semantik und visuelle Konsistenz

- Seitenkicker: `TAGESPLAN`, nicht `SALONBETRIEB`.
- `Läuft` verwendet denselben violetten Statusbereich wie laufende beziehungsweise angekommene Terminkarten.
- Das Agenda-Badge ist konzentrisch ausgerichtet und zugänglich beschriftet.
- Der vollständige Benutzername wird ohne zufällige Ellipse angezeigt.
- Das Verwaltungssymbol wird als eindeutiges Regler-/Verwaltungssymbol dargestellt.

### 10. Datum, Zeitbereiche und technische Ränder

Verbindliche Datumsformate:

- groß: `Montag, 24. August`,
- mittel: `Mo., 24. Aug.`,
- kompakt: `Mo., 24.8.`.

Zeitbereiche verwenden tabellarische Ziffern und den Gedankenstrich `–`.

Mobile Navigation und Kalenderinhalt berücksichtigen `safe-area-inset-bottom`. Es existiert im Normalzustand nur eine primäre vertikale Kalenderbewegung; die Agenda besitzt nur während ihres temporären Öffnungszustands einen eigenen Scrollbereich.

## Regression und Abnahme

Verbindlich geprüft werden:

- `1512 × 982` als Desktop-Master,
- `1920 × 1080` als Expansion,
- `1366 × 768` als Desktop-Stresstest,
- `844 × 390` als kompaktes Querformat,
- `390 × 844` als mobiles Hochformat.

Automatische Nachweise umfassen:

- Zeitstrich-z-index kleiner als Karten-z-index,
- keine sichtbare Desktop-Zeitpille bei sichtbarer Seitenleistenuhr,
- initiale Jetzt-Position bei kompakten Viewports,
- horizontal scrollbare 132-Pixel-Spalten im Hochformat,
- explizite `x weitere`-Offenlegung,
- semantisch klassifizierte Karten,
- Suche als Feld im Querformat und als Schaltfläche im Hochformat,
- vollständiger Benutzername,
- `TAGESPLAN` als Seitenkicker,
- kein horizontaler Gesamtseitenüberlauf.

## Schutzregel

Die vor diesem Präzisionsdurchgang veröffentlichte Referenz ist auf dem Branch `archive/vertical-agenda-before-precision-2026-08-24` unverändert archiviert. Die Referenz simuliert weiterhin keine Backendpersistenz.
