# Gasserwerk · Kanonische Produktoberfläche V1

Status: verbindlicher Integrationsvertrag für den Branch `feat/canonical-product-surface-v1`

## Zweck

Dieses Dokument überführt die akzeptierten Entscheidungen aus der interaktiven Referenzarbeit in einen nachvollziehbaren Repository-Arbeitsvertrag. Es verhindert, dass weitere Funktionen auf widersprüchlichen CSS-Schichten, verworfenen Varianten oder impliziten Annahmen aufgebaut werden.

Die neue primäre Bearbeitungsquelle entsteht seitenbasiert unter `pages/` und `src/`. Die bestehende vollständige GitHub-Pages-Anwendung in `index.html` und `404.html` bleibt während der Migration als ausführbares Vergleichs- und Releaseartefakt erhalten. Manifest, Service Worker und App-Icons bleiben separat. In diesem Arbeitsschritt findet keine Framework-Migration statt.

## Verbindlicher Produktstand

### Produktschale

- Die Desktop-Sidebar bleibt dauerhaft sichtbar und dient der Orientierung im Gesamtsystem.
- Auf Mobilgeräten wird dieselbe fachliche Navigation in einer eigenständigen mobilen Anordnung angeboten.
- Der Produktkopf enthält Seitenkontext, Datum beziehungsweise Titel, Suche und die primäre Terminaktion.
- Darstellung, Installation und administrative Hilfsfunktionen konkurrieren nicht mit operativen Salonaktionen.
- Die Raumdichte wird responsiv gesteuert; Browser-Zoom oder `transform: scale()` sind keine Layoutstrategie.

### Datum und Tageszustand

- Das Datum im Produktkopf ist der einzige primäre Auslöser für die Datumsauswahl.
- Ein separater Date-Stepper auf der Tagesfläche entfällt.
- `Heute` wechselt das Datum; `Jetzt` positioniert die aktuelle Uhrzeit. Beide Begriffe bleiben semantisch getrennt.
- Der frühere eigenständige Bereich `Heute` geht im Tagesplan auf.

### Operative Teamarbeitsfläche

- Personen stehen links; Zeit läuft horizontal nach rechts.
- Die Namensspalte bleibt `sticky`, vollständig deckend und liegt über dem darunter verschwindenden Zeitraster.
- Zeitkopf, Raster, Termine, Aufgaben und Jetzt-Linie verwenden denselben horizontalen Scrollzustand.
- Das Arbeitsraster verwendet eine klare Hierarchie:
  - 15 Minuten: sehr feine Linie
  - 30 Minuten: mittlere Linie
  - 60 Minuten: stärkste Linie mit Zeitbeschriftung
- Der operative Desktopausschnitt umfasst verbindlich 240 Minuten.
- Im passiven Live-Zustand bleiben 45 Minuten Vergangenheit und 195 Minuten Zukunft sichtbar; Jetzt liegt damit bei 18,75 % der Zeitfläche.
- Terminbreiten bleiben immer proportional zur realen Dauer.
- Kompakte Personenzeilen liegen bei 60–64 px, Standard-Desktopzeilen bei 68–72 px; automatische Zeilenstreckung zum Füllen der Resthöhe ist verboten.
- Freie Zeit ist selbst die Buchungsaktion.
- Es gibt keine permanente Tages-Toolbar, keine zusätzliche Zusammenfassung und keinen Footer innerhalb der Kalenderfläche.

### Lebende Zeitfläche

- Die Jetzt-Linie bleibt mathematisch Teil der Zeitachse; sie wird nicht als künstlich fixiertes Overlay über das Raster gelegt.
- Im passiven Live-Zustand wird der gemeinsame Viewport so nachgeführt, dass die Jetzt-Linie an einem stabilen visuellen Anker liegt.
- Zielanker: ungefähr 18–22 % innerhalb der sichtbaren Zeitfläche, nicht direkt an der Namensspalte.
- Dadurch bleiben etwa 20–30 Minuten Vergangenheit und überwiegend kommende Zeit sichtbar.
- Die Zeit wird ruhig nachgeführt, ungefähr alle 10–15 Sekunden mit kurzer weicher Bewegung.
- Jede bewusste Kalenderinteraktion pausiert die Live-Verfolgung sofort, unter anderem Scrollen, Pointer-/Touch-Bewegung, Tastaturbedienung, Terminauswahl, Dialoge und Popover.
- Im entkoppelten Zustand erscheint genau eine dezente richtungsabhängige Rückkehraktion: `← Jetzt` oder `Jetzt →`.
- Eine automatische Rückkehr ist frühestens nach 20–30 Sekunden echter Inaktivität zulässig und nur, wenn keine Auswahl, kein Drag, kein Eingabefokus, kein Panel und keine andere aktive Handlung vorliegt.
- Auf vergangenen und zukünftigen Tagen existieren keine Jetzt-Linie, keine Live-Verfolgung und keine Jetzt-Rückkehr.

### Ganzer Arbeitstag

- `Ganzer Tag` ist ein anderer Maßstab derselben Tagesfläche, keine separate Navigationsseite.
- Der Maßstabswechsel wird einmalig und kontextuell angeboten, nicht als permanente Modusleiste im Raster.
- Auswahl, Datum, Personenbezug, Zeitkontext und geöffnetes Kontextpanel bleiben beim Wechsel erhalten.
- Im Ganztagesmaßstab wird das Raster bewusst ruhiger als in der operativen Arbeitsfläche dargestellt.

### Personenfokus

- Die normale Teamansicht bleibt `Personen × horizontale Zeit`.
- Die Aktivierung einer Person dreht dieselbe Tagesfläche in einen vertikalen Einzeltag: `eine Person × ganzer Arbeitstag`.
- Die Sidebar und der normale Produktkopf bleiben unverändert.
- Im Fokuszustand gibt es genau eine ruhige Kontextzeile mit Person, Datum und Rückkehraktion.
- Eine dominante zusätzliche Personenleiste und ein separater schwebender Fokus-Chip dürfen nicht gleichzeitig erscheinen.
- Die linke Zeitachse ist die Skala; eine zusätzliche Box mit der Aufschrift `Zeit` entfällt.
- Die Jetzt-Darstellung besteht ausschließlich aus einer dünnen Linie und einem kleinen Zeitlabel.
- Interne Aufgaben und Pausen bleiben durch eigene Muster beziehungsweise Formen eindeutig von Kundenterminen unterscheidbar.

### Terminmaterialität

- Terminflächen bleiben nahe an Weiß beziehungsweise sehr hell getönt.
- Der fachliche Zustand wird primär durch eine 3–4 Pixel starke linke Statuskante, Text und gegebenenfalls Symbol kommuniziert.
- Stärkere Flächentönung ist ausgewählten, laufenden oder konkret aufmerksamkeitsrelevanten Zuständen vorbehalten.
- Farbe kommuniziert Zustand, nicht Person oder Position.
- Auswahl-, Such- und Fokusfarbe bleibt vom Terminstatus getrennt.

### 14-Zoll-Dichte

- Typische kompakte Laptop-Viewports sollen bei 100 % Browserzoom ungefähr so dicht wirken wie die bisherige 80-%-Referenz.
- Verdichtet werden primär Sidebarbreite, Headerhöhe, Außenabstände, Kartenabstände, Tabellenzeilen und Kalendergeometrie.
- Haupttexte bleiben im Regelfall mindestens 14 Pixel groß.
- Sekundärtexte bleiben im Regelfall mindestens 11–12 Pixel groß.
- Primäre Touch- und Pointerziele behalten sichere Trefferflächen.
- Die Dichte wird über gemeinsame Tokens und klar definierte Viewportbereiche gesteuert, nicht über seitenweise Sonderregeln.

## Repository-Strategie

### Seitenbasierte Primärquelle

- Dauerhafte Navigationsziele werden als eigenständig aufrufbare Referenzseiten unter `pages/` aufgebaut.
- Produktschale, Komponenten, Tokens, Utilities und Datenadapter werden zentral unter `src/` geteilt.
- Eine Seite importiert gemeinsame Bausteine und darf Sidebar, Produktkopf, Overlays oder Designregeln nicht lokal kopieren.
- Teamarbeitsfläche, Ganztagesmassstab, Personenfokus, Kundenkartei, Suche und Kontextpanels bleiben Zustände beziehungsweise gemeinsame Komponenten und werden nicht zu künstlichen Navigationsseiten.

### Bestehende Gesamtvorschau schützen

- `index.html` und `404.html` bleiben während der Migration vollständig funktionsfähig und funktional identisch.
- Beide Dateien sind Vergleichs- und Releaseartefakte, nicht mehr die primäre Bearbeitungsquelle neuer Seiten.
- `gasserwerk.webmanifest`, `gasserwerk-sw.js`, `icons/` und PWA-Metadaten bleiben separat und funktionsfähig.
- Bestehende externe beziehungsweise fingerprintete Assets werden nicht ohne Prüfung gelöscht.
- Nach erfolgreicher Seitenmigration werden `index.html` und `404.html` aus den modularen Quellen erzeugt oder auf die modulare Vorschau ausgerichtet.

### Integrationsdisziplin

- Keine großen, ungeprüften Direktänderungen auf `main`.
- Änderungen erfolgen in kleinen, fachlich benannten Commits auf diesem Branch.
- Verträge, Struktur, Verhalten und visuelle Verfeinerung werden getrennt geändert und geprüft.
- Alte verworfene Renderer oder Steuerungen werden entfernt, nicht nur durch spätere CSS-Regeln versteckt.
- Wiederholte Maße werden in zentrale Tokens überführt.
- Neue Seiten sprechen nur gegen die fachliche `DashboardDataSource` und emittieren dokumentierte Events.
- Jeder Commit hält die bestehende Gesamtvorschau lauffähig; implementierte modulare Seiten müssen zusätzlich direkt aufrufbar bleiben.

## Umsetzungsreihenfolge

### 1. Vertragsgrundlage und Schutznetz

- gemeinsame Daten-, Ereignis-, Capability- und Zustandsregeln dokumentieren
- alle acht Seitenverträge vollständig ausarbeiten
- offene Backendfragen klassifizieren
- semantischen Vertragsdurchgang durchführen
- automatisierte Vertrags- und Static-Build-Prüfung ergänzen

Dieser Schritt ist abgeschlossen; die Seitenverträge stehen auf `Zur Freigabe`.

### 2. Gemeinsame Modulbasis

- zentrale Farb-, Typografie-, Layout- und Dichtetokens einführen
- kompakter Desktop, Standard-Desktop und Touch/Mobil eindeutig trennen
- Datums-, Zeit-, DOM- und Fokusutilities bereitstellen
- Seitenkatalog und Routenmodell festlegen
- Produktschale, Navigation und Produktkopf extrahieren
- Suche, Datumsauswahl und Kontextfläche als gemeinsame Komponenten implementieren

### 3. Mock-Datengrenze

- `DashboardDataSource` mit deterministischem Mock-Adapter implementieren
- Fixtures auf normalisierte View-Models abbilden
- Lade-, Leer-, Partial-, Fehler-, Offline-, Stale- und Forbidden-Zustände reproduzierbar machen
- historische Fixture-Zeit von echter Uhrzeit trennen

### 4. Tagesplan als erste Referenzseite

- direkt aufrufbaren Einstieg `pages/tagesplan/` herstellen
- Datumsauslöser im Produktkopf vereinheitlichen
- Tages-Toolbar, doppelte Zusammenfassungen und Footer entfernen
- Teamarbeitsfläche, Ganztagesmaßstab und Personenfokus auf ein gemeinsames Tagesmodell zurückführen
- Personenbezeichnungen als direkte Fokusauslöser vereinheitlichen

### 5. Live-Zeitcontroller

- einen einzigen gemeinsamen horizontalen Zeit-Viewport verwenden
- Live-Anker berechnen und kontinuierlich nachführen
- manuelle Entkopplung, richtungsabhängige Jetzt-Rückkehr und sichere Inaktivitätslogik implementieren
- andere Kalendertage explizit von Live-Zeitverhalten ausschließen

### 6. Visueller Qualitätsdurchgang

- Rasterintensität, Terminmaterialität, Zeilenrhythmus, Rahmen, Schatten und Kontrast separat abnehmen
- keine neuen Funktionen in diesem Durchgang ergänzen

### 7. Weitere Seiten

- Kundschaft und Termine
- Team, Angebot und Verwaltung
- Login und Onboarding
- jede Seite direkt aufrufbar, vertragstreu und unabhängig vom Backend

### 8. Responsive Regression

Mindestens folgende Viewports prüfen:

- 1366 × 768
- 1440 × 900
- 1512 × 982
- 1536 × 864
- 1600 × 900
- 1920 × 1080
- 390 × 844
- 430 × 932
- 844 × 390
- Tablet Hochformat
- Tablet Querformat

Mindestens folgende Oberflächen prüfen:

- Tagesplan im Live-Zustand
- Tagesplan manuell entkoppelt
- Ganzer Arbeitstag
- Personenfokus
- Datumsauswahl
- Suche
- Terminpanel/Buchung
- Termine
- Kundschaftsliste
- Kundenkartei
- Team
- Angebot
- Verwaltung

### 9. Phase 3 erst nach Freigabe

Direkte Terminmanipulation beginnt erst nach Abschluss dieser Stabilisierung:

- Zeit verschieben
- Person wechseln
- Dauer ändern
- 15-Minuten-Snap
- Konfliktvorschau
- Commit erst beim Loslassen
- unmittelbares Rückgängig
- Tastatur- und Touch-Alternative

## Harte Abnahmekriterien

Die kanonische V1 ist abgeschlossen, wenn:

- jede Navigationsseite direkt aufrufbar ist;
- gemeinsame Komponenten importiert und nicht seitenweise kopiert werden;
- keine Gesamtseite horizontal überläuft;
- Header, Suche und Hauptaktion in allen Zielviewports kollisionsfrei bleiben;
- die Sidebar auf Desktop vollständig erreichbar bleibt;
- alle Haupttexte und Sekundärtexte ihre Mindestlesbarkeit einhalten;
- die 15-Minuten-Linien sichtbar, aber nicht dominant sind;
- Jetzt-Anker, Zeitkopf, Raster und Termine geometrisch synchron bleiben;
- manuelle Navigation niemals durch einen voreiligen Rücksprung gestört wird;
- Personenfokus und Rückkehr räumlich nachvollziehbar bleiben;
- ein ausgewählter Termin in allen Tagesdarstellungen erkennbar bleibt;
- Datumsauswahl, Suche und Kontextpanel ihren Fokus korrekt zurückgeben;
- Desktop und Mobil dieselben fachlichen Zustände verwenden;
- keine verworfenen Steuerungen oder Renderer unsichtbar im DOM verbleiben;
- `index.html` und `404.html` funktional übereinstimmen;
- Manifest und Service Worker auf den aktuellen Build zeigen;
- keine JavaScript-, Konsolen- oder Laufzeitfehler auftreten.

## Nicht-Ziele dieses Branches

- Keine Framework-Migration.
- Kein Backend und keine echte Persistenz.
- Kein Drag-and-drop vor Abschluss der V1-Stabilisierung.
- Kein standardmäßig eingeklappter Desktop-Navigationsrahmen.
- Kein sichtbarer Komfort-/Kompakt-Schalter ohne reale Nutzungsdaten.
- Keine neuen Dashboardkennzahlen oder dekorativen Oberflächenmodule.
