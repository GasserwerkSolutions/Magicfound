# Gasserwerk Dashboard · gemeinsamer UI-Vertrag

Status: **Zur Freigabe – semantisch konsolidiert, Integrationsfragen explizit**

## 1. Zweck und Geltung

Bevor die Referenzseiten modular umgesetzt werden, werden die fachlichen und interaktiven Verträge vollständig beschrieben. Der Vertrag ist die Übergabegrenze zwischen:

- Referenzoberfläche
- späterer Produktionsanwendung
- noch nicht festgelegtem Backend
- Mock-Daten und realen Datenadaptern

Die Dokumente legen **fachliche Eingaben, sichtbare Zustände, ausgehende Absichten, Berechtigungen, Responsive-Verhalten und Abnahmekriterien** fest. Sie legen keine HTTP-Endpunkte, Datenbanktabellen oder Framework-Stores fest.

Bei Widersprüchen gilt diese Reihenfolge:

1. akzeptierte Produktentscheidungen in `docs/PRODUCT_SURFACE_V1.md`
2. seitenübergreifende Regeln in diesem Dokument
3. jeweiliger Seitenvertrag unter `pages/*/CONTRACT.md`
4. modulare Referenzimplementierung unter `pages/` und `src/`
5. bestehende Gesamtvorschau in `index.html` und `404.html`
6. technische Implementierungsdetails

Eine Abweichung von einer höheren Ebene muss ausdrücklich dokumentiert werden. Das Ergebnis des semantischen Abgleichs liegt in `docs/contracts/SEMANTIC_REVIEW.md`.

## 2. Arbeitsreihenfolge

Die Entwicklung folgt ab jetzt dieser Reihenfolge:

1. gemeinsame Begriffe und Zustände festlegen
2. alle Seitenverträge ausarbeiten
3. offene Backendfragen sichtbar sammeln
4. Verträge semantisch konsolidieren und auf `Zur Freigabe` setzen
5. gemeinsame Produktschale und Datenquelle implementieren
6. Seiten einzeln umsetzen und abnehmen
7. erst danach persistente Backendintegration

UI-Code wird nicht verwendet, um offene fachliche Fragen stillschweigend zu entscheiden.

## 3. Vertragsstatus

Jeder Vertrag trägt einen Status:

- **Entwurf:** vollständig genug zur Diskussion, aber noch veränderbar
- **Zur Freigabe:** alle bekannten Entscheidungen enthalten; offene Punkte sind explizit
- **Verbindlich:** fachlich freigegeben; Änderungen brauchen einen dokumentierten Entscheid
- **Implementiert:** Referenzseite erfüllt den verbindlichen Vertrag
- **In Produktion abgebildet:** Produktionsanwendung erfüllt denselben Vertrag

Alle acht Seitenverträge befinden sich nach dem semantischen Durchgang auf **Zur Freigabe**. Bereits akzeptierte Produktoberflächenregeln sind darin normativ und nicht erneut offen. Eine neue offene Frage der Klasse `B` setzt den betroffenen Vertrag zurück auf `Entwurf`.

## 4. Normative Begriffe

- **MUSS:** zwingende Produkt- oder Integrationsanforderung
- **DARF NICHT:** verbotene Abweichung
- **SOLL:** Standard, von dem nur mit dokumentierter Begründung abgewichen wird
- **KANN:** optionale Erweiterung
- **OFFEN:** noch nicht durch Quellen oder Produktentscheid entschieden

## 5. Gemeinsame Produktschale

Alle Seiten innerhalb des angemeldeten Produkts verwenden dieselbe Schale:

- Desktop-Sidebar als dauerhafte Orientierung
- mobilspezifische Navigation mit derselben fachlichen Struktur
- Produktkopf mit Seitentitel beziehungsweise Datum, Kontext, Suche und primärer Aktion
- gemeinsame Datumsauswahl, Suche, Kontextflächen, Statusdarstellung und leere Zustände
- zentrale Dichte-, Typografie-, Farb- und Fokusregeln

Login und Onboarding verwenden eine dafür konfigurierte Schalenvariante, erfinden aber keine zweite Designwelt.

Eine Seite darf gemeinsame Komponenten konfigurieren, aber nicht lokal kopieren oder visuell neu definieren.

## 6. Gemeinsame Datenquellengrenze

Seiten erhalten Daten ausschliesslich über eine fachliche Datenquelle. Die Referenz verwendet einen Mock-Adapter; die Produktionsanwendung liefert später einen Backend-Adapter.

```js
export class DashboardDataSource {
  getSessionContext() {}
  getAuthenticationOptions() {}
  getOnboardingState() {}
  getDayPlan(query) {}
  listAppointments(query) {}
  getAppointment(id) {}
  listCustomers(query) {}
  getCustomer(id) {}
  listStaff(query) {}
  getStaffMember(id) {}
  listServices(query) {}
  getService(id) {}
  getAdministrationSettings() {}
}
```

Alle Methoden dürfen synchron oder asynchron implementiert werden; die Seite behandelt ihre Ergebnisse grundsätzlich als potenziell asynchron.

Seiten kennen nicht:

- API-URLs
- HTTP-Verben
- Authentifizierungstokens
- Datenbanktabellen
- Cachebibliotheken
- Framework-Stores
- Server-Action-Namen

## 7. Normalisierte gemeinsame View-Models

Die konkrete Backendform ist offen. Der Adapter MUSS jedoch normalisierte View-Models liefern.

### `SessionContext`

```js
{
  account: {
    id,
    displayName,
    initials,
    productRoleLabel
  },
  salon: {
    id,
    name,
    locationLabel,
    timeZone
  },
  capabilities: string[],
  locale: "de-CH",
  currency: "CHF"
}
```

`productRoleLabel` ist eine Berechtigungsrolle wie `Inhaberin`. Sie darf nicht mit der fachlichen Teamfunktion wie `Top Stylistin` verwechselt werden.

### `StaffMemberSummary`

```js
{
  id,
  displayName,
  initials,
  professionalRoleLabel,
  availabilitySummary,
  isActive
}
```

### `AppointmentSummary`

```js
{
  id,
  kind: "appointment",
  date,
  startMinute,
  durationMinutes,
  customer: { id, displayName, phoneLabel },
  service: { id, displayName },
  staff: { id, displayName },
  status,
  note,
  price,
  visitStep
}
```

Für die Referenz dürfen `customer.id` oder `service.id` aus vorhandenen Fixtures stabil abgeleitet werden, falls die historischen Mock-Daten nur Namen enthalten. Die Produktionsintegration MUSS stabile fachliche IDs liefern.

### `OperationalBlock`

```js
{
  id,
  kind: "task" | "break" | "absence" | "conflict",
  date,
  startMinute,
  durationMinutes,
  staff: { id, displayName },
  label,
  note
}
```

Interne Aufgaben, Pausen und Abwesenheiten sind keine Termine und dürfen nicht als Kundentermine serialisiert werden.

### `ServiceSummary`

```js
{
  id,
  displayName,
  durationMinutes,
  price,
  assignedStaffIds,
  isActive
}
```

### `CustomerSummary`

```js
{
  id,
  displayName,
  phoneLabel,
  emailLabel,
  lastVisit,
  nextAppointment,
  tags
}
```

Nur tatsächlich verfügbare Felder werden angezeigt. Fehlende Felder werden nicht durch erfundene Werte ersetzt.

## 8. Zeit-, Datums- und Geldregeln

- Datumswerte verwenden im Vertrag `YYYY-MM-DD`.
- Zeitpunkte innerhalb eines Salontages werden im View-Model als Minuten seit Mitternacht normalisiert.
- Darstellung erfolgt in `de-CH`.
- Der Salon-Zeitraum wird in der Salon-Zeitzone interpretiert.
- `Heute` ändert das Datum; `Jetzt` positioniert die aktuelle Uhrzeit.
- Live-Zeit darf nicht aus einem historischen Fixture-Zeitpunkt als reale Uhr ausgegeben werden.
- Geld wird als Zahl plus Währung behandelt; die Darstellung erfolgt in CHF.
- Rundung, Mehrwertsteuer und Zahlungslogik sind OFFEN, solange das Backendmodell fehlt.

## 9. Terminstatus und operative Arten

Verbindliche Terminstatus der aktuellen Referenz:

```text
confirmed  Bestätigt
pending    Angefragt
arrived    Im Salon
completed  Abgeschlossen
cancelled  Abgesagt
no-show    Nicht erschienen
```

`blocked` bleibt ein historischer Sammelbegriff und SOLL in neuen View-Models durch eine konkrete operative Art ersetzt werden.

Verbindliche operative Arten:

```text
task       interne Aufgabe
break      Pause
absence    Abwesenheit
conflict   Konfliktanzeige
```

Erlaubte Statusübergänge und fachliche Pflichtgründe sind noch OFFEN und werden nicht von der Referenz erfunden.

## 10. Gemeinsames Zustandsmodell

Jede Seite beschreibt mindestens:

- `initial`: Seite wurde aufgerufen, noch keine Datenentscheidung
- `loading`: Daten werden geladen
- `ready`: Daten sind vollständig nutzbar
- `empty`: gültige Antwort ohne fachliche Einträge
- `partial`: Teilinformationen fehlen, Kernaufgabe bleibt möglich
- `saving`: eine angeforderte Änderung wird verarbeitet
- `error`: Kernaufgabe kann nicht geladen oder abgeschlossen werden
- `forbidden`: Capability fehlt
- `offline`: Netzwerk ist nicht verfügbar
- `stale`: vorhandene Daten sind sichtbar, Aktualität ist unsicher

Ein leerer Zustand ist kein Fehlerzustand. `offline` und `stale` dürfen vorhandene Arbeitsdaten nicht unnötig verdecken.

## 11. Ereignisvertrag

Seiten melden fachliche Absichten als Events. Ein Event enthält:

```js
{
  type,
  source,
  occurredAt,
  correlationId,
  payload
}
```

`occurredAt` ist technisch; fachliche Datums- und Zeitwerte stehen zusätzlich im Payload.

### Gemeinsame Navigation und Suche

```text
shell:navigate-requested
search:opened
search:closed
search:submitted
search:result-selected
```

### Tagesplan und Termine

```text
day:date-change-requested
day:scale-change-requested
day:staff-focus-requested
day:staff-focus-cleared
day:live-follow-paused
day:live-follow-resume-requested
appointments:query-changed
appointment:create-requested
appointment:selected
appointment:edit-requested
appointment:status-change-requested
appointment:cancel-requested
```

### Kundschaft

```text
customer:query-changed
customer:selected
customer:detail-closed
customer:appointment-create-requested
customer:edit-requested
```

### Team, Angebot und Verwaltung

```text
staff:query-changed
staff:selected
staff:create-requested
staff:edit-requested
staff:active-state-change-requested
services:query-changed
service:selected
service:create-requested
service:edit-requested
service:active-state-change-requested
administration:section-opened
administration:change-requested
product-preference:theme-change-requested
product-install:requested
```

### Authentifizierung und Onboarding

```text
auth:sign-in-requested
auth:magic-link-requested
auth:password-reset-requested
auth:sign-out-requested
onboarding:step-change-requested
onboarding:save-and-continue-requested
onboarding:completed
```

Direkte Terminmanipulation ist Phase 3. Folgende Events sind reserviert, aber werden in V1 noch nicht emittiert:

```text
appointment:move-requested
appointment:resize-requested
appointment:undo-requested
```

## 12. Capability-Modell

Die UI prüft Fähigkeiten, nicht hart codierte Rollennamen.

```text
day-plan:view
day-plan:create-appointment
appointment:view
appointment:edit
appointment:change-status
customer:view
customer:view-sensitive-notes
customer:edit
staff:view
staff:manage
service:view
service:manage
administration:view
administration:manage-salon
administration:manage-access
administration:view-billing
onboarding:manage
auth:sign-in
```

Die Zuordnung von Rollen zu Capabilities bleibt Sache der Produktionsanwendung. Die aktuelle Referenzperson `Inhaberin` darf als vollständiger Demo-Zugriff dienen, ist aber keine endgültige Rollenmatrix.

Eine nicht erlaubte Aktion wird nicht nur deaktiviert, sondern erhält je nach Kontext einen verständlichen Berechtigungszustand. Vertrauliche Daten werden bei fehlender Capability gar nicht in das View-Model aufgenommen.

## 13. Fokus, Tastatur und Overlays

- Jede Seite besitzt eine nachvollziehbare Überschriften- und Fokusreihenfolge.
- Öffnende Komponenten speichern ihren Ursprung.
- Schliessen oder Abbrechen gibt den Fokus an den Ursprung zurück.
- `Escape` schliesst die oberste schliessbare Kontextfläche.
- Dialoge und Sheets halten den Fokus innerhalb ihrer Fläche.
- Wichtige Zustandsänderungen werden über eine Live-Region angekündigt.
- Pointer-Gesten erhalten immer eine Tastatur- beziehungsweise einfache Aktivierungsalternative.
- Eine Seite darf den Fokus nicht nach jedem Datenrefresh ungefragt verschieben.

## 14. Responsive- und Dichtevertrag

Die gleiche fachliche Seite darf räumlich anders dargestellt werden, aber keine andere Fachlogik erhalten.

Verbindliche Bereiche:

- kompakter Desktop beziehungsweise typische 14-Zoll-Viewports
- Standard-Desktop
- Touch/Mobil

Es wird nicht über `zoom` oder `transform: scale()` verdichtet. Geometrie und Typografie werden getrennt gesteuert.

Mindestprüfungen:

```text
1366 × 768
1440 × 900
1512 × 982
1536 × 864
1600 × 900
1920 × 1080
390 × 844
430 × 932
844 × 390
Tablet Hochformat
Tablet Querformat
```

## 15. Abnahme eines Seitenvertrags

Ein Vertrag ist `Zur Freigabe`, wenn:

- alle 13 Pflichtabschnitte ausgefüllt sind
- fachliche Begriffe dem gemeinsamen Vertrag entsprechen
- Datenfelder als erforderlich, optional oder offen markiert sind
- alle ausgehenden Events mit Payload beschrieben sind
- Lade-, Leer-, Fehler- und Berechtigungszustände definiert sind
- Desktop, Mobil und Tastaturverhalten beschrieben sind
- keine Backenddetails erfunden wurden
- offene Punkte in `docs/contracts/OPEN_QUESTIONS.md` referenziert sind
- keine offene Frage der Klasse `B` die Referenzimplementierung blockiert

Ein Vertrag wird erst nach fachlicher Abnahme `Verbindlich`. Danach beginnt beziehungsweise stabilisiert sich die modulare Implementierung der betreffenden Seite gegen denselben Vertrag.
