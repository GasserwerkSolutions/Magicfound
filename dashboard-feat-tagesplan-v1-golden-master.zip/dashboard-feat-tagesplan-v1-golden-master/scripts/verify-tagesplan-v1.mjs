import { readFileSync, statSync } from 'node:fs';
import { resolve } from 'node:path';
import vm from 'node:vm';

const root = process.cwd();
const referencePath = resolve(root, 'references/tagesplan/v1.0/tagesplan-reference.html');
const html = readFileSync(referencePath, 'utf8');
const errors = [];

function requireText(text, label) {
  if (!html.includes(text)) errors.push(`Golden Master enthält nicht: ${label}`);
}

function forbid(pattern, label) {
  if (pattern.test(html)) errors.push(`Golden Master enthält eine verbotene Laufzeitabhängigkeit: ${label}`);
}

const size = statSync(referencePath).size;
if (size > 5 * 1024 * 1024) errors.push(`Golden Master ist grösser als 5 MiB: ${size} Bytes`);

const styleTags = html.match(/<style\b[^>]*>/gi) ?? [];
const inlineScripts = [...html.matchAll(/<script\b(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi)];
if (styleTags.length !== 1) errors.push(`Erwartet genau ein eingebettetes Stylesheet, gefunden ${styleTags.length}`);
if (inlineScripts.length !== 1) errors.push(`Erwartet genau ein eingebettetes Skript, gefunden ${inlineScripts.length}`);

forbid(/<link\b[^>]*\brel=["']?stylesheet/i, 'externes Stylesheet');
forbid(/<script\b[^>]*\bsrc=/i, 'externes Skript');
forbid(/<img\b[^>]*\bsrc=["'](?!data:)/i, 'externes Bild');
forbid(/\bimport\s+(?:[^('";]+\s+from\s+)?["']/i, 'ES-Modul-Import');
forbid(/\.\.\/\.\.\/(?:src|assets|pages)\//i, 'relativer Projektpfad');
forbid(/url\(["']?(?:https?:|\/\/)/i, 'externe CSS-Ressource');

[
  ['data-gw-reference="tagesplan-v1"', 'Referenzkennung'],
  ['data-gw-page="tagesplan"', 'Seitentyp'],
  ['meta name="gw-reference-version" content="1.0.0"', 'Version 1.0.0'],
  ['data-tp-reference-version', 'Laufzeitversion'],
  ['data-tp-complete-day-visible', 'Desktop-Ganztagsdiagnostik'],
  ['data-tp-vertical-scroll-systems', 'mobile Scrollsystemdiagnostik'],
  ['data-tp-horizontal-staff-scrollable', 'Mitarbeitendenbewegung'],
  ['data-tp-calendar-surface', 'Single-Surface-Diagnostik'],
  ['tp-v1-service-icon', 'eingebettete Service-Symbole'],
  ['tp-v1-empty-habitat', 'dosierter leerer Tagesplan'],
  ['Heute ist es noch erstaunlich ruhig.', 'verbindlicher Leerzustandstext'],
  ['data:image/webp;base64,', 'eingebettetes alpines Asset'],
  ['Als Nächstes', 'Kopfzeilenagenda'],
  ['09:00', 'primärer Zeitanker 09:00'],
  ['12:00', 'primärer Zeitanker 12:00'],
  ['15:00', 'primärer Zeitanker 15:00'],
  ['18:00', 'primärer Zeitanker 18:00']
].forEach(([text, label]) => requireText(text, label));

if (inlineScripts.length === 1) {
  try {
    new vm.Script(inlineScripts[0][1], { filename: 'tagesplan-reference.inline.js' });
  } catch (error) {
    errors.push(`Eingebettetes JavaScript ist syntaktisch ungültig: ${error.message}`);
  }
}

if (errors.length) {
  console.error(`Tagesplan-v1-Prüfung fehlgeschlagen (${errors.length}):`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`✓ Tagesplan v1.0 ist statisch isoliert, vollständig und syntaktisch gültig (${Math.round(size / 1024)} KiB).`);
