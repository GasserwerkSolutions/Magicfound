# Tagesplan · Vertikale Teamfläche mit aufklappbarer Agenda

Direkt ausführbare Referenz zu ADR-004 und ADR-005 sowie aktueller Einstieg der automatisch veröffentlichten Dashboard-Referenz.

## Grundmodell

Die Zeit läuft von oben nach unten. Alle Mitarbeitenden bleiben als Spalten derselben Teamfläche sichtbar. Termine vermitteln ihre reale Dauer über die Höhe; Überschneidungen teilen nur die Breite innerhalb der betroffenen Personenspalte.

Der Personenfokus erzeugt keinen zweiten Kalender:

- alle Spalten bleiben bestehen,
- die fokussierte Spalte bleibt im normalen Kontrast,
- Nachbarspalten werden über eine neutrale Fokusmaske zurückgenommen,
- Klick auf dieselbe Person oder `Escape` hebt den Fokus auf,
- Auswahl und Suchtreffer bleiben oberhalb der Fokusmaske sichtbar.

## Die Zeit verändert die Fläche

Nicht einzelne Terminkarten erhalten künstliche Zeitstufen. Auf dem heutigen Tag liegt vom Öffnungszeitpunkt bis zur aktuellen Salonzeit eine einzige gleichmässige und sehr feine vergangene Zeitfläche.

- Ausgangswert: **5 Prozent** zusätzliche Dunkelheit,
- kein Verlauf,
- exakte Abschlusskante an der Jetzt-Linie,
- gleiche Tönung über Zeitachse und sämtliche Teamspalten,
- fachliche Statuskante bleibt unverändert,
- Start und Ende bleiben auf ausreichend hohen Karten sichtbar.

Vergangenheit, Gegenwart und Zukunft entstehen damit aus der gemeinsamen Zeitgeometrie. Die Kalenderkarten werden nicht zusätzlich in `Davor`, `Jetzt` und `Danach` eingefärbt.

## Kopfzeile: Als Nächstes

Der frühere sichtbare Kopfzeilenkontext

```text
Zürich Enge · 08:00–18:00
```

ist im Tagesplan durch **Als Nächstes** ersetzt.

Der Standort bleibt in der festen Betriebsinformation der Seitenleiste sichtbar. Öffnung und Schliessung werden durch die vertikale Zeitachse getragen. Dadurch ist die Kopfzeile für den nächsten operativen Kontext frei.

Die Agenda nimmt im geschlossenen Zustand keine dauerhafte Kalenderbreite mehr ein. Der Auslöser zeigt eine kompakte Vorschau und öffnet ein nicht-modales, an die Kopfzeile gebundenes Popover.

Das Popover enthält:

- `Davor`: zuletzt beendeter relevanter Termin,
- `Jetzt`: aktuell laufende relevante Termine,
- `Danach`: die nächsten Termine,
- nächste freie Lücke: früheste tatsächlich freie Lücke ab 30 Minuten.

Die freie Lücke endet am nächsten belegten Block und wird nicht fälschlich bis zum Salonende verlängert.

## Kontrollierter Dreiton-Test

Die vorgeschlagenen drei zeitlichen Töne werden bewusst nur innerhalb des Agenda-Popovers getestet:

- `Davor`: neutral zurückgenommen,
- `Jetzt`: ruhig grünlich betont,
- `Danach`: helle, leicht warme Zukunftsfläche.

Diese Töne gruppieren die operative Reihenfolge. Sie ersetzen weder Terminstatus noch die globale vergangene Zeitfläche und färben den Kalender nicht um.

Kalender und Agenda verwenden dieselben Terminobjekte, dieselbe Suche, denselben Personenfokus, dieselbe Auswahl und dasselbe Kontextpanel.

## Interaktion und Fokus

- `Als Nächstes` öffnet und schliesst das Popover.
- `Escape` schliesst das Popover und gibt den Fokus an den Auslöser zurück.
- Ein Aussenklick schliesst es, ohne den Kalenderzustand zu verändern.
- Ein Termin aus der Agenda öffnet denselben Terminkontext wie die Kalenderkarte.
- Beim Öffnen eines Termins einer anderen Person wandert ein aktiver Personenfokus zu dieser Spalte.
- Auf Tablet und Mobilgerät erscheint ein kompakter Agenda-Auslöser in den Kopfaktionen.
- Die frühere permanente Agenda rechts beziehungsweise oberhalb des mobilen Kalenders ist vollständig verborgen.

## Referenzparameter

Deterministische Salonzeit:

```text
?referenceNow=11:22
```

Agenda direkt öffnen:

```text
?referenceNow=11:22&agenda=open
```

Personenfokus:

```text
?referenceNow=11:22&focus=melanie
```

Diagnosemodus für Browserprüfungen; er öffnet die Agenda automatisch:

```text
?referenceNow=11:22&verify=1
```

## Responsive Verhalten

- Desktop und 14 Zoll: fünf Mitarbeitendenspalten nutzen die volle Kalenderbreite; die Agenda öffnet über der Fläche.
- Schmaler Desktop und Tablet: derselbe Kalender bleibt primär; der kompakte Kopfzeilenauslöser öffnet das Popover.
- Mobil hochkant und quer: keine permanente Agenda; alle Mitarbeitendenspalten bleiben Teil derselben Teamfläche.
- Kein horizontaler Gesamtseitenüberlauf.

## Backendgrenze

Die Seite verwendet den gemeinsamen `DashboardDataSource`-Adapter und emittiert fachliche Events. Es gibt keine produktive Persistenz, keine echten Backendmutationen und noch kein Drag/Resize.

## Prüfung

Bei jedem Feature-Push laufen statische und echte Chrome-Prüfungen für `1366×768`, `1440×900`, `1512×982`, `1920×1080`, `390×844` und `844×390`. Geprüft werden zusätzlich:

- genau eine globale vergangene Zeitfläche,
- fünf Mitarbeitendenspuren,
- keine permanente Agenda-Spalte,
- `Als Nächstes` statt des alten Kopfzeilenkontexts,
- genau ein sichtbares Agenda-Popover im geöffneten Prüfzustand,
- gemeinsame Auswahl zwischen Kalender und Agenda,
- vier gedimmte Kontextspalten im Fokus auf Melanie,
- keine Dreiton-Klassen auf Kalenderkarten.
