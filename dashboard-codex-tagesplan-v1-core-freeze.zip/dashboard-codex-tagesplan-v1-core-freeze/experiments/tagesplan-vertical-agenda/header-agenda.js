const root = document.querySelector('#dashboard-root');
const content = document.querySelector('#gw-page-content');
const context = document.querySelector('#gw-page-context');
const headerActions = document.querySelector('#gw-header-actions');
const params = new URLSearchParams(location.search);

const state = {
  open: params.get('agenda') === 'open' || params.get('verify') === '1',
  returnVariant: 'desktop',
  scheduled: false,
  layer: null,
  panel: null
};

function visible(element) {
  return Boolean(element && element.getClientRects().length);
}

function sourcePanel() {
  const mobile = matchMedia('(max-width: 1100px)').matches;
  const preferred = content?.querySelector(mobile
    ? '.va-mobile-agenda .va-agenda-panel'
    : '.va-desktop-agenda .va-agenda-panel');
  return preferred ?? content?.querySelector('.va-agenda-panel') ?? null;
}

function summaryFrom(panel) {
  if (!panel) return 'Wird geladen';
  const current = panel.querySelector('.va-agenda-section.is-current .va-agenda-row');
  const next = panel.querySelector('.va-agenda-section.is-next .va-agenda-row');
  const previous = panel.querySelector('.va-agenda-section.is-before .va-agenda-row');
  const row = current ?? next ?? previous;
  if (!row) return 'Keine weiteren Termine';

  const time = row.querySelector('.va-agenda-time')?.textContent?.trim() ?? '';
  const name = row.querySelector('.va-agenda-copy strong')?.textContent?.trim() ?? '';
  if (current) return `Jetzt · ${name || time}`;
  if (next) return `${time.split('–')[0] || time} · ${name}`.replace(/^ · | · $/g, '');
  return 'Tag abgeschlossen';
}

function triggerMarkup(variant, summary) {
  const mobile = variant === 'mobile';
  const expanded = state.open ? 'true' : 'false';
  if (mobile) {
    return `<button class="gw-button va-agenda-trigger va-agenda-trigger-mobile" type="button" data-header-agenda-toggle data-agenda-variant="mobile" aria-haspopup="dialog" aria-controls="va-agenda-popover" aria-expanded="${expanded}" aria-label="Als Nächstes öffnen">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg>
      <span class="gw-visually-hidden">Als Nächstes</span>
    </button>`;
  }

  return `<button class="va-agenda-trigger" type="button" data-header-agenda-toggle data-agenda-variant="desktop" aria-haspopup="dialog" aria-controls="va-agenda-popover" aria-expanded="${expanded}">
    <span class="va-agenda-trigger-label">Als Nächstes</span>
    <span class="va-agenda-trigger-preview">${summary}</span>
    <svg class="va-agenda-trigger-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m7 9 5 5 5-5"/></svg>
  </button>`;
}

function ensureTriggers() {
  const panel = sourcePanel() ?? state.panel;
  const summary = summaryFrom(panel);

  if (context) {
    const existing = context.querySelector('[data-header-agenda-toggle]');
    if (!existing) context.innerHTML = triggerMarkup('desktop', summary);
    else {
      existing.setAttribute('aria-expanded', String(state.open));
      const preview = existing.querySelector('.va-agenda-trigger-preview');
      if (preview && preview.textContent !== summary) preview.textContent = summary;
    }
  }

  if (headerActions && matchMedia('(max-width: 1100px)').matches) {
    let mobileTrigger = headerActions.querySelector('[data-header-agenda-toggle]');
    if (!mobileTrigger) {
      headerActions.insertAdjacentHTML('afterbegin', triggerMarkup('mobile', summary));
      mobileTrigger = headerActions.querySelector('[data-header-agenda-toggle]');
    }
    mobileTrigger?.setAttribute('aria-expanded', String(state.open));
  } else {
    headerActions?.querySelector('.va-agenda-trigger-mobile')?.remove();
  }

  root?.querySelectorAll('[data-header-agenda-toggle]').forEach((button) => {
    button.setAttribute('aria-expanded', String(state.open));
  });
}

function ensureLayer() {
  if (state.layer?.isConnected) {
    state.layer.hidden = false;
    return state.layer;
  }
  const layer = document.createElement('div');
  layer.className = 'va-agenda-layer';
  layer.dataset.headerAgendaLayer = '';
  document.body.append(layer);
  state.layer = layer;
  return layer;
}

function preparePanel(panel) {
  panel.id = 'va-agenda-popover';
  panel.classList.add('va-agenda-popover');
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-modal', 'false');
  panel.setAttribute('aria-label', 'Als Nächstes');
  panel.dataset.headerAgendaPopover = '';
  panel.hidden = false;

  const head = panel.querySelector('.va-agenda-head');
  if (head && !head.querySelector('[data-header-agenda-close]')) {
    const actions = document.createElement('div');
    actions.className = 'va-agenda-head-actions';
    const count = head.querySelector('.va-agenda-count');
    if (count) actions.append(count);
    actions.insertAdjacentHTML('beforeend', `<button class="va-agenda-close" type="button" data-header-agenda-close aria-label="Als Nächstes schliessen"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg></button>`);
    head.append(actions);
  }
  return panel;
}

function activeTrigger() {
  const preferred = root?.querySelector(`[data-agenda-variant="${state.returnVariant}"]`);
  if (visible(preferred)) return preferred;
  return [...(root?.querySelectorAll('[data-header-agenda-toggle]') ?? [])].find(visible) ?? null;
}

function positionPanel() {
  if (!state.open || !state.panel) return;
  const trigger = activeTrigger();
  if (!trigger) return;

  const margin = 8;
  const rect = trigger.getBoundingClientRect();
  const width = Math.min(430, window.innerWidth - margin * 2);
  state.panel.style.width = `${width}px`;

  const compact = matchMedia('(max-width: 1100px)').matches;
  const left = compact ? margin : Math.max(margin, Math.min(rect.left, window.innerWidth - width - margin));
  state.panel.style.left = `${left}px`;

  const height = state.panel.offsetHeight;
  const below = rect.bottom + 7;
  const above = rect.top - height - 7;
  const top = below + height <= window.innerHeight - margin ? below : Math.max(margin, above);
  state.panel.style.top = `${top}px`;
}

function closeAgenda({ restoreFocus = false } = {}) {
  state.open = false;
  if (state.panel) state.panel.hidden = true;
  if (state.layer) state.layer.hidden = true;
  ensureTriggers();
  if (root) root.dataset.visibleAgendaPanels = '0';
  if (restoreFocus) requestAnimationFrame(() => activeTrigger()?.focus({ preventScroll: true }));
}

function openAgenda(trigger) {
  if (trigger?.dataset.agendaVariant) state.returnVariant = trigger.dataset.agendaVariant;
  state.open = true;
  sync();
  requestAnimationFrame(() => state.panel?.querySelector('[data-header-agenda-close]')?.focus({ preventScroll: true }));
}

function ensureAgenda() {
  if (!state.open) {
    closeAgenda();
    return;
  }

  const freshPanel = sourcePanel();
  if (freshPanel && freshPanel !== state.panel) {
    content?.querySelectorAll('.va-agenda-panel').forEach((panel) => {
      if (panel !== freshPanel) panel.remove();
    });
    state.panel?.remove();
    state.panel = preparePanel(freshPanel);
    ensureLayer().append(state.panel);
  }

  if (!state.panel) return;
  ensureLayer();
  state.panel.hidden = false;
  ensureTriggers();
  positionPanel();
  if (root) {
    root.dataset.visibleAgendaPanels = '1';
    root.dataset.permanentAgendaContainerCount = '0';
    root.dataset.legacyHeaderContextCount = '0';
  }
}

function sync() {
  state.scheduled = false;
  ensureTriggers();
  ensureAgenda();
}

function scheduleSync() {
  if (state.scheduled) return;
  state.scheduled = true;
  requestAnimationFrame(sync);
}

root?.addEventListener('click', (event) => {
  const trigger = event.target.closest('[data-header-agenda-toggle]');
  if (!trigger) return;
  event.preventDefault();
  if (state.open) closeAgenda({ restoreFocus: true });
  else openAgenda(trigger);
});

document.addEventListener('click', (event) => {
  if (!state.open) return;
  if (event.target.closest('[data-header-agenda-close]')) {
    event.preventDefault();
    closeAgenda({ restoreFocus: true });
    return;
  }
  if (event.target.closest('[data-agenda-appointment-id], [data-book-gap]')) {
    queueMicrotask(() => closeAgenda());
  }
}, true);

document.addEventListener('pointerdown', (event) => {
  if (!state.open) return;
  if (event.target.closest('[data-header-agenda-toggle], [data-header-agenda-popover]')) return;
  closeAgenda();
});

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape' || !state.open) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  closeAgenda({ restoreFocus: true });
}, true);

window.addEventListener('resize', scheduleSync, { passive: true });
window.addEventListener('gasserwerk:agenda-projection-updated', scheduleSync);

const observer = new MutationObserver(scheduleSync);
if (root) observer.observe(root, { subtree: true, childList: true, characterData: true });

scheduleSync();
