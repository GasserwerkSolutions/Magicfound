function personNameVariants(fullName) {
  const parts = String(fullName || '').trim().split(/\s+/).filter(Boolean);
  const first = parts[0] ?? '';
  const last = parts.at(-1) ?? '';
  const initials = parts.slice(0, 2).map((part) => part[0]).join('').toLocaleUpperCase('de-CH');
  return {
    full: parts.join(' '),
    medium: last && last !== first ? `${first} ${last[0]}.` : first,
    first,
    initials
  };
}

function serviceVariant(fullService, width) {
  const value = String(fullService || '').trim();
  if (width >= 160) return value;
  const firstMeaningful = value.split(/\s*&\s*|\s*\+\s*/)[0]?.trim();
  return firstMeaningful || value;
}

function classifyCard(card) {
  const copy = card.querySelector('.va-card-copy');
  const nameNode = copy?.querySelector('strong');
  const serviceNode = copy?.querySelector('small');
  const initialsNode = card.querySelector('.va-card-initials');
  if (!nameNode || !initialsNode) return;

  card.dataset.fullCustomerName ||= nameNode.textContent.trim();
  if (serviceNode) card.dataset.fullServiceName ||= serviceNode.textContent.trim();
  const rect = card.getBoundingClientRect();
  if (!rect.width || !rect.height) return;

  let tier = 'full';
  if (rect.width < 58 || rect.height < 22) tier = 'initials';
  else if (rect.width < 86 || rect.height < 30) tier = 'first';
  else if (rect.width < 118 || rect.height < 41) tier = 'name';
  else if (rect.width < 164 || rect.height < 56) tier = 'time-name';

  const variants = personNameVariants(card.dataset.fullCustomerName);
  const nextName = tier === 'full' ? variants.full : tier === 'time-name' ? variants.medium : tier === 'name' ? variants.medium : variants.first;
  const nextInitials = variants.initials;
  setText(nameNode, nextName);
  setText(initialsNode, nextInitials);
  if (serviceNode) setText(serviceNode, serviceVariant(card.dataset.fullServiceName, rect.width));
  card.dataset.contentTier = tier;
}

function ensureCardObserver() {
  if (!state.cardObserver) {
    state.cardObserver = new ResizeObserver((entries) => {
      for (const entry of entries) classifyCard(entry.target);
      updateCardDiagnostics();
    });
  }
  root?.querySelectorAll('.va-appointment').forEach((card) => {
    if (state.observedCards.has(card)) return;
    state.observedCards.add(card);
    state.cardObserver.observe(card);
    classifyCard(card);
  });
}

function updateCardDiagnostics() {
  if (!root) return;
  const cards = [...root.querySelectorAll('.va-appointment')];
  const classified = cards.filter((card) => card.dataset.contentTier).length;
  root.dataset.cardSemanticTruncation = cards.length > 0 && classified === cards.length ? '1' : '0';
}

function ensureStaffHeaderNames() {
  root?.querySelectorAll('.va-staff-head').forEach((button) => {
    const nameNode = button.querySelector('strong');
    if (!nameNode) return;
    button.dataset.fullStaffName ||= nameNode.textContent.trim();
    const variants = personNameVariants(button.dataset.fullStaffName);
    const next = matchMedia('(max-width: 900px)').matches ? variants.first : variants.full;
    setText(nameNode, next);
    button.dataset.semanticStaffName = next;
  });
}

function enhanceCalendarStructure() {
  const panel = root?.querySelector('.va-calendar-panel');
  if (!panel) return null;
  let viewport = panel.querySelector(':scope > .va-calendar-viewport');
  if (!viewport) {
    const head = panel.querySelector(':scope > .va-calendar-head');
    const scroll = panel.querySelector(':scope > .va-calendar-scroll');
    if (!head || !scroll) return null;
    viewport = document.createElement('div');
    viewport.className = 'va-calendar-viewport';
    viewport.dataset.calendarViewport = '';
    panel.insertBefore(viewport, head);
    viewport.append(head, scroll);
  }

  if (state.viewport !== viewport) {
    state.viewport = viewport;
    bindCalendarViewport(viewport);
    requestAnimationFrame(() => requestAnimationFrame(() => restoreOrPositionCalendar(viewport)));
  }
  return viewport;
}
