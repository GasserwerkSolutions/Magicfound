import { DashboardEvent, createDashboardEvent } from '../data/contracts/events.js';

export const DASHBOARD_NAVIGATION = Object.freeze([
  { id: 'tagesplan', label: 'Tagesplan', href: '../tagesplan/', icon: 'calendar' },
  { id: 'termine', label: 'Termine', href: '../termine/', icon: 'list' },
  { id: 'kundschaft', label: 'Kundschaft', href: '../kundschaft/', icon: 'customers' },
  { id: 'team', label: 'Team', href: '../team/', icon: 'team' },
  { id: 'angebot', label: 'Angebot', href: '../angebot/', icon: 'services' },
  { id: 'verwaltung', label: 'Verwaltung', href: '../verwaltung/', icon: 'settings' }
]);

const iconPaths = Object.freeze({
  calendar: '<path d="M4 6.5h16v13H4zM7 3v6M17 3v6M4 10h16"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
  customers: '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3.5 19c.5-4 2.3-6 5.5-6s5 2 5.5 6M14 14c3.4-.4 5.5 1.3 6 5"/>',
  team: '<circle cx="8" cy="8" r="3"/><circle cx="16.5" cy="8.5" r="2.5"/><path d="M2.5 19c.5-4.1 2.4-6.1 5.5-6.1s5 2 5.5 6.1M13 14c3.5-.6 5.9 1 6.5 5"/>',
  services: '<path d="M5 4h14v16H5zM8 8h8M8 12h8M8 16h5"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>'
});

export function shellIcon(name, className = '') {
  const path = iconPaths[name] ?? iconPaths.calendar;
  return `<svg class="${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
}

function navigationMarkup(activePage) {
  return DASHBOARD_NAVIGATION.map((item) => `
    <a class="gw-nav-link ${item.id === activePage ? 'is-active' : ''}" href="${item.href}" data-navigation-id="${item.id}" ${item.id === activePage ? 'aria-current="page"' : ''}>
      ${shellIcon(item.icon, 'gw-nav-icon')}
      <span>${item.label}</span>
    </a>
  `).join('');
}

function mobileNavigationMarkup(activePage) {
  return DASHBOARD_NAVIGATION.slice(0, 5).map((item) => `
    <a class="gw-mobile-nav-link ${item.id === activePage ? 'is-active' : ''}" href="${item.href}" data-navigation-id="${item.id}" ${item.id === activePage ? 'aria-current="page"' : ''}>
      ${shellIcon(item.icon, 'gw-mobile-nav-icon')}
      <span>${item.label}</span>
    </a>
  `).join('');
}

function emitShellEvent(target, type, payload) {
  target.dispatchEvent(new CustomEvent('gasserwerk:event', {
    bubbles: true,
    detail: createDashboardEvent(type, payload, { source: 'dashboard-shell' })
  }));
}

/**
 * Creates the shared, framework-neutral product shell around a page-owned work area.
 * The page owns only the content inside `refs.content` and its page-specific events.
 */
export function createDashboardShell(root, options = {}) {
  if (!(root instanceof HTMLElement)) throw new TypeError('createDashboardShell requires a root HTMLElement');

  const activePage = options.activePage ?? 'tagesplan';
  const title = options.title ?? 'Gasserwerk';
  const kicker = options.kicker ?? 'Salonbetrieb';
  const context = options.context ?? '';
  const primaryActionLabel = options.primaryActionLabel ?? '';
  const searchable = options.searchable !== false;

  root.innerHTML = `
    <div class="gw-app-shell">
      <aside class="gw-sidebar" aria-label="Produktnavigation">
        <div class="gw-product-signature"><span class="gw-product-mark">G</span><span>Gasserwerk</span></div>
        <section class="gw-salon-identity" aria-label="Aktiver Salon">
          <h2>${options.salonName ?? 'Coiffure Sonnegg'}</h2>
          <p>${options.locationLabel ?? 'Zürich Enge'}</p>
        </section>
        <nav class="gw-primary-nav">${navigationMarkup(activePage)}</nav>
        <div class="gw-sidebar-spacer"></div>
        <section class="gw-location-card"><span>Standort</span><strong>${options.locationLabel ?? 'Zürich Enge'}</strong></section>
        <section class="gw-account-card"><span class="gw-account-avatar">${options.accountInitials ?? 'MS'}</span><span><strong>${options.accountName ?? 'Melanie Schneider'}</strong><small>${options.accountRole ?? 'Inhaberin'}</small></span></section>
      </aside>

      <section class="gw-workspace">
        <header class="gw-product-header">
          <div class="gw-heading-area">
            <span class="gw-page-kicker">${kicker}</span>
            <div class="gw-page-title-row">
              <h1 id="gw-page-title">${title}</h1>
              <span id="gw-page-context" class="gw-page-context">${context}</span>
            </div>
          </div>
          <div class="gw-header-search" ${searchable ? '' : 'hidden'}>
            ${shellIcon('search', 'gw-search-icon')}
            <input id="gw-global-search" type="search" autocomplete="off" placeholder="Kundin, Termin oder freie Zeit suchen" aria-label="Suchen">
            <kbd>⌘K</kbd>
          </div>
          <div id="gw-header-actions" class="gw-header-actions">
            ${primaryActionLabel ? `<button id="gw-primary-action" class="gw-button gw-button-primary" type="button">${shellIcon('plus')}<span>${primaryActionLabel}</span></button>` : ''}
          </div>
        </header>
        <main id="gw-page-content" class="gw-page-content" tabindex="-1"></main>
      </section>

      <nav class="gw-mobile-navigation" aria-label="Mobile Produktnavigation">${mobileNavigationMarkup(activePage)}</nav>
      <div id="gw-shell-live-region" class="gw-visually-hidden" aria-live="polite" aria-atomic="true"></div>
    </div>
  `;

  const refs = Object.freeze({
    content: root.querySelector('#gw-page-content'),
    title: root.querySelector('#gw-page-title'),
    context: root.querySelector('#gw-page-context'),
    headerActions: root.querySelector('#gw-header-actions'),
    primaryAction: root.querySelector('#gw-primary-action'),
    searchInput: root.querySelector('#gw-global-search'),
    liveRegion: root.querySelector('#gw-shell-live-region')
  });

  root.querySelectorAll('[data-navigation-id]').forEach((link) => {
    link.addEventListener('click', () => {
      emitShellEvent(root, DashboardEvent.SHELL_NAVIGATE_REQUESTED, {
        pageId: link.dataset.navigationId,
        href: link.getAttribute('href')
      });
    });
  });

  refs.primaryAction?.addEventListener('click', () => options.onPrimaryAction?.());
  refs.searchInput?.addEventListener('focus', () => emitShellEvent(root, DashboardEvent.SEARCH_OPENED, { pageId: activePage }));
  refs.searchInput?.addEventListener('input', (event) => options.onSearch?.(event.target.value));
  refs.searchInput?.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.currentTarget.value = '';
      options.onSearch?.('');
      event.currentTarget.blur();
      emitShellEvent(root, DashboardEvent.SEARCH_CLOSED, { pageId: activePage });
    }
  });

  const keyboardShortcut = (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k' && refs.searchInput) {
      event.preventDefault();
      refs.searchInput.focus();
    }
  };
  document.addEventListener('keydown', keyboardShortcut);

  return Object.freeze({
    refs,
    setTitle(value) { refs.title.textContent = value; },
    setTitleContent(value) { refs.title.innerHTML = value; },
    setContext(value) { refs.context.textContent = value; },
    setContextContent(value) { refs.context.innerHTML = value; },
    setHeaderActions(markup) { refs.headerActions.innerHTML = markup; },
    announce(message) {
      refs.liveRegion.textContent = '';
      requestAnimationFrame(() => { refs.liveRegion.textContent = message; });
    },
    destroy() { document.removeEventListener('keydown', keyboardShortcut); }
  });
}
