# ADR-005 · Aufklappbare Kopfzeilenagenda „Als Nächstes“

Status: **Akzeptiert – Umsetzung in der vertikalen Tagesplanreferenz**  
Datum: 2026-08-24  
Betroffene Bereiche: Tagesplankopf, operative Agenda, Kalenderbreite, Responsive Verhalten

## Kontext

ADR-004 führt die vertikale Team-Tagesfläche mit globaler vergangener Zeitfläche, horizontaler Jetzt-Linie und Personenfokus ohne Geometriewechsel ein.

Die erste Umsetzung positionierte die operative Agenda dauerhaft rechts neben dem Kalender beziehungsweise auf Mobilgeräten oberhalb der Teamfläche. Inhaltlich war die Agenda richtig, räumlich belegte sie jedoch dauerhaft einen erheblichen Teil der Arbeitsfläche. Gerade auf 14-Zoll-Viewports wurde die zusätzliche Reihenfolgeinformation mit schmaleren Mitarbeitendenspalten bezahlt.

Gleichzeitig wiederholte der sichtbare Kopfzeilenkontext

```text
Zürich Enge · 08:00–18:00
```

Informationen, die bereits an stabileren Orten vorhanden sind:

- Standort in der Betriebsinformation der Seitenleiste,
- Öffnung und Schliessung in der vertikalen Zeitachse.

## Entscheidung

### 1. „Als Nächstes“ ersetzt den Tagesplankontext

Im Tagesplankopf wird der sichtbare Text `Zürich Enge · 08:00–18:00` vollständig durch den Auslöser **Als Nächstes** ersetzt.

Der Auslöser zeigt:

- die feste Bezeichnung `Als Nächstes`,
- eine kompakte Vorschau des operativ nächsten Eintrags,
- einen eindeutigen Öffnungszustand über `aria-expanded` und Chevron.

Ist ein Termin aktiv, lautet die Vorschau sinngemäss `Jetzt · Kundschaft`. Besteht kein laufender Termin, werden Startzeit und Kundschaft des nächsten Termins gezeigt. Nach Tagesende wird `Tag abgeschlossen` angezeigt.

### 2. Keine permanente Agenda-Fläche

Die Agenda ist im geschlossenen Zustand vollständig aus dem Layout entfernt.

Verbindlich:

- keine rechte Agenda-Spalte,
- keine Agenda unter dem Kalender auf Tablet,
- keine dauerhaft vorangestellte Agenda auf Mobilgeräten,
- die Team-Tagesfläche nutzt die gesamte verbleibende Kalenderbreite,
- das Öffnen der Agenda verändert weder Spaltenbreiten noch Kalendergeometrie noch Scrollposition.

### 3. Nicht-modales Kopfzeilen-Popover

Die bestehende Agenda wird beim Öffnen als nicht-modales Popover an den sichtbaren Kopfzeilenauslöser gebunden.

- Desktop: Auslöser im bisherigen Kontextbereich neben dem Datum.
- Tablet und Mobilgerät: kompakter Auslöser in den Kopfaktionen.
- maximale Breite ungefähr 430 Pixel,
- maximale Höhe an den Viewport gebunden,
- eigener interner Scrollbereich,
- Schliessen über Auslöser, Schliessen-Schaltfläche, `Escape` oder Aussenklick,
- Fokus kehrt nach `Escape` oder explizitem Schliessen zum auslösenden Element zurück,
- ein Termin aus dem Popover öffnet denselben Terminkontext wie die Kalenderkarte.

Die Agenda wird nicht dupliziert. Das vorhandene Agendaelement wird in die Popover-Ebene verschoben, sodass vorhandene Auswahl- und Buchungsinteraktionen erhalten bleiben.

### 4. Kontrollierter Dreiton-Test

Die gewünschte Unterscheidung von vorherigem, laufendem und folgendem Termin wird als begrenzter Vergleichstest ausschliesslich im Agenda-Popover umgesetzt.

- `Davor`: neutral und leicht zurückgenommen,
- `Jetzt`: ruhig grünlich betont,
- `Danach`: helle, leicht warme Zukunftsfläche.

Diese Töne:

- sind keine Terminstatusfarben,
- verändern keine Kalenderkarte,
- ersetzen nicht die globale vergangene Zeitfläche,
- dienen nur der schnelleren Erfassung der chronologischen Gruppen.

Im Kalender bleibt ADR-004 unverändert: Vergangenheit wird durch eine einzige globale 5-Prozent-Zeitfläche, Gegenwart durch die Jetzt-Linie und Zukunft durch die unveränderte Fläche kommuniziert.

### 5. Gemeinsame Daten- und Auswahlwahrheit

Kalender und Popoveragenda verwenden dieselben normalisierten Terminobjekte.

- Suche wirkt auf beide Flächen.
- Personenfokus filtert die Agenda auf die fokussierte Person.
- Kalenderauswahl markiert denselben Agendaeintrag.
- Agendaauswahl öffnet denselben Terminkontext.
- Die nächste freie Lücke verwendet dieselbe Belegungsberechnung wie zuvor.
- Es entsteht keine zweite Datenquelle und keine zweite Statuslogik.

### 6. Diagnostik und Regression

Für den deterministischen Browserlauf öffnet `?verify=1` die Agenda automatisch. Der normale Produktzustand bleibt geschlossen.

Zusätzlich werden geprüft:

- alter Kopfzeilenkontext ist nicht sichtbar,
- permanenter Agenda-Container ist nicht sichtbar,
- genau ein Agenda-Popover ist im Prüfzustand sichtbar,
- fünf Mitarbeitendenspalten bleiben vorhanden,
- horizontaler Gesamtseitenüberlauf bleibt null,
- `Davor`, `Jetzt` und `Danach` sind im Popover vorhanden,
- keine Dreiton-Klassen werden auf Kalenderkarten eingeführt.

## Invarianten

- ADR-004 bleibt für Zeitfläche, Jetzt-Linie, Karten und Personenfokus verbindlich.
- Standort bleibt in der Seitenleiste sichtbar.
- Öffnungszeiten bleiben durch die Zeitachse verständlich.
- Agendaöffnung ist ein temporärer Kontext, kein Ansichtswechsel.
- Backendpersistenz wird weiterhin nicht simuliert.
- Die separate Seite `Termine` bleibt das Register für Suche, Filter, Historie und grössere Zeiträume.

## Konsequenz

Die vertikale Teamfläche gewinnt die zuvor von der Agenda belegte Breite zurück. Die operative Reihenfolge bleibt mit einem einzigen Kopfzeilenaufruf erreichbar. Der Dreiton-Versuch wird dort geprüft, wo er semantisch eindeutig ist, ohne das ruhigere globale Zeitmodell des Kalenders zu beschädigen.
