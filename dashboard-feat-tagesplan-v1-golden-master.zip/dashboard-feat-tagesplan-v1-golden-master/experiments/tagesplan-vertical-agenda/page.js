import { createDashboardShellV2, shellIconV2 } from '../../src/shell/dashboard-shell-v2.js';
import { createMockDashboardDataSourceV1 } from '../../src/data/mock-dashboard-data-source-v1.js';
import { Capability, hasCapability } from '../../src/data/contracts/capabilities.js';
import { DashboardEvent, createDashboardEvent } from '../../src/data/contracts/events.js';
import { AppointmentStatus, OperationalKind } from '../../src/data/contracts/domain-values.js';

const OPEN_MINUTE = 480;
const CLOSE_MINUTE = 1080;
const DAY_DURATION = CLOSE_MINUTE - OPEN_MINUTE;
const CLOCK_TICK_MS = 15_000;
const AGENDA_UPCOMING_LIMIT = 5;
const PRIMARY_TIME_ANCHORS = new Set([540, 720, 900, 1080]);
const VISIBLE_CARD_TIME_MINUTES = 45;

const STATUS_LABEL = Object.freeze({
  [AppointmentStatus.CONFIRMED]: 'Bestätigt',
  [AppointmentStatus.PENDING]: 'Offen',
  [AppointmentStatus.ARRIVED]: 'Im Salon',
  [AppointmentStatus.COMPLETED]: 'Abgeschlossen',
  [AppointmentStatus.CANCELLED]: 'Abgesagt',
  [AppointmentStatus.NO_SHOW]: 'Fehlt'
});

const root = document.querySelector('#dashboard-root');
const dataSource = createMockDashboardDataSourceV1();
const query = new URLSearchParams(location.search);

const state = {
  session: null,
  plan: null,
  date: null,
  search: '',
  selectedAppointmentId: null,
  focusedStaffId: null,
  loading: true,
  error: null,
  overlay: null,
  overlayOrigin: null
};

let renderFrame = 0;
let clockTimer = 0;
let resizeTimer = 0;

const shell = createDashboardShellV2(root, {
  activePage: 'tagesplan',
  navigationBase: '../../pages',
  todayHref: './',
  title: 'Tagesplan',
  kicker: 'Salonbetrieb',
  context: 'Zürich Enge',
  primaryActionLabel: 'Termin',
  onPrimaryAction: () => openBookingPanel({ source: 'day-plan-header' }),
  onClockActivate: () => returnToToday(),
  onSearch: (value) => {
    state.search = value.trim();
    scheduleRender();
  }
});

shell.refs.content.classList.add('va-page-host');

function emit(type, payload, source = 'tagesplan-vertical-agenda') {
  root.dispatchEvent(new CustomEvent('gasserwerk:event', {
    bubbles: true,
    detail: createDashboardEvent(type, payload, { source })
  }));
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function formatTime(minute) {
  const normalized = clamp(Math.round(minute), 0, 1439);
  return `${String(Math.floor(normalized / 60)).padStart(2, '0')}:${String(normalized % 60).padStart(2, '0')}`;
}

function zurichDateParts(instant = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Zurich',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(instant);
  return Object.fromEntries(parts.map((part) => [part.type, part.value]));
}

function todayIso() {
  const parts = zurichDateParts();
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function dateFromIso(value) {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day, 12));
}

function formatDate(value, compact = false) {
  const options = compact
    ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'short' }
    : { timeZone: 'Europe/Zurich', weekday: 'long', day: 'numeric', month: 'long' };
  return new Intl.DateTimeFormat('de-CH', options)
    .format(dateFromIso(value))
    .replace(/\.,\s*/, ' ');
}

function formatHeaderDate(value) {
  const options = isMobileLayout()
    ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'numeric' }
    : matchMedia('(max-width: 1450px)').matches
      ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'short' }
      : { timeZone: 'Europe/Zurich', weekday: 'long', day: 'numeric', month: 'long' };
  return new Intl.DateTimeFormat('de-CH', options)
    .format(dateFromIso(value))
    .replace(/\.,\s*/, ' ');
}

function formatMoney(price) {
  if (!price || !Number.isFinite(price.amount)) return 'Nicht hinterlegt';
  return new Intl.NumberFormat('de-CH', {
    style: 'currency',
    currency: price.currency ?? 'CHF',
    maximumFractionDigits: 0
  }).format(price.amount);
}

function referenceMinuteOverride() {
  const value = query.get('referenceNow');
  if (!value || !/^\d{1,2}:\d{2}$/.test(value)) return null;
  const [hour, minute] = value.split(':').map(Number);
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  return hour * 60 + minute;
}

function currentSalonMinute() {
  const override = referenceMinuteOverride();
  if (override != null) return override;
  const parts = Object.fromEntries(new Intl.DateTimeFormat('de-CH', {
    timeZone: 'Europe/Zurich',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).formatToParts(new Date()).map((part) => [part.type, part.value]));
  return Number(parts.hour) * 60 + Number(parts.minute);
}

function isToday() {
  return state.date === todayIso();
}

function isMobileLayout() {
  return matchMedia('(max-width: 760px), (max-width: 900px) and (max-height: 600px), (pointer: coarse) and (max-height: 820px)').matches;
}

function can(capability) {
  return hasCapability(state.session, capability);
}

function itemEnd(item) {
  return item.startMinute + item.durationMinutes;
}

function minutePercent(minute) {
  return clamp((minute - OPEN_MINUTE) / DAY_DURATION * 100, 0, 100);
}

function appointmentById(id) {
  return state.plan?.appointments.find((appointment) => appointment.id === id) ?? null;
}

function personById(id) {
  return state.plan?.staff.find((person) => person.id === id) ?? null;
}

function appointmentsForStaff(staffId) {
  return state.plan.appointments
    .filter((item) => item.staff.id === staffId)
    .sort((a, b) => a.startMinute - b.startMinute || a.durationMinutes - b.durationMinutes);
}

function timelineItemsForStaff(staffId) {
  const appointments = appointmentsForStaff(staffId);
  const blocks = state.plan.operationalBlocks.filter((item) => item.staff.id === staffId);
  return [...appointments, ...blocks].sort((a, b) => a.startMinute - b.startMinute || itemEnd(a) - itemEnd(b));
}

function layoutTimelineItems(items) {
  const laneEnds = [];
  const positioned = items.map((item) => {
    const freeLane = laneEnds.findIndex((endMinute) => endMinute <= item.startMinute);
    const laneIndex = freeLane >= 0 ? freeLane : laneEnds.length;
    laneEnds[laneIndex] = itemEnd(item);
    return { item, laneIndex };
  });
  return { items: positioned, laneCount: Math.max(1, laneEnds.length) };
}

function appointmentInitials(displayName) {
  return displayName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toLocaleUpperCase('de-CH');
}

function matchesSearch(item) {
  if (!state.search) return true;
  const text = item.kind === 'appointment'
    ? `${item.customer.displayName} ${item.service.displayName} ${item.staff.displayName} ${item.note ?? ''}`
    : `${item.label} ${item.staff.displayName} ${item.note ?? ''}`;
  return text.toLocaleLowerCase('de-CH').includes(state.search.toLocaleLowerCase('de-CH'));
}

function appointmentDensity(durationMinutes) {
  if (durationMinutes <= 30) return 'is-micro';
  if (durationMinutes < 60) return 'is-compact';
  if (durationMinutes < 90) return 'is-standard';
  return 'is-long';
}

function searchClass(item) {
  if (!state.search) return '';
  return matchesSearch(item) ? 'is-search-hit' : 'is-search-muted';
}

function visibleStaff() {
  return state.plan?.staff ?? [];
}

function agendaStaff() {
  if (!state.focusedStaffId) return state.plan?.staff ?? [];
  return (state.plan?.staff ?? []).filter((person) => person.id === state.focusedStaffId);
}

function relevantAppointments() {
  const staffIds = new Set(agendaStaff().map((person) => person.id));
  return state.plan.appointments
    .filter((appointment) => staffIds.has(appointment.staff.id))
    .filter(matchesSearch)
    .filter((appointment) => appointment.status !== AppointmentStatus.CANCELLED)
    .sort((a, b) => a.startMinute - b.startMinute || a.staff.displayName.localeCompare(b.staff.displayName, 'de-CH'));
}

function globalAgendaModel() {
  const appointments = relevantAppointments();
  const now = isToday() ? currentSalonMinute() : OPEN_MINUTE - 1;
  const previous = isToday()
    ? appointments
      .filter((appointment) => itemEnd(appointment) <= now)
      .sort((a, b) => itemEnd(b) - itemEnd(a))[0] ?? null
    : null;
  const current = isToday()
    ? appointments
      .filter((appointment) => appointment.startMinute <= now && itemEnd(appointment) > now)
      .filter((appointment) => ![AppointmentStatus.COMPLETED, AppointmentStatus.CANCELLED, AppointmentStatus.NO_SHOW].includes(appointment.status))
    : [];
  const upcoming = appointments
    .filter((appointment) => appointment.startMinute > now)
    .slice(0, AGENDA_UPCOMING_LIMIT);
  return { previous, current, upcoming, now };
}

function nextFreeGap(minimumDuration = 30) {
  const now = isToday() ? Math.max(OPEN_MINUTE, Math.ceil(currentSalonMinute() / 15) * 15) : OPEN_MINUTE;
  let best = null;
  for (const person of agendaStaff()) {
    const busy = timelineItemsForStaff(person.id)
      .filter((item) => item.kind !== 'appointment' || item.status !== AppointmentStatus.CANCELLED)
      .map((item) => ({ start: item.startMinute, end: itemEnd(item) }))
      .filter((item) => item.end > now)
      .sort((a, b) => a.start - b.start);

    let cursor = now;
    let candidate = null;
    for (const item of busy) {
      if (item.start - cursor >= minimumDuration) {
        candidate = { person, start: cursor, end: item.start };
        break;
      }
      cursor = Math.max(cursor, item.end);
    }
    if (!candidate && CLOSE_MINUTE - cursor >= minimumDuration) {
      candidate = { person, start: cursor, end: CLOSE_MINUTE };
    }
    if (candidate && (!best || candidate.start < best.start || (candidate.start === best.start && candidate.end - candidate.start > best.end - best.start))) {
      best = candidate;
    }
  }
  return best;
}

function renderHeader() {
  shell.setTitleContent(`
    <button class="va-header-date" type="button" data-open-date-picker aria-haspopup="dialog">
      <span>${formatHeaderDate(state.date)}</span>
      ${shellIconV2('calendar')}
    </button>
  `);
  shell.setContextContent(`<span>Zürich Enge · 08:00–18:00</span>`);

  const now = isToday() ? currentSalonMinute() : null;
  const currentLabel = now != null && now >= OPEN_MINUTE && now <= CLOSE_MINUTE
    ? `<span class="va-header-now">${formatTime(now)}</span>`
    : '';
  const primary = can(Capability.DAY_PLAN_CREATE_APPOINTMENT)
    ? `<button class="gw-button gw-button-primary" type="button" data-create-appointment>${shellIconV2('plus')}<span>Termin</span></button>`
    : '';
  shell.setHeaderActions(`${currentLabel}${primary}`);
}

function renderLoading() {
  shell.refs.content.innerHTML = `<section class="va-state-page" aria-busy="true"><div><strong>Tagesplan wird geladen</strong><span>Team, Termine und Agenda werden vorbereitet.</span></div></section>`;
}

function renderError() {
  shell.refs.content.innerHTML = `<section class="va-state-page"><div><strong>Tagesplan konnte nicht geladen werden</strong><span>${escapeHtml(state.error?.message ?? 'Unbekannter Fehler')}</span><button class="gw-button" type="button" data-retry>Erneut laden</button></div></section>`;
}

function renderForbidden() {
  shell.refs.content.innerHTML = `<section class="va-state-page"><div><strong>Tagesplan nicht verfügbar</strong><span>Die erforderliche Berechtigung fehlt.</span></div></section>`;
}

function timeLabelsMarkup() {
  const labels = [];
  for (let minute = OPEN_MINUTE; minute <= CLOSE_MINUTE; minute += 60) {
    const edgeClass = minute === OPEN_MINUTE ? 'is-start' : minute === CLOSE_MINUTE ? 'is-end' : '';
    const anchorClass = PRIMARY_TIME_ANCHORS.has(minute) ? 'is-primary-anchor' : '';
    labels.push(`<span class="va-time-label ${edgeClass} ${anchorClass}" style="top:${minutePercent(minute)}%">${formatTime(minute)}</span>`);
  }
  return labels.join('');
}

function statusNotice(appointment) {
  if (appointment.status === AppointmentStatus.PENDING) return '<span class="va-card-notice">Offen</span>';
  if (appointment.status === AppointmentStatus.NO_SHOW) return '<span class="va-card-notice">Fehlt</span>';
  return '';
}

function appointmentCardMarkup(appointment, laneIndex, laneCount) {
  const top = minutePercent(appointment.startMinute);
  const height = minutePercent(itemEnd(appointment)) - top;
  const laneWidth = 100 / laneCount;
  const left = laneIndex * laneWidth;
  const selected = state.selectedAppointmentId === appointment.id;
  const timeMarkup = appointment.durationMinutes >= VISIBLE_CARD_TIME_MINUTES
    ? `<span class="va-card-time">${formatTime(appointment.startMinute)}–${formatTime(itemEnd(appointment))}</span>`
    : '';
  return `
    <button
      class="va-appointment status-${appointment.status} ${appointmentDensity(appointment.durationMinutes)} ${searchClass(appointment)} ${selected ? 'is-selected' : ''}"
      style="top:${top}%;height:${height}%;left:calc(${left}% + 5px);width:calc(${laneWidth}% - 9px)"
      type="button"
      data-appointment-id="${appointment.id}"
      data-start-minute="${appointment.startMinute}"
      data-end-minute="${itemEnd(appointment)}"
      aria-label="${formatTime(appointment.startMinute)} bis ${formatTime(itemEnd(appointment))}, ${escapeHtml(appointment.customer.displayName)}, ${escapeHtml(appointment.service.displayName)}, ${escapeHtml(appointment.staff.displayName)}, ${STATUS_LABEL[appointment.status]}"
      aria-pressed="${selected}"
    >
      ${timeMarkup}
      <span class="va-card-initials" aria-hidden="true">${appointmentInitials(appointment.customer.displayName)}</span>
      <span class="va-card-copy"><strong>${escapeHtml(appointment.customer.displayName)}</strong><small>${escapeHtml(appointment.service.displayName)}</small></span>
      ${statusNotice(appointment)}
    </button>
  `;
}

function operationalCardMarkup(block, laneIndex, laneCount) {
  const top = minutePercent(block.startMinute);
  const height = minutePercent(itemEnd(block)) - top;
  const laneWidth = 100 / laneCount;
  const left = laneIndex * laneWidth;
  const timeMarkup = block.durationMinutes >= VISIBLE_CARD_TIME_MINUTES
    ? `<small class="va-operational-time">${formatTime(block.startMinute)}–${formatTime(itemEnd(block))}</small>`
    : '';
  return `
    <button
      class="va-operational kind-${block.kind} ${searchClass(block)}"
      style="top:${top}%;height:${height}%;left:calc(${left}% + 5px);width:calc(${laneWidth}% - 9px)"
      type="button"
      data-operational-id="${block.id}"
      aria-label="${formatTime(block.startMinute)} bis ${formatTime(itemEnd(block))}, ${escapeHtml(block.label)}, ${escapeHtml(block.staff.displayName)}"
    >${timeMarkup}<span>${escapeHtml(block.label)}</span></button>
  `;
}

function staffHeaderMarkup(person) {
  const focused = state.focusedStaffId === person.id;
  const contextual = Boolean(state.focusedStaffId && !focused);
  return `
    <button class="va-staff-head ${focused ? 'is-focused' : ''} ${contextual ? 'is-context' : ''}" type="button" data-focus-staff="${person.id}" aria-pressed="${focused}" aria-label="${focused ? 'Personenfokus aufheben' : `Auf ${escapeHtml(person.displayName)} fokussieren`}">
      <span class="va-staff-avatar">${person.initials}</span>
      <span><strong>${escapeHtml(person.displayName)}</strong><small>${escapeHtml(person.professionalRoleLabel)}</small></span>
    </button>
  `;
}

function temporalSurfaceMarkup() {
  if (!isToday()) return '';
  const minute = currentSalonMinute();
  if (minute < OPEN_MINUTE || minute > CLOSE_MINUTE) return '';
  const position = minutePercent(minute);
  return `
    <div class="va-past-shade" style="height:${position}%" aria-hidden="true"></div>
    <div class="va-now-line" style="top:${position}%"><span>${formatTime(minute)}</span></div>
  `;
}

function renderCalendar() {
  const people = visibleStaff();
  const tracks = people.map((person) => {
    const layout = layoutTimelineItems(timelineItemsForStaff(person.id));
    const focused = state.focusedStaffId === person.id;
    const contextual = Boolean(state.focusedStaffId && !focused);
    const cards = layout.items.map(({ item, laneIndex }) => item.kind === 'appointment'
      ? appointmentCardMarkup(item, laneIndex, layout.laneCount)
      : operationalCardMarkup(item, laneIndex, layout.laneCount)
    ).join('');
    return `<div class="va-staff-track ${focused ? 'is-focused' : ''} ${contextual ? 'is-context' : ''}" data-staff-track="${person.id}" tabindex="0" role="button" aria-label="Freie Zeit bei ${escapeHtml(person.displayName)} auswählen">${cards}</div>`;
  }).join('');

  const returnToTeam = state.focusedStaffId
    ? `<button class="va-team-return" type="button" data-clear-staff-focus>${shellIconV2('back')}<span>Team</span></button>`
    : '<span>Zeit</span>';

  return `
    <section class="va-calendar-panel" aria-label="Vertikaler Tagesplan">
      <header class="va-calendar-head" style="--staff-count:${people.length}">
        <div class="va-time-corner">${returnToTeam}</div>
        ${people.map(staffHeaderMarkup).join('')}
      </header>
      <div class="va-calendar-scroll" data-calendar-scroll>
        <div class="va-calendar-grid" style="--staff-count:${people.length}" data-temporal-model="surface-shadow">
          <div class="va-time-rail" aria-hidden="true">${timeLabelsMarkup()}</div>
          ${tracks}
          ${temporalSurfaceMarkup()}
        </div>
      </div>
    </section>
  `;
}

function agendaStatusMarkup(appointment, temporalRole) {
  if (temporalRole === 'current') return '<span class="va-agenda-status is-current">Läuft</span>';
  if (appointment.status === AppointmentStatus.PENDING) return '<span class="va-agenda-status">Offen</span>';
  if (appointment.status === AppointmentStatus.ARRIVED) return '<span class="va-agenda-status">Im Salon</span>';
  if (appointment.status === AppointmentStatus.NO_SHOW) return '<span class="va-agenda-status is-alert">Fehlt</span>';
  return '';
}

function agendaRowMarkup(appointment, temporalRole = '') {
  const selected = state.selectedAppointmentId === appointment.id;
  return `
    <button class="va-agenda-row ${selected ? 'is-selected' : ''}" type="button" data-agenda-appointment-id="${appointment.id}" aria-pressed="${selected}" aria-label="${formatTime(appointment.startMinute)} bis ${formatTime(itemEnd(appointment))}, ${escapeHtml(appointment.customer.displayName)}, ${escapeHtml(appointment.service.displayName)}, ${escapeHtml(appointment.staff.displayName)}">
      <span class="va-agenda-time">${formatTime(appointment.startMinute)}–${formatTime(itemEnd(appointment))}</span>
      <span class="va-agenda-copy"><strong>${escapeHtml(appointment.customer.displayName)}</strong><small>${escapeHtml(appointment.service.displayName)} · ${escapeHtml(appointment.staff.displayName.split(' ')[0])}</small></span>
      ${agendaStatusMarkup(appointment, temporalRole)}
    </button>
  `;
}

function agendaSectionMarkup(label, items, temporalRole = '') {
  if (!items.length) return '';
  return `
    <section class="va-agenda-section is-${temporalRole || 'upcoming'}" data-temporal-section="${temporalRole || 'upcoming'}">
      <h3>${label}</h3>
      <div>${items.map((item, index) => agendaRowMarkup(item, temporalRole === 'next' && index > 0 ? '' : temporalRole)).join('')}</div>
    </section>
  `;
}

function renderAgenda() {
  const model = globalAgendaModel();
  const gap = nextFreeGap(30);
  const context = state.focusedStaffId
    ? personById(state.focusedStaffId)?.displayName ?? 'Person'
    : 'Salonweit';
  const previous = model.previous ? [model.previous] : [];
  const current = model.current;
  const upcoming = model.upcoming;
  const empty = !previous.length && !current.length && !upcoming.length;

  return `
    <aside class="va-agenda-panel" aria-label="Als Nächstes">
      <header class="va-agenda-head"><div><span>Arbeitsfolge</span><h2>Als Nächstes</h2><small>${escapeHtml(context)}</small></div><span class="va-agenda-count">${current.length + upcoming.length}</span></header>
      <div class="va-agenda-scroll">
        ${agendaSectionMarkup('Davor', previous, 'before')}
        ${agendaSectionMarkup('Jetzt', current, 'current')}
        ${agendaSectionMarkup('Danach', upcoming, 'next')}
        ${empty ? '<div class="va-agenda-empty"><strong>Keine relevanten Termine</strong><span>Die Tagesfläche bleibt direkt buchbar.</span></div>' : ''}
      </div>
      ${gap ? `
        <button class="va-free-gap" type="button" data-book-gap data-staff-id="${gap.person.id}" data-start-minute="${gap.start}">
          <span>Nächste freie Lücke</span><strong>${formatTime(gap.start)}–${formatTime(gap.end)}</strong><small>${escapeHtml(gap.person.displayName)}</small>
        </button>
      ` : ''}
    </aside>
  `;
}

function renderMain() {
  const staffCount = visibleStaff().length;
  return `
    <section class="va-page ${state.focusedStaffId ? 'has-staff-focus' : ''}" data-visible-staff-count="${staffCount}">
      <span class="gw-visually-hidden" role="status">${state.plan.appointments.length} Termine · ${staffCount} sichtbare Mitarbeitende</span>
      <div class="va-mobile-agenda">${renderAgenda()}</div>
      <div class="va-desktop-layout">
        ${renderCalendar()}
        <div class="va-desktop-agenda">${renderAgenda()}</div>
      </div>
    </section>
    ${renderOverlay()}
  `;
}

function overlayTitle() {
  if (!state.overlay) return '';
  if (state.overlay.type === 'date') return 'Datum wählen';
  if (state.overlay.type === 'appointment') return 'Termin';
  if (state.overlay.type === 'operational') return 'Interne Zeit';
  return 'Termin eintragen';
}

function dateOverlayMarkup() {
  return `
    <form class="va-overlay-form" data-date-form>
      <label><span>Datum</span><input type="date" name="date" value="${state.date}" required></label>
      <div class="va-overlay-actions"><button class="gw-button" type="button" data-today>Heute</button><button class="gw-button gw-button-primary" type="submit">Öffnen</button></div>
    </form>
  `;
}

function appointmentOverlayMarkup() {
  const appointment = appointmentById(state.overlay.id);
  if (!appointment) return '<p>Der Termin ist nicht verfügbar.</p>';
  return `
    <div class="va-detail-list">
      <div><span>Zeit</span><strong>${formatTime(appointment.startMinute)}–${formatTime(itemEnd(appointment))}</strong></div>
      <div><span>Kundschaft</span><strong>${escapeHtml(appointment.customer.displayName)}</strong></div>
      <div><span>Dienstleistung</span><strong>${escapeHtml(appointment.service.displayName)}</strong></div>
      <div><span>Person</span><strong>${escapeHtml(appointment.staff.displayName)}</strong></div>
      <div><span>Status</span><strong>${STATUS_LABEL[appointment.status]}</strong></div>
      <div><span>Preis</span><strong>${formatMoney(appointment.price)}</strong></div>
      ${appointment.note ? `<div class="is-wide"><span>Notiz</span><strong>${escapeHtml(appointment.note)}</strong></div>` : ''}
    </div>
    ${can(Capability.APPOINTMENT_EDIT) ? `<button class="gw-button gw-button-primary va-full-button" type="button" data-edit-appointment="${appointment.id}">Termin bearbeiten</button>` : ''}
  `;
}

function operationalOverlayMarkup() {
  const block = state.plan.operationalBlocks.find((item) => item.id === state.overlay.id);
  if (!block) return '<p>Der Eintrag ist nicht verfügbar.</p>';
  return `
    <div class="va-detail-list">
      <div><span>Zeit</span><strong>${formatTime(block.startMinute)}–${formatTime(itemEnd(block))}</strong></div>
      <div><span>Art</span><strong>${block.kind === OperationalKind.BREAK ? 'Pause' : 'Interne Aufgabe'}</strong></div>
      <div><span>Person</span><strong>${escapeHtml(block.staff.displayName)}</strong></div>
      <div class="is-wide"><span>Bezeichnung</span><strong>${escapeHtml(block.label)}</strong></div>
    </div>
  `;
}

function bookingOverlayMarkup() {
  const staffId = state.overlay.staffId ?? state.focusedStaffId ?? state.plan.staff[0]?.id;
  const minute = Number.isFinite(state.overlay.startMinute)
    ? state.overlay.startMinute
    : clamp(isToday() ? Math.ceil(currentSalonMinute() / 15) * 15 : OPEN_MINUTE, OPEN_MINUTE, CLOSE_MINUTE - 15);
  return `
    <form class="va-overlay-form" data-booking-form>
      <label><span>Kundschaft</span><input name="customer" autocomplete="off" placeholder="Name" required></label>
      <label><span>Dienstleistung</span><input name="service" autocomplete="off" placeholder="Dienstleistung" required></label>
      <label><span>Person</span><select name="staff">${state.plan.staff.map((person) => `<option value="${person.id}" ${person.id === staffId ? 'selected' : ''}>${escapeHtml(person.displayName)}</option>`).join('')}</select></label>
      <div class="va-form-pair"><label><span>Datum</span><input type="date" name="date" value="${state.date}" required></label><label><span>Zeit</span><input type="time" name="time" value="${formatTime(minute)}" step="900" required></label></div>
      <button class="gw-button gw-button-primary va-full-button" type="submit">Terminabsicht übernehmen</button>
      <p class="va-reference-note">Referenzzustand: Es wird keine Backendpersistenz ausgeführt.</p>
    </form>
  `;
}

function renderOverlay() {
  if (!state.overlay) return '';
  const content = state.overlay.type === 'date'
    ? dateOverlayMarkup()
    : state.overlay.type === 'appointment'
      ? appointmentOverlayMarkup()
      : state.overlay.type === 'operational'
        ? operationalOverlayMarkup()
        : bookingOverlayMarkup();
  return `
    <div class="va-overlay-backdrop" data-overlay-backdrop>
      <section class="va-overlay-panel" role="dialog" aria-modal="true" aria-labelledby="va-overlay-title">
        <header><div><span>Gasserwerk</span><h2 id="va-overlay-title">${overlayTitle()}</h2></div><button type="button" data-close-overlay aria-label="Schliessen">${shellIconV2('close')}</button></header>
        <div class="va-overlay-body">${content}</div>
      </section>
    </div>
  `;
}


function updateDiagnostics() {
  if (query.get('verify') !== '1') return;
  requestAnimationFrame(() => {
    root.dataset.documentOverflowX = String(document.documentElement.scrollWidth - document.documentElement.clientWidth);
    root.dataset.visibleStaffTracks = String(shell.refs.content.querySelectorAll('.va-staff-track').length);
    root.dataset.visibleAgendaPanels = String([...shell.refs.content.querySelectorAll('.va-agenda-panel')].filter((node) => node.getClientRects().length).length);
    root.dataset.pastShadeCount = String(shell.refs.content.querySelectorAll('.va-past-shade').length);
    root.dataset.focusContextCount = String(shell.refs.content.querySelectorAll('.va-staff-track.is-context').length);
    root.dataset.visibleCardTimeCount = String(shell.refs.content.querySelectorAll('.va-card-time').length);
    root.dataset.prohibitedSequenceClassCount = String(shell.refs.content.querySelectorAll('[class*="is-sequence-"]').length);
  });
}

function render() {
  cancelAnimationFrame(renderFrame);
  renderFrame = requestAnimationFrame(() => {
    renderHeader();
    if (state.loading) renderLoading();
    else if (state.error) renderError();
    else if (!can(Capability.DAY_PLAN_VIEW)) renderForbidden();
    else shell.refs.content.innerHTML = renderMain();
    bindInteractions();
    updateDiagnostics();
  });
}

function scheduleRender() {
  render();
}

function rememberOrigin(kind, id = '') {
  state.overlayOrigin = { kind, id };
}

function openOverlay(overlay, origin = null) {
  if (origin) state.overlayOrigin = origin;
  state.overlay = overlay;
  scheduleRender();
  requestAnimationFrame(() => shell.refs.content.querySelector('[data-close-overlay]')?.focus());
}

function openAppointmentPanel(id, origin = { kind: 'appointment', id }) {
  const appointment = appointmentById(id);
  if (state.focusedStaffId && appointment && appointment.staff.id !== state.focusedStaffId) {
    state.focusedStaffId = appointment.staff.id;
    emit(DashboardEvent.DAY_STAFF_FOCUS_REQUESTED, {
      staffId: appointment.staff.id,
      date: state.date,
      presentation: 'lane-emphasis',
      source: 'appointment-selection'
    });
  }
  state.selectedAppointmentId = id;
  emit(DashboardEvent.APPOINTMENT_SELECTED, { appointmentId: id, date: state.date });
  openOverlay({ type: 'appointment', id }, origin);
}

function openBookingPanel(options = {}) {
  emit(DashboardEvent.APPOINTMENT_CREATE_REQUESTED, {
    date: state.date,
    staffId: options.staffId ?? null,
    startMinute: Number.isFinite(options.startMinute) ? options.startMinute : null,
    source: options.source ?? 'day-plan'
  });
  openOverlay({ type: 'booking', ...options }, options.origin ?? { kind: 'header-create' });
}

function closeOverlay({ restoreFocus = true } = {}) {
  const origin = state.overlayOrigin;
  state.overlay = null;
  state.overlayOrigin = null;
  scheduleRender();
  if (!restoreFocus || !origin) return;
  requestAnimationFrame(() => {
    if (origin.kind === 'agenda') shell.refs.content.querySelector(`[data-agenda-appointment-id="${origin.id}"]`)?.focus();
    else if (origin.kind === 'appointment') shell.refs.content.querySelector(`[data-appointment-id="${origin.id}"]`)?.focus();
    else if (origin.kind === 'staff') shell.refs.content.querySelector(`[data-focus-staff="${origin.id}"]`)?.focus();
    else if (origin.kind === 'operational') shell.refs.content.querySelector(`[data-operational-id="${origin.id}"]`)?.focus();
    else if (origin.kind === 'date') shell.refs.title.querySelector('[data-open-date-picker]')?.focus();
    else shell.refs.headerActions.querySelector('[data-create-appointment]')?.focus();
  });
}

function selectStaff(id) {
  const previous = state.focusedStaffId;
  state.focusedStaffId = previous === id ? null : id;
  emit(state.focusedStaffId ? DashboardEvent.DAY_STAFF_FOCUS_REQUESTED : DashboardEvent.DAY_STAFF_FOCUS_CLEARED, {
    staffId: id,
    date: state.date,
    presentation: state.focusedStaffId ? 'lane-emphasis' : 'team',
    previousStaffId: previous
  });
  scheduleRender();
}

function clearStaffFocus() {
  const previous = state.focusedStaffId;
  state.focusedStaffId = null;
  emit(DashboardEvent.DAY_STAFF_FOCUS_CLEARED, { staffId: previous, date: state.date });
  scheduleRender();
  requestAnimationFrame(() => shell.refs.content.querySelector(`[data-focus-staff="${previous}"]`)?.focus());
}

async function changeDate(date) {
  if (!date || date === state.date) {
    closeOverlay();
    return;
  }
  state.date = date;
  state.loading = true;
  state.error = null;
  state.selectedAppointmentId = null;
  emit(DashboardEvent.DAY_DATE_CHANGE_REQUESTED, { date });
  closeOverlay({ restoreFocus: false });
  scheduleRender();
  try {
    state.plan = await dataSource.getDayPlan({ date });
  } catch (error) {
    state.error = error;
  } finally {
    state.loading = false;
    scheduleRender();
  }
}

async function returnToToday() {
  const today = todayIso();
  if (state.date === today) {
    shell.announce('Heutiger Tagesplan ist geöffnet.');
    return;
  }
  await changeDate(today);
}

function minuteFromPointer(track, clientY) {
  const rect = track.getBoundingClientRect();
  const ratio = clamp((clientY - rect.top) / Math.max(1, rect.height), 0, 1);
  return clamp(Math.round((OPEN_MINUTE + ratio * DAY_DURATION) / 15) * 15, OPEN_MINUTE, CLOSE_MINUTE - 15);
}

function keyboardDefaultMinute() {
  if (!isToday()) return OPEN_MINUTE;
  return clamp(Math.ceil(currentSalonMinute() / 15) * 15, OPEN_MINUTE, CLOSE_MINUTE - 15);
}

function bindInteractions() {
  shell.refs.title.querySelector('[data-open-date-picker]')?.addEventListener('click', () => {
    rememberOrigin('date');
    openOverlay({ type: 'date' });
  });
  shell.refs.headerActions.querySelector('[data-create-appointment]')?.addEventListener('click', () => openBookingPanel({ source: 'day-plan-header' }));
  shell.refs.content.querySelector('[data-retry]')?.addEventListener('click', load);

  shell.refs.content.querySelectorAll('[data-focus-staff]').forEach((button) => {
    button.addEventListener('click', () => selectStaff(button.dataset.focusStaff));
  });
  shell.refs.content.querySelector('[data-clear-staff-focus]')?.addEventListener('click', clearStaffFocus);

  shell.refs.content.querySelectorAll('[data-appointment-id]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.stopPropagation();
      openAppointmentPanel(button.dataset.appointmentId, { kind: 'appointment', id: button.dataset.appointmentId });
    });
  });
  shell.refs.content.querySelectorAll('[data-agenda-appointment-id]').forEach((button) => {
    button.addEventListener('click', () => openAppointmentPanel(button.dataset.agendaAppointmentId, { kind: 'agenda', id: button.dataset.agendaAppointmentId }));
  });
  shell.refs.content.querySelectorAll('[data-operational-id]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.stopPropagation();
      openOverlay({ type: 'operational', id: button.dataset.operationalId }, { kind: 'operational', id: button.dataset.operationalId });
    });
  });

  shell.refs.content.querySelectorAll('[data-staff-track]').forEach((track) => {
    track.addEventListener('click', (event) => {
      if (event.target.closest('[data-appointment-id], [data-operational-id]')) return;
      openBookingPanel({
        staffId: track.dataset.staffTrack,
        startMinute: minuteFromPointer(track, event.clientY),
        source: 'calendar-free-slot',
        origin: { kind: 'staff', id: track.dataset.staffTrack }
      });
    });
    track.addEventListener('keydown', (event) => {
      if (!['Enter', ' '].includes(event.key)) return;
      event.preventDefault();
      openBookingPanel({
        staffId: track.dataset.staffTrack,
        startMinute: keyboardDefaultMinute(),
        source: 'calendar-keyboard',
        origin: { kind: 'staff', id: track.dataset.staffTrack }
      });
    });
  });

  const gapButton = shell.refs.content.querySelector('[data-book-gap]');
  gapButton?.addEventListener('click', () => openBookingPanel({
    staffId: gapButton.dataset.staffId,
    startMinute: Number(gapButton.dataset.startMinute),
    source: 'agenda-free-gap',
    origin: { kind: 'gap' }
  }));

  const backdrop = shell.refs.content.querySelector('[data-overlay-backdrop]');
  backdrop?.addEventListener('mousedown', (event) => {
    if (event.target === backdrop) closeOverlay();
  });
  shell.refs.content.querySelector('[data-close-overlay]')?.addEventListener('click', () => closeOverlay());
  shell.refs.content.querySelector('[data-today]')?.addEventListener('click', () => changeDate(todayIso()));
  shell.refs.content.querySelector('[data-date-form]')?.addEventListener('submit', (event) => {
    event.preventDefault();
    changeDate(new FormData(event.currentTarget).get('date'));
  });
  shell.refs.content.querySelector('[data-booking-form]')?.addEventListener('submit', (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    emit(DashboardEvent.APPOINTMENT_CREATE_REQUESTED, {
      date: form.get('date'),
      time: form.get('time'),
      staffId: form.get('staff'),
      customerLabel: form.get('customer'),
      serviceLabel: form.get('service'),
      referenceOnly: true
    }, 'tagesplan-vertical-agenda-booking');
    closeOverlay({ restoreFocus: false });
    shell.announce('Terminabsicht erfasst. In der Referenz wurde nichts gespeichert.');
  });
  shell.refs.content.querySelector('[data-edit-appointment]')?.addEventListener('click', (event) => {
    emit(DashboardEvent.APPOINTMENT_EDIT_REQUESTED, { appointmentId: event.currentTarget.dataset.editAppointment });
    shell.announce('Bearbeitungsabsicht ausgelöst.');
  });
}

async function load() {
  state.loading = true;
  state.error = null;
  scheduleRender();
  try {
    state.session = await dataSource.getSessionContext();
    state.date = state.date ?? todayIso();
    state.plan = await dataSource.getDayPlan({ date: state.date });
    const requestedFocus = query.get('focus');
    if (requestedFocus && state.plan.staff.some((person) => person.id === requestedFocus)) {
      state.focusedStaffId = requestedFocus;
    }
  } catch (error) {
    state.error = error;
  } finally {
    state.loading = false;
    scheduleRender();
  }
}

function globalKeydown(event) {
  if (event.key !== 'Escape') return;
  if (state.overlay) {
    event.preventDefault();
    closeOverlay();
  } else if (state.focusedStaffId) {
    event.preventDefault();
    clearStaffFocus();
  }
}

function handleResize() {
  clearTimeout(resizeTimer);
  resizeTimer = window.setTimeout(() => scheduleRender(), 90);
}

document.addEventListener('keydown', globalKeydown);
window.addEventListener('resize', handleResize);
clockTimer = window.setInterval(() => {
  shell.refreshClock();
  if (isToday() && !state.overlay) scheduleRender();
}, CLOCK_TICK_MS);

window.addEventListener('beforeunload', () => {
  clearInterval(clockTimer);
  clearTimeout(resizeTimer);
  document.removeEventListener('keydown', globalKeydown);
  window.removeEventListener('resize', handleResize);
  shell.destroy();
}, { once: true });

load();
