# ADR-007 · Tagesplan v1.0 als Golden-Master-Pipeline

Status: **Accepted, amended by ADR-008**  
Datum: 2026-08-25  
Ausführungsvertrag: [`docs/TAGESPLAN_V1_EXECUTION_CONTRACT.md`](../TAGESPLAN_V1_EXECUTION_CONTRACT.md)  
Freeze-Richtlinie: [`docs/TAGESPLAN_V1_FREEZE_POLICY.md`](../TAGESPLAN_V1_FREEZE_POLICY.md)  
Wirkungssystem: [`docs/WIRKUNGSSYSTEM_V1.md`](../WIRKUNGSSYSTEM_V1.md)

## Kontext

Der Tagesplan ist die operativ komplexeste und identitätsstärkste Seite des Gasserwerk Dashboards. Die Referenz hat die tragende räumliche Grammatik geklärt:

- Zeit läuft von oben nach unten;
- Mitarbeitende stehen horizontal nebeneinander;
- der vollständige Salon bleibt als eine Teamfläche sichtbar;
- `Als Nächstes` ist eine temporäre Kopfzeilenagenda;
- Fokus verändert Aufmerksamkeit, nicht Geometrie;
- die vergangene Tageszeit ist eine globale Flächeneigenschaft;
- die Jetzt-Linie liegt hinter Terminkarten.

Die Seite muss vor jeder atmosphärischen oder illustrativen Ausarbeitung als reproduzierbare, fachlich korrekte, responsive und zugängliche Arbeitsoberfläche stabil sein. Beseelungsvarianten dürfen nicht gleichzeitig mit der Grundgeometrie, Zustandslogik oder Artefakterzeugung verändert werden, weil ihre Wirkung sonst nicht sauber vergleichbar wäre.

## Entscheidung

Die Arbeit erfolgt auf dem isolierten Branch:

```text
feat/tagesplan-v1-golden-master
```

und wird in dieser verbindlichen Reihenfolge geführt:

1. **Geometrie:** ein responsives Flächensystem ohne konkurrierende Scrollcontainer;
2. **Funktion und Zustände:** vollständige Betriebs-, Lade-, Fehler-, Offline-, Fokus-, Such- und Kontextlogik;
3. **Technischer Core Freeze:** reproduzierbare Single-HTML-Referenz, vollständige Nachweise, Integritätsmanifest und unveränderlicher Tag;
4. **Beseelungsexperimente:** mehrere additive Varianten, die ausschließlich vom Core-Freeze-Tag abzweigen;
5. **Erfahrungsfreigabe:** Auswahl einer Variante ohne Änderung des eingefrorenen fachlichen und geometrischen Kerns;
6. **Integration:** sichtbare, funktionale und zugängliche Parität in `pages/tagesplan/`.

Der technische Core Freeze geht der Beseelung zwingend voraus. Die Seite `Termine` beginnt erst nach bestandener Übergabe des vollständigen Tagesplans; die Integrationslinie darf den Core Freeze bereits als belastbare technische Grundlage verwenden.

## Responsive Entscheidung

Die Kalenderprojektion wird aus tatsächlich verfügbarer Breite und Höhe abgeleitet, nicht aus Gerätenamen.

### Vollständige Desktopfläche

Wenn nach Produktschale, Produktkopf, Außenabständen und Mitarbeitendenkopf mindestens 44 Pixel pro Stunde verbleiben:

- sind alle zehn Öffnungsstunden gleichzeitig sichtbar;
- besitzen Seite und Kalender keinen vertikalen Scroll;
- füllt das Raster die Kalenderfläche exakt bis `18:00`;
- passt sich der Karteninhalt semantisch an reale Kartenbreite und -höhe an.

### Kompakte Projektion

Wenn weniger als 44 Pixel pro Stunde verbleiben oder fünf Mitarbeitende nicht sinnvoll nebeneinander lesbar sind:

- besitzt der Kalender genau eine primäre vertikale Bewegung;
- bleibt die Zeitachse links sticky;
- bleiben Mitarbeitendenköpfe oben sticky;
- bewegen sich Mitarbeitende horizontal in Spalten mit definierter Mindestbreite;
- bleibt die Seite selbst ohne konkurrierenden Scroll.

### Zoom

Browserzoom wird als veränderte verfügbare CSS-Fläche behandelt. Es gibt keine zoomspezifischen Sonderstile. Die Abnahme prüft 90, 100, 110 und 125 Prozent als äquivalente CSS-Viewportgeometrien.

## Technischer Core Freeze

Nach bestandener Geometrie-, Funktions-, Zustands-, Accessibility- und Resilienzabnahme entsteht:

```text
references/tagesplan/v1.0/
├── tagesplan-reference.html
├── CONTRACT.md
├── STATES.md
├── INTEGRATION.md
├── ACCESSIBILITY.md
├── FREEZE_MANIFEST.json
├── CHECKSUMS.sha256
└── evidence/
```

`tagesplan-reference.html` besitzt keine externe Laufzeitressource, keinen erforderlichen Buildschritt und keine Backendabhängigkeit. Der Build selbst ist deterministisch und wird aus einem sauberen Checkout erzeugt.

Der Freeze wird durch den unveränderlichen Tag

```text
tagesplan-v1.0-core-freeze
```

und den exakten Commit-SHA identifiziert. Ein Freeze wird niemals nachträglich verändert. Jede Korrektur erzeugt einen neuen Release Candidate und einen neuen Tag.

## Beseelung nach dem Freeze

Das Wirkungssystem bleibt vor dem Freeze als Vertrag und maschinenlesbare Infrastruktur vorhanden, beeinflusst den Freeze aber nicht als experimentelle Material-, Bewegungs- oder Illustrationsschicht.

Beseelungsvarianten:

- zweigen ausschließlich vom Core-Freeze-Tag ab;
- verwenden identische Fixtures, Zustände und Browsermatrix;
- dürfen keine Datenbedeutung, Statusfarbe, Fokussemantik, Suchsemantik, Kalendergeometrie oder Bedienlogik verändern;
- werden als getrennte Varianten vergleichbar dokumentiert;
- können jederzeit verworfen werden, ohne den Core Freeze zu berühren.

Vorgesehene Branchkonvention:

```text
exp/tagesplan-v1-soul-<variante>
```

## Wirkungssystem

Die maschinenlesbare Infrastruktur besteht aus:

```text
src/experience/profiles.js
src/styles/experience.css
```

Sie darf ausschließlich folgende Achsen steuern:

- Raumrhythmus;
- Materialtiefe;
- Bewegungstempo;
- Aufmerksamkeitsstärke;
- Illustrationspräsenz.

Statusfarbe, Fokussemantik, Suche, Datenbedeutung und Warnstärke bleiben den fachlichen Verträgen und Tokens vorbehalten.

## Konsequenzen

### Gewollt

- Der Core Freeze ist eine neutrale, belastbare Vergleichs- und Integrationsbasis.
- Beseelung kann sicher in mehreren Varianten getestet werden.
- Referenzgestaltung und Produktionsintegration bleiben klar getrennt.
- Jede Freigabe ist anhand von Viewport-, Zoom-, Zustands-, Accessibility- und Integritätsnachweisen reproduzierbar.
- Kein atmosphärischer Versuch kann die eingefrorene Zeit-, Daten- oder Interaktionswahrheit still verändern.

### In Kauf genommen

- Die emotionale Ausarbeitung beginnt später als ursprünglich geplant.
- Einzelne attraktive Details bleiben bis zum Core Freeze deaktiviert.
- Mobile und Desktopprojektion dürfen räumlich verschieden sein, müssen aber dieselbe fachliche und interaktive Logik tragen.
- Ein technisch grüner Core Freeze ist noch nicht automatisch die endgültige beseelte Produktfassung.

## Nicht entschieden

Diese ADR entscheidet noch nicht:

- welche Beseelungsvariante ausgewählt wird;
- den finalen SVG-Dienstleistungssatz;
- produktive Backendendpunkte;
- das endgültige Framework;
- Drag-and-drop oder Resize direkter Terminmanipulation;
- die finale alpine Illustration des leeren Tagesplans.
