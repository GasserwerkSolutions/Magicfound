import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const root = process.cwd();
const output = resolve(root, 'artifacts/tagesplan-v1');
const profile = mkdtempSync(join(tmpdir(), 'gasserwerk-tagesplan-v1-'));
const port = 4181;
const base = `http://127.0.0.1:${port}/references/tagesplan/v1.0/tagesplan-reference.html`;
const errors = [];
const captureOnly = process.argv.includes('--capture-only');
const assertOnly = process.argv.includes('--assert-only');

const desktopMatrix = [
  ['desktop-stress-1366x768', 1366, 768],
  ['desktop-compact-1440x810', 1440, 810],
  ['desktop-1440x900', 1440, 900],
  ['desktop-master-1512x982', 1512, 982],
  ['desktop-1600x900', 1600, 900],
  ['desktop-expanded-1920x1080', 1920, 1080],
  ['zoom-equivalent-90-1680x1091', 1680, 1091],
  ['zoom-equivalent-110-1375x893', 1375, 893],
  ['zoom-equivalent-125-1210x786', 1210, 786],
  ['tablet-wide-1024x768', 1024, 768]
];

const mobileMatrix = [
  ['mobile-430x932', 430, 932],
  ['mobile-390x844', 390, 844],
  ['mobile-landscape-844x390', 844, 390]
];

const stateMatrix = [
  ['state-empty', 1512, 982, 'scenario=empty&state=empty'],
  ['state-loading', 1512, 982, 'scenario=loading&state=loading'],
  ['state-error', 1512, 982, 'scenario=error&state=error'],
  ['state-offline', 1512, 982, 'scenario=offline&state=offline'],
  ['state-stale', 1512, 982, 'scenario=stale&state=stale'],
  ['state-forbidden', 1512, 982, 'scenario=forbidden&state=forbidden'],
  ['state-before-opening', 1512, 982, 'referenceNow=07:30'],
  ['state-after-closing', 1512, 982, 'referenceNow=18:30'],
  ['state-past-date', 1512, 982, 'date=2026-08-24&referenceNow=11:22'],
  ['state-future-date', 1512, 982, 'date=2026-08-26&referenceNow=11:22'],
  ['state-agenda-open', 1512, 982, 'agenda=open&referenceNow=11:22'],
  ['state-person-focus', 1512, 982, 'focus=melanie&referenceNow=11:22'],
  ['state-selected-appointment', 1512, 982, 'selected=a6&referenceNow=11:22'],
  ['state-stress', 1512, 982, 'scenario=stress&referenceNow=11:22'],
  ['state-quiet', 1512, 982, 'scenario=quiet&referenceNow=11:22']
];

function findChrome() {
  for (const candidate of [process.env.CHROME_BIN, 'google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser'].filter(Boolean)) {
    const probe = spawnSync('bash', ['-lc', `command -v ${candidate}`], { encoding: 'utf8' });
    if (probe.status === 0 && probe.stdout.trim()) return probe.stdout.trim();
  }
  return null;
}

function runChrome(chrome, label, args, budget = 3400) {
  const started = Date.now();
  const result = spawnSync('timeout', [
    '--signal=TERM', '--kill-after=3s', '45s', chrome,
    '--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage',
    '--disable-background-networking', '--disable-background-timer-throttling',
    '--disable-component-update', '--disable-default-apps', '--disable-extensions',
    '--disable-sync', '--disable-features=MediaRouter,OptimizationHints,Translate',
    '--no-first-run', '--no-default-browser-check', '--hide-scrollbars',
    '--run-all-compositor-stages-before-draw', `--user-data-dir=${profile}`,
    `--virtual-time-budget=${budget}`, ...args
  ], { cwd: root, encoding: 'utf8', maxBuffer: 50 * 1024 * 1024 });
  console.log(`${label}: status=${result.status} ${Date.now() - started}ms`);
  if ([124, 137, 143].includes(result.status)) throw new Error(`${label}: Chrome-Zeitlimit überschritten`);
  if (result.error) throw result.error;
  return result;
}

async function waitForServer() {
  for (let attempt = 0; attempt < 60; attempt += 1) {
    try {
      const response = await fetch(`${base}?referenceNow=11:22`);
      if (response.ok) return;
    } catch { /* starts */ }
    await delay(100);
  }
  throw new Error('Lokaler Tagesplan-v1-Server antwortet nicht.');
}

function url(parameters = '') {
  const suffix = parameters ? `${parameters}&` : '';
  return `${base}?${suffix}referenceNow=${parameters.includes('referenceNow=') ? '' : '11:22'}`.replace(/referenceNow=&/, '');
}

function dataset(dom, name) {
  const match = dom.match(new RegExp(`data-${name}="([^"]*)"`));
  return match?.[1] ?? null;
}

function number(dom, name) {
  const value = dataset(dom, name);
  return value == null ? null : Number(value);
}

function requireText(dom, text, label) {
  if (!dom.includes(text)) errors.push(`${label}: nicht im gerenderten DOM gefunden`);
}

function dump(chrome, name, width, height, parameters = '') {
  const target = url(parameters);
  const result = runChrome(chrome, `DOM ${name}`, [`--window-size=${width},${height}`, '--dump-dom', target]);
  if (result.status !== 0) {
    errors.push(`${name}: Chrome-DOM-Prüfung fehlgeschlagen: ${result.stderr.trim()}`);
    return '';
  }
  writeFileSync(resolve(output, `${name}.html`), result.stdout);
  return result.stdout;
}

function screenshot(chrome, name, width, height, parameters = '') {
  const path = resolve(output, `${name}.png`);
  const result = runChrome(chrome, `Screenshot ${name}`, [`--window-size=${width},${height}`, `--screenshot=${path}`, url(parameters)]);
  if (result.status !== 0 || !existsSync(path)) errors.push(`${name}: Screenshot fehlt`);
}

function assertDesktop(dom, name) {
  const expectedZero = ['tp-document-overflow-x', 'tp-document-overflow-y', 'tp-page-overflow-y', 'tp-viewport-overflow-y', 'tp-calendar-overflow-y'];
  if (dataset(dom, 'tp-v1-layout') !== 'desktop') errors.push(`${name}: Desktopprojektion fehlt`);
  for (const key of expectedZero) if ((number(dom, key) ?? -1) > 2) errors.push(`${name}: ${key}=${number(dom, key)}`);
  if (dataset(dom, 'tp-complete-day-visible') !== '1') errors.push(`${name}: vollständiger Arbeitstag ist nicht sichtbar`);
  if (dataset(dom, 'tp-calendar-surface') !== 'single') errors.push(`${name}: Kalender ist keine einzelne Fläche`);
  if (dataset(dom, 'tp-reference-version') !== '1.0.0') errors.push(`${name}: falsche Referenzversion`);
  requireText(dom, '08:00', `${name}: Tagesbeginn`);
  requireText(dom, '18:00', `${name}: Tagesende`);
  requireText(dom, 'Als Nächstes', `${name}: Kopfzeilenagenda`);
}

function assertMobile(dom, name) {
  if (dataset(dom, 'tp-v1-layout') !== 'mobile') errors.push(`${name}: mobile Projektion fehlt`);
  if ((number(dom, 'tp-document-overflow-x') ?? -1) > 2) errors.push(`${name}: horizontaler Gesamtseitenüberlauf`);
  if ((number(dom, 'tp-document-overflow-y') ?? -1) > 2) errors.push(`${name}: zusätzlicher Seiten-Scroll`);
  if (dataset(dom, 'tp-vertical-scroll-systems') !== '1') errors.push(`${name}: nicht genau ein vertikales Kalenderscrollsystem`);
  if (dataset(dom, 'tp-horizontal-staff-scrollable') !== '1') errors.push(`${name}: Mitarbeitende sind nicht horizontal erreichbar`);
}

rmSync(output, { recursive: true, force: true });
mkdirSync(output, { recursive: true });
const server = spawn('python3', ['-m', 'http.server', String(port), '--bind', '127.0.0.1'], { cwd: root, stdio: 'ignore' });

try {
  await waitForServer();
  const chrome = findChrome();
  if (!chrome) throw new Error('Chrome/Chromium fehlt.');
  const warm = runChrome(chrome, 'Chrome warm-up', ['--dump-dom', 'about:blank'], 800);
  if (warm.status !== 0) throw new Error('Chrome-Warm-up fehlgeschlagen.');

  if (!captureOnly) {
    for (const [name, width, height] of desktopMatrix) assertDesktop(dump(chrome, name, width, height), name);
    for (const [name, width, height] of mobileMatrix) assertMobile(dump(chrome, name, width, height), name);

    const moved = dump(chrome, 'mobile-staff-scroll-proof', 390, 844, 'verifyStaffScroll=1');
    assertMobile(moved, 'mobile-staff-scroll-proof');
    if (dataset(moved, 'tp-staff-scroll-functional') !== '1' || !(number(moved, 'tp-staff-scroll-delta') > 2)) {
      errors.push('mobile-staff-scroll-proof: reale horizontale Bewegung fehlt');
    }

    const empty = dump(chrome, 'state-empty', 1512, 982, 'scenario=empty&state=empty');
    requireText(empty, 'tp-v1-empty-habitat', 'Leerzustand: Habitat-Zone');
    requireText(empty, 'Heute ist es noch erstaunlich ruhig.', 'Leerzustand: Text');
    if (empty.includes('class="va-appointment')) errors.push('Leerzustand enthält Termine');

    const agenda = dump(chrome, 'state-agenda-open', 1512, 982, 'agenda=open');
    if (dataset(agenda, 'visible-agenda-panels') !== '1') errors.push('Agenda: genau ein sichtbares Popover erwartet');
    requireText(agenda, 'Davor', 'Agenda: Davor');
    requireText(agenda, 'Jetzt', 'Agenda: Jetzt');
    requireText(agenda, 'Danach', 'Agenda: Danach');

    const focus = dump(chrome, 'state-person-focus', 1512, 982, 'focus=melanie');
    if (number(focus, 'visible-staff-count') !== 5 || number(focus, 'focus-context-count') !== 4) errors.push('Personenfokus verändert die Teamgeometrie');

    for (const [name, width, height, parameters] of stateMatrix) {
      const dom = dump(chrome, `${name}-assertion`, width, height, parameters);
      requireText(dom, 'data-tp-reference-version="1.0.0"', `${name}: Referenz aktiv`);
      if ((number(dom, 'tp-document-overflow-x') ?? 0) > 2) errors.push(`${name}: horizontaler Seitenüberlauf`);
    }
  }

  if (!assertOnly) {
    const captures = [
      ...desktopMatrix,
      ...mobileMatrix,
      ['mobile-staff-scroll-proof', 390, 844, 'verifyStaffScroll=1'],
      ...stateMatrix
    ];
    for (const [name, width, height, parameters = ''] of captures) screenshot(chrome, name, width, height, parameters);
  }
} catch (error) {
  errors.push(error.message);
} finally {
  server.kill('SIGTERM');
  rmSync(profile, { recursive: true, force: true });
}

if (errors.length) {
  console.error(`Tagesplan-v1-Browserprüfung fehlgeschlagen (${errors.length}):`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`✓ Tagesplan v1.0: Browser-, Zoomäquivalent- und Zustandsmatrix bestanden (${base}).`);
