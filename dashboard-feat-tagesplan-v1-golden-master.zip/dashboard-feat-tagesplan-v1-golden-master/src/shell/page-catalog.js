import { Capability } from '../data/contracts/capabilities.js';

export const ShellVariant = Object.freeze({
  PRODUCT: 'product',
  AUTH: 'auth',
  ONBOARDING: 'onboarding'
});

export const PageId = Object.freeze({
  LOGIN: 'login',
  ONBOARDING: 'onboarding',
  DAY_PLAN: 'tagesplan',
  APPOINTMENTS: 'termine',
  CUSTOMERS: 'kundschaft',
  TEAM: 'team',
  OFFER: 'angebot',
  ADMINISTRATION: 'verwaltung'
});

export const PAGE_DEFINITIONS = Object.freeze([
  Object.freeze({
    id: PageId.LOGIN,
    label: 'Login',
    pathSegment: 'login',
    contractPath: 'pages/login/CONTRACT.md',
    shellVariant: ShellVariant.AUTH,
    requiredCapability: Capability.AUTH_SIGN_IN,
    primaryNavigation: false,
    navigationOrder: null
  }),
  Object.freeze({
    id: PageId.ONBOARDING,
    label: 'Onboarding',
    pathSegment: 'onboarding',
    contractPath: 'pages/onboarding/CONTRACT.md',
    shellVariant: ShellVariant.ONBOARDING,
    requiredCapability: Capability.ONBOARDING_MANAGE,
    primaryNavigation: false,
    navigationOrder: null
  }),
  Object.freeze({
    id: PageId.DAY_PLAN,
    label: 'Tagesplan',
    pathSegment: 'tagesplan',
    contractPath: 'pages/tagesplan/CONTRACT.md',
    shellVariant: ShellVariant.PRODUCT,
    requiredCapability: Capability.DAY_PLAN_VIEW,
    primaryNavigation: true,
    navigationOrder: 10
  }),
  Object.freeze({
    id: PageId.APPOINTMENTS,
    label: 'Termine',
    pathSegment: 'termine',
    contractPath: 'pages/termine/CONTRACT.md',
    shellVariant: ShellVariant.PRODUCT,
    requiredCapability: Capability.APPOINTMENT_VIEW,
    primaryNavigation: true,
    navigationOrder: 20
  }),
  Object.freeze({
    id: PageId.CUSTOMERS,
    label: 'Kundschaft',
    pathSegment: 'kundschaft',
    contractPath: 'pages/kundschaft/CONTRACT.md',
    shellVariant: ShellVariant.PRODUCT,
    requiredCapability: Capability.CUSTOMER_VIEW,
    primaryNavigation: true,
    navigationOrder: 30
  }),
  Object.freeze({
    id: PageId.TEAM,
    label: 'Team',
    pathSegment: 'team',
    contractPath: 'pages/team/CONTRACT.md',
    shellVariant: ShellVariant.PRODUCT,
    requiredCapability: Capability.STAFF_VIEW,
    primaryNavigation: true,
    navigationOrder: 40
  }),
  Object.freeze({
    id: PageId.OFFER,
    label: 'Angebot',
    pathSegment: 'angebot',
    contractPath: 'pages/angebot/CONTRACT.md',
    shellVariant: ShellVariant.PRODUCT,
    requiredCapability: Capability.SERVICE_VIEW,
    primaryNavigation: true,
    navigationOrder: 50
  }),
  Object.freeze({
    id: PageId.ADMINISTRATION,
    label: 'Verwaltung',
    pathSegment: 'verwaltung',
    contractPath: 'pages/verwaltung/CONTRACT.md',
    shellVariant: ShellVariant.PRODUCT,
    requiredCapability: Capability.ADMINISTRATION_VIEW,
    primaryNavigation: true,
    navigationOrder: 60
  })
]);

const PAGE_BY_ID = new Map(PAGE_DEFINITIONS.map((definition) => [definition.id, definition]));

export function getPageDefinition(pageId) {
  const definition = PAGE_BY_ID.get(pageId);
  if (!definition) throw new RangeError(`unknown Gasserwerk page: ${pageId}`);
  return definition;
}

export function getPrimaryNavigationPages() {
  return PAGE_DEFINITIONS
    .filter((definition) => definition.primaryNavigation)
    .slice()
    .sort((first, second) => first.navigationOrder - second.navigationOrder);
}

export function buildReferencePath(pageId, options = {}) {
  const { basePath = '/dashboard/' } = options;
  const definition = getPageDefinition(pageId);
  const normalizedBase = basePath.endsWith('/') ? basePath : `${basePath}/`;
  return `${normalizedBase}pages/${definition.pathSegment}/`;
}

export function assertPageCatalog() {
  const ids = new Set();
  const pathSegments = new Set();
  for (const definition of PAGE_DEFINITIONS) {
    if (ids.has(definition.id)) throw new Error(`duplicate page id: ${definition.id}`);
    if (pathSegments.has(definition.pathSegment)) throw new Error(`duplicate page path: ${definition.pathSegment}`);
    ids.add(definition.id);
    pathSegments.add(definition.pathSegment);
  }
  if (ids.has('today') || pathSegments.has('heute')) {
    throw new Error('Heute is a day-plan state and must not be a page');
  }
  return true;
}
