#!/usr/bin/env python3
"""Link observed token interventions to declared/candidate identities and applicable oracles.
Edges preserve provenance: directly measured != hypothetical relational ripple.
"""
import argparse,collections,json
from pathlib import Path

def matches(rec,selector):
    if selector.startswith('.'):
        cls=selector[1:].split(':')[0]
        return cls in rec.get('classes',[]) and not (':not(.active)' in selector and 'active' in rec.get('classes',[]))
    if selector.startswith('#'): return rec.get('id')==selector[1:]
    if selector.startswith('[role='):
        role=selector.partition('=')[2].rstrip(']').strip('"\'')
        return rec.get('role')==role
    return False

def make(measure,identities,mutations,contract):
    by_scenario={s['meta']['scenario']:s for s in measure['scenarios']}
    ident_idx={(r['scenario'],r['index']):r for r in identities['records']}
    checks_by_scenario=collections.defaultdict(list)
    for ch in contract['checks']:
      for scene in ch.get('scenarios',[]): checks_by_scenario[scene].append(ch)
    geometry_rules={'same-edges','paired-edges','no-overlap','parent-containment','minimum-size','no-horizontal-overflow'}
    impacts=[]; by_token=collections.defaultdict(lambda:{'scenarios':set(),'nodes':set(),'measuredEdges':0,'ruleIds':set(),'ruleRuns':0,'potentialRelationEdges':0})
    for event in mutations['interventions']:
      if event['mutationId']=='negative-unused-token':continue
      scen=event['scenario'];sc=by_scenario[scen];records=sc['records'];idx={r['index']:r for r in records}
      affected={n['index'] for n in event['affectedNodes']}
      edge_set=[];affected_rule_ids=[];selector_hits=[];hypothetical=[];nodes=[]
      for item in event['affectedNodes']:
        i=item['index'];identity=ident_idx[(scen,i)];rec=idx[i]
        nodes.append({'index':i,'identity':identity['identityKey'],'identityCertainty':identity['certainty'],
          'visibleInLayout':rec['visibleInLayout'],'viewportIntersection':rec.get('viewportIntersection'),
          'family':identity['family'],'properties':list(item['changedProperties']),
          'geometryDeltasPx':item['geometryDeltasPx'],'pseudo':list(item['pseudoChanged'])})
        edge_set.append({'type':'observed-intervention-affects-node','from':event['mutationId'],'to':identity['identityKey'],
            'scenario':scen,'index':i,'certainty':'measured','role':'affected computed CSS or geometry'})
        # DOM ancestors/context are relational review candidates, NOT observed computed changes.
        p=rec['parentIndex'];level=0
        while p is not None and level<2:
            if p not in affected:
                parent=ident_idx[(scen,p)]
                hypothetical.append({'type':'possible-context-review','affectedNodeIndex':i,'contextIndex':p,
                  'contextIdentity':parent['identityKey'],'certainty':'candidate','reason':'DOM ancestor may be context for visual contract'})
            p=idx[p]['parentIndex'];level+=1
      for chk in checks_by_scenario[scen]:
        sel=chk.get('selector','');tar=chk.get('target','')
        selected={r['index'] for r in records if (sel and matches(r,sel)) or (tar and matches(r,tar))}
        hit=sorted(affected&selected)
        if hit:
          selector_hits.append({'id':chk['id'],'type':chk['type'],'selectorMatchedIndices':hit})
          relevant=False
          if chk['type'] in geometry_rules:
            relevant=any(bool(n.get('geometryDeltasPx')) for n in event['affectedNodes'] if n['index'] in hit)
          elif chk['type']=='focus-ring':
            relevant=any(any(p.startswith('outline-') for p in n['changedProperties']) for n in event['affectedNodes'] if n['index'] in hit)
          elif chk['type']=='style-diff-from-scenario':
            relevant=any(chk.get('property') in n['changedProperties'] for n in event['affectedNodes'] if n['index'] in hit)
          if relevant:
            affected_rule_ids.append({'id':chk['id'],'type':chk['type'],'directlyAffectedIndices':hit,
              'rerun':'REQUIRED','reason':'Measured mutation changed an input that this oracle evaluates'})
      record={'scenario':scen,'token':event['cssVariable'],'mutationId':event['mutationId'],
       'measurementStatus':event['status'],'nodes':nodes,'observedEdges':edge_set,
       'contextCandidates':hypothetical,'selectorIntersectionsNotNecessarilyRelevant':selector_hits, 'contractRecheckTargets':affected_rule_ids,
       'recommendedChecks':sorted(set(
         (['visual-regression','text-contrast','nontext-contrast'] if any(any(k in v['properties'] for k in ('color','background-color','border-left-color','outline-color')) or v['pseudo'] for v in nodes) else [])
         +(['geometry-and-overlap','responsive-layout'] if any(v['geometryDeltasPx'] for v in nodes) else [])
         +(['design-token-alias-integrity','theme-pair-parity'])))}
      impacts.append(record)
      bucket=by_token[event['cssVariable']]
      bucket['scenarios'].add(scen)
      bucket['nodes'].update((scen,n['index']) for n in nodes)
      bucket['measuredEdges']+=len(edge_set)
      bucket['ruleIds'].update(c['id'] for c in affected_rule_ids)
      bucket['ruleRuns']+=len(affected_rule_ids)
      bucket['potentialRelationEdges']+=len(hypothetical)
    summaries={k:{'scenariosTested':len(v['scenarios']),'observedNodeInterventions':len(v['nodes']),
       'observedEdges':v['measuredEdges'],'directlyIntersectingOracleIds':sorted(v['ruleIds']),
       'intersectingOracleRuns':v['ruleRuns'],'contextCandidates':v['potentialRelationEdges']} for k,v in sorted(by_token.items())}
    return {'schema':'ui-change-impact-graph/v1','sourceSha256':measure['source']['sha256'],
       'meaning':{'observedEdges':'Mutation empirically altered listed computed properties on a DOM node',
       'contextCandidates':'Parent context; no proof that their own styles changed',
       'contractRecheckTargets':'Measured input of explicit rule changed; re-evaluation required but no current FAIL inferred',
       'selectorIntersectionsNotNecessarilyRelevant':'Selected nodes show CSS change, but particular oracle may be unaffected',
       'recommendedChecks':'Review/retest suggestions, not tests executed'},
       'tokenSummary':summaries,'interventions':impacts}

def main():
 p=argparse.ArgumentParser()
 for k in ('measurement','identities','mutations','contract','output'):p.add_argument('--'+k,required=True)
 args=p.parse_args()
 obj=make(*[json.loads(Path(getattr(args,k)).read_text()) for k in ('measurement','identities','mutations','contract')]);o=Path(args.output);o.parent.mkdir(parents=True,exist_ok=True);o.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(obj['tokenSummary'],ensure_ascii=False,indent=2))
if __name__=='__main__':main()
