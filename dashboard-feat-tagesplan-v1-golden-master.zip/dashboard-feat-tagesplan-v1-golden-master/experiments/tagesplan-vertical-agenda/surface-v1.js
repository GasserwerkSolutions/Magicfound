(() => {
  const root = document.getElementById('dashboard-root');
  if (!root) return;

  const query = new URLSearchParams(location.search);
  const COMPACT_MEDIA = '(max-width: 760px), (max-width: 900px) and (max-height: 600px), (pointer: coarse) and (max-height: 820px)';
  const MIN_DESKTOP_GRID_HEIGHT = 440;
  const HOURS_VISIBLE = 10;
  const EPSILON = 2;
  const state = { frame: 0, reportFrame: 0, resizeObserver: null, mutationObserver: null };

  function select(selector, scope = document) { return scope?.querySelector(selector) ?? null; }

  function requiredNodes() {
    const workspace = select('.gw-workspace', root);
    const header = select('.gw-product-header', workspace);
    const pageHost = select('.gw-page-content.va-page-host', workspace);
    const page = select('.va-page', pageHost);
    const layout = select('.va-desktop-layout', page);
    const panel = select('.va-calendar-panel', layout);
    const viewport = select('.va-calendar-viewport', panel);
    const calendarHead = select('.va-calendar-head', viewport);
    const calendarScroll = select('.va-calendar-scroll', viewport);
    const grid = select('.va-calendar-grid', calendarScroll);
    return { workspace, header, pageHost, page, layout, panel, viewport, calendarHead, calendarScroll, grid };
  }

  const number = (value) => Number.isFinite(Number.parseFloat(value)) ? Number.parseFloat(value) : 0;
  const overflowAmount = (element, axis) => !element ? 0 : Math.max(0, Math.round(axis === 'x' ? element.scrollWidth - element.clientWidth : element.scrollHeight - element.clientHeight));

  function isScrollableY(element) {
    if (!element) return false;
    const overflow = getComputedStyle(element).overflowY;
    return (overflow === 'auto' || overflow === 'scroll') && overflowAmount(element, 'y') > EPSILON;
  }

  const unique = (elements) => [...new Set(elements.filter(Boolean))];

  function setExperienceAttributes() {
    const requestedState = query.get('state') || 'normal';
    document.body.dataset.gwPage = 'tagesplan';
    document.body.dataset.gwState = requestedState;
    document.body.dataset.gwExperienceProfile = 'tagesplan-v1';
    root.dataset.gwPage = 'tagesplan';
    root.dataset.gwState = requestedState;
    root.dataset.gwExperienceProfile = 'tagesplan-v1';
  }

  function densityForHourPixels(pixelsPerHour, compact) {
    if (compact) return 'dense';
    if (pixelsPerHour >= 60) return 'roomy';
    if (pixelsPerHour >= 48) return 'compact';
    return 'dense';
  }

  function schedule() {
    cancelAnimationFrame(state.frame);
    state.frame = requestAnimationFrame(applyLayoutRegime);
  }

  function applyLayoutRegime() {
    state.frame = 0;
    setExperienceAttributes();
    const nodes = requiredNodes();
    if (Object.values(nodes).some((node) => !node)) {
      root.dataset.vaLayoutReady = '0';
      return;
    }

    const compact = matchMedia(COMPACT_MEDIA).matches;
    const viewportHeight = Math.max(0, Math.floor(nodes.viewport.getBoundingClientRect().height));
    const headHeight = Math.max(0, Math.ceil(nodes.calendarHead.getBoundingClientRect().height));
    const availableGridHeight = Math.max(0, viewportHeight - headHeight);
    const pixelsPerHour = availableGridHeight / HOURS_VISIBLE;

    let regime;
    if (compact) regime = innerWidth > innerHeight ? 'compact-landscape-scroll' : 'compact-portrait-scroll';
    else if (availableGridHeight >= MIN_DESKTOP_GRID_HEIGHT) regime = pixelsPerHour >= 54 ? 'desktop-full' : 'desktop-compact';
    else regime = 'desktop-scroll';

    const density = densityForHourPixels(pixelsPerHour, compact);
    root.dataset.vaLayoutRegime = regime;
    root.dataset.vaLayoutReady = '1';
    root.dataset.vaAvailableGridHeight = String(Math.round(availableGridHeight));
    root.dataset.vaHourPixels = pixelsPerHour.toFixed(2);
    root.dataset.gwDensity = density;
    document.body.dataset.gwDensity = density;

    cancelAnimationFrame(state.reportFrame);
    state.reportFrame = requestAnimationFrame(() => reportDiagnostics(nodes, regime));
  }

  function reportDiagnostics(nodes, regime) {
    state.reportFrame = 0;
    const { pageHost, viewport, calendarScroll, grid } = nodes;
    if (!viewport.isConnected || !grid.isConnected) { schedule(); return; }

    const compact = regime.startsWith('compact-');
    const desktopFit = regime === 'desktop-full' || regime === 'desktop-compact';
    const documentElement = document.documentElement;
    const scrollingElement = document.scrollingElement || documentElement;
    const verticalOwners = unique([scrollingElement, pageHost, viewport, calendarScroll]).filter(isScrollableY);

    const viewportRect = viewport.getBoundingClientRect();
    const gridRect = grid.getBoundingClientRect();
    const expectedGridBottom = viewportRect.bottom - number(getComputedStyle(viewport).borderBottomWidth);
    const gridBottomGap = Math.round(expectedGridBottom - gridRect.bottom);

    const documentOverflowX = overflowAmount(documentElement, 'x');
    const documentOverflowY = overflowAmount(documentElement, 'y');
    const pageOverflowY = overflowAmount(pageHost, 'y');
    const calendarOverflowX = overflowAmount(viewport, 'x');
    const calendarOverflowY = overflowAmount(viewport, 'y');

    const cleanDesktop = desktopFit && documentOverflowX <= EPSILON && documentOverflowY <= EPSILON && pageOverflowY <= EPSILON && calendarOverflowY <= EPSILON && verticalOwners.length === 0 && Math.abs(gridBottomGap) <= EPSILON;
    const cleanCompact = compact && documentOverflowX <= EPSILON && documentOverflowY <= EPSILON && pageOverflowY <= EPSILON && verticalOwners.length === 1 && verticalOwners[0] === viewport && calendarOverflowY > EPSILON;

    root.dataset.documentOverflowX = String(documentOverflowX);
    root.dataset.documentOverflowY = String(documentOverflowY);
    root.dataset.pageOverflowY = String(pageOverflowY);
    root.dataset.calendarSurfaceOverflowX = String(calendarOverflowX);
    root.dataset.calendarSurfaceOverflowY = String(calendarOverflowY);
    root.dataset.calendarVerticalOwnerCount = String(verticalOwners.length);
    root.dataset.calendarPrimaryScrollOwner = verticalOwners[0] === viewport ? 'calendar-viewport' : verticalOwners.length ? 'other' : 'none';
    root.dataset.calendarGridBottomGap = String(gridBottomGap);
    root.dataset.calendarSurfaceClean = cleanDesktop || cleanCompact ? '1' : '0';
    root.dataset.calendarDesktopFit = desktopFit ? '1' : '0';
    root.dataset.calendarCompactProjection = compact ? '1' : '0';
    root.dataset.viewportCssWidth = String(Math.round(innerWidth));
    root.dataset.viewportCssHeight = String(Math.round(innerHeight));
  }

  state.mutationObserver = new MutationObserver((records) => {
    if (records.some((record) => record.type === 'childList')) schedule();
  });
  state.mutationObserver.observe(root, { childList: true, subtree: true });

  if ('ResizeObserver' in window) {
    state.resizeObserver = new ResizeObserver(schedule);
    state.resizeObserver.observe(root);
    state.resizeObserver.observe(document.body);
  }

  window.addEventListener('resize', schedule, { passive: true });
  window.addEventListener('orientationchange', schedule);
  window.addEventListener('load', schedule, { once: true });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') schedule(); });

  setExperienceAttributes();
  schedule();
  requestAnimationFrame(schedule);
  setTimeout(schedule, 120);
  setTimeout(schedule, 360);

  window.addEventListener('pagehide', () => {
    state.mutationObserver?.disconnect();
    state.resizeObserver?.disconnect();
    cancelAnimationFrame(state.frame);
    cancelAnimationFrame(state.reportFrame);
  }, { once: true });
})();
