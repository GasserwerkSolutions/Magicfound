import { createDashboardShellV2, shellIconV2 } from '../../src/shell/dashboard-shell-v2.js';
import { createMockDashboardDataSourceV1 } from '../../src/data/mock-dashboard-data-source-v1.js';
import { Capability, hasCapability } from '../../src/data/contracts/capabilities.js';
import { DashboardEvent, createDashboardEvent } from '../../src/data/contracts/events.js';
import { AppointmentStatus, OperationalKind } from '../../src/data/contracts/domain-values.js';

const OPEN_MINUTE = 480;
const PERIOD_SPLIT_MINUTE = 780;
const CLOSE_MINUTE = 1080;
const DAY_DURATION = CLOSE_MINUTE - OPEN_MINUTE;
const CLOCK_TICK_MS = 15_000;

const PERIODS = Object.freeze([
  Object.freeze({ id: 'morning', label: 'Vormittag', startMinute: OPEN_MINUTE, endMinute: PERIOD_SPLIT_MINUTE }),
  Object.freeze({ id: 'afternoon', label: 'Nachmittag', startMinute: PERIOD_SPLIT_MINUTE, endMinute: CLOSE_MINUTE })
]);

const STATUS_LABEL = Object.freeze({
  [AppointmentStatus.CONFIRMED]: 'Bestätigt',
  [AppointmentStatus.PENDING]: 'Angefragt',
  [AppointmentStatus.ARRIVED]: 'Im Salon',
  [AppointmentStatus.COMPLETED]: 'Abgeschlossen',
  [AppointmentStatus.CANCELLED]: 'Abgesagt',
  [AppointmentStatus.NO_SHOW]: 'Nicht erschienen'
});

const root = document.querySelector('#dashboard-root');
const dataSource = createMockDashboardDataSourceV1();

const state = {
  session: null,
  plan: null,
  date: null,
  search: '',
  selectedAppointmentId: null,
  focusedStaffId: null,
  focusScrollTop: 0,
  loading: true,
  error: null,
  overlay: null,
  overlayOrigin: null
};

let clockTimer = 0;
let renderFrame = 0;

const shell = createDashboardShellV2(root, {
  activePage: 'tagesplan',
  navigationBase: '../../pages',
  todayHref: '../../pages/tagesplan/',
  title: 'Tagesplan',
  kicker: 'Salonbetrieb',
  context: 'Zürich Enge',
  primaryActionLabel: 'Termin',
  onPrimaryAction: () => openBookingPanel({ source: 'day-plan-header' }),
  onClockActivate: () => returnToTodayNow(),
  onSearch: (query) => {
    state.search = query.trim();
    scheduleRender();
  }
});

function emit(type, payload, source = 'tagesplan-two-period') {
  root.dispatchEvent(new CustomEvent('gasserwerk:event', {
    bubbles: true,
    detail: createDashboardEvent(type, payload, { source })
  }));
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function zurichDateParts(instant = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Zurich',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(instant);
  return Object.fromEntries(parts.map((part) => [part.type, part.value]));
}

function todayIso() {
  const parts = zurichDateParts();
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function dateFromIso(value) {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day, 12));
}

function formatDate(value, compact = false) {
  const options = compact
    ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'short' }
    : { timeZone: 'Europe/Zurich', weekday: 'long', day: 'numeric', month: 'long' };
  return new Intl.DateTimeFormat('de-CH', options).format(dateFromIso(value)).replace(/\.,\s*/, ' ');
}

function formatHeaderDate(value) {
  const options = isMobileLayout()
    ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'numeric' }
    : matchMedia('(max-width: 1450px)').matches
      ? { timeZone: 'Europe/Zurich', weekday: 'short', day: 'numeric', month: 'short' }
      : { timeZone: 'Europe/Zurich', weekday: 'long', day: 'numeric', month: 'long' };
  return new Intl.DateTimeFormat('de-CH', options).format(dateFromIso(value)).replace(/\.,\s*/, ' ');
}

function formatTime(minute) {
  const normalized = Math.max(0, Math.min(1439, Math.round(minute)));
  return `${String(Math.floor(normalized / 60)).padStart(2, '0')}:${String(normalized % 60).padStart(2, '0')}`;
}

function formatMoney(price) {
  if (!price || !Number.isFinite(price.amount)) return 'Nicht hinterlegt';
  return new Intl.NumberFormat('de-CH', {
    style: 'currency',
    currency: price.currency ?? 'CHF',
    maximumFractionDigits: 0
  }).format(price.amount);
}

function referenceMinuteOverride() {
  const value = new URLSearchParams(location.search).get('referenceNow');
  if (!value || !/^\d{1,2}:\d{2}$/.test(value)) return null;
  const [hour, minute] = value.split(':').map(Number);
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  return hour * 60 + minute;
}

function currentSalonMinute() {
  const override = referenceMinuteOverride();
  if (override != null) return override;
  const parts = Object.fromEntries(new Intl.DateTimeFormat('de-CH', {
    timeZone: 'Europe/Zurich',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).formatToParts(new Date()).map((part) => [part.type, part.value]));
  return Number(parts.hour) * 60 + Number(parts.minute);
}

function isToday() {
  return state.date === todayIso();
}

function isMobileLayout() {
  return matchMedia('(max-width: 760px), (max-width: 900px) and (max-height: 600px), (pointer: coarse) and (max-height: 820px)').matches;
}

function can(capability) {
  return hasCapability(state.session, capability);
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function itemEnd(item) {
  return item.startMinute + item.durationMinutes;
}

function minutePercent(minute, start = OPEN_MINUTE, end = CLOSE_MINUTE) {
  return clamp((minute - start) / Math.max(1, end - start) * 100, 0, 100);
}

function personById(id) {
  return state.plan?.staff.find((person) => person.id === id) ?? null;
}

function appointmentById(id) {
  return state.plan?.appointments.find((appointment) => appointment.id === id) ?? null;
}

function timelineItemsForStaff(staffId) {
  const appointments = state.plan.appointments.filter((item) => item.staff.id === staffId);
  const blocks = state.plan.operationalBlocks.filter((item) => item.staff.id === staffId);
  return [...appointments, ...blocks].sort((a, b) => a.startMinute - b.startMinute);
}

function layoutTimelineItems(items) {
  const laneEnds = [];
  const positioned = items.map((item) => {
    const freeLane = laneEnds.findIndex((endMinute) => endMinute <= item.startMinute);
    const laneIndex = freeLane >= 0 ? freeLane : laneEnds.length;
    laneEnds[laneIndex] = itemEnd(item);
    return { item, laneIndex };
  });
  return { items: positioned, laneCount: Math.max(1, laneEnds.length) };
}

function matchesSearch(item) {
  if (!state.search) return true;
  const text = item.kind === 'appointment'
    ? `${item.customer.displayName} ${item.service.displayName} ${item.staff.displayName} ${item.note ?? ''}`
    : `${item.label} ${item.staff.displayName} ${item.note ?? ''}`;
  return text.toLocaleLowerCase('de-CH').includes(state.search.toLocaleLowerCase('de-CH'));
}

function appointmentInitials(displayName) {
  return displayName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toLocaleUpperCase('de-CH');
}

function densityClass(durationMinutes) {
  if (durationMinutes <= 30) return 'is-micro';
  if (durationMinutes < 60) return 'is-compact';
  if (durationMinutes < 75) return 'is-medium';
  return 'is-wide';
}

function renderHeader() {
  shell.setTitleContent(`
    <button class="split-header-date" type="button" data-open-date-picker aria-haspopup="dialog">
      <span>${formatHeaderDate(state.date)}</span>
      ${shellIconV2('calendar')}
    </button>
  `);
  shell.setContextContent(`<span>Zürich Enge · 08:00–18:00</span>`);

  const current = isToday() ? currentSalonMinute() : null;
  const nowStatus = current != null && current >= OPEN_MINUTE && current <= CLOSE_MINUTE
    ? `<span class="split-header-now">${formatTime(current)}</span>`
    : '';
  const primary = can(Capability.DAY_PLAN_CREATE_APPOINTMENT)
    ? `<button class="gw-button gw-button-primary" type="button" data-create-appointment>${shellIconV2('plus')}<span>Termin</span></button>`
    : '';
  shell.setHeaderActions(`${nowStatus}${primary}`);
}

function renderLoading() {
  shell.refs.content.innerHTML = `<section class="split-page is-centered" aria-busy="true"><div class="split-state"><strong>Tageslandkarte wird geladen</strong><span>Team, Perioden und Termine werden vorbereitet.</span></div></section>`;
}

function renderError() {
  shell.refs.content.innerHTML = `<section class="split-page is-centered"><div class="split-state"><strong>Tageslandkarte konnte nicht geladen werden</strong><span>${escapeHtml(state.error?.message ?? 'Unbekannter Fehler')}</span><button class="gw-button" type="button" data-retry>Erneut laden</button></div></section>`;
}

function renderForbidden() {
  shell.refs.content.innerHTML = `<section class="split-page is-centered"><div class="split-state"><strong>Tagesplan nicht verfügbar</strong><span>Die erforderliche Berechtigung fehlt.</span></div></section>`;
}

function desktopRulerLabels() {
  const labels = [];
  for (let minute = OPEN_MINUTE; minute <= CLOSE_MINUTE; minute += 60) {
    labels.push(`<span class="split-ruler-label" style="left:${minutePercent(minute)}%">${formatTime(minute)}</span>`);
  }
  return labels.join('');
}

function periodBandsMarkup() {
  return PERIODS.map((period) => {
    const left = minutePercent(period.startMinute);
    const width = minutePercent(period.endMinute) - left;
    return `<span class="split-period-band is-${period.id}" style="left:${left}%;width:${width}%"><strong>${period.label}</strong><small>${formatTime(period.startMinute)}–${formatTime(period.endMinute)}</small></span>`;
  }).join('');
}

function appointmentCardMarkup(appointment, laneIndex = 0) {
  const left = minutePercent(appointment.startMinute);
  const width = minutePercent(itemEnd(appointment)) - left;
  const selected = state.selectedAppointmentId === appointment.id;
  const hidden = matchesSearch(appointment) ? '' : 'hidden';
  return `
    <button class="split-appointment status-${appointment.status} ${densityClass(appointment.durationMinutes)} ${selected ? 'is-selected' : ''}" style="--lane:${laneIndex};left:calc(${left}% + 3px);width:calc(${width}% - 6px)" type="button" data-appointment-id="${appointment.id}" ${hidden} aria-label="${formatTime(appointment.startMinute)} bis ${formatTime(itemEnd(appointment))}, ${escapeHtml(appointment.customer.displayName)}, ${escapeHtml(appointment.service.displayName)}">
      <span class="split-card-initials" aria-hidden="true">${appointmentInitials(appointment.customer.displayName)}</span>
      <span class="split-card-time">${formatTime(appointment.startMinute)}</span>
      <strong>${escapeHtml(appointment.customer.displayName)}</strong>
      <small>${escapeHtml(appointment.service.displayName)}</small>
    </button>
  `;
}

function operationalCardMarkup(block, laneIndex = 0) {
  const left = minutePercent(block.startMinute);
  const width = minutePercent(itemEnd(block)) - left;
  const hidden = matchesSearch(block) ? '' : 'hidden';
  return `<button class="split-operational kind-${block.kind}" style="--lane:${laneIndex};left:calc(${left}% + 3px);width:calc(${width}% - 6px)" type="button" data-operational-id="${block.id}" ${hidden}><span>${escapeHtml(block.label)}</span></button>`;
}

function nowCursorMarkup(className = 'split-now-cursor') {
  if (!isToday()) return '';
  const minute = currentSalonMinute();
  if (minute < OPEN_MINUTE || minute > CLOSE_MINUTE) return '';
  return `<div class="${className}" style="--now-position:${minutePercent(minute)}%"><span>${formatTime(minute)}</span></div>`;
}

function renderDesktopBoard() {
  const rows = state.plan.staff.map((person) => {
    const layout = layoutTimelineItems(timelineItemsForStaff(person.id));
    const items = layout.items.map(({ item, laneIndex }) => item.kind === 'appointment'
      ? appointmentCardMarkup(item, laneIndex)
      : operationalCardMarkup(item, laneIndex)
    ).join('');
    return `
      <div class="split-staff-row ${layout.laneCount > 1 ? 'has-multiple-lanes' : ''}" style="--lane-count:${layout.laneCount}">
        <button class="split-staff-button" type="button" data-focus-staff="${person.id}" aria-label="Einzeltag von ${escapeHtml(person.displayName)} öffnen">
          <span class="split-staff-avatar">${person.initials}</span>
          <span><strong>${escapeHtml(person.displayName)}</strong><small>${escapeHtml(person.professionalRoleLabel)}</small></span>
        </button>
        <div class="split-track" data-free-track="${person.id}" tabindex="0" role="button" aria-label="Freie Zeit bei ${escapeHtml(person.displayName)} auswählen">${items}</div>
      </div>
    `;
  }).join('');

  return `
    <section class="split-desktop-board" aria-label="Vollständiger Arbeitstag">
      <div class="split-board-header">
        <div class="split-team-head">Team</div>
        <div class="split-time-head">
          <div class="split-period-bands">${periodBandsMarkup()}</div>
          <div class="split-ruler">${desktopRulerLabels()}</div>
        </div>
      </div>
      <div class="split-board-rows">${rows}</div>
      <div class="split-period-divider" aria-hidden="true"></div>
      ${nowCursorMarkup()}
    </section>
  `;
}

function periodMinutePercent(minute, period) {
  return minutePercent(minute, period.startMinute, period.endMinute);
}

function mobileSegmentMarkup(item, period, laneIndex = 0) {
  const start = Math.max(item.startMinute, period.startMinute);
  const end = Math.min(itemEnd(item), period.endMinute);
  if (end <= start || !matchesSearch(item)) return '';
  const left = periodMinutePercent(start, period);
  const width = periodMinutePercent(end, period) - left;
  const continuesBefore = item.startMinute < period.startMinute;
  const continuesAfter = itemEnd(item) > period.endMinute;
  const continuationClass = `${continuesBefore ? 'continues-before' : ''} ${continuesAfter ? 'continues-after' : ''}`;

  if (item.kind !== 'appointment') {
    return `<button class="split-operational split-mobile-card ${continuationClass}" style="--lane:${laneIndex};left:calc(${left}% + 3px);width:calc(${width}% - 6px)" type="button" data-operational-id="${item.id}"><span>${escapeHtml(item.label)}</span></button>`;
  }

  return `
    <button class="split-appointment split-mobile-card status-${item.status} ${densityClass(item.durationMinutes)} ${continuationClass} ${state.selectedAppointmentId === item.id ? 'is-selected' : ''}" style="--lane:${laneIndex};left:calc(${left}% + 3px);width:calc(${width}% - 6px)" type="button" data-appointment-id="${item.id}" aria-label="${formatTime(item.startMinute)} bis ${formatTime(itemEnd(item))}, ${escapeHtml(item.customer.displayName)}">
      <span class="split-card-initials">${appointmentInitials(item.customer.displayName)}</span>
      <span class="split-card-time">${formatTime(item.startMinute)}</span>
      <strong>${escapeHtml(item.customer.displayName)}</strong>
    </button>
  `;
}

function mobilePeriodRuler(period) {
  const labels = [];
  for (let minute = period.startMinute; minute <= period.endMinute; minute += 60) {
    labels.push(`<span style="left:${periodMinutePercent(minute, period)}%">${formatTime(minute)}</span>`);
  }
  return labels.join('');
}

function mobilePeriodMarkup(period) {
  const rows = state.plan.staff.map((person) => {
    const relevant = timelineItemsForStaff(person.id).filter((item) => itemEnd(item) > period.startMinute && item.startMinute < period.endMinute);
    const layout = layoutTimelineItems(relevant);
    const cards = layout.items.map(({ item, laneIndex }) => mobileSegmentMarkup(item, period, laneIndex)).join('');
    return `
      <div class="split-mobile-row" style="--lane-count:${layout.laneCount}">
        <button class="split-mobile-person" type="button" data-focus-staff="${person.id}" aria-label="Einzeltag von ${escapeHtml(person.displayName)} öffnen"><span>${person.initials}</span><strong>${escapeHtml(person.displayName.split(' ')[0])}</strong></button>
        <div class="split-mobile-track" data-period-free-track="${person.id}" data-period-start="${period.startMinute}" data-period-end="${period.endMinute}" tabindex="0" role="button">${cards}</div>
      </div>
    `;
  }).join('');

  let now = '';
  if (isToday()) {
    const minute = currentSalonMinute();
    if (minute >= period.startMinute && minute <= period.endMinute) {
      now = `<div class="split-mobile-now" style="--now-position:${periodMinutePercent(minute, period)}%"><span>${formatTime(minute)}</span></div>`;
    }
  }

  return `
    <section class="split-mobile-period is-${period.id}">
      <header><div><strong>${period.label}</strong><span>${formatTime(period.startMinute)}–${formatTime(period.endMinute)}</span></div><div class="split-mobile-ruler">${mobilePeriodRuler(period)}</div></header>
      <div class="split-mobile-period-body">${rows}${now}</div>
    </section>
  `;
}

function renderMobilePeriods() {
  const minute = isToday() ? currentSalonMinute() : null;
  const periods = minute != null && minute >= PERIOD_SPLIT_MINUTE ? [...PERIODS].reverse() : PERIODS;
  return `<div class="split-mobile-periods">${periods.map(mobilePeriodMarkup).join('')}</div>`;
}

function focusLabels() {
  const labels = [];
  for (let minute = OPEN_MINUTE; minute <= CLOSE_MINUTE; minute += 60) {
    labels.push(`<span style="top:${minutePercent(minute)}%">${formatTime(minute)}</span>`);
  }
  return labels.join('');
}

function focusItemMarkup(item, laneIndex, laneCount) {
  const top = minutePercent(item.startMinute);
  const height = Math.max(1.6, minutePercent(itemEnd(item)) - top);
  const laneWidth = 100 / laneCount;
  const left = laneIndex * laneWidth;
  if (!matchesSearch(item)) return '';
  if (item.kind !== 'appointment') {
    return `<button class="split-focus-operational" style="top:${top}%;height:${height}%;left:calc(${left}% + 7px);width:calc(${laneWidth}% - 11px)" type="button" data-operational-id="${item.id}">${escapeHtml(item.label)}</button>`;
  }
  return `
    <button class="split-focus-appointment status-${item.status} ${state.selectedAppointmentId === item.id ? 'is-selected' : ''}" style="top:${top}%;height:${height}%;left:calc(${left}% + 7px);width:calc(${laneWidth}% - 11px)" type="button" data-appointment-id="${item.id}">
      <span>${formatTime(item.startMinute)}–${formatTime(itemEnd(item))}</span><strong>${escapeHtml(item.customer.displayName)}</strong><small>${escapeHtml(item.service.displayName)}</small>
    </button>
  `;
}

function renderStaffFocus() {
  const person = personById(state.focusedStaffId);
  if (!person) {
    state.focusedStaffId = null;
    return renderMain();
  }
  const layout = layoutTimelineItems(timelineItemsForStaff(person.id));
  const cards = layout.items.map(({ item, laneIndex }) => focusItemMarkup(item, laneIndex, layout.laneCount)).join('');
  let now = '';
  if (isToday()) {
    const minute = currentSalonMinute();
    if (minute >= OPEN_MINUTE && minute <= CLOSE_MINUTE) now = `<div class="split-focus-now" style="top:${minutePercent(minute)}%"><span>${formatTime(minute)}</span></div>`;
  }
  return `
    <section class="split-focus-view">
      <header class="split-focus-context"><div><span class="split-staff-avatar">${person.initials}</span><span><strong>${escapeHtml(person.displayName)}</strong><small>${formatDate(state.date)}</small></span></div><button type="button" data-clear-staff-focus aria-label="Zum Team zurück">${shellIconV2('close')}</button></header>
      <div id="split-focus-scroll" class="split-focus-scroll"><div class="split-focus-grid"><div class="split-focus-time-rail">${focusLabels()}</div><div class="split-focus-track" data-focus-free-track="${person.id}" tabindex="0" role="button">${cards}</div>${now}</div></div>
    </section>
  `;
}

function renderMain() {
  return `<section class="split-page"><span class="split-visually-hidden" role="status">${state.plan.appointments.length} Termine · ${state.plan.staff.length} Mitarbeitende</span>${isMobileLayout() ? renderMobilePeriods() : renderDesktopBoard()}</section>`;
}

function render() {
  cancelAnimationFrame(renderFrame);
  renderFrame = requestAnimationFrame(() => {
    renderHeader();
    if (state.loading) renderLoading();
    else if (state.error) renderError();
    else if (!can(Capability.DAY_PLAN_VIEW)) renderForbidden();
    else shell.refs.content.innerHTML = state.focusedStaffId ? renderStaffFocus() : renderMain();
    bindEvents();
    const focusScroll = document.querySelector('#split-focus-scroll');
    if (focusScroll) requestAnimationFrame(() => { focusScroll.scrollTop = state.focusScrollTop; });
  });
}

function scheduleRender() {
  render();
}

function focusableElements(container) {
  return [...container.querySelectorAll('button:not([disabled]), input:not([disabled]), [href], [tabindex]:not([tabindex="-1"])')]
    .filter((element) => !element.hidden && getComputedStyle(element).display !== 'none');
}

function openOverlay(kind, content, origin = document.activeElement) {
  closeOverlay({ restoreFocus: false });
  state.overlay = kind;
  state.overlayOrigin = origin instanceof HTMLElement ? origin : null;
  document.body.insertAdjacentHTML('beforeend', `<div class="split-dialog-backdrop" data-overlay-backdrop><section class="split-dialog" role="dialog" aria-modal="true" aria-labelledby="split-dialog-title">${content}</section></div>`);
  const overlay = document.querySelector('[data-overlay-backdrop]');
  overlay.addEventListener('mousedown', (event) => { if (event.target === overlay) closeOverlay(); });
  overlay.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      closeOverlay();
      return;
    }
    if (event.key !== 'Tab') return;
    const items = focusableElements(overlay);
    if (!items.length) return;
    if (event.shiftKey && document.activeElement === items[0]) {
      event.preventDefault();
      items.at(-1).focus();
    } else if (!event.shiftKey && document.activeElement === items.at(-1)) {
      event.preventDefault();
      items[0].focus();
    }
  });
  overlay.querySelectorAll('[data-close-overlay]').forEach((button) => button.addEventListener('click', () => closeOverlay()));
  requestAnimationFrame(() => focusableElements(overlay)[0]?.focus());
}

function closeOverlay({ restoreFocus = true } = {}) {
  document.querySelector('[data-overlay-backdrop]')?.remove();
  const origin = state.overlayOrigin;
  state.overlay = null;
  state.overlayOrigin = null;
  if (restoreFocus) requestAnimationFrame(() => origin?.focus({ preventScroll: true }));
}

function openDatePicker(origin) {
  openOverlay('date', `
    <header class="split-dialog-header"><h2 id="split-dialog-title">Datum wählen</h2><button type="button" data-close-overlay aria-label="Schliessen">${shellIconV2('close')}</button></header>
    <div class="split-dialog-body"><label class="split-field"><span>Tag</span><input id="split-date-input" type="date" value="${state.date}"></label></div>
    <footer class="split-dialog-footer"><button class="gw-button" type="button" data-date-today>Heute</button><button class="gw-button gw-button-primary" type="button" data-date-apply>Öffnen</button></footer>
  `, origin);
  document.querySelector('[data-date-today]').addEventListener('click', () => applyDate(todayIso()));
  document.querySelector('[data-date-apply]').addEventListener('click', () => applyDate(document.querySelector('#split-date-input').value));
}

function applyDate(date) {
  if (!date) return;
  emit(DashboardEvent.DAY_DATE_CHANGE_REQUESTED, { date });
  closeOverlay({ restoreFocus: false });
  state.date = date;
  state.selectedAppointmentId = null;
  loadDay(date, { focusDateButton: true });
}

function openAppointmentPanel(id, origin) {
  const appointment = appointmentById(id);
  if (!appointment || !can(Capability.APPOINTMENT_VIEW)) return;
  state.selectedAppointmentId = id;
  emit(DashboardEvent.APPOINTMENT_SELECTED, { appointmentId: id, date: state.date, originGeometry: state.focusedStaffId ? 'staff-focus' : 'two-period-day-map' });
  scheduleRender();
  openOverlay('appointment', `
    <header class="split-dialog-header"><div><span class="split-status">${STATUS_LABEL[appointment.status]}</span><h2 id="split-dialog-title">${escapeHtml(appointment.customer.displayName)}</h2></div><button type="button" data-close-overlay aria-label="Schliessen">${shellIconV2('close')}</button></header>
    <div class="split-dialog-body"><div class="split-detail-grid"><div><span>Zeit</span><strong>${formatTime(appointment.startMinute)}–${formatTime(itemEnd(appointment))}</strong></div><div><span>Person</span><strong>${escapeHtml(appointment.staff.displayName)}</strong></div><div><span>Dienstleistung</span><strong>${escapeHtml(appointment.service.displayName)}</strong></div><div><span>Preis</span><strong>${formatMoney(appointment.price)}</strong></div></div>${appointment.note ? `<div class="split-note"><strong>Salonnotiz</strong><p>${escapeHtml(appointment.note)}</p></div>` : ''}</div>
    <footer class="split-dialog-footer"><button class="gw-button" type="button" data-close-overlay>Schliessen</button>${can(Capability.APPOINTMENT_EDIT) ? '<button class="gw-button gw-button-primary" type="button" data-edit-appointment>Bearbeiten</button>' : ''}</footer>
  `, origin);
  document.querySelector('[data-edit-appointment]')?.addEventListener('click', () => {
    emit(DashboardEvent.APPOINTMENT_EDIT_REQUESTED, { appointmentId: id, source: 'two-period-day-map' });
    shell.announce('Bearbeitungsabsicht ausgelöst. Die Referenz speichert nicht.');
  });
}

function openOperationalPanel(id, origin) {
  const block = state.plan.operationalBlocks.find((item) => item.id === id);
  if (!block) return;
  openOverlay('operational', `
    <header class="split-dialog-header"><h2 id="split-dialog-title">${escapeHtml(block.label)}</h2><button type="button" data-close-overlay aria-label="Schliessen">${shellIconV2('close')}</button></header>
    <div class="split-dialog-body"><div class="split-detail-grid"><div><span>Zeit</span><strong>${formatTime(block.startMinute)}–${formatTime(itemEnd(block))}</strong></div><div><span>Person</span><strong>${escapeHtml(block.staff.displayName)}</strong></div><div><span>Art</span><strong>${block.kind === OperationalKind.TASK ? 'Interne Aufgabe' : escapeHtml(block.kind)}</strong></div></div></div>
    <footer class="split-dialog-footer"><button class="gw-button" type="button" data-close-overlay>Schliessen</button></footer>
  `, origin);
}

function openBookingPanel(options = {}, origin = document.activeElement) {
  if (!can(Capability.DAY_PLAN_CREATE_APPOINTMENT)) return;
  const person = options.staffId ? personById(options.staffId) : null;
  const startMinute = Number.isFinite(options.startMinute) ? options.startMinute : null;
  openOverlay('booking', `
    <header class="split-dialog-header"><h2 id="split-dialog-title">Termin eintragen</h2><button type="button" data-close-overlay aria-label="Schliessen">${shellIconV2('close')}</button></header>
    <div class="split-dialog-body"><div class="split-detail-grid"><div><span>Datum</span><strong>${formatDate(state.date)}</strong></div><div><span>Zeit</span><strong>${startMinute == null ? 'Noch offen' : formatTime(startMinute)}</strong></div><div><span>Person</span><strong>${escapeHtml(person?.displayName ?? 'Noch offen')}</strong></div></div><p>Die Referenz übergibt nur die Buchungsabsicht. Verfügbarkeit und Speicherung bleiben Aufgabe der Produktionsintegration.</p></div>
    <footer class="split-dialog-footer"><button class="gw-button" type="button" data-close-overlay>Abbrechen</button><button class="gw-button gw-button-primary" type="button" data-confirm-booking>Absicht auslösen</button></footer>
  `, origin);
  document.querySelector('[data-confirm-booking]').addEventListener('click', () => {
    emit(DashboardEvent.APPOINTMENT_CREATE_REQUESTED, { date: state.date, staffId: person?.id ?? null, suggestedStartMinute: startMinute, source: options.source ?? 'day-plan-header' });
    shell.announce('Buchungsabsicht ausgelöst. Die Referenz speichert keinen Termin.');
    closeOverlay();
  });
}

function minuteFromHorizontalTrack(track, event, startMinute = OPEN_MINUTE, endMinute = CLOSE_MINUTE) {
  const rect = track.getBoundingClientRect();
  const ratio = clamp((event.clientX - rect.left) / Math.max(1, rect.width), 0, 1);
  return clamp(Math.round((startMinute + ratio * (endMinute - startMinute)) / 15) * 15, startMinute, endMinute - 15);
}

function minuteFromVerticalTrack(track, event) {
  const rect = track.getBoundingClientRect();
  const ratio = clamp((event.clientY - rect.top) / Math.max(1, rect.height), 0, 1);
  return clamp(Math.round((OPEN_MINUTE + ratio * DAY_DURATION) / 15) * 15, OPEN_MINUTE, CLOSE_MINUTE - 15);
}

function focusStaff(staffId, origin) {
  state.focusedStaffId = staffId;
  emit(DashboardEvent.DAY_STAFF_FOCUS_REQUESTED, { staffId, date: state.date, originScale: 'two-period-day-map' });
  scheduleRender();
  requestAnimationFrame(() => document.querySelector('[data-clear-staff-focus]')?.focus({ preventScroll: true }) ?? origin?.focus?.());
}

function clearStaffFocus() {
  const previous = state.focusedStaffId;
  state.focusedStaffId = null;
  emit(DashboardEvent.DAY_STAFF_FOCUS_CLEARED, { staffId: previous, date: state.date, returnScale: 'two-period-day-map' });
  scheduleRender();
  requestAnimationFrame(() => document.querySelector(`[data-focus-staff="${previous}"]`)?.focus({ preventScroll: true }));
}

function returnToTodayNow() {
  const today = todayIso();
  if (state.date !== today) {
    state.date = today;
    state.selectedAppointmentId = null;
    loadDay(today);
  } else {
    scheduleRender();
  }
  shell.announce(`Heute geöffnet. Salonzeit ${formatTime(currentSalonMinute())}.`);
}

function bindEvents() {
  document.querySelectorAll('[data-open-date-picker]').forEach((button) => button.addEventListener('click', () => openDatePicker(button)));
  document.querySelectorAll('[data-create-appointment]').forEach((button) => button.addEventListener('click', () => openBookingPanel({ source: 'day-plan-header' }, button)));
  document.querySelector('[data-retry]')?.addEventListener('click', () => loadDay(state.date));

  document.querySelectorAll('[data-appointment-id]').forEach((button) => button.addEventListener('click', (event) => {
    event.stopPropagation();
    openAppointmentPanel(button.dataset.appointmentId, button);
  }));
  document.querySelectorAll('[data-operational-id]').forEach((button) => button.addEventListener('click', (event) => {
    event.stopPropagation();
    openOperationalPanel(button.dataset.operationalId, button);
  }));
  document.querySelectorAll('[data-focus-staff]').forEach((button) => button.addEventListener('click', () => focusStaff(button.dataset.focusStaff, button)));
  document.querySelector('[data-clear-staff-focus]')?.addEventListener('click', clearStaffFocus);

  document.querySelectorAll('[data-free-track]').forEach((track) => {
    track.addEventListener('click', (event) => {
      if (event.target.closest('[data-appointment-id], [data-operational-id]')) return;
      openBookingPanel({ staffId: track.dataset.freeTrack, startMinute: minuteFromHorizontalTrack(track, event), source: 'day-plan-free-space' }, track);
    });
  });

  document.querySelectorAll('[data-period-free-track]').forEach((track) => {
    track.addEventListener('click', (event) => {
      if (event.target.closest('[data-appointment-id], [data-operational-id]')) return;
      const start = Number(track.dataset.periodStart);
      const end = Number(track.dataset.periodEnd);
      openBookingPanel({ staffId: track.dataset.periodFreeTrack, startMinute: minuteFromHorizontalTrack(track, event, start, end), source: 'day-plan-free-space' }, track);
    });
  });

  const focusTrack = document.querySelector('[data-focus-free-track]');
  focusTrack?.addEventListener('click', (event) => {
    if (event.target.closest('[data-appointment-id], [data-operational-id]')) return;
    openBookingPanel({ staffId: focusTrack.dataset.focusFreeTrack, startMinute: minuteFromVerticalTrack(focusTrack, event), source: 'day-plan-free-space' }, focusTrack);
  });
  const focusScroll = document.querySelector('#split-focus-scroll');
  focusScroll?.addEventListener('scroll', () => { state.focusScrollTop = focusScroll.scrollTop; }, { passive: true });
}

async function loadDay(date, options = {}) {
  state.loading = true;
  state.error = null;
  render();
  try {
    state.plan = await dataSource.getDayPlan({ date });
    state.date = state.plan.date;
    state.loading = false;
    render();
    if (options.focusDateButton) requestAnimationFrame(() => document.querySelector('[data-open-date-picker]')?.focus({ preventScroll: true }));
  } catch (error) {
    state.error = error;
    state.loading = false;
    render();
  }
}

function refreshClockSurface() {
  shell.refreshClock();
  if (!state.loading && !state.error) scheduleRender();
}

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  if (state.overlay) {
    event.preventDefault();
    closeOverlay();
  } else if (state.focusedStaffId) {
    event.preventDefault();
    clearStaffFocus();
  }
});

window.addEventListener('resize', () => scheduleRender(), { passive: true });

async function initialize() {
  try {
    state.session = await dataSource.getSessionContext();
    state.date = todayIso();
    await loadDay(state.date);
    clearInterval(clockTimer);
    clockTimer = window.setInterval(refreshClockSurface, CLOCK_TICK_MS);
  } catch (error) {
    state.error = error;
    state.loading = false;
    render();
  }
}

initialize();
