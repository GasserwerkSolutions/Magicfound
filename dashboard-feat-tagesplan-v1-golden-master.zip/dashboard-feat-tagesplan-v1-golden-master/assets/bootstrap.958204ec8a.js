(() => {
      const root = document.documentElement;
      let initialThemeMode = "system";
      try { initialThemeMode = localStorage.getItem("gasserwerk-theme-mode") || "system"; } catch { /* private context */ }
      const initialTheme = initialThemeMode === "light" ? "light" : initialThemeMode === "dark" ? "dark" : window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      root.dataset.themeMode = initialThemeMode;
      root.dataset.theme = initialTheme;
      root.style.colorScheme = initialTheme === "dark" ? "dark" : "light";
      const classify = () => {
        const width = window.innerWidth;
        const height = window.innerHeight;
        const coarse = window.matchMedia?.('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;
        const compactTouch = coarse && Math.min(width, height) <= 820 && Math.max(width, height) <= 1180;
        const mobile = width <= 760 || compactTouch;
        root.classList.toggle('mobile-ui', mobile);
        root.classList.toggle('mobile-portrait', mobile && height >= width);
        root.classList.toggle('mobile-landscape', mobile && width > height);
        root.classList.toggle('tablet-ui', mobile && Math.min(width, height) >= 600);
      };
      classify();
      window.__gasserwerkClassifyViewport = classify;
    })();

if (new URLSearchParams(location.search).has("demo")) document.documentElement.classList.add("demo-mode");
