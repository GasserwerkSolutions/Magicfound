import { DashboardDataSource } from './contracts/dashboard-data-source.js';
import { Capability } from './contracts/capabilities.js';
import {
  REFERENCE_DATE,
  REFERENCE_INSTANT,
  referenceAdministrationSettings,
  referenceAppointments,
  referenceAuthenticationOptions,
  referenceCustomers,
  referenceOnboardingState,
  referenceOperationalBlocks,
  referenceServices,
  referenceSessionContext,
  referenceStaff,
  stressAppointments
} from './fixtures/reference-fixtures.js';

export const MockScenario = Object.freeze({ READY: 'ready', EMPTY: 'empty', STRESS: 'stress', PARTIAL: 'partial', ERROR: 'error', OFFLINE: 'offline', STALE: 'stale', FORBIDDEN: 'forbidden' });
const KNOWN_SCENARIOS = new Set(Object.values(MockScenario));

function clone(value) { return globalThis.structuredClone ? structuredClone(value) : JSON.parse(JSON.stringify(value)); }
function delay(milliseconds) { return milliseconds > 0 ? new Promise((resolve) => setTimeout(resolve, milliseconds)) : Promise.resolve(); }
function compareAppointments(first, second) { return first.date.localeCompare(second.date) || first.startMinute - second.startMinute || first.id.localeCompare(second.id); }
function includesText(value, query) { return String(value ?? '').toLocaleLowerCase('de-CH').includes(query.toLocaleLowerCase('de-CH')); }

export class MockDataSourceError extends Error {
  constructor(message, options = {}) {
    super(message);
    this.name = 'MockDataSourceError';
    this.code = options.code ?? 'MOCK_ERROR';
    this.retryable = options.retryable ?? true;
  }
}

export class MockDashboardDataSource extends DashboardDataSource {
  constructor(options = {}) {
    super();
    const scenario = options.scenario ?? MockScenario.READY;
    if (!KNOWN_SCENARIOS.has(scenario)) throw new RangeError(`unknown mock scenario: ${scenario}`);
    this.scenario = scenario;
    this.latencyMs = Number.isFinite(options.latencyMs) ? Math.max(0, options.latencyMs) : 0;
    this.clock = typeof options.clock === 'function' ? options.clock : () => new Date(REFERENCE_INSTANT);
    this.capabilities = options.capabilities ? [...options.capabilities] : null;
  }

  setScenario(scenario) {
    if (!KNOWN_SCENARIOS.has(scenario)) throw new RangeError(`unknown mock scenario: ${scenario}`);
    this.scenario = scenario;
  }

  async #prepare(options = {}) {
    await delay(this.latencyMs);
    if (this.scenario === MockScenario.ERROR && !options.allowInError) throw new MockDataSourceError('Referenzdaten konnten nicht geladen werden.', { code: 'MOCK_ERROR' });
    if (this.scenario === MockScenario.OFFLINE && !options.allowInOffline) throw new MockDataSourceError('Keine Netzwerkverbindung.', { code: 'OFFLINE', retryable: true });
  }

  #meta() {
    return { scenario: this.scenario, isStale: this.scenario === MockScenario.STALE, referenceDate: REFERENCE_DATE, generatedAt: this.clock().toISOString() };
  }

  #session() {
    const session = clone(referenceSessionContext);
    if (this.scenario === MockScenario.FORBIDDEN) session.capabilities = [Capability.AUTH_SIGN_IN];
    if (this.capabilities) session.capabilities = [...this.capabilities];
    return session;
  }

  #staff() { return clone(referenceStaff); }
  #services() { return clone(referenceServices); }
  #customers() { return clone(referenceCustomers); }

  #appointments() {
    if (this.scenario === MockScenario.EMPTY) return [];
    const base = clone(referenceAppointments);
    if (this.scenario === MockScenario.STRESS) return [...base, ...clone(stressAppointments)].sort(compareAppointments);
    if (this.scenario === MockScenario.PARTIAL) return base.map(({ note, price, visitStep, ...appointment }) => appointment);
    return base;
  }

  #blocks() { return this.scenario === MockScenario.EMPTY ? [] : clone(referenceOperationalBlocks); }

  #appointmentView(appointment) {
    const customer = this.#customers().find((item) => item.id === appointment.customerId);
    const service = this.#services().find((item) => item.id === appointment.serviceId);
    const staff = this.#staff().find((item) => item.id === appointment.staffId);
    return {
      id: appointment.id,
      kind: 'appointment',
      date: appointment.date,
      startMinute: appointment.startMinute,
      durationMinutes: appointment.durationMinutes,
      customer: customer ? { id: customer.id, displayName: customer.displayName, phoneLabel: customer.phoneLabel } : { id: appointment.customerId, displayName: 'Unbekannte Kundschaft', phoneLabel: null },
      service: service ? { id: service.id, displayName: service.displayName } : { id: appointment.serviceId, displayName: 'Unbekannte Dienstleistung' },
      staff: staff ? { id: staff.id, displayName: staff.displayName } : { id: appointment.staffId, displayName: 'Unbekannte Person' },
      status: appointment.status,
      note: appointment.note ?? null,
      price: Number.isFinite(appointment.price) ? appointment.price : null,
      visitStep: appointment.visitStep ?? null
    };
  }

  #blockView(block) {
    const staff = this.#staff().find((item) => item.id === block.staffId);
    return { id: block.id, kind: block.kind, date: block.date, startMinute: block.startMinute, durationMinutes: block.durationMinutes, staff: staff ? { id: staff.id, displayName: staff.displayName } : { id: block.staffId, displayName: 'Unbekannte Person' }, label: block.label, note: block.note ?? null };
  }

  async getSessionContext() { await this.#prepare({ allowInError: true, allowInOffline: true }); return this.#session(); }
  async getAuthenticationOptions() { await this.#prepare({ allowInError: true, allowInOffline: true }); return clone(referenceAuthenticationOptions); }

  async getOnboardingState() {
    await this.#prepare();
    const state = clone(referenceOnboardingState);
    if (this.scenario === MockScenario.EMPTY) {
      state.currentStepId = 'salonprofil';
      state.steps = state.steps.map((step, index) => ({ ...step, state: index === 0 ? 'in-progress' : 'not-started' }));
      state.servicesSummary = { count: 0, completeCount: 0 };
      state.staffSummary = { count: 0, completeCount: 0 };
      state.workingHoursSummary = { completeCount: 0, attentionCount: 0 };
      state.readiness = { isBookable: false, blockers: ['Salonprofil unvollständig'], warnings: [] };
    }
    return { ...state, meta: this.#meta() };
  }

  async getDayPlan(query = {}) {
    await this.#prepare();
    const date = query.date ?? REFERENCE_DATE;
    const session = this.#session();
    const items = date === REFERENCE_DATE ? [...this.#appointments().map((item) => this.#appointmentView(item)), ...this.#blocks().map((item) => this.#blockView(item))] : [];
    return {
      date,
      salon: { id: session.salon.id, name: session.salon.name, locationLabel: session.salon.locationLabel, timeZone: session.salon.timeZone, openingMinute: 480, closingMinute: 1080, currentInstant: this.clock().toISOString() },
      staff: this.#staff(),
      items,
      meta: this.#meta()
    };
  }

  async listAppointments(query = {}) {
    await this.#prepare();
    let items = this.#appointments().map((item) => this.#appointmentView(item));
    if (query.dateFrom) items = items.filter((item) => item.date >= query.dateFrom);
    if (query.dateTo) items = items.filter((item) => item.date <= query.dateTo);
    if (query.statuses?.length) items = items.filter((item) => query.statuses.includes(item.status));
    if (query.staffIds?.length) items = items.filter((item) => query.staffIds.includes(item.staff.id));
    if (query.serviceIds?.length) items = items.filter((item) => query.serviceIds.includes(item.service.id));
    if (query.customerQuery) items = items.filter((item) => includesText(item.customer.displayName, query.customerQuery));
    items.sort(compareAppointments);
    const pageSize = Number.isInteger(query.pageSize) && query.pageSize > 0 ? query.pageSize : items.length;
    return { items: items.slice(0, pageSize), pageInfo: { cursor: null, nextCursor: items.length > pageSize ? String(pageSize) : null, totalCount: items.length }, meta: this.#meta() };
  }

  async getAppointment(id) {
    await this.#prepare();
    const appointment = this.#appointments().find((item) => item.id === id);
    if (!appointment) throw new MockDataSourceError(`Termin nicht gefunden: ${id}`, { code: 'NOT_FOUND', retryable: false });
    return { item: this.#appointmentView(appointment), meta: this.#meta() };
  }

  async listCustomers(query = {}) {
    await this.#prepare();
    let customers = this.scenario === MockScenario.EMPTY ? [] : this.#customers();
    if (query.text) customers = customers.filter((item) => includesText(item.displayName, query.text) || includesText(item.phoneLabel, query.text));
    customers.sort((first, second) => first.displayName.localeCompare(second.displayName, 'de-CH'));
    const appointmentViews = this.#appointments().map((item) => this.#appointmentView(item));
    const items = customers.map((customer) => {
      const visits = appointmentViews.filter((item) => item.customer.id === customer.id).sort(compareAppointments);
      return { ...customer, lastVisit: visits.filter((item) => item.date <= REFERENCE_DATE).at(-1)?.date ?? null, nextAppointment: visits.find((item) => item.date >= REFERENCE_DATE && item.status !== 'cancelled') ?? null };
    });
    return { items, pageInfo: { cursor: null, nextCursor: null, totalCount: items.length }, meta: this.#meta() };
  }

  async getCustomer(id) {
    await this.#prepare();
    const customer = this.#customers().find((item) => item.id === id);
    if (!customer) throw new MockDataSourceError(`Kundschaft nicht gefunden: ${id}`, { code: 'NOT_FOUND', retryable: false });
    const appointments = this.#appointments().map((item) => this.#appointmentView(item)).filter((item) => item.customer.id === id).sort(compareAppointments);
    return { item: { ...customer, notes: customer.tags.includes('Kontakt per SMS') ? ['Kontakt bevorzugt per SMS'] : [], nextAppointments: appointments.filter((item) => item.date >= REFERENCE_DATE && !['completed', 'cancelled'].includes(item.status)), visitHistory: appointments.filter((item) => item.status === 'completed').reverse(), summary: { appointmentCount: appointments.length } }, meta: this.#meta() };
  }

  async listStaff(query = {}) {
    await this.#prepare();
    let items = this.scenario === MockScenario.EMPTY ? [] : this.#staff();
    if (query.activeOnly) items = items.filter((item) => item.isActive);
    if (query.text) items = items.filter((item) => includesText(item.displayName, query.text) || includesText(item.professionalRoleLabel, query.text));
    return { items, meta: this.#meta() };
  }

  async getStaffMember(id) {
    await this.#prepare();
    const item = this.#staff().find((staff) => staff.id === id);
    if (!item) throw new MockDataSourceError(`Teammitglied nicht gefunden: ${id}`, { code: 'NOT_FOUND', retryable: false });
    return { item, meta: this.#meta() };
  }

  async listServices(query = {}) {
    await this.#prepare();
    let items = this.scenario === MockScenario.EMPTY ? [] : this.#services();
    if (query.activeOnly) items = items.filter((item) => item.isActive);
    if (query.staffIds?.length) items = items.filter((item) => item.assignedStaffIds.some((id) => query.staffIds.includes(id)));
    if (query.text) items = items.filter((item) => includesText(item.displayName, query.text));
    return { items, meta: this.#meta() };
  }

  async getService(id) {
    await this.#prepare();
    const item = this.#services().find((service) => service.id === id);
    if (!item) throw new MockDataSourceError(`Dienstleistung nicht gefunden: ${id}`, { code: 'NOT_FOUND', retryable: false });
    return { item, meta: this.#meta() };
  }

  async getAdministrationSettings() { await this.#prepare(); return { ...clone(referenceAdministrationSettings), meta: this.#meta() }; }
}

export function createMockDashboardDataSource(options = {}) { return new MockDashboardDataSource(options); }
