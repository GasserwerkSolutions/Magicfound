const referenceValue = new URLSearchParams(location.search).get('referenceNow');

if (/^\d{1,2}:\d{2}$/.test(referenceValue ?? '')) {
  const [hour, minute] = referenceValue.split(':').map(Number);
  const isValid = hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59;

  if (isValid) {
    const label = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    const hourAngle = ((hour % 12) + minute / 60) * 30;
    const minuteAngle = minute * 6;

    const syncReferenceClock = () => {
      const face = document.querySelector('.gw-clock-face');
      const digital = document.querySelector('[data-clock-digital]');
      const button = document.querySelector('[data-work-clock]');
      if (!face || !digital) return false;

      face.style.setProperty('--gw-clock-hour-angle', `${hourAngle}deg`);
      face.style.setProperty('--gw-clock-minute-angle', `${minuteAngle}deg`);
      if (digital.textContent !== label) digital.textContent = label;
      button?.setAttribute('aria-label', `Salonzeit ${label}. Heutigen Tagesplan öffnen.`);
      return true;
    };

    const start = () => {
      if (!syncReferenceClock()) {
        requestAnimationFrame(start);
        return;
      }

      const digital = document.querySelector('[data-clock-digital]');
      const observer = new MutationObserver(syncReferenceClock);
      observer.observe(digital, { childList: true, subtree: true });
      addEventListener('pagehide', () => observer.disconnect(), { once: true });
    };

    start();
  }
}
