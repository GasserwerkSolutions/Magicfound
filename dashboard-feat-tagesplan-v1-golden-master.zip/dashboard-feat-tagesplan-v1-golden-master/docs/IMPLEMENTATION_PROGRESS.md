# Gasserwerk Dashboard · Implementierungsfortschritt

## Aktiver Branch

```text
feat/canonical-product-surface-v1
```

## Vertragsphase

| Bereich | Status |
|---|---|
| gemeinsamer UI-Vertrag | Zur Freigabe |
| Login | Zur Freigabe |
| Onboarding | Zur Freigabe |
| Tagesplan | Zur Freigabe; vertikale Teamfläche in Browserabnahme |
| Termine | Zur Freigabe |
| Kundschaft | Zur Freigabe |
| Team | Zur Freigabe |
| Angebot | Zur Freigabe |
| Verwaltung | Zur Freigabe |

## Modulare Basis

- [x] Datenquellenvertrag
- [x] Eventkatalog
- [x] Capability-Katalog
- [x] Domainwerte
- [x] gemeinsame Produktschale
- [x] feste Desktop-Arbeitsuhr
- [x] vier globale Navigationsziele
- [x] 14-Zoll-/Standard-/Mobil-Dichtebasis
- [x] deterministischer Mock-Datenadapter
- [x] automatische Verifikation und GitHub-Pages-Veröffentlichung

## Aktiver Tagesplanversuch

- [x] vertikale Zeitachse 08:00–18:00
- [x] fünf Mitarbeitendenspalten
- [x] operative Agenda Davor / Jetzt / Danach
- [x] nächste freie Lücke
- [x] 15-/30-/60-Minuten-Raster
- [x] Hauptanker 09:00 / 12:00 / 15:00 / 18:00
- [x] globale vergangene Zeitfläche mit 5-Prozent-Ausgangswert
- [x] exakte horizontale Jetzt-Grenze
- [x] sichtbare Start-/Endzeit auf ausreichend hohen Karten
- [x] fachliche Statuskante unabhängig von zeitlicher Lage
- [x] Personenfokus ohne Geometriewechsel
- [x] neutrale 34-Prozent-Fokusmaske auf Kontextspalten
- [x] fünf Spalten bleiben auch im Fokus und auf Mobil erhalten
- [x] Suchtreffer und Auswahl durchbrechen die Fokusmaske
- [x] Datumsauswahl, Termin-, Aufgaben- und Buchungskontext
- [x] statische und echte Browserprüfung
- [x] Screenshotmatrix über alle Zielviewports
- [ ] qualitative visuelle Abnahme durch Produktverantwortung
- [ ] Übernahme nach `pages/tagesplan/`
- [ ] Tagesplanvertrag auf `Implementiert` setzen
- [ ] hochwertiger SVG-Dienstleistungssatz

## Verworfene Hypothese

Die zeitliche Dreitonigkeit einzelner Terminkarten wurde nach genauerer Prüfung verworfen. Vergangenheit, Gegenwart und Zukunft werden durch eine einzige globale Zeitfläche und die Jetzt-Grenze ausgedrückt. Dadurch bleiben Status und Zeit semantisch getrennt.

## Nächste Arbeitsfolge

1. Live-Referenz der vertikalen Teamfläche prüfen
2. Dichte, Kartenlesbarkeit, Zeitfläche und Fokusmaske visuell abnehmen
3. akzeptierte Geometrie nach `pages/tagesplan/` übernehmen
4. Tagesplanvertrag auf `Implementiert` setzen
5. hochwertigen monochromen SVG-Satz entwickeln
6. Verwaltung, Kundschaft und Termine auf dieselbe Schale konsolidieren

## Schutzregel

Die Referenz emittiert fachliche Events, behauptet aber keine Backendpersistenz. Die archivierte horizontale Tageslandkarte bleibt nachvollziehbar erhalten.
