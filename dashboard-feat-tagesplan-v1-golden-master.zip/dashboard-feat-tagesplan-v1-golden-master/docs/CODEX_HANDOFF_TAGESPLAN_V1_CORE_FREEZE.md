# Codex-Handoff · Tagesplan v1.0 · Technischer Core Freeze

Status: **Freeze Candidate – nicht freigegeben**  
Repository: `GasserwerkSolutions/dashboard`  
Ausgangsbranch: `feat/tagesplan-v1-golden-master`  
Empfohlener Codex-Branch: `codex/tagesplan-v1-core-freeze`  
Übergeordneter Draft-PR: `#3`  
Implementationsbasis vor dem Handoff: `db354d99ca8d55653c17f499ce6a10b0b1eed4cd`

## 1. Mission

Führe den Tagesplan zu einem neutralen, reproduzierbaren, eigenständig ausführbaren und vollständig geprüften technischen Core Freeze. **Keine Beseelung vor dem Freeze.** Kein Merge, Deployment oder finaler Tag ohne ausdrückliche Freigabe aus dem führenden Chat.

```text
Geometrie
→ Funktion und Zustände
→ Accessibility und Resilienz
→ deterministischer Single-HTML-Build
→ vollständige technische Abnahme
→ Core Freeze
→ erst danach Beseelungsvarianten
```

## 2. Rollen

### Codex

- Repository-Analyse, Implementierung und Bereinigung;
- lokale und CI-basierte Tests;
- Browserautomation;
- deterministischer Build;
- Artefakte und technische Dokumentation;
- Child-PR gegen `feat/tagesplan-v1-golden-master`.

### Führender Chat

- Produkt- und Architekturfreigabe;
- visuelle Beurteilung;
- Entscheidung bei Vertragskonflikten;
- Freigabe der Gates;
- Freigabe von Freeze-Commit und finalem Tag;
- spätere Führung der Beseelungsvarianten.

Produktsemantik nie still ändern. Bei einem echten Konflikt Optionen und Evidenz liefern und stoppen.

## 3. Zuerst vollständig lesen

```text
AGENTS.md
docs/TAGESPLAN_V1_EXECUTION_CONTRACT.md
docs/TAGESPLAN_V1_FREEZE_POLICY.md
docs/WIRKUNGSSYSTEM_V1.md
docs/decisions/ADR-004-vertical-day-agenda.md
docs/decisions/ADR-005-collapsible-header-agenda.md
docs/decisions/ADR-007-tagesplan-v1-golden-master.md
docs/decisions/ADR-008-technical-freeze-before-beseelung.md
references/tagesplan/v1.0/CONTRACT.md
references/tagesplan/v1.0/README.md
pages/tagesplan/CONTRACT.md
```

## 4. Unveränderliche Produktwahrheit

### Aufgabe

> Was geschieht jetzt, bei wem und was kommt unmittelbar danach?

### Geometrie

```text
Zeit vertikal
Mitarbeitende horizontal
08:00–18:00
Raster 15 / 30 / 60 Minuten
starke Zeitanker 09:00 / 12:00 / 15:00 / 18:00
Agenda als temporäres Kopfzeilen-Popover
Fokus als Zustand derselben Teamfläche
```

### Seitenleiste

Reihenfolge bleibt: `GASSERWERK` → Salonzeit → Arbeitsnavigation → Betrieb und angemeldete Person. Die Uhr bleibt ein konstantes Arbeitsinstrument; `Coiffure Sonnegg` bleibt unten als Betriebskontext.

### Zeitmodell

- Vergangenheit ist eine globale Flächenschicht, keine Kartentönung.
- Position = Beginn, Höhe = Dauer.
- Jetzt-Linie hinter Karten und vor Raster.
- Statusfarbe bleibt fachlicher Status.
- vergangene/zukünftige Tage ohne falsche Jetzt-Semantik.
- Zeitzone `Europe/Zurich`.
- Referenzdatum `2026-08-25`, Referenzzeit `11:22`.

### Fokus

- kein Einpersonen-Renderer;
- alle fünf Spalten bleiben sichtbar;
- Kontextspalten neutral zurücknehmen, aber bedienbar lassen;
- Fokus verändert weder Geometrie noch globale Zeitlage.

### Agenda

- standardmäßig geschlossen und nicht-modal;
- gleiche Objekte wie Kalender;
- `Davor`, `Jetzt`, `Danach`, freie Lücke;
- `x weitere` statt stillem Abschneiden;
- Schließen stellt Fokus zum Ursprung wieder her;
- keine Änderung der Kalendergeometrie.

### Responsive

Bei mindestens 44 CSS-Pixeln pro Stunde:

- kompletter Tag und fünf Personen gleichzeitig;
- kein Dokument-, Seiten-, Panel- oder Kalenderscroll;
- kein Doppelscroll;
- Rasterabschluss innerhalb von 2 Pixeln.

Unter 44 Pixeln pro Stunde oder bei unlesbarer Mitarbeitendenbreite:

- exakt ein vertikaler Scroll-Owner: Kalender-Viewport;
- sticky Zeitachse und Mitarbeitendenkopf;
- horizontale Mitarbeitendenbewegung;
- Seite ohne zusätzlichen Scroll;
- initial nahe Jetzt, danach Respekt vor manueller Bewegung.

Tests klassifizieren anhand gemessener Geometrie. Nicht jeder Fall über 960 Pixel Breite ist automatisch `desktop-fit`.

### Kartentext

```text
full       Zeit · Name · Leistung
time-name  Zeit · Name
name       Name
first      sinnvoller Kurzname
initials   Initialen / später Symbol
```

Keine zufälligen Ellipsen und keine beliebig kleine Schrift.

## 5. Core Freeze ist neutral

Im Freeze nicht aktivieren:

- alpine Szenen oder Murmeltier-Habitat;
- emotionale Materialvarianten;
- experimentelle Mikroanimationen;
- alternative Sprachtemperaturen;
- finale Dienstleistungssymbole.

Das Wirkungssystem darf als Vertrag und Anschlussstelle verbleiben. Freeze-Manifest: `"beseelung": "disabled"`.

## 6. Bekannte Blocker

### CI

Fast alle bestehenden Prüfungen sind grün. Rot ist:

```text
Verify Tagesplan v1 responsive surface matrix
```

Assertions nicht abschwächen, nur damit CI grün wird.

### Ready-/Diagnose-Race

`surface-v1.js` findet in Headless-Läufen die gerenderten Kalenderknoten nicht zuverlässig; `data-va-layout-ready` bleibt `0` oder Diagnostik fehlt. Erforderlich:

- expliziter Render-ready- und Layout-stable-Handshake;
- Tests warten darauf;
- keine MutationObserver-/ResizeObserver-Rückkopplung;
- keine Messung halb gerenderter Frames.

### Zwei konkurrierende V1-Pfade

```text
surface-v1.css / surface-v1.js
tagesplan-v1.css / tagesplan-v1.js
```

Die Experimentseite lädt `surface-v1.*`, der Single-HTML-Builder bündelt `tagesplan-v1.*`. Entwicklungsseite, Test und Golden Master führen dadurch potenziell unterschiedliche Wahrheiten aus. Ziel: genau ein autoritativer Pfad; den anderen erst nach Paritätsnachweis löschen.

### Aktive Beseelung im technischen Pfad

`tagesplan-v1.js` enthält Dienstleistungssymbole und ein alpines Leerzustand-Habitat. Aus dem Core Freeze entfernen oder in eine deaktivierte spätere Wirkungsschicht verschieben.

### Temporäre Datei

Löschen:

```text
scripts/.tagesplan-v1-payload-01.part
```

Auch nach weiteren `*part*`, `*payload*`, `*patch*`, `*diagnose*`, `*tmp*` suchen.

### Builder

Aktuell nicht deterministisch bzw. freeze-tauglich:

- `new Date().toISOString()`;
- `npx --yes esbuild@...` als Netzbezug;
- alpine Ressource;
- keine festgeschriebene Toolchain/Lockdatei.

Erforderlich: gepinnte lokale Abhängigkeiten, `SOURCE_DATE_EPOCH`, stabile Reihenfolge, offline Build nach `npm ci`, Doppelbuild mit identischen SHA-256-Werten.

## 7. Ausführungsfolge

### Phase 0 · Baseline

1. aktuellen Head auschecken;
2. `codex/tagesplan-v1-core-freeze` erzeugen;
3. alle bestehenden Prüfungen reproduzieren;
4. Baseline-SHA, Tree, Node und Browser protokollieren;
5. Root-Cause-Bericht vor großem Refactor.

### Phase 1 · Autoritativer Pfad

- einen V1-Pfad auswählen und begründen;
- CSS trägt Layoutwahrheit;
- JS setzt Zustände, koordiniert Ready/Stable und misst;
- Entwicklungspage, Test und Builder nutzen denselben Pfad;
- keine Inline-/CSS-Höhenkonkurrenz;
- Scrollbars nicht nur verstecken;
- Agenda und Fokus geometrisch invariant.

Empfohlene Signale:

```text
data-tp-render-state="ready"
data-tp-layout-state="stable"
data-tp-diagnostics-version="1"
```

### Phase 2 · Geometriematrix

```text
1366×768
1440×810
1440×900
1512×982
1600×900
1920×1080
1024×768
844×390
430×932
390×844
```

Zoomäquivalente 90/100/110/125 Prozent auf mindestens 1512×982 und 1366×768.

#### `desktop-fit`

```text
hourPixels >= 44
documentOverflowX/Y <= 2
pageOverflowY <= 2
calendarOverflowY <= 2
verticalScrollOwnerCount = 0
abs(gridBottomGap) <= 2
08:00 und 18:00 sichtbar
fünf Personen sichtbar
```

#### `compact-scroll`

```text
documentOverflowX/Y <= 2
pageOverflowY <= 2
verticalScrollOwnerCount = 1
primaryScrollOwner = calendar viewport
calendarOverflowY > 2
horizontaler Mitarbeitendenüberlauf, wenn nötig
sticky Zeitachse und Staff-Header
initial nahe Jetzt
```

### Phase 3 · Zustände

Deterministisch reproduzierbar:

```text
normal stress quiet empty loading error offline stale forbidden
before-opening during-opening after-closing
past-date future-date
staff-focus appointment-selected agenda-open search-active
```

Empfohlene Parameter:

```text
?scenario=...
?referenceDate=2026-08-25
?referenceNow=07:30|11:22|18:30
?dateMode=past|today|future
?focus=melanie
?appointment=<fixture-id>
?agenda=open
?search=Anna
```

### Phase 4 · Accessibility/Resilienz

- vollständige Tastaturbedienung;
- sichtbarer Fokus und logische Tab-Reihenfolge;
- `aria-pressed`, `aria-expanded`, `aria-controls`;
- korrekte Popover-/Dialogrollen;
- `Escape`-Hierarchie und Fokuswiederherstellung;
- vollständige accessible names für gekürzte Karten;
- Touchziele mindestens 44×44 CSS-Pixel;
- Reduced-Motion-Parität;
- keine Information nur durch Farbe;
- keine Konsolenfehler oder unbehandelten Rejections;
- Tab-Wiederaufnahme synchronisiert Zeit.

Ergebnis in `references/tagesplan/v1.0/ACCESSIBILITY.md` dokumentieren.

### Phase 5 · Golden Master

Ziel:

```text
references/tagesplan/v1.0/tagesplan-reference.html
```

Vollständig eingebettet, keine externe Laufzeitressource, file:// und HTTP, keine Backend-/CDN-/Service-Worker-Abhängigkeit, URL-Zustände funktionieren, Beseelung deaktiviert.

### Phase 6 · Manifest und Checksummen

Keine zirkuläre Selbst-SHA bauen. Zwei Commitstufen:

- Commit A: finaler Source Candidate, grün;
- Commit B: generierte Referenz, Manifest, Checksummen, Evidenz; keine Quelländerung.

Manifest referenziert Commit A und dessen Tree. Finaler annotierter Tag zeigt später auf Commit B. `CHECKSUMS.sha256` hasht sich nicht selbst.

### Phase 7 · Bereinigung

Am Ende genau ein V1-Pfad, keine Payload-/Patch-/Diagnosereste, keine alpinen Assets im Core-Golden-Master, keine ungenutzten Imports, keine lokalen absoluten Pfade und keine zufälligen Buildartefakte.

### Phase 8 · Browser und CI

Pflicht:

```text
Chromium current
Firefox stable
WebKit/Safari-kompatibel
```

Mindestens getrennte Jobs für statische Verträge, Chromium, Firefox, WebKit, Accessibility, deterministischen Build und Freeze-Integrität. Zwei vollständige grüne Kontrollläufe desselben Commit A.

## 8. Freeze-Paket

```text
references/tagesplan/v1.0/
├── tagesplan-reference.html
├── CONTRACT.md
├── STATES.md
├── INTEGRATION.md
├── ACCESSIBILITY.md
├── FREEZE_MANIFEST.json
├── CHECKSUMS.sha256
└── evidence/
```

## 9. Tag-Sperre

Codex darf den finalen Tag erst nach der wortwörtlichen Freigabe setzen:

```text
Core Freeze freigegeben. Finalen Tag setzen.
```

Dann:

```text
tagesplan-v1.0-core-freeze
```

Tag niemals verschieben oder überschreiben.

## 10. Stop-Regeln

Stoppen und Entscheidung anfordern, wenn:

- Vertrag und Testannahme widersprechen;
- no-scroll nur durch unlesbare Schrift, abgeschnittene Zeit oder zu kleine Touchziele erreichbar wäre;
- Status-, Fokus-, Such- oder Datensemantik geändert werden müsste;
- Firefox/WebKit nur durch Überspringen „bestehen“;
- Beseelung technisch erforderlich erscheint;
- main, kanonische Linie, Pages, Merge oder Tag betroffen wären.

## 11. Verboten

- mit `Termine` beginnen;
- Beseelungsvarianten anlegen;
- Tests lockern;
- Scrollbars nur verstecken;
- Inhalte still verstecken;
- neue permanente Controls/Modi;
- zweite Agenda-Datenquelle;
- verschachtelte Modalketten;
- PR #3 mergen oder ready setzen;
- öffentliche Pages-Veröffentlichung;
- finaler Tag ohne Freigabe;
- „fertig“ melden, solange ein Pflichtgate rot ist.

## 12. Berichtsschema

```text
STATUS
- Gate / pass-fail-blocked

REPOSITORY
- Base SHA / Head SHA / Branch / PR

ÄNDERUNGEN
- Dateien / Architektur / entfernte Altpfade

PRÜFUNGEN
- Befehle / Ergebnisse / CI / Browser-Viewport-Zustand

EVIDENZ
- Screenshots / Messdaten / Checksummen

RISIKEN
- Abweichungen / Ursache / Korrektur

ENTSCHEIDUNGSBEDARF
- Frage / Optionen / Empfehlung
```

## 13. Übergabe an den führenden Chat

Vor Tagsetzung liefern:

```text
source commit A
artifact commit B
source tree
Codex-PR
PR #3
Single-HTML-Pfad und SHA-256
Manifest-SHA-256
Checksummenpfad
zwei CI-Run-IDs
Browser-Versionen
Evidenzartefakt
gelöschte temporäre Dateien
autoritativer Implementationspfad
bekannte Einschränkungen
offene Entscheidungen
```

Bis zur ausdrücklichen Freigabe lautet der Status ausschließlich:

```text
Freeze Candidate – nicht freigegeben
```
