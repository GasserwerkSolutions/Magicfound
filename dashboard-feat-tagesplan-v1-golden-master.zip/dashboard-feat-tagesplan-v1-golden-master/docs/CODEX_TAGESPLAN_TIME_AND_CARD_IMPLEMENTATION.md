# Codex-Implementierungsauftrag · Tagesplan-Zeitfläche und Terminkarten

Status: **Verbindliche Ergänzung zum Core-Freeze-Handoff**  
Vorrang bei Widerspruch: `ADR-009-calendar-surface-before-appointment-cards.md`

## 1. Korrektur der Ausführungsfolge

„Erst die Fläche, dann Termine“ bezeichnet die innere Reihenfolge des Tagesplans:

```text
Kalenderfläche und Zeitwahrheit
→ Terminkarten und Dienstleistungssemantik
→ technischer Core Freeze
→ Beseelungsvarianten
```

Es bedeutet ausdrücklich **nicht**:

```text
Tagesplan fertigstellen
→ separate Produktseite Termine beginnen
```

Die separate Seite `Termine` bleibt außerhalb dieses Auftrags.

---

# Teil A · Kalenderfläche und Zeitwahrheit

Dieser Teil wird vollständig fertiggestellt und abgenommen, bevor die Terminkarten visuell finalisiert werden.

## A1 · Autoritative Zeitberechnung

```text
OPEN_MINUTE  = 480   // 08:00
CLOSE_MINUTE = 1080  // 18:00
DAY_MINUTES  = 600
```

Für das heutige Datum in `Europe/Zurich`:

```text
progress = clamp((nowMinute - OPEN_MINUTE) / DAY_MINUTES, 0, 1)
nowY     = gridTop + progress * gridHeight
```

Alle folgenden Komponenten verwenden exakt dieselbe Zeitquelle:

- Analoguhr;
- digitale Salonzeit;
- kompakte Zeitpille;
- Agenda `Als Nächstes`;
- vergangene Zeitfläche;
- Jetzt-Linie;
- Jetzt-Beschriftung;
- laufende beziehungsweise nächste Terminberechnung.

Synchronisation:

- Aktualisierung exakt am Minutenwechsel;
- Neusynchronisation bei `visibilitychange` zurück auf `visible`;
- Neusynchronisation bei Wiederaufnahme nach längerer Inaktivität;
- Referenzzustände verwenden deterministisch `referenceNow`, standardmäßig `11:22`.

## A2 · Globale vergangene Zeitfläche

Im vertikalen Tagesplan verläuft die Zeit von oben nach unten.

Die vergangene Zeitfläche:

- beginnt exakt bei `08:00`;
- endet exakt an der aktuellen Zeit;
- umfasst die Zeitachse und alle Mitarbeitendenspalten;
- ist eine einzige gemeinsame Schicht;
- wird nicht je Mitarbeitendenlane oder Terminkarte wiederholt;
- besitzt keinen Verlauf;
- besitzt eine harte, mathematisch korrekte Abschlusskante.

Visuelle Ausgangskalibrierung:

```text
4–6 % zusätzliche neutrale Dunkelheit
maximal 8 %
kein Sättigungs- oder Helligkeitsverlauf über die Vergangenheit
```

Der Eindruck muss lauten:

```text
Diese Zeit ist bereits durchlaufen.
```

Nicht:

```text
Dieser Bereich ist deaktiviert.
```

Zustände:

### Heute vor Öffnung

```text
pastProgress = 0
keine Jetzt-Linie innerhalb des Rasters
```

### Heute während der Öffnung

```text
pastProgress = progress
Jetzt-Linie bei nowY
```

### Heute nach Schließung

```text
pastProgress = 1
keine Jetzt-Linie innerhalb des Rasters
```

### Vergangenes oder zukünftiges Datum

```text
keine Live-Jetzt-Linie
keine globale Live-Vergangenheitstönung
```

Terminkarten erhalten **keine** eigenen Klassen oder Farbtöne für vergangen, laufend und künftig.

Nicht zulässig:

```text
is-before / is-current / is-next als zusätzliche Kartenfarbwelt
separate Vergangenheitstönung pro Lane
Verlauf von stark vergangen zu schwach vergangen
Statusfarbe zur Zeitdarstellung verwenden
```

## A3 · Jetzt-Linie

Die Jetzt-Linie ist im vertikalen Tagesplan horizontal.

Sie:

- beginnt an beziehungsweise innerhalb der Zeitachse;
- läuft geometrisch über die gesamte Teamfläche;
- verwendet dieselbe `nowY`-Position wie die vergangene Zeitfläche;
- besitzt ein kleines exaktes Zeitlabel in der Zeitachse;
- ist rein informativ und nicht fokussierbar;
- wird nicht als zusätzliche große Pille im Desktopkopf wiederholt, solange Seitenleistenuhr und digitale Salonzeit sichtbar sind.

Verbindliche Ebenenfolge:

```text
0  Grundfläche und Kalenderraster
1  globale vergangene Zeitfläche
2  Jetzt-Linie und Zeitlabel
3  Terminkarten, Aufgaben und Pausen
4  Fokusmaske auf Kontextspalten
5  Auswahl, Suchtreffer und sichtbarer Tastaturfokus
```

Die wichtigste Folge:

> Die Jetzt-Linie liegt oberhalb des Rasters, aber unterhalb der Terminkarten.

Sie ist in freien Bereichen sichtbar, verschwindet jedoch unter einer undurchsichtigen Terminkarte. Sie darf niemals Namen, Dienstleistung oder Zeittext durchstreichen.

Wenn die laufende Position an einer Karte zusätzlich erkennbar sein soll, ist ausschließlich ein kleiner, kontrollierter Einschnitt am Kartenrand zulässig:

```text
Breite: 3–4 px
kein Durchziehen durch den Karteninhalt
keine zweite Linie innerhalb der Karte
```

Der Einschnitt ist optional. Die globale Linie bleibt die einzige Zeitlinie.

## A4 · Bedeutung einer laufenden Karte

Eine laufende Karte erhält keinen künstlichen eigenen Zeitfarbton.

Die Zeitwahrheit entsteht aus:

```text
Position der Karte = Beginn
Höhe der Karte     = Dauer
sichtbare Zeit     = exakte Bestätigung
globale Vergangenheit = bereits verstrichener Tagesanteil
Jetzt-Linie        = gegenwärtiger Moment
Statuskante        = fachlicher Terminstatus
```

Die fachliche Statusfarbe darf nicht für „vergangen“, „läuft“ oder „danach“ zweckentfremdet werden.

## A5 · Fokus und Zeitfläche

Personenfokus verändert Aufmerksamkeit, nicht Zeit.

- Die vergangene Zeitfläche bleibt global und wird nicht pro Lane neu berechnet.
- Die Jetzt-Geometrie bleibt über alle fünf Spalten identisch.
- Die Fokusmaske darf die Linie in Kontextspalten leicht zurücknehmen, aber nicht räumlich unterbrechen.
- Fokussierte Lane bleibt im normalen Kontrast.
- Kontextlanes werden über eine eigene neutrale Maske zurückgenommen, nicht über pauschale Container-Opacity.
- Suchtreffer, Auswahl und Tastaturfokus dürfen die Maske durchbrechen.

## A6 · Kompakte Projektionen

Beim heutigen Datum:

- initiale vertikale Position in der Nähe von Jetzt;
- Jetzt ungefähr im oberen Drittel bis in der Mitte des Viewports;
- nach manueller Bewegung kein eigenmächtiger Rücksprung;
- Aktivieren der digitalen Zeit beziehungsweise mobilen Zeitpille führt kontrolliert zurück zu Jetzt;
- Minutenwechsel bewegt die Linie, nicht automatisch den Viewport.

Auf Desktop-Volltag:

- kein automatisches Scrollen;
- nur die Zeitmarkierung bewegt sich;
- der vollständige Tag bleibt stabil sichtbar.

## A7 · Pflichtdiagnostik

Mindestens folgende Werte müssen maschinenlesbar sein:

```text
data-tp-time-source="Europe/Zurich"
data-tp-now-minute="682"              // bei 11:22
data-tp-past-progress="0.336667"
data-tp-now-line-visible="1"
data-tp-past-layer-count="1"
data-tp-now-line-count="1"
data-tp-now-line-behind-cards="1"
data-tp-card-time-tone-count="0"
data-tp-time-sync-state="stable"
```

Vor Öffnung, nach Schließung und auf anderen Daten werden die erwarteten Werte separat geprüft.

## A8 · Abnahmebilder

Für `referenceNow=11:22` müssen mindestens vorliegen:

```text
1512 × 982
1366 × 768
390 × 844
844 × 390
Personenfokus
Agenda geöffnet
```

Visuell muss erkennbar sein:

- gleichmäßige Vergangenheit von 08:00 bis 11:22;
- exakte horizontale Grenze bei 11:22;
- Linie in freien Bereichen;
- keine Linie über Kartentext;
- keine drei zeitlichen Kartentöne;
- identische Zeitposition in allen fünf Spalten;
- Agenda und Fokus verändern die Zeitgeometrie nicht.

---

# Teil B · Terminkarten und Dienstleistungssemantik

Dieser Teil beginnt erst nach expliziter Freigabe der Kalenderfläche.

## B1 · Fachliche Kartenwahrheit

Für jede Karte gilt:

```text
Top-Position = Startzeit
Höhe        = reale Dauer
Lane        = zuständige Person
Statuskante = fachlicher Status
Inhalt      = semantisch nach realem Raum verdichtet
```

Die Terminkartenphase umfasst vollständig:

- Kundentermine;
- offene Termine;
- abgeschlossene Termine;
- laufende Termine;
- interne Aufgaben;
- Pausen;
- Auswahl;
- Tastaturfokus;
- Kontextöffnung;
- zugängliche Namen.

## B2 · Informationsstufen

Entscheidung anhand der tatsächlichen Kartenbreite **und** Kartenhöhe:

```text
full       Symbol · Zeit · Name · Leistung
time-name  Symbol · Zeit · Name
name       Symbol · Name
first      Symbol · sinnvoller Kurzname
minimal    Symbol · Initialen
```

Regeln:

- keine mechanische Ellipse mitten im Vornamen;
- keine immer kleinere Schrift als Ersatz für Priorisierung;
- Leistung entweder vollständig, semantisch kurz oder ausgeblendet;
- vollständige Information bleibt in `aria-label`, Kontextpanel und Agenda;
- sichtbare Zeitbereiche verwenden tabellarische Ziffern und den Gedankenstrich `–`.

## B3 · Hochwertiges Dienstleistungssymbolsystem

Die Symbole sind fachliche Deklaration und Bestandteil des neutralen Core Freeze. Sie sind keine alpine oder atmosphärische Beseelung.

Mindestens benötigt:

```text
schnitt
farbe
balayage / highlights
glossing / tönung
pflege
beratung
föhnen / styling
interne aufgabe
pause
fallback / sonstige leistung
```

Technische Anforderungen:

- echte eingebettete SVGs;
- keine Favicons im Browser-Sinn, keine Emoji, keine Icon-Font;
- einheitliche `viewBox="0 0 24 24"`;
- optisch einheitliche Strichstärke, Ausgangswert `1.6–1.75`;
- `stroke-linecap="round"` und `stroke-linejoin="round"`, sofern fachlich passend;
- monochrom über `currentColor`;
- keine Statusfarbe im Symbol;
- lokale beziehungsweise im Single HTML eingebettete Ressource;
- keine externe Laufzeitabhängigkeit;
- keine Layoutverschiebung beim Laden;
- semantische Zuordnung über stabilen Leistungscode, nicht über fragile Teilstrings im Anzeigenamen;
- eindeutiger Fallback für unbekannte Leistungen.

Optische Größen:

```text
16 px in sehr kompakten Karten
18 px im Normalfall
20 px nur bei ausreichend großen Karten
```

Das Symbol beschreibt ausschließlich **was gemacht wird**. Die Statuskante beschreibt **in welchem fachlichen Zustand der Termin ist**.

## B4 · Kartenhierarchie

Verbindliche Priorität:

```text
1. Kundschaft beziehungsweise Terminidentität
2. Zeit, wenn der Raum reicht
3. Dienstleistungssymbol
4. Dienstleistungsbezeichnung, wenn der Raum reicht
5. Ausnahme- oder Handlungsstatus
```

Das Symbol darf den Namen nicht verdrängen. In Minimalzuständen ersetzt es die ausgeschriebene Dienstleistung, nicht zwingend die Kundschaft.

Statusbadges erscheinen nur bei Abweichung oder konkretem Handlungsbedarf, etwa:

```text
offen
fehlt
abgesagt
Konflikt
```

Normal bestätigte Termine brauchen kein permanentes Textbadge.

## B5 · Aufgaben und Pausen

Interne Aufgaben und Pausen sind keine Kundentermine.

Sie erhalten:

- eigenes Symbol;
- eigene zugängliche Rollenbeschreibung;
- die bereits etablierte gestreifte beziehungsweise abweichende Materiallogik;
- keine Kundschaftssemantik;
- dieselbe zeitliche Geometriewahrheit wie Termine.

## B6 · Accessibility

Jede interaktive Karte besitzt einen vollständigen zugänglichen Namen mit:

```text
Start und Ende
Kundschaft oder Aufgabentitel
Dienstleistung
zuständige Person
Status
```

Beispiel:

```text
10:30 bis 12:00, Anna Keller, Schnitt und Föhnen, bei Melanie Schneider, bestätigt.
```

Symbole sind bei vorhandener Textsemantik `aria-hidden="true"`. Die Bedeutung darf niemals ausschließlich aus dem Piktogramm oder aus Farbe entstehen.

## B7 · Kartenabnahme

Pflichtfälle:

- 15-, 30-, 45-, 60-, 90- und 120-Minuten-Karten;
- breite und schmale Überschneidungen;
- lange und kurze Namen;
- jede Dienstleistungskategorie;
- Aufgabe und Pause;
- offen, bestätigt, im Salon, abgeschlossen, abgesagt und fehlt;
- ausgewählt, fokussiert und per Tastatur erreicht;
- Desktop, 125-Prozent-Stresstest, Mobil hochkant und Mobil quer.

Harte Assertions:

```text
keine zufällige Namensellipse
kein Kartentext von Jetzt-Linie durchschnitten
genau ein Dienstleistungssymbol pro deklarierter Karte
keine Statusfarbe im Dienstleistungssymbol
vollständiger zugänglicher Name
keine externe Symbolressource
keine Karten-Geometrieänderung durch Symbol-Laden
```

---

# Teil C · Freeze und spätere Beseelung

Der technische Core Freeze wird erst nach Teil A und Teil B erzeugt.

Er enthält:

- stabile Kalenderfläche;
- vollständige Zeitwahrheit;
- fertige neutrale Terminkarten;
- hochwertiges neutrales Dienstleistungssymbolsystem;
- alle fachlichen Zustände und Interaktionen;
- deterministische Single-HTML-Referenz.

Er enthält noch nicht:

- alpine Szene;
- Murmeltier-Habitat;
- emotionale Materialvarianten;
- alternative atmosphärische Bewegungen;
- dekorative Symbolvarianten;
- experimentelle Sprachtemperaturen.

Nach dem Freeze dürfen Beseelungsvarianten die eingefrorene fachliche, geometrische und interaktive Wahrheit nicht verändern.

---

# Stop-Regel

Codex stoppt und meldet einen Konflikt, wenn eine gewünschte Symbol- oder Kartenlösung:

- unter 44 × 44 CSS-Pixel große notwendige Touchziele erzwingt;
- die Zeitposition oder Kartendauer verfälscht;
- eine zusätzliche Statusfarbe benötigt;
- einen neuen Scrollcontainer einführt;
- die Jetzt-Linie über Text legen würde;
- eine externe Laufzeitressource verlangt;
- die Abnahmematrix nur durch abgeschwächte Tests bestehen würde.

Kein stiller Kompromiss.
