# ADR-009 · Kalenderfläche vor Terminkarten

Status: **Accepted**  
Datum: 2026-08-26  
Gilt für: `feat/tagesplan-v1-golden-master` und `codex/tagesplan-v1-core-freeze`

## Kontext

Die Formulierung „erst die Fläche, dann Termine“ wurde zu weit ausgelegt. Gemeint ist keine Reihenfolge aus Tagesplan-Seite und späterer separater Termine-Seite, sondern die innere Ausführungsfolge des Tagesplans:

1. zuerst die Kalenderfläche samt Zeitmodell vollständig stabilisieren;
2. danach die Terminkarten samt Dienstleistungsdeklaration vollständig ausarbeiten;
3. erst danach den technischen Core Freeze freigeben.

Die separate Produktseite `Termine` bleibt außerhalb dieses Arbeitsauftrags.

## Entscheidung

### Stufe 1 · Kalenderfläche und Zeitwahrheit

Vor jeder abschließenden Kartenverfeinerung werden fertiggestellt:

- Geometrie und Scrollmodell;
- 15-/30-/60-Minuten-Raster;
- globale vergangene Zeitfläche;
- Jetzt-Linie und Jetzt-Beschriftung;
- Schichtung oberhalb des Rasters und unterhalb der Terminkarten;
- Synchronisation von Salonzeit, Agenda und Zeitmarkierung;
- Fokus- und Agenda-Invarianz;
- Desktop-, Zoom- und kompakte Projektionen.

### Stufe 2 · Terminkarten und Dienstleistungssemantik

Nach Freigabe der Fläche werden fertiggestellt:

- Kartenposition, Kartenhöhe und Informationsstufen;
- Statuskante und Ausnahmehinweise;
- hochwertige, neutrale SVG-Dienstleistungssymbole;
- klare Semantik für Schnitt, Farbe, Balayage beziehungsweise Highlights, Glossing beziehungsweise Tönung, Pflege, Beratung, Föhnen beziehungsweise Styling;
- eigene Semantik für interne Aufgabe und Pause;
- vollständige zugängliche Namen und Tastaturbedienung;
- Auswahl-, Fokus- und Kontextverhalten.

### Stufe 3 · Core Freeze

Der Core Freeze enthält deshalb bereits das neutrale, hochwertige Dienstleistungssymbolsystem. Es ist keine alpine oder emotionale Beseelung, sondern fachliche Deklaration der Terminkarten.

Beseelungsvarianten nach dem Freeze dürfen Materialtiefe, Raumrhythmus, Bewegungstempo, Aufmerksamkeitsstärke und Illustrationspräsenz untersuchen. Sie dürfen weder die Dienstleistungszuordnung noch Kartengeometrie, Status, Fokus, Suche, Scrollmodell oder Tastatursemantik verändern.

## Zeitdarstellung

Im vertikalen Tagesplan läuft Zeit von oben nach unten.

- Die vergangene Zeit ist eine einzige globale, gleichmäßig getönte Fläche vom Tagesbeginn bis zur aktuellen Uhrzeit.
- Die Jetzt-Linie verläuft horizontal über Zeitachse und alle Mitarbeitendenspalten.
- Die Jetzt-Linie liegt oberhalb des Rasters, aber unterhalb der Terminkarten.
- Sie bleibt in freien Bereichen sichtbar und darf niemals Text durchstreichen.
- Bei einer laufenden Karte darf optional ein kleiner Einschnitt am Kartenrand die aktuelle Höhe bestätigen.
- Terminkarten erhalten keine eigenen Vergangenheits-, Gegenwarts- oder Zukunftsfarbtöne.
- Statusfarben bleiben ausschließlich fachliche Statusfarben.

## Konsequenzen

- Der separate Bereich `Termine` beginnt nicht nach Gate A des Tagesplans.
- Die Tagesplanarbeit endet nicht mit einer leeren Rasterfläche; die Terminkarten sind Teil von Tagesplan v1.0.
- Frühere Dokumentstellen, die finale Dienstleistungssymbole vollständig aus dem Core Freeze ausschließen, werden durch diese ADR präzisiert: ausgeschlossen bleiben dekorative beziehungsweise atmosphärische Symbolvarianten; eingeschlossen ist das neutrale fachliche SVG-Symbolsystem.
- Codex darf die Kartenschicht erst finalisieren, nachdem die Kalenderfläche und die Zeitwahrheit messbar stabil sind.
