(() => {
      "use strict";

      const icons = {
        today: '<svg viewBox="0 0 24 24"><path d="M3 12h4l3-8 4 16 3-8h4"/></svg>',
        day: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/></svg>',
        bookings: '<svg viewBox="0 0 24 24"><path d="M6 3h12v18H6zM9 8h6M9 12h6M9 16h4"/></svg>',
        customers: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c.7-5 3.3-7 8-7s7.3 2 8 7"/></svg>',
        team: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="10" r="2.5"/><path d="M3 20c.5-4 2.5-6 6-6s5.5 2 6 6M15 15c3.5 0 5.3 1.7 6 5"/></svg>',
        offer: '<svg viewBox="0 0 24 24"><path d="M4 5h16v14H4zM8 9h8M8 13h5"/></svg>',
        admin: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19 15l2 1-2 4-2-1a8 8 0 0 1-3 2v2H9v-2a8 8 0 0 1-3-2l-2 1-2-4 2-1a8 8 0 0 1 0-4L2 10l2-4 2 1a8 8 0 0 1 3-2V3h5v2a8 8 0 0 1 3 2l2-1 2 4-2 1a8 8 0 0 1 0 4z"/></svg>',
        plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
        close: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
        back: '<svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg>',
        next: '<svg viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>',
        rotate: '<svg viewBox="0 0 24 24"><path d="M8 4h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z"/><path d="M3 9a9 9 0 0 1 9-6M3 9l-1-4M3 9l4-1"/></svg>',
        theme: '<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 9 9c0-.5 0-1-.1-1.5A7.2 7.2 0 0 1 12 3Z"/><path d="M12 3v18"/></svg>',
        install: '<svg viewBox="0 0 24 24"><path d="M12 3v11M8 10l4 4 4-4"/><path d="M5 17v3h14v-3"/></svg>'
      };
      const alpineAssets = {
        kantenblick: "/assets/alpine/kantenblick.8375fcb60e.webp",
        observer: "/assets/alpine/observer.8f004d4991.webp",
        success: "/assets/alpine/success.13a39b7292.webp"
      };

      /* ==================================================================
         CENTRAL PRODUCT TRUTH · all visible fixture truth comes from here
         ================================================================== */
      const productTruth = window.GASSERWERK_PRODUCT_TRUTH;

      const navItems = productTruth.navItems;
      const staff = productTruth.staff;
      const baseAppointments = productTruth.appointments;
      const prototypePhaseDisplayNames = productTruth.phaseDisplayNames;
      const customers = productTruth.customers;
      const services = productTruth.services;

      const screenMeta = {
        login: ["Sicherer Zugang", "Login", "Gasserwerk Kundenbereich"],
        onboarding: ["Salonstart", "Einrichtung", "4 von 5 Schritten"],
        today: ["Salonbetrieb", "Heute", ""],
        day: ["Tagesplan", "", ""],
        bookings: ["Terminregister", "Termine", ""],
        customers: ["Beziehungen", "Kundschaft", ""],
        team: ["Buchbarkeit", "Team", ""],
        offer: ["Buchbarkeit", "Angebot", ""],
        admin: ["Organisation", "Verwaltung", "Salonprofil und System"],
      };

      function storedValue(key) {
        try { return window.localStorage.getItem(key); } catch { return null; }
      }

      function storeValue(key, value) {
        try { window.localStorage.setItem(key, value); } catch { /* storage may be unavailable in embedded previews */ }
      }

      function isMobileUI() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        const coarse = window.matchMedia?.("(pointer: coarse)").matches || navigator.maxTouchPoints > 0;
        const compactTouch = coarse && Math.min(width, height) <= 820 && Math.max(width, height) <= 1180;
        return width <= 760 || compactTouch;
      }

      function isMobilePortrait() {
        return isMobileUI() && window.innerHeight >= window.innerWidth;
      }

      function isTabletUI() {
        return isMobileUI() && Math.min(window.innerWidth, window.innerHeight) >= 600;
      }

      function syncMobileUiClass() {
        window.__gasserwerkClassifyViewport?.();
        const mobile = isMobileUI();
        document.documentElement.classList.toggle("mobile-ui", mobile);
        document.documentElement.classList.toggle("mobile-portrait", mobile && window.innerHeight >= window.innerWidth);
        document.documentElement.classList.toggle("mobile-landscape", mobile && window.innerWidth > window.innerHeight);
        document.documentElement.classList.toggle("tablet-ui", mobile && Math.min(window.innerWidth, window.innerHeight) >= 600);
        return mobile;
      }

      function syncThemeChrome() {
        const meta = document.getElementById("theme-color");
        if (meta) meta.content = state.theme === "dark" ? "#173F36" : "#0D4B3E";
      }

      const systemThemeQuery = window.matchMedia?.("(prefers-color-scheme: dark)");
      let deferredInstallPrompt = null;

      function resolveTheme(mode) {
        if (mode === "light") return "light";
        if (mode === "dark") return "dark";
        return systemThemeQuery?.matches ? "dark" : "light";
      }

      function themeModeText() {
        if (state.themeMode === "system") return `System · ${state.theme === "dark" ? "Abend" : "Tag"}`;
        return state.theme === "dark" ? "Abend" : "Tag";
      }

      function applyThemeMode(mode, { persist = true, announce = false } = {}) {
        state.themeMode = ["system", "light", "dark"].includes(mode) ? mode : "system";
        state.theme = resolveTheme(state.themeMode);
        document.documentElement.dataset.theme = state.theme;
        document.documentElement.dataset.themeMode = state.themeMode;
        document.documentElement.style.colorScheme = state.theme === "dark" ? "dark" : "light";
        if (persist) storeValue("gasserwerk-theme-mode", state.themeMode);
        syncThemeChrome();
        const demoToggle = el("theme-toggle");
        if (demoToggle) {
          demoToggle.setAttribute("aria-pressed", state.theme === "dark" ? "true" : "false");
          const label = demoToggle.querySelector("span:last-child");
          if (label) label.textContent = themeModeText();
        }
        document.querySelectorAll("[data-theme-cycle]").forEach(button => {
          button.setAttribute("aria-label", `Darstellung: ${themeModeText()}. Wechseln`);
          button.setAttribute("title", `Darstellung: ${themeModeText()}`);
          const label = button.querySelector(".theme-mode-label");
          if (label) label.textContent = themeModeText();
        });
        if (announce && typeof toast === "function") toast("Darstellung geändert", state.themeMode === "system" ? `Systemeinstellung · ${state.theme === "dark" ? "Abendsalon" : "Tag"}` : state.theme === "dark" ? "Abendsalon" : "Tag");
      }

      function cycleThemeMode() {
        if (state.themeMode === "system") {
          applyThemeMode(state.theme === "dark" ? "light" : "dark", { announce: true });
        } else if (state.themeMode === "dark") {
          applyThemeMode("light", { announce: true });
        } else {
          applyThemeMode("system", { announce: true });
        }
        renderHeader();
        bindHeaderUtilities();
      }

      async function requestInstall() {
        if (!deferredInstallPrompt) return;
        const prompt = deferredInstallPrompt;
        deferredInstallPrompt = null;
        await prompt.prompt();
        try { await prompt.userChoice; } catch { /* browser-specific */ }
        document.documentElement.classList.remove("pwa-installable");
        renderHeader();
        bindHeaderUtilities();
      }

      function syncNetworkStatus() {
        const node = el("network-status");
        if (!node) return;
        node.hidden = navigator.onLine;
      }

      let pwaRegistration = null;
      let reloadingForServiceWorker = false;

      function showPwaUpdate(registration) {
        pwaRegistration = registration || pwaRegistration;
        const banner = el("pwa-update-banner");
        if (banner) banner.hidden = false;
      }

      function hidePwaUpdate() {
        const banner = el("pwa-update-banner");
        if (banner) banner.hidden = true;
      }

      function bindPwaUpdateAction() {
        document.querySelectorAll("[data-pwa-update]").forEach(button => button.addEventListener("click", () => {
          const waiting = pwaRegistration?.waiting;
          if (!waiting) return hidePwaUpdate();
          button.disabled = true;
          button.textContent = "Aktualisiere …";
          waiting.postMessage({ type: "SKIP_WAITING" });
        }));
      }


      function bindHeaderUtilities() {
        document.querySelectorAll("[data-theme-cycle]").forEach(button => button.addEventListener("click", cycleThemeMode));
        document.querySelectorAll("[data-install-app]").forEach(button => button.addEventListener("click", requestInstall));
      }


      const state = {
        screen: screenFromLocation(),
        mode: "normal",
        themeMode: storedValue("gasserwerk-theme-mode") || "system",
        theme: document.documentElement.dataset.theme || "light",
        appointments: structuredClone(baseAppointments).map(appointment => ({
          ...appointment,
          phaseDisplayNames: structuredClone(prototypePhaseDisplayNames[appointment.id] || [])
        })),
        selectedId: null,
        selectedCustomer: null,
        customerListScrollTop: 0,
        search: "",
        origin: null,
        panelView: "detail",
        selectedSlot: null,
        busy: false,
        onboardingStep: 3,
        dayPart: "work",
        dayView: storedValue("gasserwerk-day-view") === "overview" ? "overview" : "work",
        currentDate: new Date(...productTruth.day.referenceDate),
        focusStart: null,
        focusMode: "live",
        mobileStaffId: storedValue("gasserwerk-mobile-staff") || "all",
        rotateHintDismissed: storedValue("gasserwerk-rotate-hint-dismissed") === "1",
        panelOrigin: null
      };

      const el = (id) => document.getElementById(id);
      const appShell = el("app-shell");
      const workspaceBody = el("workspace-body");
      const workspaceHeader = el("workspace-header");
      const searchInput = el("global-search");
      const searchResult = el("search-result");
      const panel = el("context-panel");
      const backdrop = el("panel-backdrop");

      function statusLabel(status) {
        return productTruth.statuses[status] || status;
      }

      function phaseDisplayNamesFor(appointment) {
        const labels = Array.isArray(appointment?.phaseDisplayNames)
          ? appointment.phaseDisplayNames.map(label => String(label || "").trim()).filter(Boolean)
          : [];
        return labels.length ? labels : [appointment?.service || "Dienstleistung"];
      }

      function currentPhaseDisplayName(appointment) {
        const phases = phaseDisplayNamesFor(appointment);
        return phases[Math.min(appointment?.visitStep || 0, phases.length - 1)] || appointment?.service || "Dienstleistung";
      }

      function timeToMinutes(time) {
        const [h, m] = time.split(":").map(Number);
        return h * 60 + m;
      }

      function minutesToTime(total) {
        const h = Math.floor(total / 60).toString().padStart(2, "0");
        const m = (total % 60).toString().padStart(2, "0");
        return `${h}:${m}`;
      }

      function visibleStaff() {
        return state.mode === "stress" ? staff : staff.slice(0, 5);
      }

      function visibleAppointments() {
        if (state.mode === "empty") return [];
        if (state.mode === "stress") return state.appointments;
        const activeStaff = new Set(visibleStaff().map(person => person.id));
        return state.appointments.filter(item => item.scenario !== "stress" && activeStaff.has(item.staff));
      }

      function visibleScheduleItems() {
        if (state.mode === "empty") return [];
        const activeStaff = new Set(visibleStaff().map(person => person.id));
        return [...visibleAppointments(), ...productTruth.scheduleBlocks.filter(item => activeStaff.has(item.staff))];
      }

      function scheduleSearchText(item) {
        return [item.customer, item.service, item.label, item.note, staff.find(person => person.id === item.staff)?.name].filter(Boolean).join(" ").toLocaleLowerCase("de-CH");
      }

      function findScheduleMatch(query) {
        if (!query) return null;
        return visibleScheduleItems().find(item => scheduleSearchText(item).includes(query));
      }

      function selectedAppointment() {
        return state.appointments.find((appointment) => appointment.id === state.selectedId);
      }

      const APP_BASE_PATH = (() => {
        const source = Array.from(document.scripts).map(script => script.src).find(src => /\/assets\/app\.[^/]+\.js(?:\?|$)/.test(src));
        if (!source) return "";
        return new URL(source, location.href).pathname.replace(/\/assets\/[^/]+$/, "").replace(/\/$/, "");
      })();
      const withBasePath = route => `${APP_BASE_PATH}${route}` || route;

      const screenRoutes = {
        today: "/heute",
        day: "/tagesplan",
        bookings: "/termine",
        customers: "/kundschaft",
        team: "/team",
        offer: "/angebot",
        admin: "/verwaltung"
      };

      function screenFromLocation() {
        if (!['http:', 'https:'].includes(location.protocol)) return 'day';
        let path = location.pathname;
        if (APP_BASE_PATH && path.startsWith(APP_BASE_PATH)) path = path.slice(APP_BASE_PATH.length) || "/";
        path = path.replace(/\/+$/, '') || '/';
        return Object.entries(screenRoutes).find(([, route]) => route === path)?.[0] || 'day';
      }

      function syncRoute(screen, replace = false) {
        if (!['http:', 'https:'].includes(location.protocol)) return;
        const route = screenRoutes[screen];
        const target = route ? withBasePath(route) : null;
        if (!target || location.pathname === target) return;
        history[replace ? 'replaceState' : 'pushState']({ screen }, '', target + location.search);
      }

      function renderNavigation() {
        const itemMarkup = ([id, label]) => `<button class="nav-button ${state.screen === id ? "is-active" : ""}" type="button" data-nav="${id}"><span class="nav-icon">${icons[id]}</span><span>${label}</span></button>`;
        el("primary-nav").innerHTML = navItems.map(itemMarkup).join("");
        el("mobile-nav").innerHTML = navItems.map(itemMarkup).join("");
        document.querySelectorAll("[data-nav]").forEach((button) => button.addEventListener("click", () => navigate(button.dataset.nav)));
      }

      function navigate(screen, options = {}) {
        const previousScreen = state.screen;
        if (screen === "customers" && previousScreen !== "customers" && !options.keepCustomerDetail) {
          state.selectedCustomer = null;
          state.customerListScrollTop = 0;
        }
        state.screen = screen;
        el("screen-picker").value = screen;
        if (!options.fromHistory) syncRoute(screen);
        if (!options.keepPanel) closePanel(false);
        workspaceBody.classList.add("is-navigating");
        render();
        workspaceBody.scrollTop = 0;
        window.setTimeout(() => workspaceBody.classList.remove("is-navigating"), 280);
        requestAnimationFrame(() => { workspaceBody.scrollTop = 0; workspaceBody.focus({ preventScroll: true }); });
      }

      function formatDayTitle(date) {
        return new Intl.DateTimeFormat("de-CH", { weekday: "long", day: "numeric", month: "long" }).format(date);
      }

      function shiftReferenceDay(days) {
        const next = new Date(state.currentDate);
        next.setDate(next.getDate() + days);
        state.currentDate = next;
        render();
      }

      function renderShellTruth() {
        const salonName = el("salon-name");
        if (salonName) salonName.innerHTML = productTruth.salon.name.replace(" ", "<br>");
        const salonContext = el("salon-context");
        if (salonContext) salonContext.textContent = `${productTruth.salon.location} · ${productTruth.salon.context}`;
        const salonLocation = el("salon-location");
        if (salonLocation) salonLocation.textContent = productTruth.salon.location;
        const accountInitials = el("account-initials");
        if (accountInitials) accountInitials.textContent = productTruth.account.initials;
        const accountName = el("account-name");
        if (accountName) accountName.textContent = productTruth.account.name;
        const accountRole = el("account-role");
        if (accountRole) accountRole.textContent = productTruth.account.role;
      }

      function renderHeader() {
        let [kicker, title, context] = screenMeta[state.screen];
        if (state.screen === "day") {
          title = formatDayTitle(state.currentDate);
          context = `${productTruth.salon.location} · ${minutesToTime(productTruth.day.openMinute)}–${minutesToTime(productTruth.day.closeMinute)}`;
        } else if (state.screen === "today") {
          context = formatDayTitle(state.currentDate);
        } else if (state.screen === "bookings") {
          context = `${formatDayTitle(state.currentDate)} · ${productTruth.salon.location}`;
        } else if (state.screen === "customers") {
          context = `${customers.length} ausgewählte Karteieinträge`;
        } else if (state.screen === "team") {
          context = `${visibleStaff().length} Mitarbeitende · ${productTruth.salon.location}`;
        } else if (state.screen === "offer") {
          context = `${services.length} konfigurierte Dienstleistungen`;
        }
        el("page-kicker").textContent = kicker;
        el("page-title").textContent = title;
        el("page-context").textContent = context;
        const mobileUi = syncMobileUiClass();
        searchInput.placeholder = mobileUi
          ? (window.innerWidth < 375 ? "Suchen …" : "Kundin, Termin oder Aufgabe suchen …")
          : "Kundin, Termin, freie Zeit oder Aufgabe suchen …";
        const isAuth = state.screen === "login";
        appShell.classList.toggle("auth-mode", isAuth);
        workspaceHeader.hidden = isAuth;
        const searchVisible = !["login", "onboarding", "admin"].includes(state.screen);
        el("search-wrap").hidden = !searchVisible;
        const primaryAction = {
          today: `<button class="button primary" type="button" data-quick-book>${icons.plus}<span>Termin</span></button>`,
          day: `<button class="button primary" type="button" data-quick-book>${icons.plus}<span>Termin</span></button>`,
          bookings: `<button class="button primary" type="button" data-quick-book>${icons.plus}<span>Termin</span></button>`,
          customers: `<button class="button primary" type="button" data-customer-book>${icons.plus}<span>Termin</span></button>`,
          team: `<button class="button primary" type="button" data-demo-action="Person anlegen">${icons.plus}<span>Person</span></button>`,
          offer: `<button class="button primary" type="button" data-demo-action="Dienstleistung anlegen">${icons.plus}<span>Dienstleistung</span></button>`,
          admin: "",
          onboarding: ""
        }[state.screen] || "";
        const themeControl = isAuth ? "" : `<button class="button compact theme-cycle-button" type="button" data-theme-cycle aria-label="Darstellung: ${themeModeText()}. Wechseln" title="Darstellung: ${themeModeText()}">${icons.theme}<span class="theme-mode-label">${themeModeText()}</span></button>`;
        const installControl = !isAuth && deferredInstallPrompt ? `<button class="button compact install-app-button" type="button" data-install-app aria-label="Gasserwerk installieren" title="Gasserwerk als App installieren">${icons.install}<span class="install-label">Installieren</span></button>` : "";
        el("header-actions").innerHTML = `${themeControl}${installControl}${primaryAction}`;
      }

      function render() {
        renderShellTruth();
        renderNavigation();
        renderHeader();
        workspaceBody.classList.toggle("is-day", state.screen === "day");
        const renderers = { login: renderLogin, onboarding: renderOnboarding, today: renderToday, day: renderDay, bookings: renderBookings, customers: renderCustomers, team: renderTeam, offer: renderOffer, admin: renderAdmin };
        workspaceBody.innerHTML = renderers[state.screen]();
        bindScreenEvents();
        bindHeaderUtilities();
        bindPwaUpdateAction();
        syncNetworkStatus();
        applySearchState();
        requestAnimationFrame(updateDayScrollHints);
      }

      function renderLogin() {
        return `<section class="screen auth-screen alpine-auth-screen">
          <div class="auth-brand alpine-auth-brand">
            <div class="product-signature"><span class="product-glyph">G</span> Gasserwerk</div>
            <div class="auth-brand-copy">
              <div class="auth-brand-kicker">SALONSOFTWARE AUS DER SCHWEIZ</div>
              <h1>Mehr Ruhe<br>im Salonalltag.</h1>
              <p>Termine, Kundschaft und Team präzise organisiert, damit persönliche Betreuung im Mittelpunkt bleibt.</p>
            </div>
            <small>Gasserwerk begleitet den Ablauf. Die Identität des Salons bleibt eigenständig.</small>
          </div>
          <div class="auth-stage alpine-auth-stage">
            <div class="login-world" aria-hidden="true">
              <div class="login-ridge login-ridge-far"></div>
              <div class="login-ridge login-ridge-near"></div>
              <img class="login-observer" src="${alpineAssets.observer}" alt="">
              <span class="login-flora login-flora-a"></span>
              <span class="login-flora login-flora-b"></span>
            </div>
            <form class="login-card alpine-login-card" id="prototype-login">
              <div class="login-product"><span class="login-product-mark">G</span><div><strong>Gasserwerk</strong><small>Anmelden im Kundenbereich</small></div></div>
              <h2>Willkommen zurück</h2>
              <p>Melde dich an, um deinen Salonalltag zu organisieren.</p>
              <div class="form-field"><label for="login-email">E-Mail</label><input id="login-email" type="email" value="melanie@sonnegg.ch" required></div>
              <div class="form-field"><label for="login-password">Passwort</label><input id="login-password" type="password" value="prototyp" required></div>
              <div class="login-actions"><button class="text-action" type="button" data-demo-action="Passwort zurücksetzen">Passwort vergessen?</button></div>
              <button class="button primary" type="submit">Anmelden</button>
              <div class="login-divider"><span>oder</span></div>
              <button class="magic-link" type="button" data-demo-action="Magic Link senden">✉ Magic Link verwenden</button>
              <div class="prototype-disclosure">Simulierter Login. Es werden keine Zugangsdaten übertragen.</div>
            </form>
          </div>
        </section>`;
      }

      function renderOnboarding() {
        const steps = ["Salonprofil", "Dienstleistungen", "Team", "Arbeitszeiten", "Startklar"];
        const stepCopy = [
          ["Dein Salon als Ausgangspunkt", "Name, Standort und Kontakt bilden die Salonidentität. Gasserwerk bleibt als Produktrahmen im Hintergrund."],
          ["Dienstleistungen prüfen", "Dauer und Preis bestimmen, welche Termine im Tagesplan tatsächlich buchbar werden."],
          ["Wer arbeitet im Salon?", "Erfasse das Team einmal zentral. Die Zuordnung zu Dienstleistungen folgt im Angebot."],
          ["Wann ist dein Team verfügbar?", "Arbeitszeiten machen aus Team und Angebot einen buchbaren Tagesplan."],
          ["Bereit für den ersten Termin", "Alle notwendigen Grundlagen sind vorhanden. Du kannst den Arbeitstag öffnen."]
        ];
        const [heading, copy] = stepCopy[state.onboardingStep];
        return `<section class="screen paper-surface onboarding-shell">
          <aside class="onboarding-progress">
            <div class="product-signature"><span class="product-glyph">G</span> Gasserwerk</div>
            <h2>Salon einrichten</h2>
            <p>Schritt ${state.onboardingStep + 1} von 5</p>
            <div class="step-list">${steps.map((step, index) => `<button type="button" class="step-button ${index === state.onboardingStep ? "is-active" : ""} ${index < state.onboardingStep ? "is-done" : ""}" data-step="${index}"><span class="step-number">${index < state.onboardingStep ? "✓" : index + 1}</span><span>${step}</span></button>`).join("")}</div>
          </aside>
          <div class="onboarding-content">
            <div class="eyebrow">Buchbarkeit herstellen</div>
            <h1>${heading}</h1>
            <p class="muted">${copy}</p>
            ${state.onboardingStep === 3 ? `<div class="check-list">
              <div class="check-row"><span><strong>Melanie Schneider</strong><br><small class="muted">Mo–Fr · 08:00–18:00</small></span><span class="status-chip confirmed">Vollständig</span></div>
              <div class="check-row"><span><strong>Sofia Keller</strong><br><small class="muted">Di–Sa · 09:00–17:30</small></span><span class="status-chip confirmed">Vollständig</span></div>
              <div class="check-row"><span><strong>Lea Bianchi</strong><br><small class="muted">Arbeitszeit fehlt am Samstag</small></span><span class="status-chip pending">Prüfen</span></div>
            </div><div class="progress-note"><strong>Auswirkung auf die Buchbarkeit</strong><br>Lea erscheint am Samstag erst im Tagesplan, wenn ihre Arbeitszeit festgelegt ist.</div>` : `<div class="progress-note"><strong>Geführter Salonstart</strong><br>Jeder Schritt zeigt, was fehlt und wie es die Buchbarkeit beeinflusst.</div>`}
            <div style="display:flex;gap:8px;justify-content:flex-end"><button class="button" type="button" data-step-back ${state.onboardingStep === 0 ? "disabled" : ""}>Zurück</button><button class="button primary" type="button" data-step-next>${state.onboardingStep === 4 ? "Heute öffnen" : "Speichern und weiter"}</button></div>
          </div>
        </section>`;
      }

      function dayCapacitySnapshot(appointments) {
        const scheduled = appointments.filter(item => item.status !== "cancelled");
        const bookedMinutes = scheduled.reduce((sum, item) => sum + item.duration, 0);
        const activeStaff = visibleStaff();
        const activeStaffIds = new Set(activeStaff.map(person => person.id));
        const blockedMinutes = state.mode === "empty" ? 0 : productTruth.scheduleBlocks.filter(item => activeStaffIds.has(item.staff)).reduce((sum, item) => sum + item.duration, 0);
        const capacityMinutes = activeStaff.length * (productTruth.day.closeMinute - productTruth.day.openMinute);
        return {
          bookedValue: scheduled.reduce((sum, item) => sum + (item.price || 0), 0),
          inSalon: scheduled.filter(item => item.status === "arrived").length,
          occupancy: Math.round((bookedMinutes + blockedMinutes) / capacityMinutes * 100)
        };
      }

      function nextRelevantAppointments(appointments, limit = 6) {
        return appointments
          .filter(item => item.status !== "cancelled" && timeToMinutes(item.start) + item.duration > HYBRID_NOW)
          .sort((a, b) => timeToMinutes(a.start) - timeToMinutes(b.start))
          .slice(0, limit);
      }

      function nextFreeGap(minDuration = 30) {
        const searchStart = Math.ceil(HYBRID_NOW / 15) * 15;
        let best = null;
        for (const person of visibleStaff()) {
          const items = [...visibleAppointments().filter(item => item.staff === person.id && item.status !== "cancelled"), ...visibleScheduleItems().filter(item => item.kind !== "appointment" && item.staff === person.id)]
            .map(item => ({ start: timeToMinutes(item.start), end: timeToMinutes(item.start) + item.duration }))
            .filter(item => item.end > searchStart)
            .sort((a, b) => a.start - b.start);
          let cursor = searchStart;
          for (const item of items) {
            if (item.start - cursor >= minDuration) {
              const candidate = { person, start: cursor, end: item.start };
              if (!best || candidate.start < best.start || (candidate.start === best.start && candidate.end - candidate.start > best.end - best.start)) best = candidate;
              break;
            }
            cursor = Math.max(cursor, item.end);
          }
          if (!best && HYBRID_DAY_END - cursor >= minDuration) best = { person, start: cursor, end: HYBRID_DAY_END };
        }
        return best;
      }

      function renderToday() {
        const appointments = visibleAppointments().filter(item => !["cancelled"].includes(item.status));
        const snapshot = dayCapacitySnapshot(appointments);
        if (!appointments.length) {
          return `<section class="screen"><div class="metric-grid">${metricCards([], snapshot)}</div><div class="paper-surface empty-state"><div><div class="empty-illustration"><span class="empty-marmot"></span></div><h2>Heute bleibt der Kalender frei.</h2><p class="muted">Füge einen Termin hinzu oder geniesse die Aussicht.</p><button class="button primary" type="button" data-quick-book>${icons.plus} Termin eintragen</button></div></div></section>`;
        }
        const next = nextRelevantAppointments(appointments, state.mode === "stress" ? 9 : 6);
        const pending = appointments.filter(item => item.status === "pending" && timeToMinutes(item.start) >= HYBRID_NOW).sort((a,b)=>timeToMinutes(a.start)-timeToMinutes(b.start))[0];
        const running = appointments.filter(item => item.status === "arrived" && timeToMinutes(item.start) <= HYBRID_NOW && timeToMinutes(item.start) + item.duration > HYBRID_NOW).sort((a,b)=>timeToMinutes(a.start)-timeToMinutes(b.start))[0];
        const gap = nextFreeGap(30);
        return `<section class="screen">
          <div class="metric-grid">${metricCards(appointments, snapshot)}</div>
          <div class="today-layout">
            <section class="paper-surface agenda-panel">
              <div class="card-head"><div><h2>Als Nächstes</h2><span class="muted">Aus derselben Tagesplanwahrheit wie Arbeitsfläche und Übersicht</span></div><button class="button compact" type="button" data-nav-inline="day">Tagesplan öffnen</button></div>
              <div class="appointment-list">${next.map(appointmentRow).join("")}</div>
            </section>
            <aside class="paper-surface">
              <div class="card-head"><div><h2>Aufmerksamkeit</h2><span class="muted">Nur konkrete nächste Handlungen</span></div></div>
              <div class="attention-list">
                ${pending ? `<div class="attention-item"><strong>${pending.customer} bestätigen</strong><span>Anfrage für ${pending.start} · ${staff.find(person=>person.id===pending.staff)?.name}</span></div>` : ""}
                ${running ? `<div class="attention-item"><strong>${running.customer} · ${currentPhaseDisplayName(running)}</strong><span>Aktueller Arbeitsschritt im Terminablauf</span></div>` : ""}
                ${gap ? `<div class="attention-item"><strong>Nächste freie Lücke</strong><span>${minutesToTime(gap.start)}–${minutesToTime(gap.end)} bei ${gap.person.name} · direkt buchbar</span></div>` : ""}
              </div>
            </aside>
          </div>
        </section>`;
      }

      function metricCards(appointments, snapshot = dayCapacitySnapshot(appointments)) {
        const items = [
          ["Termine", appointments.length, "Im heutigen Tagesplan"],
          ["Gebucht", `CHF ${snapshot.bookedValue.toLocaleString("de-CH")}`, "Bestätigt, angefragt und im Salon"],
          ["Belegung", `${snapshot.occupancy}%`, "Termine, Pausen und interne Zeit"],
          ["Im Salon", snapshot.inSalon, "Empfangen oder Dienstleistung läuft"]
        ];
        return items.map(([label, value, note]) => `<article class="metric-card"><span class="metric-label">${label}</span><strong>${value}</strong><span class="muted">${note}</span></article>`).join("");
      }

      function appointmentRow(appointment) {
        const member = staff.find(person => person.id === appointment.staff);
        return `<button type="button" class="appointment-row" data-appointment="${appointment.id}"><span class="time">${appointment.start}</span><span><strong>${appointment.customer}</strong><small>${appointment.service} · ${member.name}</small></span><span class="status-chip ${appointment.status}">${statusLabel(appointment.status)}</span></button>`;
      }

      const HYBRID_DAY_START = productTruth.day.openMinute;
      const HYBRID_DAY_END = productTruth.day.closeMinute;
      const HYBRID_WINDOW = productTruth.day.windowMinutes;
      const HYBRID_NOW = productTruth.day.currentMinute;

      function clampMinute(value, min, max) {
        return Math.max(min, Math.min(max, value));
      }

      function defaultLiveStart() {
        return clampMinute(Math.floor((HYBRID_NOW - 30) / 15) * 15, HYBRID_DAY_START, HYBRID_DAY_END - HYBRID_WINDOW);
      }

      function hybridWindowConfig() {
        const start = clampMinute(Number.isFinite(state.focusStart) ? state.focusStart : defaultLiveStart(), HYBRID_DAY_START, HYBRID_DAY_END - HYBRID_WINDOW);
        state.focusStart = start;
        return { start, end: start + HYBRID_WINDOW, now: HYBRID_NOW, range: HYBRID_WINDOW };
      }

      function layoutTimelineAppointments(items) {
        const laneEnds = [];
        const sorted = items.slice().sort((a, b) => timeToMinutes(a.start) - timeToMinutes(b.start));
        const laidOut = sorted.map(appointment => {
          const start = timeToMinutes(appointment.start);
          const end = start + appointment.duration;
          let lane = laneEnds.findIndex(laneEnd => laneEnd <= start);
          if (lane < 0) lane = laneEnds.length;
          laneEnds[lane] = end;
          return { appointment, lane };
        });
        const laneCount = Math.max(1, laneEnds.length);
        return laidOut.map(item => ({ ...item, laneCount }));
      }

      function renderTimeRuler(config) {
        const ticks = [];
        for (let minute = Math.ceil(config.start / 15) * 15; minute <= config.end; minute += 15) {
          const x = (minute - config.start) / config.range * 100;
          const isHour = minute % 60 === 0;
          const isHalf = minute % 30 === 0;
          const showLabel = isHour || isHalf || minute === config.start || minute === config.end;
          const nearEdge = ((minute - config.start) < 30 && minute !== config.start) || ((config.end - minute) < 30 && minute !== config.end);
          ticks.push(`<span class="work-ruler-tick ${isHour ? "is-hour" : isHalf ? "is-half" : "is-quarter"} ${nearEdge ? "is-near-edge" : ""}" style="left:${x}%">${showLabel ? `<strong>${minutesToTime(minute)}</strong>` : ""}</span>`);
        }
        if (config.start % 15 !== 0) ticks.unshift(`<span class="work-ruler-tick is-hour" style="left:0"><strong>${minutesToTime(config.start)}</strong></span>`);
        return ticks.join("");
      }

      function renderEmptyHabitat(className = "work-empty-habitat") {
        return `<div class="${className}" aria-hidden="true">
          <div class="empty-habitat-copy"><strong>Heute ist es noch erstaunlich ruhig.</strong></div>
          <svg class="empty-habitat-landscape" viewBox="0 0 1200 150" preserveAspectRatio="none">
            <path class="habitat-ridge-far" d="M0 105 C130 66 190 92 285 70 C390 44 470 101 565 76 C675 47 744 94 836 73 C944 48 1028 91 1200 58 L1200 150 L0 150 Z"/>
            <path class="habitat-ridge-near" d="M0 127 C120 108 202 128 305 111 C414 93 498 133 610 113 C722 94 824 132 942 111 C1040 94 1110 116 1200 100 L1200 150 L0 150 Z"/>
            <g class="habitat-flora" transform="translate(100 84)"><path d="M0 55 C2 27 8 15 16 0 M12 55 C14 32 25 18 34 8 M24 55 C27 36 31 30 42 19"/><circle cx="16" cy="5" r="4"/><circle cx="35" cy="10" r="3.5"/></g>
            <g class="habitat-flora" transform="translate(1000 90)"><path d="M0 52 C2 30 8 15 14 2 M14 52 C18 31 25 18 34 10 M27 52 C31 38 37 28 44 22"/><circle cx="14" cy="6" r="4"/><circle cx="35" cy="12" r="3.5"/></g>
          </svg>
          <img class="habitat-marmot" src="${alpineAssets.kantenblick}" alt="">
          <div class="habitat-edge"></div>
        </div>`;
      }

      function overviewAppointment(item, config) {
        const start = timeToMinutes(item.start);
        const end = start + item.duration;
        if (end <= HYBRID_DAY_START || start >= HYBRID_DAY_END) return "";
        const visibleStart = Math.max(start, HYBRID_DAY_START);
        const visibleEnd = Math.min(end, HYBRID_DAY_END);
        const top = (visibleStart - HYBRID_DAY_START) / (HYBRID_DAY_END - HYBRID_DAY_START) * 100;
        const height = Math.max(1.3, (visibleEnd - visibleStart) / (HYBRID_DAY_END - HYBRID_DAY_START) * 100);
        const query = state.search.trim().toLocaleLowerCase("de-CH");
        const match = query && scheduleSearchText(item).includes(query);
        const operational = item.kind && item.kind !== "appointment";
        const label = operational ? item.label : item.customer;
        const detail = operational ? item.note : item.service;
        const dataAttr = operational ? `data-schedule-block="${item.id}"` : `data-appointment="${item.id}"`;
        return `<button type="button" class="overview-appointment status-${item.status} ${operational ? `is-operational kind-${item.kind}` : ""} ${match ? "is-search-hit" : ""}" style="top:${top}%;height:${height}%" ${dataAttr} title="${item.start}–${minutesToTime(end)} · ${label} · ${detail || ""}"><strong>${label}</strong><small>${detail || ""}</small></button>`;
      }

      function renderDayOverview(appointments, people, config, isEmpty, mobileActiveId) {
        const labels = [];
        for (let minute = HYBRID_DAY_START; minute <= HYBRID_DAY_END; minute += 120) {
          const rawTop = (minute - HYBRID_DAY_START) / (HYBRID_DAY_END - HYBRID_DAY_START) * 100;
          const top = minute === HYBRID_DAY_START ? 1.5 : minute === HYBRID_DAY_END ? 98.5 : rawTop;
          labels.push(`<span class="overview-time-label ${minute % 120 === 0 ? "is-major" : ""}" style="top:${top}%">${minutesToTime(minute)}</span>`);
        }
        const columns = people.map(person => {
          const cards = appointments.filter(item => item.staff === person.id).map(item => overviewAppointment(item, config)).join("");
          return `<div class="overview-staff-column ${person.id === mobileActiveId ? "is-mobile-active" : ""}"><button type="button" class="overview-column-head" data-mobile-focus-person="${person.id}" aria-label="${person.name} ${person.surname} fokussieren"><span class="overview-avatar">${person.name[0]}${person.surname[0]}</span><span class="overview-name">${person.name}</span></button><div class="overview-body" data-overview-track data-staff="${person.id}">${cards}</div></div>`;
        }).join("");
        const nowTop = (HYBRID_NOW - HYBRID_DAY_START) / (HYBRID_DAY_END - HYBRID_DAY_START) * 100;
        return `<section class="day-overview-section" aria-label="Tagesübersicht">
          <div class="overview-viewport" id="day-overview-viewport">
            <div class="overview-grid" style="--overview-staff-count:${people.length}">
              <div class="overview-time-column"><div class="overview-column-head">Zeit</div><div class="overview-body">${labels.join("")}</div></div>
              ${columns}
              <div class="overview-now-line" style="top:calc(28px + (100% - 28px) * ${nowTop / 100})"></div>
            </div>
            ${isEmpty ? renderEmptyHabitat("overview-empty-habitat") : ""}
          </div>
        </section>`;
      }

      function workAppointment(item, lane, laneCount, config, rowHeight) {
        const start = timeToMinutes(item.start);
        const end = start + item.duration;
        const visibleStart = Math.max(start, config.start);
        const visibleEnd = Math.min(end, config.end);
        const left = (visibleStart - config.start) / config.range * 100;
        const width = Math.max(2.5, (visibleEnd - visibleStart) / config.range * 100);
        const widthPxEstimate = Math.max(40, (window.innerWidth - (isMobileUI() ? (isTabletUI() ? 240 : isMobilePortrait() ? 120 : 142) : 500)) * width / 100);
        const compactClass = widthPxEstimate < (isMobileUI() ? 48 : 62) ? "is-compact is-micro" : widthPxEstimate < (isMobileUI() ? 84 : 112) ? "is-compact" : "";
        const mobileTeamCompact = isMobileUI() && rowHeight <= 40;
        const cardHeight = mobileTeamCompact ? 26 : laneCount > 1 ? 34 : 42;
        const laneBlockHeight = laneCount * cardHeight + Math.max(0, laneCount - 1) * 5;
        const blockTop = Math.max(4, (rowHeight - laneBlockHeight) / 2);
        const top = blockTop + lane * (cardHeight + 5);
        const query = state.search.trim().toLocaleLowerCase("de-CH");
        const match = query && scheduleSearchText(item).includes(query);
        const dimmed = query && !match;
        const operational = item.kind && item.kind !== "appointment";
        const label = operational ? item.label : item.customer;
        const sublabel = operational ? item.note : item.service;
        const initials = operational ? "" : item.customer.split(" ").filter(Boolean).map(part => part[0]).slice(0, 2).join("");
        const delta = start - config.now;
        const isRunning = !operational && start <= config.now && end > config.now;
        const isStartingSoon = !operational && delta > 0 && delta <= 15;
        const isPast = end <= config.now;
        const continuesBefore = start < config.start;
        const continuesAfter = end > config.end;
        const temporal = isRunning ? `<span class="work-temporal-badge is-running">läuft</span>` : isStartingSoon ? `<span class="work-temporal-badge">in ${delta} Min.</span>` : "";
        const dataAttr = operational ? `data-schedule-block="${item.id}"` : `data-appointment="${item.id}"`;
        return `<button type="button" class="work-appointment appointment-card status-${item.status} ${operational ? `is-operational blocked-card kind-${item.kind}` : ""} ${compactClass} ${isRunning ? "is-running" : ""} ${isStartingSoon ? "is-starting-soon" : ""} ${isPast ? "is-past" : ""} ${continuesBefore ? "continues-before" : ""} ${continuesAfter ? "continues-after" : ""} ${match ? "is-search-hit" : ""} ${dimmed ? "is-dimmed" : ""} ${state.selectedId === item.id ? "is-selected" : ""}" style="left:calc(${left}% + 4px);width:calc(${width}% - 8px);top:${top}px;height:${cardHeight}px" ${dataAttr} title="${item.start}–${minutesToTime(end)} · ${label} · ${sublabel || ""}" aria-label="${item.start}, ${label}, ${sublabel || ""}${operational ? "" : `, ${statusLabel(item.status)}`}">
          ${continuesBefore ? `<span class="work-continuation-tag before">${isMobileUI() ? item.start : `seit ${item.start}`}</span>` : ""}${continuesAfter ? `<span class="work-continuation-tag after">weiter</span>` : ""}${temporal}${operational ? "" : `<span class="appointment-initials">${initials}</span>`}<span class="appt-time">${item.start}</span><strong>${label}</strong><span class="appt-service">${sublabel || ""}</span>
        </button>`;
      }

      function renderWorkSurface(appointments, people, config, isEmpty) {
        const ruler = renderTimeRuler(config);
        const rows = people.map((person, index) => {
          const personAppointments = appointments.filter(item => {
            const start = timeToMinutes(item.start);
            return item.staff === person.id && start + item.duration > config.start && start < config.end;
          });
          const layout = layoutTimelineAppointments(personAppointments);
          const laneCount = layout[0]?.laneCount || 1;
          const allTeamOnMobile = isMobileUI() && people.length > 1;
          const demoFiveMobile = allTeamOnMobile && state.mode !== "stress" && people.length <= 5;
          const baseHeight = demoFiveMobile ? (isMobilePortrait() ? 56 : 48) : allTeamOnMobile ? (isTabletUI() ? 54 : isMobilePortrait() ? 33 : 36) : isMobileUI() ? 96 : people.length <= 5 ? 76 : 54;
          const rowHeight = isEmpty ? baseHeight : Math.max(baseHeight, allTeamOnMobile ? 5 + laneCount * 28 : 10 + laneCount * 39);
          const cards = layout.map(item => workAppointment(item.appointment, item.lane, item.laneCount, config, rowHeight)).join("");
          return `<div class="work-resource-row ${index % 2 ? "is-alternate" : ""}" style="height:${rowHeight}px"><div class="work-resource-label"><span class="staff-avatar">${person.name[0]}${person.surname[0]}</span><span class="staff-name"><strong>${person.name} ${person.surname}</strong><small>${person.role}</small></span></div><div class="work-resource-track" data-work-track data-staff="${person.id}" data-start="${config.start}" data-range="${config.range}" tabindex="0" role="button" aria-label="Freie Zeit bei ${person.name} ${person.surname} wählen">${cards}</div></div>`;
        }).join("");
        const nowVisible = config.now >= config.start && config.now <= config.end;
        const nowX = (config.now - config.start) / config.range * 100;
        const rotateHint = isMobilePortrait() && !state.rotateHintDismissed ? `<aside class="mobile-rotate-tip" aria-label="Hinweis zum Querformat"><span class="mobile-rotate-icon" aria-hidden="true">${icons.rotate}</span><span><strong>Mehr Überblick in der Arbeitsfläche</strong><small>Drehe dein Handy quer, um die nächsten zwei Stunden auf einmal zu sehen. Hochkant bleibt vollständig nutzbar.</small></span><button type="button" class="mobile-rotate-close" data-dismiss-rotate aria-label="Hinweis schliessen">${icons.close}</button></aside>` : "";
        const demoStretch = state.mode !== "stress" && people.length <= 5;
        const allSingleLane = people.every(person => {
          const items = appointments.filter(item => {
            const start = timeToMinutes(item.start);
            return item.staff === person.id && start + item.duration > config.start && start < config.end;
          });
          return layoutTimelineAppointments(items).every(item => item.laneCount === 1);
        });
        return `<section class="work-surface-section ${rotateHint ? "has-mobile-tip" : ""}" aria-label="Arbeitsfläche, zwei Stunden">
          ${rotateHint}<div class="work-viewport-wrap ${isEmpty ? "is-empty" : ""}" style="--hybrid-staff-rail:${isMobileUI() ? (people.length > 1 ? (isTabletUI() ? 148 : 50) : 148) : window.innerWidth <= 1100 ? 180 : 218}px"><div class="work-viewport" id="day-viewport"><div class="work-timeline ${demoStretch ? "is-demo-stretch" : ""} ${demoStretch && allSingleLane ? "is-single-lane" : ""}" style="--work-staff-count:${people.length}"><div class="work-header-row"><div class="work-corner"><span>Team</span><small>Zeit →</small></div><div class="work-ruler">${ruler}</div></div>${rows}${nowVisible ? `<div class="work-now-line" style="left:calc(var(--hybrid-staff-rail) + (100% - var(--hybrid-staff-rail)) * ${nowX / 100})"><span>${minutesToTime(config.now)}</span></div>` : ""}</div></div>${isEmpty ? renderEmptyHabitat("work-empty-habitat") : ""}</div>
        </section>`;
      }

      function renderDayViewSwitch() {
        return `<div class="segment day-view-switch" role="tablist" aria-label="Ansicht des Tagesplans"><button type="button" role="tab" aria-selected="${state.dayView === "work"}" class="${state.dayView === "work" ? "is-active" : ""}" data-hybrid-view="work" title="Aktuelle zwei Stunden">Arbeitsfläche</button><button type="button" role="tab" aria-selected="${state.dayView === "overview"}" class="${state.dayView === "overview" ? "is-active" : ""}" data-hybrid-view="overview" title="Ganzer Arbeitstag">Tagesübersicht</button></div>`;
      }

      function renderDayViewControls(config) {
        if (state.dayView === "overview") return `<span class="day-range-chip"><strong>${minutesToTime(HYBRID_DAY_START)}–${minutesToTime(HYBRID_DAY_END)}</strong><span>Ganzer Tag</span></span>`;
        return `<div class="day-window-controls" aria-label="Zeitraum der Arbeitsfläche"><button class="button compact icon-button" type="button" data-window-shift="-30" aria-label="30 Minuten früher" title="30 Minuten früher">${icons.back}</button><button class="button compact now-button ${state.focusMode === "live" ? "is-current" : ""}" type="button" data-now-window>Jetzt</button><button class="button compact icon-button" type="button" data-window-shift="30" aria-label="30 Minuten später" title="30 Minuten später">${icons.next}</button><span class="day-range-chip ${state.focusMode === "live" ? "is-live" : ""}"><strong>${minutesToTime(config.start)}–${minutesToTime(config.end)}</strong><span>${state.focusMode === "live" ? `Jetzt ${minutesToTime(config.now)}` : "Gewählter Zeitraum"}</span></span></div>`;
      }

      function renderDay() {
        const appointments = visibleAppointments();
        const scheduleItems = visibleScheduleItems();
        const allPeople = visibleStaff();
        const isMobile = isMobileUI();
        const focusedPerson = state.mobileStaffId !== "all" ? allPeople.find(person => person.id === state.mobileStaffId) : null;
        const workPeople = isMobile && focusedPerson ? [focusedPerson] : allPeople;
        const overviewPeople = isMobile && focusedPerson ? [focusedPerson] : allPeople;
        const config = hybridWindowConfig();
        const isEmpty = appointments.length === 0;
        const mobileSwitcher = isMobile ? `<label class="mobile-staff-switcher"><span>Teamansicht</span><select class="filter-select" data-mobile-staff><option value="all" ${!focusedPerson ? "selected" : ""}>Alle Mitarbeitenden</option>${allPeople.map(person => `<option value="${person.id}" ${focusedPerson?.id === person.id ? "selected" : ""}>${person.name} ${person.surname}</option>`).join("")}</select></label>` : "";
        const summary = isEmpty ? "Keine Termine" : `<strong>${appointments.length} Termine</strong> · ${allPeople.length} Mitarbeitende`;
        const overview = renderDayOverview(scheduleItems, overviewPeople, config, isEmpty, focusedPerson?.id);
        const work = renderWorkSurface(scheduleItems, workPeople, config, isEmpty);
        const activeView = state.dayView === "overview" ? overview : work;
        const teamModeClass = isMobile && !focusedPerson ? "is-mobile-team-all" : isMobile ? "is-mobile-team-focus" : "";
        return `<section class="screen paper-surface day-shell hybrid-day-shell ${state.dayView === "overview" ? "is-overview" : "is-work"} ${teamModeClass} ${isEmpty ? "is-empty" : ""}"><div class="day-toolbar">${dateControls()}${renderDayViewSwitch()}${mobileSwitcher}<span class="day-summary">${summary}</span><span class="hybrid-toolbar-spacer"></span>${renderDayViewControls(config)}</div><div class="hybrid-day-body">${activeView}</div>${dayFooter(config)}</section>`;
      }

      function dateControls() {
        return `<div class="date-stepper" aria-label="Tag wechseln"><button class="button compact day-nav-button" type="button" data-day-shift="-1" aria-label="Vorheriger Tag">${icons.back}<span>Zurück</span></button><button class="button compact day-today-button" type="button" data-day-today>Heute</button><button class="button compact day-nav-button" type="button" data-day-shift="1" aria-label="Nächster Tag"><span>Weiter</span>${icons.next}</button></div>`;
      }

      function dayFooter(config) {
        const context = state.dayView === "work" ? `Arbeitsfläche · ${minutesToTime(config.start)}–${minutesToTime(config.end)}` : `Tagesübersicht · ${minutesToTime(HYBRID_DAY_START)}–${minutesToTime(HYBRID_DAY_END)}`;
        return `<div class="day-footer hybrid-day-footer"><span class="footer-view-context">${context}</span><div class="legend"><span><i></i>Bestätigt</span><span><i style="background:var(--amber)"></i>Angefragt</span><span><i style="background:var(--violet)"></i>Im Salon</span><span><i style="background:#6d7975"></i>Abgeschlossen</span><span><i style="background:var(--red)"></i>Nicht erschienen</span></div></div>`;
      }

      function renderBookings() {
        const appointments = visibleAppointments();
        const filters = `<div class="filter-row"><select class="filter-select"><option>Alle Status</option><option>Bestätigt</option><option>Im Salon</option><option>Abgeschlossen</option></select><select class="filter-select"><option>${productTruth.salon.location}</option><option>Alle Standorte</option></select><button class="button compact" type="button" data-demo-action="Zeitraum wählen">20.–27. August</button><span class="muted">${appointments.length} Einträge</span></div>`;
        if (isMobileUI()) {
          const rows = appointments.map(appointment => {
            const person = staff.find(member => member.id === appointment.staff);
            return `<button type="button" class="mobile-register-row" data-appointment="${appointment.id}"><span class="mobile-register-time"><strong>${appointment.start}</strong><small>20. Aug.</small></span><span class="mobile-register-main"><strong>${appointment.customer}</strong><small>${appointment.service} · ${person?.name || "Team"}</small></span><span class="status-chip ${appointment.status}">${statusLabel(appointment.status)}</span></button>`;
          }).join("");
          return `<section class="screen">${filters}<div class="paper-surface mobile-appointment-register">${rows || `<div class="empty-state"><div><h2>Noch keine Termine</h2><p class="muted">Sobald ein Termin eingetragen wird, erscheint er hier.</p></div></div>`}</div></section>`;
        }
        return `<section class="screen">${filters}
          <div class="paper-surface table-wrap">${appointments.length ? `<table class="data-table"><thead><tr><th>Zeit</th><th>Kundschaft</th><th>Dienstleistung</th><th>Mitarbeitende</th><th>Status</th></tr></thead><tbody>${appointments.map(appointment => { const person = staff.find(member => member.id === appointment.staff); return `<tr data-appointment="${appointment.id}" tabindex="0"><td><strong>20. Aug.</strong><small>${appointment.start}</small></td><td><strong>${appointment.customer}</strong><small>${appointment.phone}</small></td><td>${appointment.service}</td><td>${person.name} ${person.surname}</td><td><span class="status-chip ${appointment.status}">${statusLabel(appointment.status)}</span></td></tr>`; }).join("")}</tbody></table>` : `<div class="empty-state"><div><h2>Noch keine Termine</h2><p class="muted">Sobald ein Termin eingetragen wird, erscheint er in diesem Register.</p><button class="button primary" type="button" data-quick-book>${icons.plus} Termin eintragen</button></div></div>`}</div>
        </section>`;
      }

      function renderCustomers() {
        const active = Number.isInteger(state.selectedCustomer) ? customers[state.selectedCustomer] : null;
        const list = `<div class="split-list" data-customer-list><div class="card-head"><div><h2>Kundschaft</h2><span class="muted">Kundenkartei öffnen, wenn Details gebraucht werden</span></div></div>${customers.map((customer, index) => `<button type="button" class="customer-row ${index === state.selectedCustomer ? "is-active" : ""}" data-customer="${index}"><span class="avatar">${customer.name.split(" ").map(word => word[0]).join("")}</span><span><strong>${customer.name}</strong><small>${customer.phone}</small></span><span class="muted">${customer.visits}</span></button>`).join("")}</div>`;
        if (!active) return `<section class="screen paper-surface split-view customer-list-only">${list}</section>`;
        const detail = `<div class="split-detail"><div class="detail-heading"><div><div class="eyebrow">Kundenkartei</div><h2>${active.name}</h2><span class="muted">${active.phone}</span></div><div class="customer-detail-actions"><button class="button compact customer-detail-close" type="button" data-customer-detail-close aria-label="Kundenkartei schliessen" title="Kundenkartei schliessen">${icons.close}</button><button class="button primary" type="button" data-customer-book>${icons.plus} Termin</button></div></div>
          <div class="detail-grid"><div class="detail-stat"><span>Besuche</span><strong>${active.visits}</strong></div><div class="detail-stat"><span>Umsatz</span><strong>CHF ${active.revenue.toLocaleString("de-CH")}</strong></div><div class="detail-stat"><span>Letzter Termin</span><strong>${active.last}</strong></div><div class="detail-stat"><span>Kontakt</span><strong>SMS erlaubt</strong></div></div>
          <div class="section-card"><div class="eyebrow">Salonnotiz</div><p style="margin:5px 0 0">${active.note}</p></div>
          <h3 style="margin-top:20px">Verlauf</h3><div class="history-item"><strong>Schnitt & Föhnen · CHF 104</strong><small>${active.last} · Melanie Schneider</small></div><div class="history-item"><strong>Terminbestätigung per SMS</strong><small>Erfolgreich zugestellt</small></div>
        </div>`;
        return `<section class="screen paper-surface split-view has-customer-detail">${list}${detail}</section>`;
      }

      function renderTeam() {
        return `<section class="screen"><div class="filter-row"><span class="status-chip confirmed">${visibleStaff().length} aktiv</span><span class="muted">Person, Rolle, Standort und Arbeitszeit werden nur hier gepflegt.</span></div><div class="people-grid">${visibleStaff().map(person => `<article class="person-card"><div class="person-card-head"><span class="avatar">${person.name[0]}${person.surname[0]}</span><div><h3>${person.name} ${person.surname}</h3><span class="muted">${person.role}</span></div></div><p>${productTruth.salon.location} · Arbeitszeit vollständig</p><div class="schedule-strip"><span class="on">Mo</span><span class="on">Di</span><span class="on">Mi</span><span class="on">Do</span><span class="on">Fr</span><span>Sa</span><span>So</span></div><button class="button compact" type="button" data-demo-action="${person.name} bearbeiten" style="margin-top:13px">Bearbeiten</button></article>`).join("")}</div></section>`;
      }

      function renderOffer() {
        const activeInitials = new Set(visibleStaff().map(person => `${person.name[0]}${person.surname[0]}`));
        return `<section class="screen"><div class="filter-row"><span class="status-chip confirmed">${services.length} aktiv</span><span class="muted">Dienstleistung, Dauer, Preis und Zuordnung zu bestehenden Personen.</span></div><div class="service-grid">${services.map(service => { const assigned = service.team.filter(initials => activeInitials.has(initials)); return `<article class="service-card"><span class="service-price">CHF ${service.price}</span><div class="eyebrow">Dienstleistung</div><h3>${service.name}</h3><p>${service.duration} Minuten · online buchbar</p><div class="service-meta"><span class="status-chip confirmed">Aktiv</span><span class="status-chip">${assigned.length} Personen</span></div><div class="assignment-list">${assigned.map(initials => `<span class="mini-avatar">${initials}</span>`).join("")}</div><button class="button compact" type="button" data-demo-action="${service.name} bearbeiten" style="margin-top:14px">Bearbeiten</button></article>`; }).join("")}</div></section>`;
      }

      function renderAdmin() {
        const cards = [["Salonprofil", "Adresse, Kontakt und rechtliche Angaben des Salons."], ["Marke", "Logo und salonbezogene Akzente, getrennt von der Gasserwerk-Shell."], ["Standorte", `${productTruth.salon.location} und künftige Filialen verwalten.`], ["Integrationen", "Kalender, Kommunikation und angebundene Dienste."], ["Rollen & Zugriff", "Fähigkeiten für Inhaberin, Leitung, Mitarbeitende und Lesende."], ["Plan & Abrechnung", "Eigentümergebundene Vertrags- und Rechnungsangaben."]];
        return `<section class="screen"><div class="admin-grid">${cards.map(([title, copy], index) => `<article class="admin-card"><div class="eyebrow">${index === 5 ? "Nur Inhaberin" : "Verwaltung"}</div><h3>${title}</h3><p>${copy}</p><button class="button compact" type="button" data-demo-action="${title} öffnen">Öffnen</button></article>`).join("")}</div></section>`;
      }

      function bindScreenEvents() {
        document.querySelectorAll("[data-work-track]").forEach(track => {
          const openAtPoint = event => {
            if (event.target.closest("[data-appointment]")) return;
            const rect = track.getBoundingClientRect();
            const start = Number(track.dataset.start);
            const range = Number(track.dataset.range);
            const rawMinute = start + clampMinute((event.clientX - rect.left) / rect.width, 0, 1) * range;
            const snapped = clampMinute(Math.round(rawMinute / 15) * 15, state.focusStart, state.focusStart + HYBRID_WINDOW - 15);
            openPrototypeBooking("", { staff: track.dataset.staff, time: minutesToTime(snapped) });
          };
          track.addEventListener("click", openAtPoint);
          track.addEventListener("keydown", event => {
            if (event.key === "Enter" || event.key === " ") {
              event.preventDefault();
              const defaultMinute = clampMinute(Math.ceil((HYBRID_NOW + 15) / 15) * 15, state.focusStart, state.focusStart + HYBRID_WINDOW - 15);
              openPrototypeBooking("", { staff: track.dataset.staff, time: minutesToTime(defaultMinute) });
            }
          });
        });
        document.querySelectorAll("[data-overview-track]").forEach(track => {
          track.addEventListener("click", event => {
            if (event.target.closest("[data-appointment]")) return;
            const rect = track.getBoundingClientRect();
            const minute = HYBRID_DAY_START + clampMinute((event.clientY - rect.top) / rect.height, 0, 1) * (HYBRID_DAY_END - HYBRID_DAY_START);
            state.focusStart = clampMinute(Math.round((minute - 30) / 15) * 15, HYBRID_DAY_START, HYBRID_DAY_END - HYBRID_WINDOW);
            state.focusMode = Math.abs(minute - HYBRID_NOW) < 20 ? "live" : "manual";
            state.dayView = "work";
            storeValue("gasserwerk-day-view", state.dayView);
            render();
          });
        });
        document.querySelectorAll("[data-day-shift]").forEach(node => node.addEventListener("click", () => shiftReferenceDay(Number(node.dataset.dayShift))));
        document.querySelectorAll("[data-day-today]").forEach(node => node.addEventListener("click", () => { state.currentDate = new Date(...productTruth.day.referenceDate); render(); }));

        document.querySelectorAll("[data-hybrid-view]").forEach(node => {
          node.addEventListener("click", () => {
            if (state.dayView === node.dataset.hybridView) return;
            state.dayView = node.dataset.hybridView;
            storeValue("gasserwerk-day-view", state.dayView);
            render();
          });
          node.addEventListener("keydown", event => {
            if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
            event.preventDefault();
            state.dayView = event.key === "ArrowLeft" ? "work" : "overview";
            storeValue("gasserwerk-day-view", state.dayView);
            render();
            requestAnimationFrame(() => document.querySelector(`[data-hybrid-view="${state.dayView}"]`)?.focus());
          });
        });
        document.querySelectorAll("[data-window-shift]").forEach(node => node.addEventListener("click", () => {
          state.focusStart = clampMinute(state.focusStart + Number(node.dataset.windowShift), HYBRID_DAY_START, HYBRID_DAY_END - HYBRID_WINDOW);
          state.focusMode = state.focusStart === defaultLiveStart() ? "live" : "manual";
          state.dayView = "work";
          render();
        }));
        document.querySelectorAll("[data-now-window]").forEach(node => node.addEventListener("click", () => { state.focusStart = defaultLiveStart(); state.focusMode = "live"; state.dayView = "work"; render(); }));
        const mobileStaff = document.querySelector("[data-mobile-staff]");
        if (mobileStaff) mobileStaff.addEventListener("change", event => {
          state.mobileStaffId = event.target.value;
          storeValue("gasserwerk-mobile-staff", state.mobileStaffId);
          render();
        });

        document.querySelectorAll("[data-mobile-focus-person]").forEach(node => node.addEventListener("click", () => {
          if (!isMobileUI()) return;
          state.mobileStaffId = node.dataset.mobileFocusPerson;
          storeValue("gasserwerk-mobile-staff", state.mobileStaffId);
          render();
        }));
        document.querySelectorAll("[data-dismiss-rotate]").forEach(node => node.addEventListener("click", () => {
          state.rotateHintDismissed = true;
          storeValue("gasserwerk-rotate-hint-dismissed", "1");
          const tip = node.closest(".mobile-rotate-tip");
          const surface = tip?.closest(".work-surface-section");
          tip?.remove();
          surface?.classList.remove("has-mobile-tip");
        }));
        document.querySelectorAll("[data-schedule-block]").forEach(node => node.addEventListener("click", event => {
          event.stopPropagation();
          const item = productTruth.scheduleBlocks.find(block => block.id === node.dataset.scheduleBlock);
          if (item) toast(item.label, `${item.start}–${minutesToTime(timeToMinutes(item.start) + item.duration)} · ${staff.find(person => person.id === item.staff)?.name || "Team"} · ${item.note}`);
        }));
        document.querySelectorAll("[data-appointment]").forEach(node => {
          node.addEventListener("click", event => { event.stopPropagation(); openAppointment(node.dataset.appointment, node); });
          node.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") openAppointment(node.dataset.appointment, node); });
        });
        document.querySelectorAll("[data-nav-inline]").forEach(node => node.addEventListener("click", () => navigate(node.dataset.navInline)));
        document.querySelectorAll("[data-customer]").forEach(node => node.addEventListener("click", () => {
          const list = document.querySelector("[data-customer-list]");
          state.customerListScrollTop = list?.scrollTop || workspaceBody.scrollTop || 0;
          state.selectedCustomer = Number(node.dataset.customer);
          render();
        }));
        document.querySelectorAll("[data-customer-detail-close]").forEach(node => node.addEventListener("click", () => {
          state.selectedCustomer = null;
          render();
          requestAnimationFrame(() => {
            const list = document.querySelector("[data-customer-list]");
            if (list && list.scrollHeight > list.clientHeight) list.scrollTop = state.customerListScrollTop || 0;
            else workspaceBody.scrollTop = state.customerListScrollTop || 0;
          });
        }));
        document.querySelectorAll("[data-step]").forEach(node => node.addEventListener("click", () => { state.onboardingStep = Number(node.dataset.step); render(); }));
        document.querySelectorAll("[data-step-back]").forEach(node => node.addEventListener("click", () => { state.onboardingStep = Math.max(0, state.onboardingStep - 1); render(); }));
        document.querySelectorAll("[data-step-next]").forEach(node => node.addEventListener("click", () => { if (state.onboardingStep >= 4) navigate("today"); else { state.onboardingStep += 1; render(); } }));
        document.querySelectorAll("[data-quick-book]").forEach(node => node.addEventListener("click", () => openPrototypeBooking()));
        document.querySelectorAll("[data-customer-book]").forEach(node => node.addEventListener("click", () => openPrototypeBooking(customers[state.selectedCustomer]?.name)));
        document.querySelectorAll("[data-demo-action]").forEach(node => node.addEventListener("click", () => toast("Demo-Aktion", `${node.dataset.demoAction} wird in dieser Vorschau nicht gespeichert.`)));
        const login = el("prototype-login");
        if (login) login.addEventListener("submit", event => { event.preventDefault(); toast("Anmeldung simuliert", "Der sichere Zielkontext Heute wurde wiederhergestellt."); navigate("today"); });
      }

      function openPrototypeBooking(customer = "", slot = null) {
        const dayViewport = el("day-viewport");
        state.origin = { screen: state.screen, search: state.search, scrollTop: workspaceBody.scrollTop, dayScrollLeft: dayViewport?.scrollLeft || 0, dayScrollTop: dayViewport?.scrollTop || 0, focusId: null };
        state.panelOrigin = null;
        state.panelView = "booking";
        state.selectedId = null;
        const defaultStaff = slot?.staff || visibleStaff()[0]?.id || "melanie";
        const defaultTime = slot?.time || minutesToTime(clampMinute(Math.ceil((HYBRID_NOW + 15) / 15) * 15, state.focusStart, state.focusStart + HYBRID_WINDOW - 15));
        const staffOptions = visibleStaff().map(person => `<option value="${person.id}" ${person.id === defaultStaff ? "selected" : ""}>${person.name} ${person.surname}</option>`).join("");
        panel.innerHTML = panelFrame("Termin eintragen", `<div class="notice"><strong>Zeit und Person bleiben verankert</strong><br>Der Einstieg kommt direkt aus der horizontalen 2-Stunden-Arbeitsfläche und behält Person und Uhrzeit bei.</div><div class="form-field"><label for="booking-customer">Kundin</label><input id="booking-customer" value="${customer}" placeholder="Vor- und Nachname"></div><div class="form-field"><label for="booking-service">Dienstleistung</label><select id="booking-service" class="filter-select" style="width:100%">${services.map(service => `<option value="${service.duration}|${service.price}">${service.name} · ${service.duration} Min.</option>`).join("")}</select></div><div class="form-field"><label for="booking-staff">Mitarbeitende</label><select id="booking-staff" class="filter-select" style="width:100%">${staffOptions}</select></div><div class="form-field"><label for="booking-time">Zeit</label><input id="booking-time" type="time" step="900" value="${defaultTime}"></div>`, `<button class="button" type="button" data-panel-close>Abbrechen</button><button class="button primary" type="button" data-booking-success>Termin eintragen</button>`);
        openPanel();
        bindPanelEvents();
        panel.querySelector("[data-booking-success]").addEventListener("click", () => {
          const customerName = panel.querySelector("#booking-customer").value.trim() || "Neue Kundin";
          const [duration, price] = panel.querySelector("#booking-service").value.split("|").map(Number);
          const service = panel.querySelector("#booking-service").selectedOptions[0].textContent.replace(/ · \d+ Min\.?$/, "");
          const staffId = panel.querySelector("#booking-staff").value;
          const time = panel.querySelector("#booking-time").value || defaultTime;
          const appointment = { id: `p${Date.now()}`, customer: customerName, phone: "Noch offen", service, staff: staffId, start: time, duration, status: "confirmed", note: "In der horizontalen 2-Stunden-Arbeitsfläche eingetragen", price };
          state.appointments.unshift(appointment);
          state.selectedId = appointment.id;
          state.mode = "normal";
          el("mode-picker").value = "normal";
          const person = staff.find(member => member.id === staffId);
          showSuccess("Termin erfolgreich erstellt", `${customerName} ist um ${time} bei ${person.name} ${person.surname} eingeplant.`, "Im Tagesplan zeigen");
        });
      }

      function openAppointment(id, trigger) {
        state.selectedId = id;
        const dayViewport=el("day-viewport");
        state.origin={screen:state.screen,search:state.search,scrollTop:workspaceBody.scrollTop,dayScrollLeft:dayViewport?.scrollLeft||0,dayScrollTop:dayViewport?.scrollTop||0,focusId:id};
        state.panelView="detail";
        if(trigger){
          const rect=trigger.getBoundingClientRect(),panelWidth=Math.min(455,window.innerWidth-32),panelLeft=window.innerWidth-16-panelWidth;
          state.panelOrigin={x:Math.max(-420,Math.min(420,rect.left-panelLeft)),y:Math.max(-420,Math.min(420,rect.top-58)),originX:Math.max(0,rect.left-panelLeft),originY:Math.max(0,rect.top-58)};
        }
        renderAppointmentPanel();
        openPanel();
        if(trigger)trigger.classList.add("is-selected");
      }

      function renderAppointmentPanel() {
        const appointment = selectedAppointment();
        if (!appointment) return;
        const person = staff.find(member => member.id === appointment.staff);
        const activeActions = !["cancelled", "no-show"].includes(appointment.status);
        const nextWorkStep = currentPhaseDisplayName(appointment);
        const terminablaufAction = appointment.status === "arrived"
          ? `<button class="action-row" type="button" data-panel-action="visit"><span><strong>${nextWorkStep}</strong><small>Nächster Arbeitsschritt im Terminablauf</small></span><span>→</span></button>`
          : appointment.status === "confirmed"
            ? `<button class="action-row" type="button" data-panel-action="arrival"><span><strong>${appointment.customer} empfangen</strong><small>Terminablauf öffnen und ersten Arbeitsschritt anzeigen</small></span><span>→</span></button>`
            : "";
        const body = `<div class="appointment-hero"><span class="status-chip ${appointment.status}">${statusLabel(appointment.status)}</span><h3>${appointment.customer}</h3><p>${appointment.start}–${minutesToTime(timeToMinutes(appointment.start) + appointment.duration)} · ${appointment.service}</p></div>
          <div class="facts"><div class="fact"><span>Mitarbeitende</span><strong>${person.name} ${person.surname}</strong></div><div class="fact"><span>Standort</span><strong>${productTruth.salon.location}</strong></div><div class="fact"><span>Kontakt</span><strong>${appointment.phone}</strong></div><div class="fact"><span>Preis</span><strong>CHF ${appointment.price}</strong></div></div>
          <div class="notice"><strong>Salonhinweis</strong><br>${appointment.note}</div>
          <div class="action-group">${terminablaufAction}${activeActions ? `<button class="action-row" type="button" data-panel-action="reschedule"><span><strong>Termin verschieben</strong><small>Kundschaft, Dienstleistung und Dauer bleiben erhalten</small></span><span>→</span></button><button class="action-row" type="button" data-panel-action="cancel"><span><strong>Termin absagen</strong><small>Folgen und Kommunikation zuerst bestätigen</small></span><span>→</span></button>` : ""}<button class="action-row" type="button" data-customer-from-panel><span><strong>Kundenkartei öffnen</strong><small>Historie, Notiz und nächster Termin</small></span><span>→</span></button></div>`;
        panel.innerHTML = panelFrame("Termin", body, `<button class="button" type="button" data-panel-close>Schliessen</button>`);
        bindPanelEvents();
      }

      function panelFrame(title, body, footer) {
        return `<div class="panel-head"><div><div class="eyebrow">Termin im Salonalltag</div><h2 id="panel-title">${title}</h2></div><button class="button icon-button ghost" type="button" data-panel-close aria-label="Panel schliessen">${icons.close}</button></div><div class="panel-body">${body}</div><div class="panel-footer">${footer}</div>`;
      }

      function bindPanelEvents() {
        panel.querySelectorAll("[data-panel-close]").forEach(node => node.addEventListener("click", () => closePanel(true)));
        panel.querySelectorAll("[data-panel-action]").forEach(node => node.addEventListener("click", () => renderPanelView(node.dataset.panelAction)));
        const customerAction = panel.querySelector("[data-customer-from-panel]");
        if (customerAction) customerAction.addEventListener("click", () => { const appointment = selectedAppointment(); const index = customers.findIndex(customer => customer.name === appointment.customer); state.selectedCustomer = index >= 0 ? index : null; closePanel(false); navigate("customers", { keepCustomerDetail: true }); });
      }

      function renderPanelView(view) {
        state.panelView = view;
        if (view === "reschedule") renderReschedule();
        if (view === "cancel") renderCancel();
        if (view === "arrival") renderArrival();
        if (view === "visit") renderVisit();
      }

      function renderReschedule() {
        const appointment = selectedAppointment();
        const member = staff.find(person => person.id === appointment.staff);
        const slots = [
          { value: "14:15", label: "Heute, 14:15", staff: member.name, note: "Nächster passender Slot" },
          { value: "09:30", label: "Freitag, 21. August · 09:30", staff: member.name, note: "Gleiche Mitarbeiterin" },
          { value: "11:15", label: "Freitag, 21. August · 11:15", staff: "Sofia", note: "Früher, andere Mitarbeiterin" }
        ];
        state.selectedSlot = null;
        panel.innerHTML = panelFrame("Termin verschieben", `<div class="appointment-hero"><span class="status-chip ${appointment.status}">Bisher</span><h3>${appointment.customer}</h3><p>Heute, ${appointment.start} · ${appointment.service}</p></div><div class="notice"><strong>Was erhalten bleibt</strong><br>Kundschaft, Dienstleistung, Dauer und Salonnotiz werden übernommen. Der alte Termin bleibt bis zum simulierten Erfolg bestehen.</div><div class="eyebrow">Passende freie Zeiten</div><div class="slot-list">${slots.map((slot, index) => `<button type="button" class="slot-button" data-slot="${index}"><span><strong>${slot.label}</strong><small>${slot.staff} · ${slot.note}</small></span><span>Wählen</span></button>`).join("")}</div><div class="form-field"><label for="custom-time">Oder Uhrzeit direkt wählen</label><input id="custom-time" type="time" value="14:15"></div>`, `<button class="button" type="button" data-panel-back>Zurück</button><button class="button primary" type="button" data-reschedule-commit disabled>Termin verschieben</button>`);
        panel.querySelectorAll("[data-slot]").forEach(button => button.addEventListener("click", () => { state.selectedSlot = slots[Number(button.dataset.slot)]; panel.querySelectorAll("[data-slot]").forEach(node => node.classList.remove("is-selected")); button.classList.add("is-selected"); panel.querySelector("[data-reschedule-commit]").disabled = false; }));
        panel.querySelector("#custom-time").addEventListener("change", event => { state.selectedSlot = { value: event.target.value, label: `Heute, ${event.target.value}`, staff: member.name, note: "Direkte Uhrwahl" }; panel.querySelector("[data-reschedule-commit]").disabled = false; });
        panel.querySelector("[data-reschedule-commit]").addEventListener("click", commitReschedule);
        panel.querySelector("[data-panel-back]").addEventListener("click", renderAppointmentPanel);
        panel.querySelectorAll("[data-panel-close]").forEach(node => node.addEventListener("click", () => closePanel(true)));
      }

      function commitReschedule() {
        const appointment = selectedAppointment();
        const action = panel.querySelector("[data-reschedule-commit]");
        action.disabled = true;
        action.textContent = "Wird geprüft ...";
        const loading = document.createElement("div"); loading.className = "loading-line"; panel.querySelector(".panel-body").append(loading);
        window.setTimeout(() => {
          appointment.start = state.selectedSlot.value;
          if (state.selectedSlot.staff === "Sofia") appointment.staff = "sofia";
          showSuccess("Termin verschoben", `${appointment.customer} ist neu ${state.selectedSlot.label} bei ${state.selectedSlot.staff} eingeplant. Die SMS-Kommunikation wurde im Prototyp als erfolgreich simuliert.`, "Neuen Termin zeigen");
        }, 650);
      }

      function renderCancel() {
        const appointment = selectedAppointment();
        panel.innerHTML = panelFrame("Termin absagen", `<div class="appointment-hero"><span class="status-chip ${appointment.status}">${statusLabel(appointment.status)}</span><h3>${appointment.customer}</h3><p>Heute, ${appointment.start} · ${appointment.service}</p></div><div class="notice danger"><strong>Dieser Termin wird als abgesagt markiert.</strong><br>${appointment.duration} Minuten werden im Tagesplan wieder frei. Die Kundin bleibt in der Historie sichtbar.</div><div class="eyebrow">Kommunikation</div><div class="choice-list"><label class="choice"><input type="radio" name="cancel-channel" value="SMS" checked><span><strong>SMS vorbereiten</strong><br><small class="muted">Im Prototyp als zugestellt simuliert</small></span></label><label class="choice"><input type="radio" name="cancel-channel" value="Telefonnotiz"><span><strong>Telefonisch informiert</strong><br><small class="muted">Nur als Salonnotiz erfassen</small></span></label></div><label class="choice" style="margin-top:12px"><input id="cancel-confirm" type="checkbox"><span>Ich habe Folgen und Kommunikation geprüft.</span></label>`, `<button class="button" type="button" data-panel-back>Zurück</button><button class="button danger" type="button" data-cancel-commit disabled>Termin absagen</button>`);
        const checkbox = panel.querySelector("#cancel-confirm");
        const commit = panel.querySelector("[data-cancel-commit]");
        checkbox.addEventListener("change", () => commit.disabled = !checkbox.checked);
        commit.addEventListener("click", () => { const channel = panel.querySelector("input[name='cancel-channel']:checked").value; appointment.status = "cancelled"; showSuccess("Termin abgesagt", `${appointment.customer} ist als abgesagt markiert. ${appointment.duration} Minuten sind wieder frei. Kommunikation: ${channel}.`, "Im Ursprung anzeigen"); });
        panel.querySelector("[data-panel-back]").addEventListener("click", renderAppointmentPanel);
        panel.querySelectorAll("[data-panel-close]").forEach(node => node.addEventListener("click", () => closePanel(true)));
      }

      function renderArrival() {
        const appointment = selectedAppointment();
        const firstWorkStep = phaseDisplayNamesFor(appointment)[0] || appointment.service;
        panel.innerHTML = panelFrame(`${appointment.customer} empfangen`, `<div class="appointment-hero"><span class="status-chip confirmed">Bestätigt</span><h3>${appointment.customer}</h3><p>${appointment.start} · ${appointment.service}</p></div><div class="notice"><strong>Empfang bereits erfasst?</strong><br>Auch bei erneutem Tippen wird der Empfang nur einmal erfasst. Dauert die Aktualisierung länger, bleibt der Zwischenstand sichtbar.</div><div class="facts"><div class="fact"><span>Nächster Zustand</span><strong>Im Salon</strong></div><div class="fact"><span>Erster Arbeitsschritt</span><strong>${firstWorkStep}</strong></div></div>`, `<button class="button" type="button" data-panel-back>Zurück</button><button class="button primary" type="button" data-arrival-commit>${appointment.customer} empfangen</button>`);
        panel.querySelector("[data-arrival-commit]").addEventListener("click", () => { appointment.status = "arrived"; appointment.visitStep = 0; showSuccess(`${appointment.customer} empfangen`, `${appointment.customer} ist im Salon. Der Terminablauf ist geöffnet. ${firstWorkStep} ist der nächste Arbeitsschritt.`, "Terminablauf öffnen", "visit"); });
        panel.querySelector("[data-panel-back]").addEventListener("click", renderAppointmentPanel);
        panel.querySelectorAll("[data-panel-close]").forEach(node => node.addEventListener("click", () => closePanel(true)));
      }

      function visitNextLabel(appointment) {
        return currentPhaseDisplayName(appointment);
      }

      function renderVisit() {
        const appointment = selectedAppointment();
        const phases = phaseDisplayNamesFor(appointment);
        const current = Math.min(appointment.visitStep || 0, phases.length - 1);
        panel.innerHTML = panelFrame("Terminablauf", `<div class="appointment-hero"><span class="status-chip arrived">Im Salon</span><h3>${appointment.customer}</h3><p>${appointment.service} · Planzeiten sind nur Hinweise</p></div><div class="visit-track">${phases.map((phase, index) => `<div class="visit-step ${index < current ? "is-done" : ""} ${index === current ? "is-current" : ""}"><span class="visit-step-number">${index < current ? "✓" : index + 1}</span><span><strong>${phase}</strong><br><small class="muted">${index < current ? "Abgeschlossen" : index === current ? "Jetzt" : "Danach"}</small></span></div>`).join("")}</div>`, `<button class="button" type="button" data-panel-back>Zum Termin</button><button class="button primary" type="button" data-visit-next>${current >= phases.length - 1 ? "Terminablauf abschliessen" : `${phases[current]} abschliessen`}</button>`);
        panel.querySelector("[data-visit-next]").addEventListener("click", () => {
          if (current >= phases.length - 1) { appointment.status = "completed"; showSuccess("Terminablauf abgeschlossen", `${appointment.customer} ist abgeschlossen. Der Termin bleibt mit Status und Verlauf im Tageskontext sichtbar.`, "Zum Tagesplan"); }
          else { appointment.visitStep = current + 1; toast("Terminablauf aktualisiert", `${phases[current]} abgeschlossen. Nächster Arbeitsschritt: ${phases[current + 1]}.`); renderVisit(); }
        });
        panel.querySelector("[data-panel-back]").addEventListener("click", renderAppointmentPanel);
        panel.querySelectorAll("[data-panel-close]").forEach(node => node.addEventListener("click", () => closePanel(true)));
      }

      function showSuccess(title, copy, buttonLabel, nextView = null) {
        panel.innerHTML = panelFrame("Ergebnis", `<div class="success-state"><div><div class="success-alpine-accent" aria-hidden="true"><img src="${alpineAssets.success}" alt=""></div><div class="success-mark">✓</div><h3>${title}</h3><p class="muted">${copy}</p><div class="notice"><strong>Du bleibst im gleichen Arbeitsmoment</strong><br>Tag, Suche „${state.search || "kein Suchbegriff"}“ und Ausgangsseite ${screenMeta[state.origin?.screen || state.screen][1]} bleiben für die Rückkehr bestehen.</div></div></div>`, `<button class="button" type="button" data-success-origin>Zum Ausgangspunkt</button><button class="button primary" type="button" data-success-next>${buttonLabel}</button>`);
        panel.querySelector("[data-success-origin]").addEventListener("click", () => returnToOrigin());
        panel.querySelector("[data-success-next]").addEventListener("click", () => { if (nextView === "visit") renderVisit(); else { closePanel(false); state.screen = "day"; el("screen-picker").value = "day"; render(); focusSelectedAppointment(); } });
        panel.querySelectorAll("[data-panel-close]").forEach(node => node.addEventListener("click", () => returnToOrigin()));
      }

      function returnToOrigin() {
        const origin = state.origin;
        closePanel(false);
        if (!origin) return;
        state.screen = origin.screen;
        state.search = origin.search;
        searchInput.value = state.search;
        el("screen-picker").value = state.screen;
        render();
        requestAnimationFrame(()=>{workspaceBody.scrollTop=origin.scrollTop||0;const dayViewport=el("day-viewport");if(dayViewport){dayViewport.scrollLeft=origin.dayScrollLeft||0;dayViewport.scrollTop=origin.dayScrollTop||0;}focusSelectedAppointment();updateDayScrollHints();});
      }

      function focusSelectedAppointment() {
        const target = document.querySelector(`[data-appointment="${state.selectedId}"]`);
        if (target) { target.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" }); target.focus({ preventScroll: true }); target.classList.add("is-selected"); }
      }

      function openPanel() {
        if(state.panelOrigin&&window.innerWidth>760){
          panel.style.setProperty("--panel-from-x",`${state.panelOrigin.x}px`);
          panel.style.setProperty("--panel-from-y",`${state.panelOrigin.y}px`);
          panel.style.setProperty("--panel-origin-x",`${state.panelOrigin.originX}px`);
          panel.style.setProperty("--panel-origin-y",`${state.panelOrigin.originY}px`);
        }else{
          ["--panel-from-x","--panel-from-y","--panel-origin-x","--panel-origin-y"].forEach(name=>panel.style.removeProperty(name));
        }
        backdrop.classList.add("is-open");
        panel.classList.add("is-open");
        document.body.style.overflow = "hidden";
        requestAnimationFrame(() => panel.querySelector("button, input, select")?.focus());
      }

      function closePanel(restoreFocus = true) {
        panel.classList.remove("is-open");
        backdrop.classList.remove("is-open");
        document.body.style.overflow = "hidden";
        if (restoreFocus) focusSelectedAppointment();
      }

      function applySearchState() {
        searchInput.value = state.search;
        const query = state.search.trim().toLocaleLowerCase("de-CH");
        if (!query) { searchResult.classList.remove("is-visible"); return; }
        const match = findScheduleMatch(query);
        if (match) {
          const matchLabel = match.customer || match.label;
          const matchDetail = match.service || match.note || "Aufgabe";
          searchResult.innerHTML = `<button type="button" data-search-match="${match.id}"><strong>${matchLabel}</strong><small>${match.start} · ${matchDetail} · Im Tagesplan hervorheben</small></button>`;
          searchResult.classList.add("is-visible");
          searchResult.querySelector("button").addEventListener("click", () => revealSearchMatch(match.id));
        } else {
          searchResult.innerHTML = `<button type="button"><strong>Kein direkter Treffer</strong><small>Suchbegriff bleibt erhalten. Versuche einen Namen oder eine Dienstleistung.</small></button>`;
          searchResult.classList.add("is-visible");
        }
      }

      function revealSearchMatch(id) {
        state.selectedId = id;
        const appointment = state.appointments.find(item => item.id === id) || productTruth.scheduleBlocks.find(item => item.id === id);
        if (appointment) {
          const start = timeToMinutes(appointment.start);
          state.focusStart = clampMinute(Math.round((start - 30) / 15) * 15, HYBRID_DAY_START, HYBRID_DAY_END - HYBRID_WINDOW);
          state.focusMode = "manual";
        }
        state.dayView = "work";
        state.screen = "day";
        el("screen-picker").value = "day";
        searchResult.classList.remove("is-visible");
        render();
        requestAnimationFrame(() => {
          const target = document.querySelector(`[data-appointment="${id}"], [data-schedule-block="${id}"]`);
          if (target) { target.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" }); target.focus({ preventScroll: true }); }
        });
      }


      function updateDayScrollHints(){ /* Hybrid view has no hidden horizontal staff axis. */ }

      function toast(title, copy) {
        const node = document.createElement("div");
        node.className = "toast";
        node.innerHTML = `<strong>${title}</strong><small>${copy}</small>`;
        el("toast-region").append(node);
        window.setTimeout(() => node.remove(), 3600);
      }

      searchInput.addEventListener("input", event => {
        state.search = event.target.value;
        applySearchState();
        if (state.screen === "day") {
          const viewport = el("day-viewport");
          const left = viewport?.scrollLeft || 0;
          const top = viewport?.scrollTop || 0;
          render();
          requestAnimationFrame(() => { const nextViewport = el("day-viewport"); if (nextViewport) { nextViewport.scrollLeft = left; nextViewport.scrollTop = top; updateDayScrollHints(); } });
        }
      });
      searchInput.addEventListener("keydown", event => {
        if (event.key === "Enter") {
          const query = state.search.trim().toLocaleLowerCase("de-CH");
          const match = findScheduleMatch(query);
          if (match) revealSearchMatch(match.id);
        }
        if (event.key === "Escape") { state.search = ""; searchInput.value = ""; searchResult.classList.remove("is-visible"); if (state.screen === "day") render(); }
      });
      document.addEventListener("keydown", event => {
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); searchInput.focus(); }
        if (event.key === "Escape" && panel.classList.contains("is-open")) closePanel(true);
      });
      backdrop.addEventListener("click", () => closePanel(true));
      el("screen-picker").addEventListener("change", event => navigate(event.target.value));
      el("mode-picker").addEventListener("change", event => { state.mode = event.target.value; state.selectedId = null; closePanel(false); render(); });
      el("theme-toggle").addEventListener("click", cycleThemeMode);

      let viewportSignature = "";
      let viewportTimer = 0;
      const handleViewportChange = () => {
        window.clearTimeout(viewportTimer);
        viewportTimer = window.setTimeout(() => {
          syncMobileUiClass();
          const signature = `${isMobileUI() ? "mobile" : "desktop"}:${window.innerWidth > window.innerHeight ? "landscape" : "portrait"}`;
          if (signature !== viewportSignature) {
            viewportSignature = signature;
            if (state.screen === "day") render();
          }
        }, 80);
      };
      window.addEventListener("resize", handleViewportChange, { passive: true });
      window.addEventListener("orientationchange", handleViewportChange, { passive: true });
      window.visualViewport?.addEventListener("resize", handleViewportChange, { passive: true });

      window.addEventListener("popstate", () => {
        const nextScreen = screenFromLocation();
        if (nextScreen !== state.screen) navigate(nextScreen, { fromHistory: true });
      });
      window.addEventListener("online", () => { syncNetworkStatus(); toast("Wieder online", "Die Verbindung ist wieder verfügbar."); });
      window.addEventListener("offline", syncNetworkStatus);

      systemThemeQuery?.addEventListener?.("change", () => {
        if (state.themeMode !== "system") return;
        applyThemeMode("system", { persist: false });
        renderHeader();
        bindHeaderUtilities();
      });

      window.addEventListener("beforeinstallprompt", event => {
        event.preventDefault();
        deferredInstallPrompt = event;
        document.documentElement.classList.add("pwa-installable");
        if (state.screen !== "login") { renderHeader(); bindHeaderUtilities(); }
      });
      window.addEventListener("appinstalled", () => {
        deferredInstallPrompt = null;
        document.documentElement.classList.remove("pwa-installable");
        toast("Gasserwerk installiert", "Die Referenzoberfläche wurde als App installiert.");
        renderHeader();
        bindHeaderUtilities();
      });

      if ("serviceWorker" in navigator && ["http:", "https:"].includes(location.protocol)) {
        window.addEventListener("load", async () => {
          try {
            const registration = await navigator.serviceWorker.register(withBasePath("/gasserwerk-sw.js"), { scope: `${APP_BASE_PATH}/` || "/" });
            pwaRegistration = registration;
            if (registration.waiting && navigator.serviceWorker.controller) showPwaUpdate(registration);
            registration.addEventListener("updatefound", () => {
              const installing = registration.installing;
              if (!installing) return;
              installing.addEventListener("statechange", () => {
                if (installing.state === "installed" && navigator.serviceWorker.controller) {
                  showPwaUpdate(registration);
                  bindPwaUpdateAction();
                }
              });
            });
            navigator.serviceWorker.addEventListener("controllerchange", () => {
              if (reloadingForServiceWorker) return;
              reloadingForServiceWorker = true;
              location.reload();
            });
          } catch (error) {
            console.warn("Gasserwerk Service Worker konnte nicht registriert werden", error);
          }
        }, { once: true });
      }

      syncMobileUiClass();
      syncRoute(state.screen, true);
      applyThemeMode(state.themeMode, { persist: false });
      viewportSignature = `${isMobileUI() ? "mobile" : "desktop"}:${window.innerWidth > window.innerHeight ? "landscape" : "portrait"}`;
      render();
    })();
