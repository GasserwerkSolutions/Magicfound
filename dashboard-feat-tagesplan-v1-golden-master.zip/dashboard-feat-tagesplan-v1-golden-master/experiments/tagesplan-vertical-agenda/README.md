# Tagesplan · Vertikale Teamfläche mit Kopfzeilenagenda

Direkt ausführbare Referenz zu ADR-004, ADR-005 und ADR-006. Sie ist der aktuelle Einstieg der automatisch veröffentlichten Dashboard-Referenz.

## Grundmodell

- Zeit läuft von `08:00` bis `18:00` von oben nach unten.
- Alle Mitarbeitenden bleiben Spalten derselben Teamfläche.
- `09:00`, `12:00`, `15:00` und `18:00` sind die stärksten Zeitanker.
- Eine globale vergangene Zeitfläche zeigt den bereits durchlaufenen Tagesanteil.
- Die horizontale Jetzt-Linie beschreibt die gemeinsame Salonzeit.
- Personenfokus dimmt Nachbarspalten, ohne die Geometrie zu wechseln.
- `Als Nächstes` ist ein aufklappbarer Kopfzeilenkontext und keine permanente Fläche.

## Präzisionsregeln

### Zeitlinie und Karten

Der Zeitstrich liegt hinter den Terminkarten. Er bleibt in freien Bereichen sichtbar, kann aber weder Namen noch Leistungen durchstreichen. Laufende Termine erhalten lediglich einen kleinen roten Einschnitt am Kartenrand an ihrer tatsächlichen Fortschrittsposition.

Karteninhalt wird aus der real gemessenen Breite und Höhe bestimmt:

1. vollständiger Name, Zeit und Leistung,
2. semantisch verkürzter Name und Zeit,
3. semantisch verkürzter Name,
4. Vorname,
5. Initialen.

Beispiel: `Mia Frei` → `Mia F.` → `Mia` → `MF`. Mechanische Ellipsen mitten im Wort sind nicht vorgesehen.

### Kompakte Kalender

Wenn der volle Tag nicht in den sichtbaren Kalender passt, wird beim ersten Öffnen des heutigen Tages einmalig zur aktuellen Salonzeit positioniert. Die Jetzt-Linie liegt ungefähr im oberen Drittel der sichtbaren Fläche.

Nach manueller Bewegung springt die Oberfläche nicht selbstständig zurück. Arbeitsuhr und mobile Zeitsteuerung führen ausdrücklich zu Jetzt.

Im Hochformat besitzt jede Mitarbeitendenspalte mindestens 132 Pixel. Zeitachse und Mitarbeitendenkopf bleiben sticky; ungefähr zwei Spalten und ein Teil der folgenden Spalte sind sichtbar. Die horizontale Bewegung rastet nur leicht ein.

### Kopfzeilenagenda

Der geschlossene Standardzustand zeigt nur `Als Nächstes`. Das Popover enthält:

- `Davor`,
- `Jetzt`,
- `Danach`,
- die nächste freie Lücke.

Auf kompakten Viewports werden weitere Einträge nicht still abgeschnitten. Stattdessen erscheinen Offenlegungen wie:

```text
3 weitere laufen
4 weitere danach
```

Die Einträge lassen sich gruppenweise erweitern. Kalender und Agenda verwenden dieselben Terminobjekte und denselben Auswahlzustand.

### Suche und Zeit

- Desktop: vollständiges Suchfeld.
- Kompaktes Querformat: Suchfeld mit 280–320 Pixel Breite.
- Hochformat: 44-Pixel-Suchschaltfläche mit temporärem Suchfeld.
- Suchtext: `Name, Termin oder freie Zeit suchen`.
- Tastaturhinweis: `⌘K` auf Apple-Plattformen, `Ctrl K` auf Windows/Linux.

Wenn die Seitenleistenuhr sichtbar ist, wird die zusätzliche Zeitpille im Desktopkopf ausgeblendet. Auf Mobilgeräten bleibt sie als 44-Pixel-Steuerung erhalten. Uhr, Pille, vergangene Fläche und Jetzt-Linie verwenden `Europe/Zurich` und werden am Minutenwechsel sowie beim Wiederaufnehmen eines inaktiven Tabs synchronisiert.

## Personenfokus

- Klick auf eine Person setzt den Fokus.
- Klick auf dieselbe Person oder `Escape` hebt ihn auf.
- Alle fünf Spalten bleiben bestehen.
- Vier Kontextspalten werden über eine neutrale Maske um 34 Prozent zurückgenommen.
- Suchtreffer, Auswahl und Tastaturfokus liegen oberhalb der Maske.

## Referenzparameter

Deterministische Salonzeit:

```text
?referenceNow=11:22
```

Geöffnete Agenda:

```text
?referenceNow=11:22&agenda=open
```

Fokus auf Melanie:

```text
?referenceNow=11:22&focus=melanie
```

Diagnosezustand mit geöffneter Agenda:

```text
?referenceNow=11:22&verify=1
```

## Responsive Abnahme

Geprüft werden:

```text
1366 × 768
1440 × 900
1512 × 982
1920 × 1080
390 × 844
844 × 390
```

`1512 × 982` ist der Desktop-Master. Die Prüfungen kontrollieren unter anderem Ebenenordnung, initiale Jetzt-Position, horizontale Mitarbeitendenbewegung, semantische Kartendichte, `x weitere`-Offenlegung, Suche, vollständigen Benutzername, sichere technische Ränder und null horizontalen Gesamtseitenüberlauf.

Die Referenz führt keine produktive Persistenz aus.
