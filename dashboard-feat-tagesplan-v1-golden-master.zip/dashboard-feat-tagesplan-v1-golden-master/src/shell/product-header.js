import { createElement, replaceChildren } from '../lib/dom.js';

function contentNode(value, className) {
  if (value?.nodeType) return value;
  return createElement('span', { className, text: value ?? '' });
}

function normalizeActions(actions) {
  if (!actions) return [];
  return (Array.isArray(actions) ? actions : [actions]).filter(Boolean);
}

export function createProductHeader(options = {}) {
  const {
    kicker = '',
    title = '',
    context = '',
    search = null,
    actions = [],
    searchOpen = false
  } = options;

  const kickerElement = createElement('p', {
    className: 'gw-product-header__kicker',
    text: kicker
  });
  const titleElement = createElement('h1', {
    className: 'gw-product-header__title',
    attributes: { tabindex: '-1' },
    children: contentNode(title, 'gw-product-header__title-copy')
  });
  const contextElement = createElement('p', {
    className: 'gw-product-header__context',
    children: contentNode(context, 'gw-product-header__context-copy')
  });
  const orientation = createElement('div', {
    className: 'gw-product-header__orientation',
    children: [kickerElement, titleElement, contextElement]
  });

  const searchElement = search?.element ?? search ?? null;
  const searchContainer = createElement('div', {
    className: 'gw-product-header__search',
    attributes: { hidden: searchElement ? null : true },
    children: searchElement
  });
  const actionsContainer = createElement('div', {
    className: 'gw-product-header__actions',
    children: normalizeActions(actions)
  });

  const header = createElement('header', {
    className: 'gw-product-header',
    attributes: {
      'data-search-open': searchOpen ? 'true' : 'false'
    },
    children: [orientation, searchContainer, actionsContainer]
  });

  return Object.freeze({
    element: header,
    orientation,
    titleElement,
    contextElement,
    searchContainer,
    actionsContainer,
    setKicker(value) {
      kickerElement.textContent = String(value ?? '');
    },
    setTitle(value) {
      replaceChildren(titleElement, contentNode(value, 'gw-product-header__title-copy'));
    },
    setContext(value) {
      replaceChildren(contextElement, contentNode(value, 'gw-product-header__context-copy'));
    },
    setActions(nextActions) {
      replaceChildren(actionsContainer, normalizeActions(nextActions));
    },
    setSearch(searchSurface) {
      const nextElement = searchSurface?.element ?? searchSurface ?? null;
      replaceChildren(searchContainer, nextElement ? [nextElement] : []);
      searchContainer.hidden = !nextElement;
    },
    setSearchOpen(value) {
      header.dataset.searchOpen = value ? 'true' : 'false';
    },
    focusTitle() {
      titleElement.focus({ preventScroll: true });
    }
  });
}
