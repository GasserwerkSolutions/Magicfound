# ADR-008 · Technischer Core Freeze vor der Beseelung

Status: **Accepted**  
Datum: 2026-08-25  
Betrifft: Tagesplan v1.0  
Ergänzt: [`ADR-007`](./ADR-007-tagesplan-v1-golden-master.md)  
Richtlinie: [`TAGESPLAN_V1_FREEZE_POLICY.md`](../TAGESPLAN_V1_FREEZE_POLICY.md)

## Kontext

Der Tagesplan soll nach Abschluss seiner räumlichen, fachlichen und interaktiven Grundarbeit in mehreren Beseelungsvarianten untersucht werden. Ohne unveränderliche Ausgangsbasis wären Unterschiede zwischen Materialität, Bewegung, Sprache, Symbolik und alpiner Welt nicht sauber von gleichzeitig auftretenden technischen Änderungen zu trennen.

Eine visuell attraktive Referenz ist deshalb noch kein geeigneter Experimentieranker. Benötigt wird zuerst ein technisch eingefrorener Kern, dessen Verhalten, Datenwahrheit, Responsivität, Accessibility und Artefaktintegrität reproduzierbar bewiesen sind.

## Entscheidung

Vor jeder Beseelung wird ein **Tagesplan v1.0 Core Freeze** bereitgestellt.

Der Core Freeze umfasst:

- die vollständige räumliche und responsive Grammatik;
- die komplette Zustands- und Interaktionslogik;
- die Zeit-, Daten- und Statuswahrheit;
- Tastatur-, Fokus-, Touch- und Reduced-Motion-Verhalten;
- die isolierte Single-HTML-Referenz;
- reproduzierbare Build- und Prüfschritte;
- Browser-, Zoom-, Zustands- und Accessibility-Evidenz;
- ein maschinenlesbares Freeze-Manifest und SHA-256-Prüfsummen;
- einen unveränderlichen Git-Tag auf dem freigegebenen Commit.

Der Core Freeze enthält keine aktivierte experimentelle Beseelungsschicht. Maschinenlesbare Profile und technische Anschlussstellen dürfen vorhanden sein, müssen im Freeze jedoch neutral beziehungsweise deaktiviert bleiben.

## Verbindliche Reihenfolge

```text
Geometrie
→ Funktion und Zustände
→ Accessibility und Resilienz
→ deterministischer Single-HTML-Build
→ vollständige technische Abnahme
→ Core-Freeze-Tag
→ Beseelungsvarianten
→ Auswahl und Erfahrungsfreigabe
→ endgültige Produktintegration
```

## Schutzregeln

1. Kein Beseelungsbranch entsteht vor dem Core-Freeze-Tag.
2. Der Freeze-Tag wird niemals verschoben oder überschrieben.
3. Beseelungsvarianten verändern keine fachlichen Verträge.
4. Geometrieänderungen nach dem Freeze gelten als Core-Änderung und benötigen einen neuen Freeze Candidate.
5. Beseelungsvarianten werden mit denselben Fixtures, Uhrzeiten, Viewports und Zuständen verglichen.
6. Die Integrationslinie darf den Core Freeze verwenden, darf dessen sichtbare oder interaktive Wahrheit aber nicht still umdeuten.
7. Die Seite `Termine` beginnt erst nach der vollständigen Tagesplanfreigabe.

## Begründung

Diese Reihenfolge schafft:

- einen belastbaren Nullzustand für visuelle und emotionale Experimente;
- eindeutige Ursachen bei Regressionen;
- reproduzierbare Vergleiche;
- eine sichere Rückfallposition;
- eine klare Grenze zwischen Produktwahrheit und atmosphärischer Ausarbeitung.

## Konsequenz für Versionierung

Der technische Kern wird markiert als:

```text
tagesplan-v1.0-core-freeze
```

Beseelungsvarianten verwenden Arbeitszweige wie:

```text
exp/tagesplan-v1-soul-still
exp/tagesplan-v1-soul-living-time
exp/tagesplan-v1-soul-alpine-empty
```

Die ausgewählte Erfahrungsfassung referenziert weiterhin exakt denselben Core-Freeze-SHA. Falls sie eine Core-Änderung erfordert, wird der bestehende Freeze nicht verändert; stattdessen entsteht ein neuer Freeze Candidate.
