import { existsSync, readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';

const root = process.cwd();
const errors = [];
const notes = [];

const requiredFiles = [
  'pages/tagesplan/index.html',
  'pages/tagesplan/page.css',
  'pages/tagesplan/page.js',
  'pages/tagesplan/CONTRACT.md',
  'src/shell/dashboard-shell-v1.js',
  'src/styles/dashboard-shell-v1.css',
  'src/data/mock-dashboard-data-source-v1.js',
  'src/data/fixtures/day-plan-v1.js',
  'src/data/contracts/dashboard-data-source.js',
  'src/data/contracts/events.js',
  'src/data/contracts/capabilities.js',
  'src/data/contracts/domain-values.js'
];

function read(path) {
  const absolute = resolve(root, path);
  if (!existsSync(absolute)) {
    errors.push(`Fehlende modulare Tagesplan-Datei: ${path}`);
    return '';
  }
  return readFileSync(absolute, 'utf8');
}

function assert(condition, message) {
  if (!condition) errors.push(message);
}

for (const file of requiredFiles) read(file);

const index = read('pages/tagesplan/index.html');
const pageScript = read('pages/tagesplan/page.js');
const pageStyles = read('pages/tagesplan/page.css');
const shellScript = read('src/shell/dashboard-shell-v1.js');
const fixture = read('src/data/fixtures/day-plan-v1.js');
const adapter = read('src/data/mock-dashboard-data-source-v1.js');

assert(index.startsWith('<!doctype html>'), 'pages/tagesplan/index.html muss mit <!doctype html> beginnen');
assert(index.includes('lang="de-CH"'), 'Modularer Tagesplan: de-CH Sprachdeklaration fehlt');
assert(index.includes('../../src/styles/dashboard-shell-v1.css'), 'Modularer Tagesplan importiert die gemeinsame Schalen-CSS nicht');
assert(index.includes('./page.css'), 'Modularer Tagesplan importiert page.css nicht');
assert(index.includes('type="module" src="./page.js"'), 'Modularer Tagesplan startet page.js nicht als ES-Modul');
assert(!/(?:href|src)=["']\//.test(index), 'Modularer Tagesplan enthält einen unsicheren absoluten Root-Pfad');

assert(pageScript.includes('createDashboardShell'), 'Tagesplan verwendet die gemeinsame Produktschale nicht');
assert(pageScript.includes('createMockDashboardDataSourceV1'), 'Tagesplan verwendet den Mock-Datenadapter nicht');
assert(pageScript.includes('DashboardEvent.DAY_LIVE_FOLLOW_PAUSED'), 'Live-Follow-Pause ist nicht als fachliches Event umgesetzt');
assert(pageScript.includes('DashboardEvent.DAY_LIVE_FOLLOW_RESUME_REQUESTED'), 'Jetzt-Rückkehr ist nicht als fachliches Event umgesetzt');
assert(pageScript.includes('DashboardEvent.DAY_STAFF_FOCUS_REQUESTED'), 'Personenfokus-Event fehlt');
assert(pageScript.includes('DashboardEvent.APPOINTMENT_CREATE_REQUESTED'), 'Buchungsabsicht fehlt');
assert(pageScript.includes('AUTO_RETURN_MS = 25_000'), 'Sichere 25-Sekunden-Inaktivitätsgrenze fehlt');
assert(pageScript.includes('OPERATIVE_VISIBLE_MINUTES_DESKTOP = 240'), '240-Minuten-Desktopmassstab fehlt');
assert(pageScript.includes('OPERATIVE_PAST_MINUTES_DESKTOP = 45'), '45-Minuten-Vergangenheitsanteil fehlt');
assert(pageScript.includes('LIVE_ANCHOR_RATIO_DESKTOP = OPERATIVE_PAST_MINUTES_DESKTOP / OPERATIVE_VISIBLE_MINUTES_DESKTOP'), 'Exakter Desktop-Jetzt-Anker fehlt');
assert(pageScript.includes('LIVE_ANCHOR_RATIO_MOBILE = 0.22'), 'Mobiler Jetzt-Anker fehlt');
assert(pageScript.includes('function referenceMinuteOverride()'), 'Kontrollierbare Referenzuhr fehlt');
assert(pageScript.includes('layoutTimelineItems'), 'Überlappungen werden nicht auf zusätzliche Bahnen verteilt');
assert(pageScript.includes("has-multiple-lanes"), 'Zeilenwachstum für echte Überschneidungen fehlt');
assert(pageScript.includes('syncVisibleTimelineContent'), 'Lesbarer Karteninhalt bei horizontalen Fortsetzungen fehlt');

assert(pageStyles.includes('--day-quarter-line'), '15-Minuten-Rastertoken fehlt');
assert(pageStyles.includes('--day-half-line'), '30-Minuten-Rastertoken fehlt');
assert(pageStyles.includes('--day-hour-line'), '60-Minuten-Rastertoken fehlt');
assert(pageStyles.includes('position: sticky'), 'Sticky Team-/Zeitskala ist nicht definiert');
assert(pageStyles.includes('.day-staff-focus'), 'Vertikaler Personenfokus fehlt');
assert(pageStyles.includes('@media (max-width: 1720px)'), '14-Zoll-Dichtebereich fehlt');
assert(pageStyles.includes('--day-appointment-height: 44px'), 'Kompakte Terminhöhe fehlt');
assert(pageStyles.includes('height: var(--day-row-height)'), 'Feste Personenzeilenhöhe fehlt');
assert(pageStyles.includes('.day-appointment-initials'), 'Mikrotermin-Hierarchie fehlt');
assert(pageStyles.includes('.day-staff-row.has-multiple-lanes'), 'CSS für echte Überlappungsbahnen fehlt');
assert(pageStyles.includes('.day-appointment.is-visible-fragment-micro'), 'Dichteanpassung für sichtbare Kartenfragmente fehlt');
assert(pageStyles.includes('.day-header-context-copy'), 'Headerpriorität für Datum und Massstabsaktion fehlt');
assert(pageStyles.includes('.day-header-date-button svg') && pageStyles.includes('width: 18px') && pageStyles.includes('height: 18px'), 'Datumssymbol ist nicht auf Produktgrösse begrenzt');
assert(!pageStyles.includes('is-demo-stretch'), 'Automatische Demo-Zeilenstreckung ist nicht zulässig');

assert(shellScript.includes('DASHBOARD_NAVIGATION'), 'Gemeinsamer Navigationskatalog fehlt');
assert(shellScript.includes('gw-mobile-navigation'), 'Gemeinsame mobile Navigation fehlt');
assert(adapter.includes('extends DashboardDataSource'), 'Mock-Adapter implementiert DashboardDataSource nicht');
assert(adapter.includes('getDayPlan(query'), 'Mock-Adapter liefert keinen Tagesplan');
assert(fixture.includes('OperationalKind.TASK'), 'Interne Aufgabenfixture fehlt');
assert(fixture.includes('AppointmentStatus.ARRIVED'), 'Aktiver Terminstatus fehlt in der Fixture');

const jsFiles = [
  'pages/tagesplan/page.js',
  'src/shell/dashboard-shell-v1.js',
  'src/data/mock-dashboard-data-source-v1.js',
  'src/data/fixtures/day-plan-v1.js'
];

for (const file of jsFiles) {
  const result = spawnSync(process.execPath, ['--check', resolve(root, file)], { encoding: 'utf8' });
  if (result.status !== 0) errors.push(`${file}: JavaScript-Syntaxfehler\n${result.stderr.trim()}`);
  else notes.push(`${file}: Syntax geprüft`);
}

for (const note of notes) console.log(`✓ ${note}`);

if (errors.length) {
  console.error(`\nModulare Tagesplan-Prüfung fehlgeschlagen (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('\n✓ Der modulare Tagesplan ist strukturell und syntaktisch konsistent.');
