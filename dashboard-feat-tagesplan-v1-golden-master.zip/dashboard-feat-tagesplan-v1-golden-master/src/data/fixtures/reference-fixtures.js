import { Capability } from '../contracts/capabilities.js';

export const REFERENCE_DATE = '2026-08-20';
export const REFERENCE_INSTANT = '2026-08-20T09:22:00.000Z';
export const REFERENCE_TIME_ZONE = 'Europe/Zurich';

function deepFreeze(value) {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  Object.freeze(value);
  for (const child of Object.values(value)) deepFreeze(child);
  return value;
}

export const referenceSessionContext = deepFreeze({
  account: { id: 'account-melanie', displayName: 'Melanie Schneider', initials: 'MS', productRoleLabel: 'Inhaberin' },
  salon: { id: 'salon-sonnegg', name: 'Coiffure Sonnegg', locationLabel: 'Zürich Enge', timeZone: REFERENCE_TIME_ZONE },
  capabilities: Object.values(Capability),
  locale: 'de-CH',
  currency: 'CHF'
});

export const referenceAuthenticationOptions = deepFreeze({
  sessionState: 'anonymous',
  product: { name: 'Gasserwerk', salonName: 'Coiffure Sonnegg', locationLabel: 'Zürich Enge' },
  authenticationMethods: ['password', 'magic-link'],
  passwordResetAvailable: true,
  maintenanceMessage: null,
  returnTarget: '/dashboard/pages/tagesplan/'
});

export const referenceStaff = deepFreeze([
  { id: 'melanie', displayName: 'Melanie Schneider', initials: 'MS', professionalRoleLabel: 'Top Stylistin', availabilitySummary: 'Mo–Fr · 08:00–18:00', isActive: true, weeklySchedule: [{ weekday: 1, startMinute: 480, endMinute: 1080 }, { weekday: 2, startMinute: 480, endMinute: 1080 }, { weekday: 3, startMinute: 480, endMinute: 1080 }, { weekday: 4, startMinute: 480, endMinute: 1080 }, { weekday: 5, startMinute: 480, endMinute: 1080 }], assignedServiceIds: ['schnitt-foehnen', 'balayage', 'farbe-pflege', 'schnitt'] },
  { id: 'sofia', displayName: 'Sofia Keller', initials: 'SK', professionalRoleLabel: 'Stylistin', availabilitySummary: 'Di–Sa · 09:00–17:30', isActive: true, weeklySchedule: [{ weekday: 2, startMinute: 540, endMinute: 1050 }, { weekday: 3, startMinute: 540, endMinute: 1050 }, { weekday: 4, startMinute: 540, endMinute: 1050 }, { weekday: 5, startMinute: 540, endMinute: 1050 }, { weekday: 6, startMinute: 540, endMinute: 1050 }], assignedServiceIds: ['schnitt-foehnen', 'farbe-pflege', 'schnitt', 'pony'] },
  { id: 'lea', displayName: 'Lea Bianchi', initials: 'LB', professionalRoleLabel: 'Stylistin', availabilitySummary: 'Mo–Fr · 08:00–17:00', isActive: true, weeklySchedule: [{ weekday: 1, startMinute: 480, endMinute: 1020 }, { weekday: 2, startMinute: 480, endMinute: 1020 }, { weekday: 3, startMinute: 480, endMinute: 1020 }, { weekday: 4, startMinute: 480, endMinute: 1020 }, { weekday: 5, startMinute: 480, endMinute: 1020 }], assignedServiceIds: ['schnitt-foehnen', 'balayage', 'farbe-pflege'] },
  { id: 'nina', displayName: 'Nina Frei', initials: 'NF', professionalRoleLabel: 'Stylistin', availabilitySummary: 'Mo–Fr · 09:00–18:00', isActive: true, weeklySchedule: [{ weekday: 1, startMinute: 540, endMinute: 1080 }, { weekday: 2, startMinute: 540, endMinute: 1080 }, { weekday: 3, startMinute: 540, endMinute: 1080 }, { weekday: 4, startMinute: 540, endMinute: 1080 }, { weekday: 5, startMinute: 540, endMinute: 1080 }], assignedServiceIds: ['schnitt', 'farbe-pflege', 'balayage'] },
  { id: 'jasmin', displayName: 'Jasmin Rüfenacht', initials: 'JR', professionalRoleLabel: 'Top Stylistin', availabilitySummary: 'Mo–Sa · 09:00–18:00', isActive: true, weeklySchedule: [{ weekday: 1, startMinute: 540, endMinute: 1080 }, { weekday: 2, startMinute: 540, endMinute: 1080 }, { weekday: 3, startMinute: 540, endMinute: 1080 }, { weekday: 4, startMinute: 540, endMinute: 1080 }, { weekday: 5, startMinute: 540, endMinute: 1080 }, { weekday: 6, startMinute: 540, endMinute: 1080 }], assignedServiceIds: ['schnitt-foehnen', 'balayage', 'farbe-pflege', 'schnitt'] }
]);

export const referenceServices = deepFreeze([
  { id: 'schnitt-foehnen', displayName: 'Schnitt & Föhnen', durationMinutes: 90, price: 118, assignedStaffIds: ['melanie', 'sofia', 'lea', 'jasmin'], isActive: true },
  { id: 'farbe-pflege', displayName: 'Farbe & Pflege', durationMinutes: 90, price: 172, assignedStaffIds: ['melanie', 'sofia', 'lea', 'nina', 'jasmin'], isActive: true },
  { id: 'balayage', displayName: 'Balayage & Glossing', durationMinutes: 150, price: 248, assignedStaffIds: ['melanie', 'lea', 'nina', 'jasmin'], isActive: true },
  { id: 'schnitt', displayName: 'Schnitt', durationMinutes: 60, price: 86, assignedStaffIds: ['melanie', 'sofia', 'nina', 'jasmin'], isActive: true },
  { id: 'pony', displayName: 'Pony nachschneiden', durationMinutes: 30, price: 42, assignedStaffIds: ['sofia'], isActive: true }
]);

export const referenceCustomers = deepFreeze([
  { id: 'customer-mia', displayName: 'Mia Frei', phoneLabel: '079 238 14 62', emailLabel: null, tags: ['Stammkundin'] },
  { id: 'customer-anna', displayName: 'Anna Keller', phoneLabel: '079 205 17 83', emailLabel: 'anna.keller@example.test', tags: ['Stammkundin'] },
  { id: 'customer-julia', displayName: 'Julia Schmid', phoneLabel: '078 616 45 92', emailLabel: null, tags: ['Farbe'] },
  { id: 'customer-chiara', displayName: 'Chiara Bianchi', phoneLabel: '079 501 27 08', emailLabel: null, tags: ['Empfindliche Kopfhaut'] },
  { id: 'customer-vanessa', displayName: 'Vanessa Meier', phoneLabel: '076 799 04 13', emailLabel: null, tags: [] },
  { id: 'customer-corinne', displayName: 'Corinne Zbinden', phoneLabel: '079 488 31 75', emailLabel: null, tags: ['Kontakt per SMS'] },
  { id: 'customer-celine', displayName: 'Céline Rufer', phoneLabel: '078 330 12 97', emailLabel: null, tags: ['Langes Haar'] },
  { id: 'customer-daria', displayName: 'Daria Meier', phoneLabel: '079 513 10 64', emailLabel: null, tags: [] }
]);

const appointment = (value) => ({ kind: 'appointment', date: REFERENCE_DATE, ...value });

export const referenceAppointments = deepFreeze([
  appointment({ id: 'a1', startMinute: 510, durationMinutes: 90, customerId: 'customer-mia', serviceId: 'schnitt-foehnen', staffId: 'melanie', status: 'completed', note: 'Feines Haar, kinnlanger Bob', price: 118 }),
  appointment({ id: 'a6', startMinute: 630, durationMinutes: 90, customerId: 'customer-anna', serviceId: 'schnitt-foehnen', staffId: 'melanie', status: 'arrived', note: 'Termin vorziehen, falls möglich', price: 118, visitStep: 2 }),
  appointment({ id: 'short2', startMinute: 725, durationMinutes: 15, customerId: 'customer-mia', serviceId: 'pony', staffId: 'melanie', status: 'pending', note: 'Kurzer Termin', price: 28 }),
  appointment({ id: 'a11', startMinute: 780, durationMinutes: 105, customerId: 'customer-celine', serviceId: 'balayage', staffId: 'melanie', status: 'confirmed', note: 'Lange Haare', price: 238 }),
  appointment({ id: 'm2', startMinute: 900, durationMinutes: 75, customerId: 'customer-daria', serviceId: 'schnitt-foehnen', staffId: 'melanie', status: 'confirmed', note: 'Volumen am Oberkopf', price: 118 }),
  appointment({ id: 'a7', startMinute: 600, durationMinutes: 90, customerId: 'customer-julia', serviceId: 'farbe-pflege', staffId: 'sofia', status: 'arrived', note: 'Farbrezeptur 7.1 / 7.13', price: 172, visitStep: 1 }),
  appointment({ id: 's2', startMinute: 855, durationMinutes: 105, customerId: 'customer-anna', serviceId: 'farbe-pflege', staffId: 'sofia', status: 'confirmed', note: 'Ansatz und Längenausgleich', price: 172 }),
  appointment({ id: 'a8', startMinute: 615, durationMinutes: 90, customerId: 'customer-chiara', serviceId: 'farbe-pflege', staffId: 'lea', status: 'arrived', note: 'Kopfhaut empfindlich', price: 160, visitStep: 2 }),
  appointment({ id: 'l2', startMinute: 840, durationMinutes: 150, customerId: 'customer-celine', serviceId: 'balayage', staffId: 'lea', status: 'confirmed', note: 'Helles Beige, weich verblenden', price: 248 }),
  appointment({ id: 'a9', startMinute: 660, durationMinutes: 90, customerId: 'customer-vanessa', serviceId: 'farbe-pflege', staffId: 'nina', status: 'arrived', note: 'Glossing nach Einwirkzeit', price: 160, visitStep: 1 }),
  appointment({ id: 'n2', startMinute: 840, durationMinutes: 60, customerId: 'customer-mia', serviceId: 'schnitt', staffId: 'nina', status: 'confirmed', note: 'Fransen und Kontur', price: 86 }),
  appointment({ id: 'a10', startMinute: 660, durationMinutes: 90, customerId: 'customer-corinne', serviceId: 'farbe-pflege', staffId: 'jasmin', status: 'arrived', note: 'Kontakt nur per SMS', price: 168, visitStep: 1 }),
  appointment({ id: 'j2', startMinute: 780, durationMinutes: 75, customerId: 'customer-daria', serviceId: 'schnitt', staffId: 'jasmin', status: 'pending', note: 'Bartkontur ergänzen', price: 94 })
]);

export const referenceOperationalBlocks = deepFreeze([
  { id: 'block-melanie-task', kind: 'task', date: REFERENCE_DATE, startMinute: 745, durationMinutes: 30, staffId: 'melanie', label: 'Farbrezepturen vorbereiten', note: 'Mischungen für den Nachmittag' },
  { id: 'block-sofia-break', kind: 'break', date: REFERENCE_DATE, startMinute: 795, durationMinutes: 30, staffId: 'sofia', label: 'Pause', note: null },
  { id: 'block-nina-task', kind: 'task', date: REFERENCE_DATE, startMinute: 780, durationMinutes: 30, staffId: 'nina', label: 'Bestellung prüfen', note: null }
]);

export const stressAppointments = deepFreeze(Array.from({ length: 18 }, (_, index) => appointment({
  id: `stress-${index + 1}`,
  startMinute: 480 + (index % 9) * 45,
  durationMinutes: index % 3 === 0 ? 90 : 45,
  customerId: referenceCustomers[index % referenceCustomers.length].id,
  serviceId: referenceServices[index % referenceServices.length].id,
  staffId: referenceStaff[index % referenceStaff.length].id,
  status: index % 5 === 0 ? 'pending' : 'confirmed',
  note: null,
  price: referenceServices[index % referenceServices.length].price
})));

export const referenceOnboardingState = deepFreeze({
  scope: { salonId: 'salon-sonnegg', locationId: 'location-enge' },
  currentStepId: 'startklar',
  steps: [
    { id: 'salonprofil', label: 'Salonprofil', state: 'complete', canEnter: true, canSkip: false, blockingReasons: [] },
    { id: 'dienstleistungen', label: 'Dienstleistungen', state: 'complete', canEnter: true, canSkip: false, blockingReasons: [] },
    { id: 'team', label: 'Team', state: 'complete', canEnter: true, canSkip: false, blockingReasons: [] },
    { id: 'arbeitszeiten', label: 'Arbeitszeiten', state: 'complete', canEnter: true, canSkip: false, blockingReasons: [] },
    { id: 'startklar', label: 'Startklar', state: 'complete', canEnter: true, canSkip: false, blockingReasons: [] }
  ],
  salonProfile: { name: 'Coiffure Sonnegg', locationLabel: 'Zürich Enge' },
  servicesSummary: { count: referenceServices.length, completeCount: referenceServices.length },
  staffSummary: { count: referenceStaff.length, completeCount: referenceStaff.length },
  workingHoursSummary: { completeCount: referenceStaff.length, attentionCount: 0 },
  readiness: { isBookable: true, blockers: [], warnings: [] }
});

export const referenceAdministrationSettings = deepFreeze({
  sections: [
    { sectionId: 'salon-profile', title: 'Salonprofil', description: 'Adresse, Kontakt und rechtliche Angaben.', state: 'complete', requiredCapability: 'administration:manage-salon' },
    { sectionId: 'brand', title: 'Marke', description: 'Logo und salonbezogene Akzente.', state: 'complete', requiredCapability: 'administration:manage-salon' },
    { sectionId: 'locations', title: 'Standorte', description: 'Zürich Enge und künftige Filialen.', state: 'complete', requiredCapability: 'administration:manage-salon' },
    { sectionId: 'integrations', title: 'Integrationen', description: 'Kalender, Kommunikation und verbundene Dienste.', state: 'attention', requiredCapability: 'administration:view' },
    { sectionId: 'access', title: 'Rollen & Zugriff', description: 'Produktrollen und Capabilities.', state: 'incomplete', requiredCapability: 'administration:manage-access' },
    { sectionId: 'billing', title: 'Plan & Abrechnung', description: 'Vertrags- und Rechnungsangaben.', state: 'unavailable', requiredCapability: 'administration:view-billing' },
    { sectionId: 'product-preferences', title: 'Darstellung & App', description: 'Theme und Installation.', state: 'complete', requiredCapability: 'administration:view' }
  ],
  productPreferences: { themeMode: 'system', installAvailable: false, standaloneState: 'browser' }
});
