import { existsSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const root = process.cwd();
const outputDirectory = resolve(root, 'artifacts/tagesplan-two-period');
const port = 4174;
const url = `http://127.0.0.1:${port}/experiments/tagesplan-two-period/?referenceNow=11:22`;
const errors = [];

function findChrome() {
  const candidates = [
    process.env.CHROME_BIN,
    'google-chrome',
    'google-chrome-stable',
    'chromium',
    'chromium-browser'
  ].filter(Boolean);

  for (const candidate of candidates) {
    const probe = spawnSync('bash', ['-lc', `command -v ${candidate}`], { encoding: 'utf8' });
    if (probe.status === 0 && probe.stdout.trim()) return probe.stdout.trim();
  }
  return null;
}

function chromeRun(chrome, args) {
  return spawnSync(chrome, [
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--disable-dev-shm-usage',
    '--hide-scrollbars',
    '--run-all-compositor-stages-before-draw',
    '--virtual-time-budget=3500',
    ...args
  ], {
    cwd: root,
    encoding: 'utf8',
    maxBuffer: 20 * 1024 * 1024
  });
}

async function waitForServer() {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {
      // Server is still starting.
    }
    await delay(125);
  }
  throw new Error(`Lokaler Referenzserver antwortet nicht auf ${url}`);
}

rmSync(outputDirectory, { recursive: true, force: true });
mkdirSync(outputDirectory, { recursive: true });

const server = spawn('python3', ['-m', 'http.server', String(port), '--bind', '127.0.0.1'], {
  cwd: root,
  stdio: ['ignore', 'pipe', 'pipe']
});

try {
  await waitForServer();
  const chrome = findChrome();
  if (!chrome) throw new Error('Kein Chrome-/Chromium-Binary für Browserprüfung gefunden');

  const domResult = chromeRun(chrome, ['--window-size=1512,982', '--dump-dom', url]);
  if (domResult.status !== 0) {
    errors.push(`Chrome DOM-Prüfung fehlgeschlagen:\n${domResult.stderr.trim()}`);
  } else {
    const dom = domResult.stdout;
    writeFileSync(resolve(outputDirectory, 'rendered-dom.html'), dom);
    const assertions = [
      ['split-desktop-board', 'vollständige Desktop-Tageslandkarte'],
      ['Vormittag', 'Vormittagsperiode'],
      ['Nachmittag', 'Nachmittagsperiode'],
      ['split-period-divider', 'visuelle Periodengrenze'],
      ['split-now-cursor', 'Jetzt-Cursor'],
      ['11:22', 'kontrollierte Referenzzeit'],
      ['gw-work-clock', 'feste Arbeitsuhr'],
      ['Salonzeit', 'digitale Uhrbeschriftung'],
      ['data-focus-staff="melanie"', 'Personenfokus-Auslöser'],
      ['data-appointment-id=', 'Mock-Termine']
    ];
    for (const [term, label] of assertions) {
      if (!dom.includes(term)) errors.push(`Gerenderter DOM enthält nicht: ${label}`);
    }
  }

  const viewports = [
    ['1366x768', 1366, 768],
    ['1512x982', 1512, 982],
    ['1920x1080', 1920, 1080],
    ['390x844', 390, 844],
    ['844x390', 844, 390]
  ];

  for (const [name, width, height] of viewports) {
    const target = resolve(outputDirectory, `tagesplan-two-period-${name}.png`);
    const result = chromeRun(chrome, [`--window-size=${width},${height}`, `--screenshot=${target}`, url]);
    if (result.status !== 0 || !existsSync(target)) {
      errors.push(`Screenshot ${name} konnte nicht erzeugt werden:\n${result.stderr.trim()}`);
    } else {
      console.log(`✓ Screenshot ${name}`);
    }
  }
} catch (error) {
  errors.push(error.message);
} finally {
  server.kill('SIGTERM');
}

if (errors.length) {
  console.error(`\nBrowserprüfung fehlgeschlagen (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`\n✓ Zweiperioden-Tageslandkarte im echten Browser gerendert: ${url}`);
