import { mkdirSync, readFileSync, realpathSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, extname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import {
  assertAutonomousDocument,
  assertAutonomyPolicySelfTest,
  assertEmbeddedCssResources
} from './tagesplan-v1-autonomy.mjs';

const root = process.cwd();
const realRoot = realpathSync(root);
const output = resolve(root, 'references/tagesplan/v1.0/tagesplan-reference.html');
const outputTemporary = join(dirname(output), `.tagesplan-reference.${process.pid}.tmp`);
const version = '1.0.0';

// Preserve the experiment order while intentionally excluding its optional experience layer.
const cssFiles = [
  'src/styles/dashboard-shell-v1.css',
  'src/styles/dashboard-shell-v2.css',
  'experiments/tagesplan-vertical-agenda/page.css',
  'experiments/tagesplan-vertical-agenda/polish.css',
  'experiments/tagesplan-vertical-agenda/header-agenda.css',
  'experiments/tagesplan-vertical-agenda/precision-01.css',
  'experiments/tagesplan-vertical-agenda/precision-02.css',
  'experiments/tagesplan-vertical-agenda/surface-v1.css'
];

// Classic scripts run before the deferred module entrypoints on the experiment page.
const controllerFiles = [
  'experiments/tagesplan-vertical-agenda/time-surface-v1.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-01.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-02.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-03.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-04.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-05.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-06.js',
  'experiments/tagesplan-vertical-agenda/surface-v1.js'
];

const moduleEntrypoints = [
  'experiments/tagesplan-vertical-agenda/page.js',
  'experiments/tagesplan-vertical-agenda/header-agenda.js'
];

function normalizeLf(value) {
  return value.replace(/\r\n?/g, '\n');
}

function read(path) {
  return normalizeLf(readFileSync(resolve(root, path), 'utf8'));
}

function displayPath(path) {
  const relativePath = relative(realRoot, path);
  return (relativePath || '.').split(sep).join('/');
}

function isWithinRepository(path) {
  const relativePath = relative(realRoot, path);
  return relativePath === ''
    || (relativePath !== '..' && !relativePath.startsWith(`..${sep}`) && !isAbsolute(relativePath));
}

function canonicalCssFile(candidate, importedBy) {
  const resolved = resolve(candidate);
  if (!isWithinRepository(resolved)) {
    throw new Error(`CSS-Import verlässt das Repository (${importedBy}): ${resolved}`);
  }

  let canonical;
  try {
    canonical = realpathSync(resolved);
  } catch (error) {
    throw new Error(`CSS-Datei fehlt oder ist nicht lesbar (${importedBy}): ${resolved}\n${error.message}`);
  }

  if (!isWithinRepository(canonical)) {
    throw new Error(`CSS-Import verlässt das Repository über einen Link (${importedBy}): ${resolved}`);
  }
  if (extname(canonical).toLowerCase() !== '.css' || !statSync(canonical).isFile()) {
    throw new Error(`CSS-Import ist keine lokale CSS-Datei (${importedBy}): ${resolved}`);
  }
  return canonical;
}

function resolveCssImport(specifier, importer) {
  const importerLabel = displayPath(importer);
  if (!specifier || specifier !== specifier.trim() || /[\\\0\r\n]/.test(specifier)) {
    throw new Error(`CSS-Import enthält einen ungültigen oder mehrdeutigen Pfad (${importerLabel}): ${JSON.stringify(specifier)}`);
  }
  if (/^[a-z][a-z\d+.-]*:/i.test(specifier) || specifier.startsWith('//') || isAbsolute(specifier)) {
    throw new Error(`Externer oder absoluter CSS-Import ist verboten (${importerLabel}): ${specifier}`);
  }
  if (/[?#%]/.test(specifier)) {
    throw new Error(`CSS-Import mit Query, Fragment oder Kodierung ist nicht reproduzierbar (${importerLabel}): ${specifier}`);
  }
  return canonicalCssFile(resolve(dirname(importer), specifier), importerLabel);
}

function inlineCssFile(candidate, ancestry = []) {
  const canonical = canonicalCssFile(candidate, ancestry.length ? displayPath(ancestry.at(-1)) : 'CSS-Einstieg');
  const cycleIndex = ancestry.indexOf(canonical);
  if (cycleIndex >= 0) {
    const cycle = [...ancestry.slice(cycleIndex), canonical].map(displayPath).join(' -> ');
    throw new Error(`Zyklischer CSS-Import ist verboten: ${cycle}`);
  }

  const source = normalizeLf(readFileSync(canonical, 'utf8'));
  const importPattern = /^[\t ]*@import\s+(?:url\(\s*(?:"([^"\r\n]*)"|'([^'\r\n]*)'|([^'")\s]+))\s*\)|"([^"\r\n]*)"|'([^'\r\n]*)')\s*;[\t ]*(?:\n|$)/gimu;
  const nextAncestry = [...ancestry, canonical];
  let cursor = 0;
  let inlined = '';

  for (const match of source.matchAll(importPattern)) {
    const specifier = match.slice(1, 6).find((value) => value !== undefined);
    const imported = resolveCssImport(specifier, canonical);
    const importedLabel = displayPath(imported);
    inlined += source.slice(cursor, match.index);
    inlined += `/* inlined: ${importedLabel} */\n${inlineCssFile(imported, nextAncestry)}\n/* end inlined: ${importedLabel} */\n`;
    cursor = match.index + match[0].length;
  }
  inlined += source.slice(cursor);

  if (/@import\b/i.test(inlined)) {
    throw new Error(`CSS-Datei enthält einen nicht unterstützten oder nicht eingebetteten @import: ${displayPath(canonical)}`);
  }
  return inlined;
}

function assertSource(path) {
  try {
    readFileSync(resolve(root, path));
  } catch (error) {
    throw new Error(`Tagesplan-v1-Quelle fehlt: ${path}\n${error.message}`);
  }
}

function sourceDate() {
  const value = process.env.SOURCE_DATE_EPOCH;
  if (!/^\d+$/.test(value ?? '')) {
    throw new Error('SOURCE_DATE_EPOCH muss als nicht-negative Anzahl Unix-Sekunden gesetzt sein.');
  }

  const milliseconds = Number(value) * 1000;
  const date = new Date(milliseconds);
  if (!Number.isSafeInteger(milliseconds) || Number.isNaN(date.getTime())) {
    throw new Error(`SOURCE_DATE_EPOCH ist ausserhalb des unterstützten Bereichs: ${value}`);
  }
  return date;
}

async function loadEsbuild() {
  try {
    const module = await import('esbuild');
    if (typeof module.build !== 'function') throw new TypeError('esbuild.build ist nicht verfügbar.');
    return module.build;
  } catch (error) {
    throw new Error(
      `Die lokal gepinnte esbuild-Abhängigkeit fehlt oder ist ungültig. Zuerst npm ci ausführen.\n${error.message}`
    );
  }
}

assertAutonomyPolicySelfTest();
[...cssFiles, ...controllerFiles, ...moduleEntrypoints].forEach(assertSource);
const sourceEpoch = sourceDate();

const entrySource = moduleEntrypoints
  .map((path) => `import ${JSON.stringify(`./${path}`)};`)
  .join('\n');

const build = await loadEsbuild();
let result;
try {
  result = await build({
    stdin: {
      contents: entrySource,
      loader: 'js',
      resolveDir: root,
      sourcefile: 'tagesplan-v1-core-entry.mjs'
    },
    bundle: true,
    write: false,
    format: 'iife',
    platform: 'browser',
    target: ['es2020'],
    charset: 'utf8',
    legalComments: 'none',
    logLevel: 'silent'
  });
} catch (error) {
  throw new Error(`Esbuild konnte den Tagesplan-v1-Core nicht bündeln.\n${error.message}`);
}

if (result.outputFiles.length !== 1) {
  throw new Error(`Esbuild lieferte ${result.outputFiles.length} statt genau einer JavaScript-Ausgabedatei.`);
}

const css = cssFiles
  .map((path) => `/* ${path} */\n${inlineCssFile(resolve(realRoot, path))}`)
  .join('\n\n');
assertEmbeddedCssResources(css, 'Eingebetteter Tagesplan-Core-CSS');
const controllers = controllerFiles
  .map((path) => `/* ${path} */\n${read(path)}`)
  .join('\n\n');
const bundle = normalizeLf(result.outputFiles[0].text);
const script = `${controllers}\n\n/* bundled module entrypoints */\n${bundle}`.replaceAll('</script>', '<\\/script>');

const html = normalizeLf(`<!doctype html>
<html lang="de-CH" data-gw-reference="tagesplan-v1" data-gw-core-path="surface-v1" data-gw-beseelung="disabled">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="color-scheme" content="light">
  <meta name="theme-color" content="#0d4b3e">
  <meta name="gw-reference-version" content="${version}">

  <title>Gasserwerk · Tagesplan v1.0 Core</title>
  <style>${css}</style>
</head>
<body data-gw-page="tagesplan" data-gw-state="normal" data-gw-density="compact" data-gw-beseelung="disabled">
  <div id="dashboard-root" data-gw-core-path="surface-v1" data-gw-beseelung="disabled"></div>
  <script>${script}</script>
</body>
</html>
`);

assertAutonomousDocument(html, 'Erzeugter Tagesplan-v1-Core');

const forbidden = [
  /\r/,
  /<link\b[^>]*\bhref=/i,
  /<script\b[^>]*\bsrc=/i,
  /@import\b/i,
  /\bimport\s+(?:[^('";]+\s+from\s+)?["']/,
  /\.\.\/\.\.\/(?:assets|src|pages)\//,
  /experience\.css/i,
  /--gw-experience-/i,
  /tagesplan-v1\.(?:css|js)/i,
  /tp-v1-(?:service-icon|empty-habitat)/i,
  /kantenblick/i
];
for (const pattern of forbidden) {
  if (pattern.test(html)) {
    throw new Error(`Tagesplan-Core enthält eine verbotene Laufzeit-, Wirkungs- oder Legacy-Abhängigkeit: ${pattern}`);
  }
}

mkdirSync(dirname(output), { recursive: true });
rmSync(outputTemporary, { force: true });
try {
  writeFileSync(outputTemporary, html, { encoding: 'utf8', flag: 'wx' });
  renameSync(outputTemporary, output);
} finally {
  rmSync(outputTemporary, { force: true });
}

console.log(`✓ ${relative(root, output)} deterministisch erzeugt (${Math.round(Buffer.byteLength(html) / 1024)} KiB; SOURCE_DATE_EPOCH ${Math.floor(sourceEpoch.getTime() / 1000)} validiert).`);
