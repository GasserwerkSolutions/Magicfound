# Gasserwerk · GitHub Pages robust

Diese Fassung ist für GitHub Pages Projektseiten wie
`https://gasserwerksolutions.github.io/dashboard/` gebaut.

Die eigentliche Anwendung (HTML, CSS, JavaScript und alpine Bildassets) liegt vollständig in `index.html`. Dadurch kann die UI nicht mehr durch fehlende fingerprintete JS/CSS-Dateien leer bleiben. Manifest, Service Worker und App-Icons bleiben separat, damit die PWA installierbar bleibt.

## Veröffentlichung
Den Inhalt dieses Ordners ins Root des `dashboard`-Repositories legen und GitHub Pages aus `main` / Root veröffentlichen.

## Nach Austausch einer bereits installierten/besuchten Fassung
Einmal hart neu laden (`Strg+Shift+R`). Falls ein alter Service Worker aus einem früheren fehlerhaften Build kontrolliert: DevTools → Application → Service Workers → Unregister, danach neu laden. Der neue Service Worker verwendet eine neue Build-ID und räumt alte `gasserwerk-*`-Caches beim Aktivieren auf.
