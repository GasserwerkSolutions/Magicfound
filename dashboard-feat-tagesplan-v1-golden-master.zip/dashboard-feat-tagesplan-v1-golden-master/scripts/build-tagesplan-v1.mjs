import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, relative, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const sourceDirectory = resolve(root, 'experiments/tagesplan-vertical-agenda');
const output = resolve(root, 'references/tagesplan/v1.0/tagesplan-reference.html');
const version = '1.0.0';

const cssFiles = [
  'src/styles/dashboard-shell-v1.css',
  'src/styles/dashboard-shell-v2.css',
  'experiments/tagesplan-vertical-agenda/page.css',
  'experiments/tagesplan-vertical-agenda/polish.css',
  'experiments/tagesplan-vertical-agenda/header-agenda.css',
  'experiments/tagesplan-vertical-agenda/precision-01.css',
  'experiments/tagesplan-vertical-agenda/precision-02.css',
  'src/styles/experience.css',
  'experiments/tagesplan-vertical-agenda/tagesplan-v1.css'
];

const controllerFiles = [
  'experiments/tagesplan-vertical-agenda/precision-controller-01.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-02.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-03.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-04.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-05.js',
  'experiments/tagesplan-vertical-agenda/precision-controller-06.js',
  'experiments/tagesplan-vertical-agenda/tagesplan-v1.js'
];

const moduleEntrypoints = [
  './experiments/tagesplan-vertical-agenda/page.js',
  './experiments/tagesplan-vertical-agenda/reference-clock-sync.js',
  './experiments/tagesplan-vertical-agenda/header-agenda.js'
];

function read(path) {
  return readFileSync(resolve(root, path), 'utf8');
}

function assertSource(path) {
  try {
    readFileSync(resolve(root, path));
  } catch (error) {
    throw new Error(`Tagesplan-v1-Quelle fehlt: ${path}\n${error.message}`);
  }
}

[...cssFiles, ...controllerFiles, ...moduleEntrypoints.map((value) => value.slice(2))].forEach(assertSource);

const temp = mkdtempSync(join(tmpdir(), 'gasserwerk-tagesplan-v1-'));
const entry = resolve(temp, 'entry.mjs');
const bundlePath = resolve(temp, 'bundle.js');
const alpinePath = resolve(root, 'assets/alpine/kantenblick.8375fcb60e.webp');
assertSource('assets/alpine/kantenblick.8375fcb60e.webp');

const entrySource = moduleEntrypoints
  .map((path) => `import ${JSON.stringify(resolve(root, path.slice(2)))};`)
  .join('\n');
writeFileSync(entry, entrySource);

const esbuild = spawnSync(
  process.platform === 'win32' ? 'npx.cmd' : 'npx',
  [
    '--yes',
    'esbuild@0.25.9',
    entry,
    '--bundle',
    '--format=iife',
    '--platform=browser',
    '--target=es2020',
    '--charset=utf8',
    '--legal-comments=none',
    `--outfile=${bundlePath}`
  ],
  { cwd: root, encoding: 'utf8', maxBuffer: 40 * 1024 * 1024 }
);

if (esbuild.status !== 0) {
  rmSync(temp, { recursive: true, force: true });
  throw new Error(`Esbuild konnte den Tagesplan nicht bündeln.\n${esbuild.stdout}\n${esbuild.stderr}`);
}

const css = cssFiles
  .map((path) => `/* ${path} */\n${read(path)}`)
  .join('\n\n');

const alpineDataUri = `data:image/webp;base64,${readFileSync(alpinePath).toString('base64')}`;
const controllers = controllerFiles
  .map((path) => `/* ${path} */\n${read(path)}`)
  .join('\n\n')
  .replaceAll('../../assets/alpine/kantenblick.8375fcb60e.webp', alpineDataUri);

const bundle = readFileSync(bundlePath, 'utf8');
const script = `${bundle}\n\n${controllers}`.replaceAll('</script>', '<\\/script>');
const generatedAt = new Date().toISOString();

const html = `<!doctype html>
<html lang="de-CH" data-gw-reference="tagesplan-v1">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="color-scheme" content="light">
  <meta name="theme-color" content="#0d4b3e">
  <meta name="gw-reference-version" content="${version}">
  <meta name="gw-generated-at" content="${generatedAt}">
  <title>Gasserwerk · Tagesplan v1.0 Golden Master</title>
  <style>${css}</style>
</head>
<body data-gw-page="tagesplan" data-gw-state="normal" data-gw-density="standard">
  <div id="dashboard-root"></div>
  <script>${script}</script>
</body>
</html>
`;

mkdirSync(dirname(output), { recursive: true });
writeFileSync(output, html);
rmSync(temp, { recursive: true, force: true });

const forbidden = [
  /<link\b[^>]*\bhref=/i,
  /<script\b[^>]*\bsrc=/i,
  /\bimport\s+(?:[^('";]+\s+from\s+)?["']/,
  /\.\.\/\.\.\/assets\//,
  /\.\.\/\.\.\/src\//
];
for (const pattern of forbidden) {
  if (pattern.test(html)) throw new Error(`Golden Master enthält eine externe Laufzeitabhängigkeit: ${pattern}`);
}

console.log(`✓ ${relative(root, output)} erzeugt (${Math.round(Buffer.byteLength(html) / 1024)} KiB).`);
