import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import {
  addDays,
  formatIsoDate,
  parseIsoDate,
  todayInTimeZone
} from '../src/lib/dates.js';
import {
  formatMinuteOfDay,
  minutesInTimeZone,
  parseTimeString,
  returnDirection,
  snapMinute,
  visibleWindowForAnchor
} from '../src/lib/time.js';
import {
  PAGE_DEFINITIONS,
  PageId,
  assertPageCatalog,
  buildReferencePath,
  getPrimaryNavigationPages
} from '../src/shell/page-catalog.js';
import {
  createAppShell,
  createMobileNavigation,
  createProductHeader,
  createSidebar
} from '../src/shell/index.js';
import {
  createButton,
  createContextPanel,
  createDatePicker,
  createEmptyState,
  createSearchSurface,
  createStatusChip
} from '../src/components/index.js';
import { dispatchDashboardEvent } from '../src/lib/dashboard-events.js';
import { createFocusScope, getFocusableElements, trapTabKey } from '../src/lib/focus.js';

const root = process.cwd();
const errors = [];
const notes = [];

function assert(condition, message) {
  if (!condition) errors.push(message);
}

function read(path) {
  const absolute = resolve(root, path);
  if (!existsSync(absolute)) {
    errors.push(`Fehlende Moduldatei: ${path}`);
    return '';
  }
  return readFileSync(absolute, 'utf8');
}

const requiredFiles = [
  'src/styles/tokens.css',
  'src/styles/reset.css',
  'src/styles/density.css',
  'src/styles/shell.css',
  'src/styles/components.css',
  'src/styles/controls.css',
  'src/styles/overlays.css',
  'src/styles/date-picker.css',
  'src/styles/index.css',
  'src/lib/time.js',
  'src/lib/dates.js',
  'src/lib/dom.js',
  'src/lib/focus.js',
  'src/lib/dashboard-events.js',
  'src/shell/page-catalog.js',
  'src/shell/icons.js',
  'src/shell/sidebar.js',
  'src/shell/mobile-navigation.js',
  'src/shell/product-header.js',
  'src/shell/app-shell.js',
  'src/shell/index.js',
  'src/components/button.js',
  'src/components/search-surface.js',
  'src/components/date-picker.js',
  'src/components/context-panel.js',
  'src/components/status-chip.js',
  'src/components/empty-state.js',
  'src/components/index.js'
];

for (const path of requiredFiles) read(path);

assert(assertPageCatalog(), 'Seitenkatalog ist ungültig');
assert(PAGE_DEFINITIONS.length === 8, `Seitenkatalog: erwartet 8 Seiten, gefunden ${PAGE_DEFINITIONS.length}`);
assert(!PAGE_DEFINITIONS.some((page) => page.id === 'today' || page.pathSegment === 'heute'), 'Seitenkatalog: Heute darf keine Seite sein');

const primaryPages = getPrimaryNavigationPages();
assert(primaryPages.length === 6, `Primärnavigation: erwartet 6 Ziele, gefunden ${primaryPages.length}`);
assert(primaryPages[0]?.id === PageId.DAY_PLAN, 'Primärnavigation: Tagesplan muss das erste Ziel sein');
assert(buildReferencePath(PageId.DAY_PLAN) === '/dashboard/pages/tagesplan/', 'Referenzpfad des Tagesplans ist falsch');

assert(parseTimeString('11:22') === 682, 'Zeitparser: 11:22 muss 682 Minuten ergeben');
assert(formatMinuteOfDay(682) === '11:22', 'Zeitformatierung: 682 Minuten muss 11:22 ergeben');
assert(snapMinute(682, { step: 15 }) === 675, '15-Minuten-Snap ist falsch');
assert(returnDirection(682, 700, 820) === 'left', 'Jetzt-Richtung links ist falsch');
assert(returnDirection(682, 540, 660) === 'right', 'Jetzt-Richtung rechts ist falsch');
assert(returnDirection(682, 600, 720) === 'visible', 'Jetzt-Sichtbarkeit ist falsch');

const liveWindow = visibleWindowForAnchor({
  currentMinute: 682,
  dayStartMinute: 480,
  dayEndMinute: 1080,
  windowMinutes: 120,
  anchorRatio: 0.2
});
assert(liveWindow.startMinute === 658, `Live-Fenster: erwarteter Start 658, gefunden ${liveWindow.startMinute}`);
assert(Math.abs(liveWindow.anchorRatio - 0.2) < 0.0001, 'Live-Fenster: Anker liegt nicht bei 20 %');

assert(formatIsoDate(parseIsoDate('2026-08-20')) === '2026-08-20', 'ISO-Datum Roundtrip ist falsch');
assert(addDays('2026-08-20', 1) === '2026-08-21', 'Datumsaddition ist falsch');
const referenceInstant = new Date('2026-08-20T09:22:00.000Z');
assert(todayInTimeZone('Europe/Zurich', referenceInstant) === '2026-08-20', 'Salon-Datum in Europe/Zurich ist falsch');
assert(minutesInTimeZone(referenceInstant, 'Europe/Zurich') === 682, 'Salon-Zeit in Europe/Zurich ist falsch');

for (const [name, value] of Object.entries({
  createAppShell,
  createSidebar,
  createMobileNavigation,
  createProductHeader,
  createButton,
  createSearchSurface,
  createDatePicker,
  createContextPanel,
  createStatusChip,
  createEmptyState,
  dispatchDashboardEvent,
  createFocusScope,
  getFocusableElements,
  trapTabKey
})) {
  assert(typeof value === 'function', `Gemeinsames Modul exportiert keine Funktion: ${name}`);
}

const foundationCss = [
  read('src/styles/tokens.css'),
  read('src/styles/reset.css'),
  read('src/styles/density.css'),
  read('src/styles/shell.css'),
  read('src/styles/components.css'),
  read('src/styles/controls.css'),
  read('src/styles/overlays.css'),
  read('src/styles/date-picker.css')
].join('\n');

for (const token of [
  '--gw-surface-frame',
  '--gw-text-primary',
  '--gw-status-confirmed-accent',
  '--gw-temporal-now',
  '--gw-layout-sidebar-width',
  '--gw-calendar-staff-rail'
]) {
  assert(foundationCss.includes(token), `CSS-Grundlage: Token fehlt: ${token}`);
}

for (const selector of [
  '.gw-app-shell',
  '.gw-sidebar',
  '.gw-product-header',
  '.gw-mobile-navigation',
  '.gw-search-surface',
  '.gw-context-panel',
  '.gw-date-picker',
  '.gw-status-chip'
]) {
  assert(foundationCss.includes(selector), `CSS-Grundlage: gemeinsamer Selektor fehlt: ${selector}`);
}

const styleIndex = read('src/styles/index.css');
for (const importPath of [
  './tokens.css',
  './reset.css',
  './density.css',
  './shell.css',
  './components.css',
  './controls.css',
  './overlays.css',
  './date-picker.css'
]) {
  assert(styleIndex.includes(importPath), `Style-Index importiert nicht: ${importPath}`);
}

assert(!/\bzoom\s*:/i.test(foundationCss), 'CSS-Grundlage darf nicht über zoom verdichten');
assert(!/transform\s*:\s*scale\s*\(/i.test(foundationCss), 'CSS-Grundlage darf nicht über transform: scale() verdichten');
assert(foundationCss.includes('@media (max-width: 1720px) and (max-height: 1050px) and (pointer: fine)'), '14-Zoll-Dichtebereich fehlt');
assert(foundationCss.includes('--gw-hit-target: 44px'), 'Sichere Touch-Trefferfläche fehlt');

notes.push(`Seitenkatalog: ${PAGE_DEFINITIONS.length} Seiten, ${primaryPages.length} Primärziele`);
notes.push(`Live-Zeit: ${formatMinuteOfDay(liveWindow.startMinute)}–${formatMinuteOfDay(liveWindow.endMinute)}, Anker ${(liveWindow.anchorRatio * 100).toFixed(0)} %`);
notes.push('Dichte: Standard, kompakter Desktop und Touch/Mobil definiert');
notes.push('Produktschale: Sidebar, Produktkopf, mobile Navigation und Overlay-Root exportiert');
notes.push('Komponenten: Suche, Datumsauswahl, Kontextpanel, Status und Leerzustand exportiert');

for (const note of notes) console.log(`✓ ${note}`);

if (errors.length) {
  console.error(`\nModulprüfung fehlgeschlagen (${errors.length}):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('\n✓ Gemeinsame Modulbasis und Komponenten sind konsistent.');
