# Stable UI-Identitäten und empirische Änderungsfolgen — V11

**Messbasis:** Original-HTML SHA-256 `8eab175bc8575c4755bf60093ee22e8d5c3d10dc3ec06182217ff8ee11b29936`; 13 Chromium-Browserzustände aus dem vorangegangenen Relationsgraph-Pilot. Vier davon wurden für gezielte Tokenmutationen erneut in Chromium geöffnet. Die HTML-Quelldatei wurde nicht verändert.

## A. Automatische Identitätserkennung

- 2,320 DOM-Beobachtungen über 13 Zustände.
- 365 Beobachtungen mit eindeutiger, expliziter DOM-ID oder `data-ui` (verbindliche DOM-Identität im Szenario); 1,955 mit lediglich vorläufiger Strukturzuordnung.
- **33 zustandsübergreifende Identitäten** mit überprüfter deklarierter Kennung, **455 Strukturpfad-Matches** (Kandidaten, nicht bestätigt).
- 0 automatisch erkannte Identitätskollisionen in dieser Stichprobe. Das bestätigt keine generelle Kollisionsfreiheit auf anderen Seiten.

*Wichtige Einschränkung:* Eine stabile DOM-ID ist nicht automatisch die kanonische Identität einer Fachkomponente oder eines Datensatzes. Die Produktimplementierung sollte `data-ui`, `data-instance-key`, `data-slot`, `data-state` mit nicht-personenbezogenen, langlebigen Instanzschlüsseln bereitstellen. Dynamische Positionsnummern sind als stabile Identitäten nicht zuverlässig.

## B. Interventionsmessung in vier Browseransichten

| CSS Token | Statische `var(...)`-Referenzen im HTML-CSS | Betroffene DOM-Vorkommen über 4 Zustände | Sichtbare DOM-Vorkommen | Elemente im Viewport | Geometriemutationen |
|---|---:|---:|---:|---:|---:|
| `--border` | 96 | 103 | 74 | 65 | 0 |
| `--brand` | 39 | 16 | 15 | 15 | 0 |
| `--radius` | 4 | 0 | 0 | 0 | 0 |
| `--surface` | 52 | 69 | 56 | 47 | 0 |

**Negativkontrolle:** Eine absichtlich nicht verwendete CSS-Variable führte bei allen vier Ansichten zu 0 beobachteten CSS- oder Geometrieänderungen. Alle 20 Interventionen einschliesslich Kontrollläufen meldeten **MEASURED**; Rücknahme aller Änderungen war im ausgewerteten Eigenschaftenset exakt. Bei `--radius` findet die statische CSS-Auswertung vier Verwendungen, die aktuellen vier Ansichten zeigen aber keine beobachtete Wirkung auf die erfassten BODY-Elemente. Damit ist die Trennung zwischen potenzieller und realisierter Abhängigkeit messbar.

**Keine vorgetäuschte Vertragsabdeckung:** Die bisherigen V11-Regeln betreffen überwiegend Geometrie und Semantik. Reine Farbänderungen treffen zwar häufig deren Selektoren, verändern aber keine geprüften geometrischen Eingaben. Daher weist die neue Analyse **0 direkt erneut auszuführende bisherige Geometrie-Oracles** nach. Daraus folgt nicht, dass Kontrast und Wahrnehmung bestanden wären: Es fehlen ausdrücklich eigene Text-/UI-Kontrast-Oracles im selben Änderungszustand sowie Dark-/Theme-Messungen.

## C. Bedeutung des Änderungsgraphen

1. `observed-intervention-affects-node` — die Browserintervention hat gemessene CSS-Eigenschaften dieses Elements geändert; empirisch belegt, für den jeweiligen Zustand.
2. `possible-context-review` — der betroffene Knoten hat einen Elterncontainer; mögliche Prüfumgebung, **keine festgestellte Änderung des Elterncontainers**.
3. `selectorIntersectionsNotNecessarilyRelevant` — ein bestehender Test spricht denselben Knoten an, möglicherweise aber eine nicht veränderte Eigenschaft.
4. `contractRecheckTargets` — nur dann erforderlich, wenn die Mutation eine Eingabe des Oracles verändert (z. B. Geometrie bei Achsenregeln oder Outline-Werte bei Fokusregeln).
5. `recommendedChecks` — Vorschläge für noch nicht ausgeführte Prüfungen, **keine bestandenen Tests**.

## D. Als Nächstes zwingend nötig

- **Explizite, nicht-personenbezogene Instanzkennungen** aus der echten Komponentenquelle statt Klassen-/Positions-Heuristik.
- **CSS-Provenienz bis zur angewendeten Regel** über Browser-Cascade/CDP; `getComputedStyle` liefert Werte, aber nicht die Quelle ihrer Ableitung.
- **Theme-, Hover-, Focus-, Overlay-, Zoom- und Geräte-Matrix** für jede benannte Komponentengruppe; derzeit nur vier Interventionen pro Token und wenige Ansichten.
- **Farbpaare, effektive Hintergründe, Kontraste und Wahrnehmungsprüfungen** bei farbverändernden Eingriffen.
- **Tatsächliche Re-Runs von betroffenem Funktions- und Visuallayout** vor jeder Freigabe; der Impact-Graph plant nur die Prüfung.

## E. Reproduzierbarkeit

`python scripts/stabile_identitaeten.py --measurement eingaben/browser-messung.json --output daten/identitaeten.json`

`python scripts/css_quellenkarte.py --html eingaben/v11-original.html --output daten/css-quellenkarte.json`

`python scripts/token_folgen_browser.py --html eingaben/v11-original.html --config config/mutations.json --output daten/token-mutationen.json`

`python scripts/folgen_graph.py --measurement eingaben/browser-messung.json --identities daten/identitaeten.json --mutations daten/token-mutationen.json --contract eingaben/relationsvertrag-v11.json --output daten/aenderungsfolgen-graph.json`

`python tests/test_relationssystem.py`

Voraussetzungen: Python 3, `tinycss2`, `playwright`, Chromium-Browser. Bei der Browserausführung nur **vertrauenswürdiges HTML**, da dessen JavaScript ausgeführt wird. Die für Tests verfügbaren Messungen sind Stichproben, keine vollständige Erfassung aller Interaktionen oder Produktionsdaten.
