const deepFreeze = (value) => {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  Object.freeze(value);
  Object.values(value).forEach(deepFreeze);
  return value;
};

export const ExperienceIntensity = deepFreeze({ NONE: 0, QUIET: 1, SUPPORTING: 2, DOMINANT: 3 });
export const ExperienceState = deepFreeze({ NORMAL: 'normal', LOADING: 'loading', EMPTY: 'empty', SUCCESS: 'success', ATTENTION: 'attention', ERROR: 'error', FORBIDDEN: 'forbidden', OFFLINE: 'offline', STALE: 'stale' });
export const ExperienceDensity = deepFreeze({ ROOMY: 'roomy', COMPACT: 'compact', DENSE: 'dense' });
export const ExperienceControlledAxis = deepFreeze({ SPACE_RHYTHM: 'space-rhythm', MATERIAL_DEPTH: 'material-depth', MOTION_TEMPO: 'motion-tempo', ATTENTION_STRENGTH: 'attention-strength', ILLUSTRATION_PRESENCE: 'illustration-presence' });
export const ExperienceForbiddenAxis = deepFreeze({ STATUS_COLOR: 'status-color', FOCUS_SEMANTICS: 'focus-semantics', SEARCH_SEMANTICS: 'search-semantics', DATA_MEANING: 'data-meaning', WARNING_SEVERITY: 'warning-severity' });

export const ExperienceTerm = deepFreeze({
  CALM: 'calm', TRUSTWORTHY: 'trustworthy', INVITING: 'inviting', ENSOULED: 'ensouled', SHELTERED: 'sheltered',
  GUIDED: 'guided', UNDERSTANDABLE: 'understandable', ENCOURAGING: 'encouraging', PROGRESSIVE: 'progressive', RELIABLE: 'reliable',
  PRESENT: 'present', BREATHING: 'breathing', FLOWING: 'flowing', ATTENTIVE: 'attentive', FINDABLE: 'findable', ORDERED: 'ordered',
  PRECISE: 'precise', PERSON_CENTERED: 'person-centered', FAMILIAR: 'familiar', DISCREET: 'discreet', WARM: 'warm', RESPECTFUL: 'respectful',
  HUMAN: 'human', APPRECIATIVE: 'appreciative', OVERVIEWABLE: 'overviewable', TOGETHER: 'together', CARED_FOR: 'cared-for',
  CRAFT_BASED: 'craft-based', VALUABLE: 'valuable', SOVEREIGN: 'sovereign', UNAMBIGUOUS: 'unambiguous', ROBUST: 'robust', CONSISTENT: 'consistent',
  STILL: 'still', EXPECTANT: 'expectant', HONEST: 'honest', SOLUTION_ORIENTED: 'solution-oriented', COMPLETED: 'completed'
});

const term = (id, intensity) => ({ id, intensity });

export const PRODUCT_EXPERIENCE_CONSTANTS = deepFreeze({
  terms: [term(ExperienceTerm.UNAMBIGUOUS, 2), term(ExperienceTerm.RELIABLE, 2), term(ExperienceTerm.CARED_FOR, 2), term(ExperienceTerm.CALM, 2), term(ExperienceTerm.WARM, 1)],
  description: 'Klar, verlässlich, gepflegt, ruhig, warm und eigenständig, ohne weichgespült oder exzentrisch zu werden.'
});

export const PAGE_EXPERIENCE_PROFILES = deepFreeze({
  login: {
    id: 'login', purpose: 'sicherer, kontrollierter Eintritt',
    primaryTerms: [term(ExperienceTerm.CALM, 3), term(ExperienceTerm.TRUSTWORTHY, 2), term(ExperienceTerm.INVITING, 2)],
    supportingTerms: [term(ExperienceTerm.ENSOULED, 1), term(ExperienceTerm.SHELTERED, 1)], antiTerms: ['spectacular', 'playful', 'mysterious'],
    density: ExperienceDensity.ROOMY, tempo: 'slow-calm', attentionAnchor: 'sign-in-card-and-primary-method',
    soulCarrier: 'product identity, calm materiality and a dosed alpine world', spatialEffect: 'clear centre with few competing elements',
    motion: 'slow and sparse, never between the user and the form', acceptance: 'Zuerst sieht man die sichere Anmeldung, danach entdeckt man die Welt des Produkts.',
    illustration: { normal: '30-40%' }
  },
  onboarding: {
    id: 'onboarding', purpose: 'einen Salon nachvollziehbar zu einem minimal buchbaren Zustand führen',
    primaryTerms: [term(ExperienceTerm.GUIDED, 3), term(ExperienceTerm.UNDERSTANDABLE, 2), term(ExperienceTerm.ENCOURAGING, 2)],
    supportingTerms: [term(ExperienceTerm.PROGRESSIVE, 2), term(ExperienceTerm.RELIABLE, 2)], antiTerms: ['lecturing', 'gamified', 'hectic'],
    density: ExperienceDensity.COMPACT, tempo: 'stepwise-calm', attentionAnchor: 'current-step-and-bookability-effect',
    soulCarrier: 'visible progress and friendly consequence language', spatialEffect: 'one step is present while completed and upcoming steps remain orienting',
    motion: 'the surface develops step by step from the same base surface', acceptance: 'Der Benutzer weiss stets, wo er ist, warum der Schritt nötig ist und was danach möglich wird.',
    illustration: { normal: '0-10%', success: '10-15%' }
  },
  tagesplan: {
    id: 'tagesplan', purpose: 'laufenden Salonbetrieb in Zeit, Personen und nächster Handlung erfassbar machen',
    primaryTerms: [term(ExperienceTerm.PRESENT, 3), term(ExperienceTerm.BREATHING, 2), term(ExperienceTerm.FLOWING, 2)],
    supportingTerms: [term(ExperienceTerm.ATTENTIVE, 2), term(ExperienceTerm.ENSOULED, 1)], antiTerms: ['decorative', 'nervous', 'dashboard-like'],
    density: ExperienceDensity.COMPACT, tempo: 'live-calm', attentionAnchor: 'current-time-or-user-viewport',
    soulCarrier: 'real salon time, people, services and the quiet operational sequence',
    spatialEffect: 'high density with a clean rhythm; time and people remain the governing geometry',
    motion: 'the full desktop day remains spatially stable; compact projections initially orient to now and then respect manual movement',
    acceptance: 'Innerhalb weniger Sekunden ist erkennbar, wer arbeitet, was jetzt läuft und was als Nächstes relevant ist.',
    illustration: { normal: '0-5%', empty: '15-22%', dayEnd: '20-25%' }
  },
  termine: {
    id: 'termine', purpose: 'einen Termin unabhängig von seiner räumlichen Position schnell finden und öffnen',
    primaryTerms: [term(ExperienceTerm.FINDABLE, 3), term(ExperienceTerm.ORDERED, 2), term(ExperienceTerm.RELIABLE, 2)],
    supportingTerms: [term(ExperienceTerm.PRECISE, 2), term(ExperienceTerm.CALM, 1)], antiTerms: ['second-timeline', 'table-cold', 'filter-carpet'],
    density: ExperienceDensity.COMPACT, tempo: 'direct-calm', attentionAnchor: 'search-active-filters-and-result-row',
    soulCarrier: 'people, service names and clear status language', spatialEffect: 'ordered density; filters support finding and do not become the main surface',
    motion: 'selection grows from the result row into the shared appointment context and returns exactly',
    acceptance: 'Ein konkreter Termin lässt sich ohne Kenntnis seines Tagesplans zuverlässig auffinden.', illustration: { normal: '0%' }
  },
  kundschaft: {
    id: 'kundschaft', purpose: 'eine Person finden, verstehen und aus ihrem Kontext sinnvoll weiterarbeiten',
    primaryTerms: [term(ExperienceTerm.PERSON_CENTERED, 3), term(ExperienceTerm.FAMILIAR, 2), term(ExperienceTerm.DISCREET, 2)],
    supportingTerms: [term(ExperienceTerm.WARM, 2), term(ExperienceTerm.RESPECTFUL, 2)], antiTerms: ['sales-driven', 'crm-cold', 'data-hungry'],
    density: ExperienceDensity.COMPACT, tempo: 'direct-warm', attentionAnchor: 'selected-person-and-current-salon-context',
    soulCarrier: 'name, relationship history, appointments and respectfully handled notes', spatialEffect: 'list and profile are two sides of the same anchored surface',
    motion: 'the profile unfolds from the list and closes back to search, scroll and focus',
    acceptance: 'Die Fläche vermittelt Nähe, ohne Privatsphäre oder fachliche Distanz zu verletzen.', illustration: { normal: '0-5%', empty: '5-10%' }
  },
  team: {
    id: 'team', purpose: 'Salonpersonen, fachliche Rollen und Verfügbarkeit verständlich machen',
    primaryTerms: [term(ExperienceTerm.HUMAN, 3), term(ExperienceTerm.APPRECIATIVE, 2), term(ExperienceTerm.OVERVIEWABLE, 2)],
    supportingTerms: [term(ExperienceTerm.TOGETHER, 1), term(ExperienceTerm.RELIABLE, 2)], antiTerms: ['ranking', 'performance-scoring', 'hr-bureaucracy'],
    density: ExperienceDensity.COMPACT, tempo: 'direct-calm', attentionAnchor: 'person-and-craft-role',
    soulCarrier: 'names, roles, work rhythm and shared craft responsibility', spatialEffect: 'people are equal, distinguishable units without value hierarchy',
    motion: 'detail and editing emerge from the person rather than a foreign admin world',
    acceptance: 'Das Team wirkt als menschlicher Teil des Salonbetriebs, nicht als Ressourcenliste.', illustration: { normal: '0-5%' }
  },
  angebot: {
    id: 'angebot', purpose: 'Dienstleistungen, Dauer, Preisstatus und Zuordnung verständlich überblicken',
    primaryTerms: [term(ExperienceTerm.UNDERSTANDABLE, 3), term(ExperienceTerm.CARED_FOR, 2), term(ExperienceTerm.CRAFT_BASED, 2)],
    supportingTerms: [term(ExperienceTerm.VALUABLE, 1), term(ExperienceTerm.INVITING, 1)], antiTerms: ['shop-like', 'luxury-overloaded', 'discount-driven'],
    density: ExperienceDensity.COMPACT, tempo: 'direct-calm', attentionAnchor: 'service-and-booking-parameters',
    soulCarrier: 'craft naming, cared-for typography, duration and staff assignment', spatialEffect: 'categories order the craft without imitating an online shop',
    motion: 'detail or editing unfolds from the service', acceptance: 'Das Angebot wirkt fachlich wertig und verständlich, nicht wie ein Verkaufskatalog.',
    illustration: { normal: '0-5%' }
  },
  verwaltung: {
    id: 'verwaltung', purpose: 'seltenere Salon-, Konto- und Systemeinstellungen sicher und gezielt zugänglich machen',
    primaryTerms: [term(ExperienceTerm.SOVEREIGN, 3), term(ExperienceTerm.UNAMBIGUOUS, 2), term(ExperienceTerm.ROBUST, 2)],
    supportingTerms: [term(ExperienceTerm.CALM, 2), term(ExperienceTerm.CONSISTENT, 2)], antiTerms: ['bureaucratic', 'technically-loud', 'playful'],
    density: ExperienceDensity.COMPACT, tempo: 'direct-controlled', attentionAnchor: 'selected-admin-area-and-real-state',
    soulCarrier: 'calm ownership boundaries and honest system feedback', spatialEffect: 'stable areas rather than one unstructured master form',
    motion: 'a section turns or unfolds the existing surface without nested modal chains',
    acceptance: 'Auch komplexe Einstellungen wirken beherrschbar, nachvollziehbar und sicher.', illustration: { normal: '0%' }
  }
});

export const STATE_EXPERIENCE_MODIFIERS = deepFreeze({
  normal: { id: 'normal', terms: [], message: 'Das Seitenprofil gilt ohne zusätzlichen Zustandsakzent.' },
  loading: { id: 'loading', terms: [term(ExperienceTerm.CALM, 2), term(ExperienceTerm.RELIABLE, 2), term(ExperienceTerm.ORDERED, 2)], message: 'Skeletons spiegeln reale Geometrie; bestehender Kontext bleibt sichtbar.' },
  empty: { id: 'empty', terms: [term(ExperienceTerm.STILL, 2), term(ExperienceTerm.EXPECTANT, 2), term(ExperienceTerm.INVITING, 1)], message: 'Leere bleibt handlungsfähig und zeigt genau eine sinnvolle nächste Handlung.' },
  success: { id: 'success', terms: [term(ExperienceTerm.WARM, 2), term(ExperienceTerm.COMPLETED, 2), term(ExperienceTerm.RELIABLE, 2)], message: 'Bestätigung erscheint am Gegenstand; der nächste Zustand ist verständlich.' },
  attention: { id: 'attention', terms: [term(ExperienceTerm.ATTENTIVE, 3), term(ExperienceTerm.PRECISE, 2)], message: 'Aufmerksamkeit bleibt proportional zur realen Auswirkung.' },
  error: { id: 'error', terms: [term(ExperienceTerm.HONEST, 3), term(ExperienceTerm.CALM, 2), term(ExperienceTerm.SOLUTION_ORIENTED, 2)], message: 'Arbeitsauswirkung, sicherer Rückweg und Retry stehen vor Technikdetails.' },
  forbidden: { id: 'forbidden', terms: [term(ExperienceTerm.RESPECTFUL, 2), term(ExperienceTerm.UNAMBIGUOUS, 3), term(ExperienceTerm.HONEST, 2)], message: 'Die fehlende Capability wird als Grenze erklärt; Scheinbedienung entfällt.' },
  offline: { id: 'offline', terms: [term(ExperienceTerm.RELIABLE, 3), term(ExperienceTerm.HONEST, 2), term(ExperienceTerm.CALM, 2)], message: 'Letzte Daten bleiben lesbar; Aktualität und Änderbarkeit werden getrennt.' },
  stale: { id: 'stale', terms: [term(ExperienceTerm.RELIABLE, 3), term(ExperienceTerm.HONEST, 2), term(ExperienceTerm.ATTENTIVE, 1)], message: 'Veraltete Daten werden klar gekennzeichnet; Erfolg wird nie simuliert.' }
});

export const EXPERIENCE_CONTRACT = deepFreeze({
  controlledAxes: Object.values(ExperienceControlledAxis), forbiddenAxes: Object.values(ExperienceForbiddenAxis),
  maxPrimaryTerms: 3, maxSupportingTerms: 2, maxDominantTerms: 1, primaryEvidenceChannels: 3, supportingEvidenceChannels: 2
});

export function getExperienceProfile(pageId) {
  const profile = PAGE_EXPERIENCE_PROFILES[pageId];
  if (!profile) throw new RangeError(`Unknown Gasserwerk experience profile: ${pageId}`);
  return profile;
}

export function getStateExperienceModifier(stateId = ExperienceState.NORMAL) {
  const modifier = STATE_EXPERIENCE_MODIFIERS[stateId];
  if (!modifier) throw new RangeError(`Unknown Gasserwerk experience state: ${stateId}`);
  return modifier;
}

export function applyExperienceAttributes(target, { page, state = ExperienceState.NORMAL, density } = {}) {
  if (!(target instanceof Element)) throw new TypeError('applyExperienceAttributes requires a DOM Element');
  const profile = getExperienceProfile(page);
  getStateExperienceModifier(state);
  target.dataset.gwPage = profile.id;
  target.dataset.gwState = state;
  target.dataset.gwDensity = density ?? profile.density;
  target.dataset.gwExperienceProfile = `${profile.id}-v1`;
  return profile;
}

export function validateExperienceRegistry() {
  const errors = [];
  const knownTerms = new Set(Object.values(ExperienceTerm));
  for (const profile of Object.values(PAGE_EXPERIENCE_PROFILES)) {
    if (profile.primaryTerms.length > EXPERIENCE_CONTRACT.maxPrimaryTerms) errors.push(`${profile.id}: too many primary terms`);
    if (profile.supportingTerms.length > EXPERIENCE_CONTRACT.maxSupportingTerms) errors.push(`${profile.id}: too many supporting terms`);
    const allTerms = [...profile.primaryTerms, ...profile.supportingTerms];
    if (allTerms.filter((entry) => entry.intensity === 3).length > 1) errors.push(`${profile.id}: more than one dominant term`);
    for (const entry of allTerms) {
      if (!knownTerms.has(entry.id)) errors.push(`${profile.id}: unknown term ${entry.id}`);
      if (!Number.isInteger(entry.intensity) || entry.intensity < 0 || entry.intensity > 3) errors.push(`${profile.id}: invalid intensity ${entry.id}`);
    }
    for (const field of ['acceptance', 'attentionAnchor', 'soulCarrier', 'spatialEffect', 'motion']) if (!profile[field]?.trim()) errors.push(`${profile.id}: missing ${field}`);
    if (!Array.isArray(profile.antiTerms) || profile.antiTerms.length < 3) errors.push(`${profile.id}: fewer than three anti-terms`);
  }
  return deepFreeze({ valid: errors.length === 0, errors });
}
