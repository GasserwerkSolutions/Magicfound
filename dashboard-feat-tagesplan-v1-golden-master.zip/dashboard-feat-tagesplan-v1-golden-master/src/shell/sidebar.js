import { DashboardEvent } from '../data/contracts/events.js';
import { createElement } from '../lib/dom.js';
import { dispatchDashboardEvent } from '../lib/dashboard-events.js';
import { buildReferencePath, getPrimaryNavigationPages } from './page-catalog.js';
import { createIcon, PAGE_ICON_NAME } from './icons.js';

function createNavigationLink(definition, options) {
  const { currentPageId, basePath, onNavigate } = options;
  const path = buildReferencePath(definition.id, { basePath });
  const active = definition.id === currentPageId;
  const link = createElement('a', {
    className: `gw-nav-link${active ? ' is-active' : ''}`,
    attributes: {
      href: path,
      'aria-current': active ? 'page' : null,
      'data-page-id': definition.id
    },
    children: [
      createElement('span', {
        className: 'gw-nav-link__icon',
        attributes: { 'aria-hidden': 'true' },
        children: createIcon(PAGE_ICON_NAME[definition.id] ?? 'tagesplan')
      }),
      createElement('span', { className: 'gw-nav-link__label', text: definition.label })
    ]
  });

  link.addEventListener('click', (event) => {
    dispatchDashboardEvent(link, DashboardEvent.SHELL_NAVIGATE_REQUESTED, {
      pageId: definition.id,
      path,
      source: 'sidebar'
    }, { source: 'sidebar' });

    if (typeof onNavigate === 'function') {
      event.preventDefault();
      onNavigate({ page: definition, path, origin: link });
    }
  });

  return link;
}

export function createSidebar(options = {}) {
  const {
    currentPageId,
    sessionContext = {},
    basePath = '/dashboard/',
    onNavigate = null
  } = options;

  const salon = sessionContext.salon ?? {};
  const account = sessionContext.account ?? {};
  const navigation = createElement('nav', {
    className: 'gw-primary-navigation',
    attributes: { 'aria-label': 'Hauptnavigation' },
    children: getPrimaryNavigationPages().map((definition) => createNavigationLink(definition, {
      currentPageId,
      basePath,
      onNavigate
    }))
  });

  const sidebar = createElement('aside', {
    className: 'gw-sidebar',
    attributes: { 'aria-label': 'Gasserwerk Produktnavigation' },
    children: [
      createElement('div', {
        className: 'gw-product-signature',
        children: [
          createElement('span', { className: 'gw-product-glyph', text: 'G', attributes: { 'aria-hidden': 'true' } }),
          createElement('span', { text: 'Gasserwerk' })
        ]
      }),
      createElement('section', {
        className: 'gw-salon-identity',
        attributes: { 'aria-label': 'Aktiver Salon' },
        children: [
          createElement('h2', { text: salon.name ?? 'Salon' }),
          createElement('p', { text: salon.locationLabel ?? 'Standort' })
        ]
      }),
      createElement('p', { className: 'gw-navigation-label', text: 'Arbeitsbereiche' }),
      navigation,
      createElement('div', { className: 'gw-sidebar__spacer' }),
      createElement('section', {
        className: 'gw-location-summary',
        children: [
          createElement('span', { text: 'Standort' }),
          createElement('strong', { text: salon.locationLabel ?? 'Nicht festgelegt' })
        ]
      }),
      createElement('section', {
        className: 'gw-account-summary',
        attributes: { 'aria-label': 'Angemeldetes Konto' },
        children: [
          createElement('span', { className: 'gw-account-summary__avatar', text: account.initials ?? 'GW', attributes: { 'aria-hidden': 'true' } }),
          createElement('span', {
            className: 'gw-account-summary__copy',
            children: [
              createElement('strong', { text: account.displayName ?? 'Gasserwerk Konto' }),
              createElement('small', { text: account.productRoleLabel ?? 'Produktzugriff' })
            ]
          })
        ]
      })
    ]
  });

  return sidebar;
}
