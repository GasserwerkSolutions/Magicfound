import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';

const root = process.cwd();
const referencePath = resolve(root, 'references/tagesplan/v1.0/tagesplan-reference.html');
const evidenceDirectory = resolve(root, 'references/tagesplan/v1.0/evidence/time-surface-r1');
const baseUrl = pathToFileURL(referencePath).href;
const checks = [];
const records = [];

mkdirSync(evidenceDirectory, { recursive: true });

function check(name, condition, detail = '') {
  assert.ok(condition, `${name}${detail ? `: ${detail}` : ''}`);
  checks.push(name);
}

async function waitForStable(page) {
  await page.waitForFunction(() => {
    const rootNode = document.querySelector('#dashboard-root');
    return rootNode?.dataset.tpRenderState === 'ready'
      && rootNode.dataset.tpLayoutState === 'stable'
      && rootNode.dataset.tpTimeSyncState === 'stable'
      && Boolean(rootNode.querySelector('.va-calendar-viewport'));
  }, null, { timeout: 15_000 });
  await page.evaluate(() => new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done))));
}

async function openAt(browser, viewport, parameters = 'referenceDate=2026-08-26&referenceNow=04%3A37') {
  const context = await browser.newContext({ viewport });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto(`${baseUrl}?${parameters}`, { waitUntil: 'load' });
  await waitForStable(page);
  return { context, page, errors };
}

async function reachability(page) {
  return page.evaluate(async () => {
    const rootNode = document.querySelector('#dashboard-root');
    const pageHost = rootNode.querySelector('.gw-page-content.va-page-host');
    const viewport = rootNode.querySelector('.va-calendar-viewport');
    const calendarScroll = viewport.querySelector('.va-calendar-scroll');
    const head = viewport.querySelector('.va-calendar-head');
    const rail = viewport.querySelector('.va-time-rail');
    const entries = [...viewport.querySelectorAll('.va-appointment, .va-operational')];
    const closingLabel = [...viewport.querySelectorAll('.va-time-label')].find((node) => node.textContent.trim() === '18:00');
    const scrollableY = (node) => ['auto', 'scroll'].includes(getComputedStyle(node).overflowY) && node.scrollHeight - node.clientHeight > 2;
    const owners = [...new Set([document.scrollingElement, pageHost, viewport, calendarScroll])].filter(scrollableY);
    const headTop = head.getBoundingClientRect().top;
    const railLeft = rail.getBoundingClientRect().left;
    const maxScrollTop = Math.max(0, viewport.scrollHeight - viewport.clientHeight);
    const maxScrollLeft = Math.max(0, viewport.scrollWidth - viewport.clientWidth);

    const entryResults = [];
    for (const entry of entries) {
      entry.scrollIntoView({ behavior: 'instant', block: 'nearest', inline: 'nearest' });
      await new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done)));
      let viewportRect = viewport.getBoundingClientRect();
      let headRect = head.getBoundingClientRect();
      let railRect = rail.getBoundingClientRect();
      let rect = entry.getBoundingClientRect();
      if (rect.top < headRect.bottom) viewport.scrollTop -= headRect.bottom - rect.top + 1;
      if (rect.bottom > viewportRect.bottom) viewport.scrollTop += rect.bottom - viewportRect.bottom + 1;
      if (rect.left < railRect.right) viewport.scrollLeft -= railRect.right - rect.left + 1;
      if (rect.right > viewportRect.right) viewport.scrollLeft += rect.right - viewportRect.right + 1;
      await new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done)));
      entry.focus({ preventScroll: true });
      viewportRect = viewport.getBoundingClientRect();
      headRect = head.getBoundingClientRect();
      railRect = rail.getBoundingClientRect();
      rect = entry.getBoundingClientRect();
      entryResults.push({
        id: entry.dataset.appointmentId ?? entry.dataset.operationalId,
        visible: rect.top >= headRect.bottom - 1
          && rect.bottom <= viewportRect.bottom + 1
          && rect.left >= railRect.right - 1
          && rect.right <= viewportRect.right + 1,
        focused: document.activeElement === entry,
        rect: { top: rect.top, right: rect.right, bottom: rect.bottom, left: rect.left }
      });
    }

    viewport.scrollTop = viewport.scrollHeight;
    viewport.scrollLeft = viewport.scrollWidth;
    await new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done)));
    const viewportRect = viewport.getBoundingClientRect();
    const headRect = head.getBoundingClientRect();
    const railRect = rail.getBoundingClientRect();
    const closingRect = closingLabel.getBoundingClientRect();
    const data = rootNode.dataset;
    return {
      regime: data.vaLayoutRegime ?? 'css-fallback',
      ownerCount: owners.length,
      primaryOwner: owners[0] === viewport ? 'calendar-viewport' : owners.length ? 'other' : 'none',
      documentOverflowY: document.documentElement.scrollHeight - document.documentElement.clientHeight,
      pageOverflowY: pageHost.scrollHeight - pageHost.clientHeight,
      maxScrollTop,
      finalScrollTop: viewport.scrollTop,
      maxScrollLeft,
      finalScrollLeft: viewport.scrollLeft,
      entryCount: entryResults.length,
      allEntriesReachable: entryResults.length > 0 && entryResults.every((entry) => entry.visible && entry.focused),
      unreachableEntries: entryResults.filter((entry) => !entry.visible || !entry.focused),
      closingVisible: closingRect.top >= headRect.bottom - 1 && closingRect.bottom <= viewportRect.bottom + 1,
      stickyHead: maxScrollTop <= 2 || Math.abs(headRect.top - headTop) <= 1,
      stickyRail: maxScrollLeft <= 2 || Math.abs(railRect.left - railLeft) <= 1,
      tabIndex: viewport.tabIndex,
      role: viewport.getAttribute('role'),
      exactClockVisible: getComputedStyle(rootNode.querySelector('.gw-clock-copy')).display !== 'none',
      timeSource: data.tpTimeSource,
      cardTimeToneCount: data.tpCardTimeToneCount
    };
  });
}

const browser = await chromium.launch({ headless: true });

try {
  const zoomCases = [
    ['100%', { width: 1366, height: 768 }],
    ['110%', { width: 1242, height: 698 }],
    ['125%', { width: 1093, height: 614 }],
    ['125%-Browserchrome', { width: 1093, height: 560 }]
  ];

  for (const [label, viewport] of zoomCases) {
    const opened = await openAt(browser, viewport);
    const result = await reachability(opened.page);
    records.push({ label, viewport, ...result });
    check(`${label}: keine JavaScriptfehler`, opened.errors.length === 0, opened.errors.join(' | '));
    check(`${label}: keine Dokument- oder Seitenscrollfläche`, result.documentOverflowY <= 1 && result.pageOverflowY <= 1, JSON.stringify(result));
    check(`${label}: exakte Salonzeit sichtbar`, result.exactClockVisible, JSON.stringify(result));
    check(`${label}: Kalender tastaturerreichbar`, result.tabIndex === 0 && result.role === 'region', JSON.stringify(result));
    check(`${label}: exakt ein oder kein vertikaler Scroll-Owner`, result.maxScrollTop > 2 ? result.ownerCount === 1 && result.primaryOwner === 'calendar-viewport' : result.ownerCount === 0, JSON.stringify(result));
    check(`${label}: alle Termine, Aufgaben, Pausen und 18:00 erreichbar`, result.allEntriesReachable && result.closingVisible && Math.abs(result.finalScrollTop - result.maxScrollTop) <= 1, JSON.stringify(result));
    check(`${label}: Kopf und Zeitachse bleiben bei Bewegung verankert`, result.stickyHead && result.stickyRail, JSON.stringify(result));
    check(`${label}: gesamte Mitarbeitendenbreite bleibt erreichbar`, Math.abs(result.finalScrollLeft - result.maxScrollLeft) <= 1, JSON.stringify(result));
    await opened.context.close();
  }

  const headerCase = await openAt(browser, { width: 1536, height: 744 }, 'referenceDate=2026-08-26&referenceNow=08%3A44');
  const header = await headerCase.page.evaluate(() => {
    const title = document.querySelector('.gw-page-title-row h1');
    const date = document.querySelector('.va-header-date');
    const icon = date.querySelector('svg');
    const preview = document.querySelector('.va-agenda-trigger-preview');
    const action = document.querySelector('[data-create-appointment]');
    const [titleRect, dateRect, iconRect, actionRect] = [title, date, icon, action].map((node) => node.getBoundingClientRect());
    return { titleRight: titleRect.right, dateRight: dateRect.right, iconRight: iconRect.right, iconWidth: iconRect.width, actionWidth: actionRect.width, previewText: preview?.textContent ?? '' };
  });
  check('Headerzustand bleibt ohne JavaScriptfehler', headerCase.errors.length === 0, headerCase.errors.join(' | '));
  check('Variable Als-Nächstes-Vorschau bleibt vorhanden', header.previewText.includes('Lynn'), JSON.stringify(header));
  check('Kalendersymbol bleibt vollständig und der Terminbutton kompakt', header.iconWidth >= 17 && header.iconRight <= header.dateRight + 1 && header.dateRight <= header.titleRight + 1 && header.actionWidth <= 150, JSON.stringify(header));
  await headerCase.context.close();

  const stateCases = [
    ['04:37 vor Öffnung', 'referenceDate=2026-08-26&referenceNow=04%3A37', { shade: '0', line: '0', behind: '0', progress: '0.000000' }],
    ['11:22 im Betrieb', 'referenceDate=2026-08-26&referenceNow=11%3A22', { shade: '1', line: '1', behind: '1', progress: '0.336667' }],
    ['18:31 nach Schliessung', 'referenceDate=2026-08-26&referenceNow=18%3A31', { shade: '1', line: '0', behind: '0', progress: '1.000000' }],
    ['vergangener Tag', 'referenceDate=2026-08-26&referenceNow=11%3A22&dateMode=past', { shade: '0', line: '0', behind: '0', progress: '0.000000' }],
    ['zukünftiger Tag', 'referenceDate=2026-08-26&referenceNow=11%3A22&dateMode=future', { shade: '0', line: '0', behind: '0', progress: '0.000000' }]
  ];
  for (const [label, parameters, expected] of stateCases) {
    const opened = await openAt(browser, { width: 1366, height: 768 }, parameters);
    const data = await opened.page.locator('#dashboard-root').evaluate((node) => ({ ...node.dataset }));
    check(`${label}: keine JavaScriptfehler`, opened.errors.length === 0, opened.errors.join(' | '));
    check(`${label}: Zeitflächenzustand ist exakt`, data.tpPastLayerCount === expected.shade && data.tpNowLineCount === expected.line && data.tpNowLineBehindCards === expected.behind && data.tpPastProgress === expected.progress && data.tpTimeProjectionState === 'stable' && data.tpTimeSyncState === 'stable', JSON.stringify(data));
    await opened.context.close();
  }

  check('Alle vier Zoomregime erreichen Tagesende und sämtliche Einträge', records.length === 4 && records.every((record) => record.allEntriesReachable && record.closingVisible));
  check('Alle Zoomregime verwenden Europe/Zurich', records.every((record) => record.timeSource === 'Europe/Zurich'), JSON.stringify(records));
  check('Keine Zoomstufe färbt Terminkarten zeitlich um', records.every((record) => record.cardTimeToneCount === '0'), JSON.stringify(records));
} finally {
  await browser.close();
}

if (checks.length !== 48) throw new Error(`Zoom-Suite muss exakt 48 Prüfungen enthalten, erhalten: ${checks.length}`);

writeFileSync(resolve(evidenceDirectory, 'zoom-reachability.json'), `${JSON.stringify({ cases: records }, null, 2)}\n`, 'utf8');
const output = JSON.stringify({ suite: 'Tagesplan v1 · Zoom- und Terminerreichbarkeit', passed: checks.length, failed: 0, checks }, null, 2);
writeFileSync(resolve(evidenceDirectory, 'verify-zoom-reachability-48.txt'), `${output}\n`, 'utf8');
console.log(output);
