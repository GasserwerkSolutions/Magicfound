export { createAppShell, mountAppShell } from './app-shell.js';
export { createSidebar } from './sidebar.js';
export { createMobileNavigation } from './mobile-navigation.js';
export { createProductHeader } from './product-header.js';
export {
  PageId,
  ShellVariant,
  PAGE_DEFINITIONS,
  getPageDefinition,
  getPrimaryNavigationPages,
  buildReferencePath
} from './page-catalog.js';
export { createIcon, PAGE_ICON_NAME } from './icons.js';
