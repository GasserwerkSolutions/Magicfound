import { DashboardEvent } from '../data/contracts/events.js';
import { createElement } from '../lib/dom.js';
import { dispatchDashboardEvent } from '../lib/dashboard-events.js';
import { buildReferencePath, getPrimaryNavigationPages } from './page-catalog.js';
import { createIcon, PAGE_ICON_NAME } from './icons.js';

export function createMobileNavigation(options = {}) {
  const {
    currentPageId,
    basePath = '/dashboard/',
    onNavigate = null
  } = options;

  return createElement('nav', {
    className: 'gw-mobile-navigation',
    attributes: { 'aria-label': 'Mobile Hauptnavigation' },
    children: getPrimaryNavigationPages().map((definition) => {
      const path = buildReferencePath(definition.id, { basePath });
      const active = definition.id === currentPageId;
      const link = createElement('a', {
        className: `gw-mobile-navigation__link${active ? ' is-active' : ''}`,
        attributes: {
          href: path,
          'aria-current': active ? 'page' : null,
          'data-page-id': definition.id
        },
        children: [
          createElement('span', {
            className: 'gw-mobile-navigation__icon',
            attributes: { 'aria-hidden': 'true' },
            children: createIcon(PAGE_ICON_NAME[definition.id] ?? 'tagesplan')
          }),
          createElement('span', { className: 'gw-mobile-navigation__label', text: definition.label })
        ]
      });

      link.addEventListener('click', (event) => {
        dispatchDashboardEvent(link, DashboardEvent.SHELL_NAVIGATE_REQUESTED, {
          pageId: definition.id,
          path,
          source: 'mobile-navigation'
        }, { source: 'mobile-navigation' });

        if (typeof onNavigate === 'function') {
          event.preventDefault();
          onNavigate({ page: definition, path, origin: link });
        }
      });

      return link;
    })
  });
}
