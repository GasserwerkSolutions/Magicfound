# Tagesplan · vollständige Tageslandkarte

Direkt ausführbare Vergleichsvariante für die akzeptierte Entscheidung ADR-003.

## Ziel

Der vollständige Arbeitstag bleibt auf Desktop stabil und ohne horizontalen Scroll sichtbar. Vormittag und Nachmittag sind nur noch leise Orientierung innerhalb eines einzigen Zeitkoordinatenraums. Die gemeinsame Zeitachse kommuniziert das `Wann`; Terminkarten kommunizieren primär `Wer`, `Was` und `Status`.

## Referenzpfad

```text
/dashboard/experiments/tagesplan-two-period/
```

Deterministische Jetzt-Zeit für Screenshots:

```text
?referenceNow=11:22
```

## Enthalten

- Produktschale V2 mit kompakter Arbeitsuhr
- globale Navigation: Tagesplan, Termine, Kundschaft, Verwaltung
- vollständiger Tag 08:00–18:00 auf einer Desktopfläche
- kein horizontaler Scroll im Desktop-Ganztag
- Vormittag und Nachmittag als zurückhaltende Tagesphasen
- ein kontinuierlicher Zeitkoordinatenraum über 13:00 hinweg
- durchgehende Karten über die Periodengrenze
- 15-/30-/60-Minuten-Raster
- hervorgehobene Zeitanker 09:00, 12:00, 15:00 und 18:00
- keine redundant sichtbare Startzeit in den Terminkarten
- vollständige Zeitinformation weiterhin im zugänglichen Namen und Kontextpanel
- beweglicher Jetzt-Cursor über der stabilen Fläche
- mobile Perioden untereinander
- vertikaler Personenfokus mit derselben Zeithierarchie
- Datumsauswahl und Kontextflächen
- Mock-Daten und fachliche Events, keine Persistenz

## Kartenhierarchie

- bis 30 Minuten: Initialen
- 30 bis unter 60 Minuten: Kundschaft
- ab 60 Minuten: Kundschaft und Dienstleistung
- Status primär über die linke Kante und eine sehr leichte Tönung
- Zeit nicht als sichtbarer Kartentext, sondern über Position, Raster und Kontextpanel

## Vergleich

Diese Variante ersetzt `pages/tagesplan/` noch nicht. Nach der Screenshot- und Bedienabnahme wird der Tagesplanvertrag aktualisiert und die akzeptierte Geometrie in die produktive Referenzseite übernommen. Der nächste visuelle Schritt ist ein hochwertiger, monochromer SVG-Satz für Schneiden, Färben, Balayage, Glossing, Pflege, Beratung, Pause und interne Aufgaben.
