#!/usr/bin/env python3
"""Build reproducible, confidence-labelled cross-state identities from recorded DOM.
No inference is promoted to a stable identity. No user/customer text is read.
"""
from __future__ import annotations
import argparse, collections, hashlib, json, re
from pathlib import Path

DYNAMIC={'active','selected','disabled','open','hidden','is-hidden','is-active','is-open','one-person','visually-hidden','current','show'}

def family(r):
    c=[x for x in r.get('classes',[]) if x not in DYNAMIC and not x.startswith('is-')]
    return (c[0] if c else r.get('tag','?'))

def load_measurement(source):
    data=json.loads(Path(source).read_text())
    assert data.get('schema')=='browser-dom-measure/v2', 'Expected existing v2 measurement'
    return data

def identify(data):
    states=[]; records=[]; issues=[]; by_identity=collections.defaultdict(list)
    for scenario in data['scenarios']:
        name=scenario['meta']['scenario']; route=scenario['meta']['route']; nodes=scenario['records']; idx={r['index']:r for r in nodes}
        ids=collections.Counter(r['id'] for r in nodes if r.get('id'))
        ui=collections.Counter((r.get('attributes') or {}).get('dataUi') for r in nodes if (r.get('attributes') or {}).get('dataUi'))
        # A path is only a useful comparison hint, never a stable identity.
        paths={}
        def makepath(i):
            if i in paths:return paths[i]
            r=idx[i]; p=r.get('parentIndex')
            if r.get('id') and ids[r['id']]==1: seg='#'+r['id']
            else:
                siblings=[t for t in nodes if t.get('parentIndex')==p and t['tag']==r['tag']]
                ordinal=next(j for j,t in enumerate(siblings,1) if t['index']==i)
                seg=f"{r['tag']}:nth-of-type({ordinal})"
            paths[i]=(makepath(p)+' > ' if p is not None else 'body > ')+seg
            return paths[i]
        within=collections.Counter()
        for r in nodes:
            a=r.get('attributes') or {}; dataui=a.get('dataUi'); instance=a.get('dataInstanceKey')
            origin='tentative-dom-path'; certainty='candidate'; why='Structural path can change or be reused by a different element'
            if dataui and instance:
                # declared identity, but only if pair unique in this document
                key=f'ui:{dataui}|key:{instance}'; certainty='declared';origin='data-ui+instance-key';why='Explicit component and instance key'
            elif r.get('id') and ids[r['id']]==1:
                key='id:'+r['id'];certainty='declared';origin='unique-dom-id';why='Unique HTML id in this scenario'
            elif dataui and ui[dataui]==1:
                key='ui:'+dataui; certainty='declared';origin='unique-data-ui';why='Unique component semantic marker'
            else:
                key=f'route:{route}|path:{makepath(r["index"])}';
            within[key]+=1
            rec={'scenario':name,'route':route,'index':r['index'],'domId':r.get('id'), 'tag':r['tag'],
                 'family':family(r),'visible':r['visibleInLayout'],'identityKey':key,'certainty':certainty,
                 'origin':origin,'reason':why, 'domPath':makepath(r['index']),
                 'geometry':{z:r['rect'][z] for z in ('left','top','width','height')},
                 'styles':{z:r['styles'].get(z) for z in ('background-color','color','border-top-left-radius','font-size','padding-left')}}
            records.append(rec);by_identity[key].append(rec)
        for dup,n in ids.items():
            if n>1:issues.append({'scenario':name,'kind':'duplicate-html-id','id':dup,'count':n})
        collisions={k:n for k,n in within.items() if n>1}
        if collisions:issues.append({'scenario':name,'kind':'identity-collision','keys':collisions})
        states.append({'scenario':name,'route':route,'total':len(nodes),'declared':sum(r['scenario']==name and r['certainty']=='declared' for r in records),'candidate':sum(r['scenario']==name and r['certainty']=='candidate' for r in records)})
    matches=[]
    for key,items in sorted(by_identity.items()):
        scs={r['scenario'] for r in items}
        if len(scs)<2:continue
        flavors={(r['tag'],r['family']) for r in items}
        declared=all(r['certainty']=='declared' for r in items)
        ambiguous=len(scs)!=len(items) or len({(r['tag'],r['family']) for r in items})>1
        # Candidate path equality does NOT establish identity even with matching signatures
        status='stable-declared' if declared and not ambiguous else ('candidate' if not ambiguous else 'ambiguous')
        if ambiguous:issues.append({'kind':'cross-state-identity-conflict','key':key,'signatureVariants':sorted(str(x) for x in flavors),'nodes':[(r['scenario'],r['index']) for r in items]})
        matches.append({'identityKey':key,'classification':status,'scenarios':sorted(scs),
                'signatureVariants':sorted(str(x) for x in flavors),'nodes':[{'scenario':r['scenario'],'index':r['index'],'visible':r['visible']} for r in items]})
    return {'schema':'cross-scenario-identity/v2','sourceSha256':data['source']['sha256'],
        'policy':{'declared':'Unique HTML id or explicit data-ui with instance key; uniqueness checked within each scenario','candidate':'DOM path is only a proposed correspondence and never a conclusive identity','warning':'DOM id stability across app rerenders must be checked in actual product; DOM identity is not business entity identity'},
        'scenarios':states,'records':records,'crossStateMatches':matches,'issues':issues,
        'summary':{'scenarioCount':len(states),'totalNodeObservations':len(records),'declaredObservations':sum(r['certainty']=='declared' for r in records),
                 'candidateObservations':sum(r['certainty']=='candidate' for r in records),
                 'stableDeclaredMatches':sum(m['classification']=='stable-declared' for m in matches),
                 'tentativeMatches':sum(m['classification']=='candidate' for m in matches),
                 'ambiguousMatches':sum(m['classification']=='ambiguous' for m in matches),
                 'issues':len(issues)}}

def main():
    p=argparse.ArgumentParser();p.add_argument('--measurement',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();data=identify(load_measurement(a.measurement));dest=Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps(data['summary'],indent=2))
if __name__=='__main__':main()
