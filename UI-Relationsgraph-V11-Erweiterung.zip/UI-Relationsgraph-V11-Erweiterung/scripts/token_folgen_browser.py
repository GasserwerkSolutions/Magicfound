#!/usr/bin/env python3
"""Empirical token intervention: measure computed-style and geometry diffs in real Chromium.
Runs only trusted local HTML. Records affected DOM nodes, not causal CSS-rule locations.
"""
import argparse,collections,hashlib,json,sys
from datetime import datetime,timezone
from pathlib import Path
from playwright.sync_api import sync_playwright

CSS_PROPS=[
 'display','visibility','position','left','top','right','bottom','width','height','min-width','min-height','max-width','max-height',
 'margin-top','margin-bottom','margin-left','margin-right', 'padding-left','padding-top','padding-right','padding-bottom',
 'border-top-width','border-left-width','border-right-width','border-bottom-width',
 'border-top-color','border-right-color','border-bottom-color','border-left-color',
 'border-top-left-radius','border-top-right-radius','border-bottom-right-radius','border-bottom-left-radius',
 'color','background-color','background-image','box-shadow','text-shadow','opacity',
 'font-size','font-weight','line-height','font-family','letter-spacing','outline-color','outline-style','outline-width',
 'fill','stroke','transform','grid-template-columns','grid-template-rows', 'column-gap','row-gap','gap',
 'justify-content','align-items','overflow-x','overflow-y','z-index','filter','text-decoration-color'
]
JS_SNAPSHOT=r'''(props) => {
 const els=[...document.body.querySelectorAll('*')];
 const nums=r=>{const x=(v)=>Math.round(v*1000)/1000;return [x(r.left),x(r.top),x(r.width),x(r.height)]};
 return els.map((el,i)=>{
   const cs=getComputedStyle(el), styles={};
   for (const p of props)styles[p]=cs.getPropertyValue(p).trim();
   const pseudo={};for(const sel of ['::before','::after']){
     const ps=getComputedStyle(el,sel);
     if(ps.content!=='normal'&&ps.content!=='none'&&ps.content!==''){
       pseudo[sel]={content:ps.content,color:ps.color,backgroundColor:ps.backgroundColor,borderColor:ps.borderTopColor,width:ps.width,height:ps.height};
     }
   }
   return {index:i,tag:el.localName,id:el.id||null,classes:typeof el.className==='string'?el.className.trim().split(/\s+/).slice(0,5):[],styles,rect:nums(el.getBoundingClientRect()),pseudo};
 });
}'''
JS_CHANGE=r'''({prop,value})=>{
 document.documentElement.style.setProperty(prop,value,'important');
 return getComputedStyle(document.documentElement).getPropertyValue(prop).trim();
}'''
JS_RESTORE=r'''({prop,old,priority})=>{
 if (old)document.documentElement.style.setProperty(prop,old,priority);
 else document.documentElement.style.removeProperty(prop);
 return getComputedStyle(document.documentElement).getPropertyValue(prop).trim();
}'''

def signature(r):
 return (r['tag'],r['id'],tuple(r['classes']))

def compare(base,mutant,eps=0.05):
 if len(base)!=len(mutant):return None,{'reason':'DOM length changed','baseline':len(base),'mutated':len(mutant)}
 changed=[]
 for a,b in zip(base,mutant):
  if signature(a)!=signature(b):return None,{'reason':'DOM signature changed','nodeIndex':a['index'],'baseline':signature(a),'mutant':signature(b)}
  changes={p:{'was':v,'now':b['styles'][p]} for p,v in a['styles'].items() if v!=b['styles'][p]}
  geom={p:round(y-x,3) for p,x,y in zip(['left','top','width','height'],a['rect'],b['rect']) if abs(x-y)>eps}
  pseudos={p:{'was':a['pseudo'].get(p),'now':b['pseudo'].get(p)} for p in set(a['pseudo'])|set(b['pseudo']) if a['pseudo'].get(p)!=b['pseudo'].get(p)}
  if changes or geom or pseudos:
   changed.append({'index':a['index'],'id':a['id'],'tag':a['tag'],'classes':a['classes'],
    'changedProperties':changes,'geometryDeltasPx':geom,'pseudoChanged':pseudos})
 return changed,None

def run(html, conf, chromium, specname):
 out=[];htmlhash=hashlib.sha256(html.encode()).hexdigest()
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path=chromium,args=['--no-sandbox','--disable-gpu'])
  version=browser.version
  try:
   for scene in conf['scenarios']:
    page=browser.new_page(viewport={'width':scene['width'],'height':scene['height']},locale='de-CH',timezone_id='Europe/Zurich',reduced_motion='reduce',device_scale_factor=1)
    errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
    try:
     page.set_content(html,wait_until='domcontentloaded',timeout=30000)
     page.evaluate('(route)=>{if(typeof navigate==="function")navigate(route)}',scene['route'])
     page.evaluate('document.fonts.ready');page.wait_for_timeout(100)
     # Stop motion in all scenarios to avoid arbitrary intermediate computed values.
     page.add_style_tag(content='*,*::before,*::after{animation:none!important;transition:none!important}')
     page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
     base=page.evaluate(JS_SNAPSHOT,CSS_PROPS)
     for mutation in conf['mutations']:
      prop=mutation['customProperty'];new=mutation['newValue'];id=mutation['id']
      old=page.evaluate('(p)=>({value:document.documentElement.style.getPropertyValue(p),priority:document.documentElement.style.getPropertyPriority(p),effective:getComputedStyle(document.documentElement).getPropertyValue(p).trim()})',prop)
      changed_value=page.evaluate(JS_CHANGE,{'prop':prop,'value':new})
      page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
      mutated=page.evaluate(JS_SNAPSHOT,CSS_PROPS)
      impacted,reason=compare(base,mutated)
      restore=page.evaluate(JS_RESTORE,{'prop':prop,'old':old['value'],'priority':old['priority']})
      page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
      restored=page.evaluate(JS_SNAPSHOT,CSS_PROPS)
      remainder,back_error=compare(base,restored)
      stable=(not back_error and not remainder)
      status='MEASURED' if (not reason and stable and changed_value==new) else 'INCONCLUSIVE'
      if mutation['type']=='negative-control' and status=='MEASURED' and impacted:
       status='CONTROL_FAILURE'
      propCounts=collections.Counter(prop for r in (impacted or []) for prop in r['changedProperties'])
      geomCount=sum(bool(r['geometryDeltasPx']) for r in (impacted or []))
      out.append({'scenario':scene['id'],'route':scene['route'],'mutationId':id,'cssVariable':prop,'oldComputedValue':old['effective'],
       'injectedValue':new,'actualRootValue':changed_value,'status':status,
       'affectedNodeCount':len(impacted or []),'geometryAffectedNodeCount':geomCount,
       'changedPropertyCounts':dict(propCounts.most_common()),'affectedNodes':impacted or [],
       'rollback':{'returnedToBaseline':stable,'remainingChanges':len(remainder or []),'error':back_error},
       'limitations':['Only BODY light DOM elements','Only selected computed CSS props and pseudo computed props',
         'SVG intrinsic paints, canvas pixels and network assets not exhaustively measured','A detected change proves impact of this intervention, not stylesheet provenance',
         'No change is not proof that token has no effect in untested states'],
       'error':reason,'pageErrors':errors[:]})
      print(f"{scene['id']}: {id}: {status}, {len(impacted or [])} changed DOM nodes, {geomCount} geometry, rollback={'ok' if stable else 'FAIL'}",flush=True)
     # Confirm root is returned to start and page stable before closing.
    finally:page.close()
  finally:browser.close()
 return {'schema':'empirical-css-token-impact/v1','sourceSha256':htmlhash,'testedAtUtc':datetime.now(timezone.utc).isoformat(),
         'browser':{'name':'Chromium','version':version},'configuration':conf,
         'summary':{'interventions':len(out),'measured':sum(x['status']=='MEASURED' for x in out),
           'inconclusive':sum(x['status']=='INCONCLUSIVE' for x in out),
           'controlFailures':sum(x['status']=='CONTROL_FAILURE' for x in out),'totalChangedObservations':sum(x['affectedNodeCount'] for x in out)},
         'interventions':out}

def main():
 p=argparse.ArgumentParser();p.add_argument('--html',required=True);p.add_argument('--config',required=True);p.add_argument('--output',required=True);p.add_argument('--chromium',default='/usr/bin/chromium')
 a=p.parse_args();html=Path(a.html).read_text(encoding='utf8');conf=json.loads(Path(a.config).read_text());d=run(html,conf,a.chromium,a.html)
 dest=Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(d['summary'],indent=2)); sys.exit(0 if not (d['summary']['inconclusive'] or d['summary']['controlFailures']) else 1)
if __name__=='__main__':main()
