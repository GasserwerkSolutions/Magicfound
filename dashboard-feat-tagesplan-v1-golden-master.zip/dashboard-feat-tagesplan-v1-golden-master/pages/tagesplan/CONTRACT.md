# Tagesplan · Seitenvertrag

Status: **Zur Freigabe – Produktoberflächenregeln konsolidiert, Backendabbildung integrationsrelevant**  
Verantwortlicher Bereich: `Salonbetrieb`  
Direkter Referenzpfad: `/dashboard/pages/tagesplan/`  
Abhängige gemeinsame Verträge: `docs/PRODUCT_SURFACE_V1.md`, `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

Der Tagesplan ist die primäre operative Arbeitsfläche des Salons.

Die Seite beantwortet ohne vorgelagerte Modusentscheidung:

- wer arbeitet
- was geschieht wann
- was läuft jetzt
- welche freie Zeit kann direkt belegt werden
- wo besteht konkreter Handlungsbedarf

`Heute` ist kein eigener Produktbereich. Der Tagesplan startet standardmässig auf dem heutigen Datum und – sofern zulässig – im Live-Zustand an der aktuellen Zeit.

Nicht Bestandteil dieser V1:

- direkte Terminverschiebung oder Grössenänderung
- produktive Konfliktauflösung
- Abrechnung oder Kasse
- eigenständiges Dashboard mit Kennzahlen

## 2. Eingabedaten

Datenquellenmethoden:

```js
getSessionContext()
getDayPlan({ date, salonId, locationId })
getAppointment(id)
```

Erforderlicher Kontext:

```js
{
  date: "YYYY-MM-DD",
  salonTimeZone,
  currentInstant,
  openingMinute,
  closingMinute,
  staff: StaffMemberSummary[],
  items: (AppointmentSummary | OperationalBlock)[],
  capabilities: string[]
}
```

Erforderliche Appointment-Felder:

- stabile `id`
- `date`
- `startMinute`
- `durationMinutes`
- `customer.displayName`
- `service.displayName`
- `staff.id`
- `status`

Optionale Felder:

- Telefonlabel
- Notiz
- Preis
- Besuchsschritt beziehungsweise fachlicher Phasenname

Erforderliche Capabilities:

- Anzeige: `day-plan:view`
- freie Zeit buchen: `day-plan:create-appointment`
- Termin öffnen: `appointment:view`

## 3. Fachliches View-Model

```js
{
  date,
  dateLabel,
  isToday,
  salon: {
    timeZone,
    openingMinute,
    closingMinute,
    currentMinute
  },
  staff: [
    {
      id,
      displayName,
      initials,
      professionalRoleLabel,
      isWorking,
      availabilitySegments
    }
  ],
  timelineItems: [
    {
      id,
      kind,
      staffId,
      startMinute,
      endMinute,
      durationMinutes,
      display,
      status,
      interaction
    }
  ],
  viewState: {
    scale: "work" | "full-day",
    focusedStaffId: null | string,
    selectedAppointmentId: null | string,
    liveFollow: "active" | "paused" | "unavailable",
    visibleStartMinute,
    visibleEndMinute,
    visibleDurationMinutes
  }
}
```

Fachliche Invarianten:

- `endMinute = startMinute + durationMinutes`.
- Termine und operative Blöcke verwenden dieselbe Zeitachse, bleiben jedoch verschiedene Arten.
- Personenposition und Zeitposition kommunizieren `Wer/Wann`; Farbe kommuniziert Zustand.
- Auf anderen Tagen als heute ist `currentMinute` für die UI `null` und Live-Follow `unavailable`.
- Die Teamreihenfolge kommt aus dem View-Model und wird nicht alphabetisch neu erfunden.
- Freie Zeit ist eine berechnete Lücke, kein persistiertes „Slot“-Objekt, sofern der Backendvertrag später nichts anderes festlegt.

Räumliche Zustände derselben Seite:

1. operative Teamarbeitsfläche: Personen links, Zeit horizontal
2. ganzer Arbeitstag: kompakter Massstab derselben Tageswahrheit
3. Personenfokus: genau eine Person, vollständiger Tag, Zeit vertikal

Verbindlicher operativer Desktopmassstab:

- Operatives Desktop-Zeitfenster: `240 Minuten`.
- Vergangenheit im passiven Live-Zustand: `45 Minuten`.
- Zukunft im passiven Live-Zustand: `195 Minuten`.
- Zeitraster: 15 Minuten fein, 30 Minuten mittel, 60 Minuten deutlich.
- Terminbreite bleibt immer proportional zur realen Dauer; Karten dürfen nicht unabhängig vom Raster verkürzt werden.
- Fortlaufende Termine behalten ihren lesbaren Karteninhalt im sichtbaren Fragment, während die reale Karte zeitlich korrekt unter der sticky Teamspalte weiterläuft.
- Kompakte Personenzeile: 60–64 px; kompakte Terminhöhe: 40–44 px.
- Standard-Desktop: Personenzeile 68–72 px; Terminhöhe 44–48 px.
- Automatische Zeilenstreckung zum Füllen der Resthöhe ist nicht zulässig. Eine Zeile wächst nur wegen realer Überschneidungen und zusätzlicher Bahnen.

## 4. Ausgehende Ereignisse

### Datum ändern

```js
{
  type: "day:date-change-requested",
  payload: { date }
}
```

Auslöser: Auswahl in der Datumskomponente. Das Datum wird erst nach erfolgreichem Zustandswechsel als aktiv dargestellt.

### Massstab ändern

```js
{
  type: "day:scale-change-requested",
  payload: {
    scale: "work" | "full-day",
    date,
    selectedAppointmentId,
    focusedStaffId,
    visibleStartMinute
  }
}
```

### Person fokussieren oder Fokus aufheben

```js
{
  type: "day:staff-focus-requested",
  payload: { staffId, date, originScale }
}

{
  type: "day:staff-focus-cleared",
  payload: { staffId, date, returnScale }
}
```

### Live-Follow

```js
{
  type: "day:live-follow-paused",
  payload: { date, visibleStartMinute, reason }
}

{
  type: "day:live-follow-resume-requested",
  payload: { date }
}
```

`reason` kann `scroll`, `pointer`, `keyboard`, `selection`, `panel` oder `search` sein.

### Termin oder operative Zeit öffnen

```js
{
  type: "appointment:selected",
  payload: { appointmentId, date, originGeometry }
}
```

Operative Blöcke verwenden ein eigenes, später zu ergänzendes Detailereignis; sie dürfen nicht als Termin-ID ausgegeben werden.

### Freie Zeit buchen

```js
{
  type: "appointment:create-requested",
  payload: {
    date,
    staffId,
    suggestedStartMinute,
    source: "day-plan-free-space"
  }
}
```

Die UI rundet die Absicht auf 15 Minuten. Die endgültige Buchbarkeit entscheidet die Produktionsintegration.

## 5. Ladezustand

- Sidebar und Produktkopf bleiben sichtbar.
- Datum und Standortkontext bleiben sichtbar, sofern bereits bekannt.
- Teamspalte und Zeitfläche erhalten strukturelle Skeletons; es werden keine erfundenen Termine gezeigt.
- Die Jetzt-Linie wird erst dargestellt, wenn Salon-Zeitzone und aktuelle Zeit geklärt sind.
- Datumsauswahl darf geöffnet werden; Terminaktionen bleiben deaktiviert, bis die Daten nutzbar sind.
- Ein Reload verschiebt den Fokus nicht ungefragt.

## 6. Leerzustand

`empty` bedeutet: gültiger Salontag, bekannte Mitarbeitende und Arbeitszeiten, aber keine Termine oder operativen Blöcke.

- Die Zeitfläche bleibt vollständig bedienbar.
- Freie Zeit bleibt direkte Buchungsaktion.
- Die alpine Habitat-Zone darf ausschliesslich im unteren Bereich erscheinen und darf Zeitraster oder Personen nicht überdecken.
- Es gibt keinen künstlichen Kennzahlen- oder Erklärungsteppich.
- Wenn niemand arbeitet, ist dies ein eigener leerer Zustand mit Hinweis auf Arbeitszeiten und ohne buchbare freie Fläche.

## 7. Fehlerzustand

Kernladefehler:

- Tagesdaten werden nicht als leere Antwort dargestellt.
- Datum, Salonkontext und erneute Ladeaktion bleiben sichtbar.
- Fehlermeldung benennt die Arbeitsauswirkung und nicht technische Interna.

Teilfehler:

- Fehlen einzelne Zusatzinformationen, bleibt die Zeitplanung nutzbar.
- Fehlende Kundennotiz oder Preis entfernt nicht den Termin.
- Unklare Person- oder Dienstleistungsreferenzen werden als unbekannt markiert und protokolliert.

Offline/Stale:

- vorhandene Daten bleiben sichtbar und werden als möglicherweise veraltet gekennzeichnet.
- persistente Änderungen werden nicht als erfolgreich simuliert.
- Live-Follow darf weiterlaufen, solange die Zeitquelle verlässlich ist; Datenaktualität und Uhrzeitstatus werden getrennt behandelt.

## 8. Berechtigungszustände

- Fehlt `day-plan:view`, erscheint ein vollständiger `forbidden`-Zustand innerhalb der Produktschale.
- Fehlt `day-plan:create-appointment`, bleiben freie Zeit und Raster sichtbar, aber nicht als Buchungsaktion aktiv.
- Fehlt `appointment:view`, werden Termine als belegte Zeit mit minimal zulässigen Angaben dargestellt; Kundendetails werden nicht geliefert.
- Fehlt `customer:view-sensitive-notes`, enthält das Termin-View-Model keine vertrauliche Notiz.
- Verwaltungs- oder Stammdatenrechte werden auf dieser Seite nicht vorausgesetzt.

## 9. Desktopverhalten

### Teamarbeitsfläche

- Sidebar bleibt sichtbar.
- Team-/Namensspalte bleibt sticky, deckend und über der darunterlaufenden Zeitfläche.
- Zeitkopf, Raster, Termine, operative Blöcke und Jetzt-Linie verwenden genau einen gemeinsamen horizontalen Scroll-Viewport.
- 15 Minuten: feine Linie; 30 Minuten: mittlere Linie; 60 Minuten: stärkste Linie mit Beschriftung.
- Im passiven Live-Zustand zeigt der Desktop exakt 240 Minuten: 45 Minuten Vergangenheit, Jetzt und 195 Minuten Zukunft. Damit liegt Jetzt bei 18,75 % der sichtbaren Zeitfläche.
- Manuelle Interaktion pausiert die Nachführung sofort.
- Im entkoppelten Zustand erscheint genau eine richtungsabhängige Rückkehraktion `← Jetzt` oder `Jetzt →`.
- Automatische Rückkehr ist frühestens nach 20–30 Sekunden echter Inaktivität erlaubt und nur ohne Auswahl, Fokusfeld, Panel oder laufende Aktion.

### Ganzer Tag

- Ist ein Massstab derselben Seite, keine Route und kein Dashboard.
- Das Raster ist ruhiger als in der Arbeitsfläche.
- Datum, Auswahl, Fokusbezug und geöffnetes Kontextpanel bleiben erhalten.

### Personenfokus

- Klick auf eine Person dreht die Fläche in einen vertikalen Einzeltag.
- Es gibt eine ruhige Kontextzeile aus Person, Datum und Rückkehraktion.
- Keine doppelte Personenleiste und kein zusätzlicher Fokus-Chip.
- Die linke Zeitachse ist die einzige Zeitbeschriftung.
- Fast die gesamte Fläche besteht aus Zeit und Einträgen.

### Dichte

Bei kompakten Desktop-/14-Zoll-Viewports werden Geometrie und Abstände verdichtet, nicht die gesamte Seite skaliert. Personenzeilen liegen bei 60–64 px, normale Terminkarten bei 40–44 px. Auf Standard-Desktop liegen Personenzeilen bei 68–72 px und Terminkarten bei 44–48 px. Haupttexte bleiben im Regelfall mindestens 14 px, Sekundärtexte mindestens 11–12 px. Leere Resthöhe darf nicht durch künstliches Aufblasen der Personenzeilen gefüllt werden.

## 10. Mobilverhalten

- Dieselben drei fachlichen Zustände bleiben erhalten.
- Die mobile Navigation ersetzt die Sidebar, ohne neue Produktbereiche einzuführen.
- Suche wird bei Bedarf als Kopfzustand geöffnet.
- Datum bleibt der einzige Kalenderauslöser.
- Die Teamarbeitsfläche bleibt horizontal untersuchbar; Personenbezeichnungen sind direkte Fokusauslöser.
- Im Personenfokus wird der vollständige Tag vertikal dargestellt.
- Kontextflächen erscheinen als untere Sheets über der weiterhin erkennbaren Arbeitsfläche.
- Trefferflächen bleiben mindestens 44 × 44 CSS-Pixel, auch wenn das sichtbare Icon kleiner ist.
- Die Gesamtseite darf nicht horizontal überlaufen; nur der definierte Zeit-Viewport darf horizontal scrollen.

## 11. Tastatur und Fokus

- Datumsauslöser ist per `Enter` und Leertaste erreichbar.
- Zeit-Viewport kann fokussiert und mit horizontalen Tasten beziehungsweise systemüblichem Scrollen untersucht werden.
- Personenbezeichnungen sind echte Buttons.
- Freie Zeit erhält eine einfache Aktivierungsalternative; eine Ziehbewegung ist nie die einzige Möglichkeit.
- `Escape` schliesst in dieser Reihenfolge: oberstes Panel, Datumsauswahl, Suche, Personenfokus.
- Beim Massstabswechsel bleibt der fachliche Fokus auf dem zuvor gewählten Termin beziehungsweise der auslösenden Massstabsaktion.
- Schliessen eines Terminpanels stellt Datum, Scale, Personenfokus, Scrollposition, Auswahl und Tastaturfokus wieder her.
- Änderungen von Live-Follow, Scale und Personenfokus werden knapp über eine Live-Region angekündigt.

## 12. Abnahmekriterien

Der Tagesplan ist übergabefähig, wenn:

- keine Tages-Toolbar, doppelte Zusammenfassung oder Footer im Kalender gerendert wird
- Datum ausschliesslich über den Produktkopf gewählt wird
- Teamspalte sticky und vollständig deckend bleibt
- Zeitkopf und Terminraster denselben horizontalen Scrollzustand verwenden
- 15-/30-/60-Minuten-Raster korrekt skaliert
- der operative Desktopausschnitt exakt 240 Minuten umfasst
- der Live-Ausschnitt 45 Minuten Vergangenheit und 195 Minuten Zukunft zeigt
- Terminbreiten mathematisch proportional zur realen Dauer bleiben
- begonnene Termine ihren Inhalt im sichtbaren Fragment lesbar halten, ohne zeitlich verschoben zu werden
- Personenzeilen nicht automatisch auf die verfügbare Resthöhe gestreckt werden
- Live-Anker in allen Desktopdichten stabil bleibt
- manuelles Scrollen Live-Follow sofort pausiert
- Jetzt-Rückkehr richtungsrichtig funktioniert
- andere Tage keinerlei Live-Zeit-UI zeigen
- Ganztagesmassstab Auswahl und Kontext erhält
- Personenfokus vertikal und ohne doppelte Fokusdarstellung funktioniert
- operative Aufgaben visuell eindeutig von Terminen getrennt bleiben
- Terminflächen nahe an Weiss bleiben und Status primär über die linke Kante kommunizieren
- Leer-, Lade-, Fehler-, Offline-, Stale- und Forbidden-Zustände geprüft sind
- 14-Zoll, Standard-Desktop, Mobil Hochformat, Mobil Querformat und Tablet geprüft sind
- Tastaturbedienung und Fokuswiederherstellung funktionieren
- keine gesamte Seite horizontal überläuft
- keine JavaScript- oder Konsolenfehler auftreten

## 13. Integrationshinweise

- Offene Backendfragen: `Q-002`, `Q-003`, `Q-004`, `Q-005`, `Q-006`, `Q-007`, `Q-DAY-001` bis `Q-DAY-005`, `Q-APT-001`.
- Der Backendadapter MUSS Salon-Zeitzone, Arbeitszeiten, stabile IDs und normalisierte Minutenwerte liefern.
- Die Referenz darf einen kontrollierbaren Clock-Provider verwenden; die Produktionsanwendung bindet die autoritative Zeitquelle an denselben Vertrag.
- Freie Slots sind eine UI-Ableitung und keine stillschweigende Backendentität.
- Konfliktprüfung und Statusübergänge bleiben Adapter-/Domain-Verantwortung.
- Phase 3 ergänzt `move`, `resize`, Konfliktvorschau und Undo erst nach Freigabe dieses Vertrags.
