import { createElement, replaceChildren, assertElement, announce } from '../lib/dom.js';
import { getPageDefinition, ShellVariant } from './page-catalog.js';
import { createSidebar } from './sidebar.js';
import { createMobileNavigation } from './mobile-navigation.js';
import { createProductHeader } from './product-header.js';

export function createAppShell(options = {}) {
  const {
    pageId,
    sessionContext = {},
    basePath = '/dashboard/',
    shellVariant = getPageDefinition(pageId).shellVariant,
    header = {},
    scrollOwner = 'page',
    onNavigate = null
  } = options;

  const definition = getPageDefinition(pageId);
  const resolvedVariant = shellVariant ?? definition.shellVariant;
  const headerApi = header?.element ? header : createProductHeader(header);
  const pageViewport = createElement('main', {
    className: 'gw-page-viewport',
    attributes: {
      id: 'main-content',
      tabindex: '-1',
      'data-scroll-owner': scrollOwner
    }
  });
  const overlayRoot = createElement('div', {
    className: 'gw-overlay-root',
    attributes: { 'data-overlay-root': '' }
  });
  const liveRegion = createElement('div', {
    className: 'gw-sr-only',
    attributes: {
      'aria-live': 'polite',
      'aria-atomic': 'true',
      'data-live-region': ''
    }
  });

  const workspace = createElement('section', {
    className: 'gw-workspace',
    attributes: { 'aria-label': `${definition.label} · Gasserwerk Dashboard` },
    children: [headerApi.element, pageViewport]
  });

  const shell = createElement('div', {
    className: 'gw-app-shell',
    attributes: {
      'data-page-id': pageId,
      'data-shell-variant': resolvedVariant
    },
    children: [
      resolvedVariant === ShellVariant.PRODUCT ? createSidebar({
        currentPageId: pageId,
        sessionContext,
        basePath,
        onNavigate
      }) : null,
      workspace,
      resolvedVariant === ShellVariant.PRODUCT ? createMobileNavigation({
        currentPageId: pageId,
        basePath,
        onNavigate
      }) : null,
      overlayRoot,
      liveRegion
    ]
  });

  return Object.freeze({
    element: shell,
    header: headerApi,
    workspace,
    pageViewport,
    overlayRoot,
    liveRegion,
    mount(root) {
      assertElement(root, 'root');
      replaceChildren(root, [shell]);
      return this;
    },
    setPageContent(content) {
      replaceChildren(pageViewport, content ? (Array.isArray(content) ? content : [content]) : []);
    },
    setScrollOwner(value) {
      pageViewport.dataset.scrollOwner = value;
    },
    announce(message) {
      announce(liveRegion, message);
    },
    focusPage() {
      pageViewport.focus({ preventScroll: true });
    }
  });
}

export function mountAppShell(root, options = {}) {
  return createAppShell(options).mount(root);
}
