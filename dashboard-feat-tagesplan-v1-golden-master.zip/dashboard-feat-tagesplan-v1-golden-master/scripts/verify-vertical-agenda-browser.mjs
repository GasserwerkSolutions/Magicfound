import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const root = process.cwd();
const outputDirectory = resolve(root, 'artifacts/tagesplan-vertical-agenda');
const chromeProfile = mkdtempSync(join(tmpdir(), 'gasserwerk-chrome-suite-'));
const port = 4176;
const baseUrl = `http://127.0.0.1:${port}/experiments/tagesplan-vertical-agenda/`;
const urls = Object.freeze({
  desktopClosed: `${baseUrl}?referenceNow=11:22`,
  desktopOpen: `${baseUrl}?referenceNow=11:22&verify=1`,
  focus: `${baseUrl}?referenceNow=11:22&focus=melanie&verify=1`,
  mobileOpen: `${baseUrl}?referenceNow=11:22&agenda=open`,
  mobileScrolled: `${baseUrl}?referenceNow=11:22&verifyStaffScroll=1`,
  landscapeOpen: `${baseUrl}?referenceNow=11:22&agenda=open`
});
const modes = new Set(process.argv.slice(2));
const runAssertions = !modes.has('--capture-only');
const runCapture = !modes.has('--assert-only');
const errors = [];

function findChrome() {
  const candidates = [process.env.CHROME_BIN, 'google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser'].filter(Boolean);
  for (const candidate of candidates) {
    const probe = spawnSync('bash', ['-lc', `command -v ${candidate}`], { encoding: 'utf8' });
    if (probe.status === 0 && probe.stdout.trim()) return probe.stdout.trim();
  }
  return null;
}

function chromeRun(chrome, label, args, virtualTimeBudget = 3200) {
  const started = Date.now();
  console.log(`→ ${label}`);
  const result = spawnSync('timeout', [
    '--signal=TERM',
    '--kill-after=3s',
    '45s',
    chrome,
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--disable-dev-shm-usage',
    '--disable-background-networking',
    '--disable-background-timer-throttling',
    '--disable-component-update',
    '--disable-default-apps',
    '--disable-extensions',
    '--disable-sync',
    '--disable-features=MediaRouter,OptimizationHints,Translate',
    '--no-first-run',
    '--no-default-browser-check',
    '--hide-scrollbars',
    '--run-all-compositor-stages-before-draw',
    `--user-data-dir=${chromeProfile}`,
    `--virtual-time-budget=${virtualTimeBudget}`,
    ...args
  ], {
    cwd: root,
    encoding: 'utf8',
    maxBuffer: 40 * 1024 * 1024
  });
  const elapsed = Date.now() - started;
  console.log(`← ${label}: status=${result.status} signal=${result.signal ?? '-'} ${elapsed}ms`);
  if ([124, 137, 143].includes(result.status)) {
    throw new Error(`${label}: Chrome wurde nach 45 Sekunden beendet; der isolierte Fall hängt.`);
  }
  if (result.error) throw result.error;
  return result;
}

async function waitForServer() {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    try {
      const response = await fetch(urls.desktopOpen);
      if (response.ok) return;
    } catch {
      // Server is still starting.
    }
    await delay(120);
  }
  throw new Error(`Lokaler Referenzserver antwortet nicht auf ${urls.desktopOpen}`);
}

function requireDom(dom, term, label) {
  if (!dom.includes(term)) errors.push(`Gerenderter DOM enthält nicht: ${label}`);
}

function forbidDom(dom, term, label) {
  if (dom.includes(term)) errors.push(`Gerenderter DOM enthält verworfenen Inhalt: ${label}`);
}

function datasetNumber(dom, name) {
  const match = dom.match(new RegExp(`data-${name}="(-?\\d+(?:\\.\\d+)?)"`));
  return match ? Number(match[1]) : null;
}

function dumpDom(chrome, name, width, height, url) {
  const result = chromeRun(chrome, `DOM ${name}`, [`--window-size=${width},${height}`, '--dump-dom', url]);
  if (result.status !== 0) {
    errors.push(`${name}: Chrome DOM-Prüfung fehlgeschlagen:\n${result.stderr.trim()}`);
    return '';
  }
  writeFileSync(resolve(outputDirectory, `${name}.html`), result.stdout);
  return result.stdout;
}

function screenshot(chrome, name, width, height, url) {
  const target = resolve(outputDirectory, `${name}.png`);
  const result = chromeRun(chrome, `Screenshot ${name}`, [`--window-size=${width},${height}`, `--screenshot=${target}`, url]);
  if (result.status !== 0 || !existsSync(target)) errors.push(`${name}: Screenshot konnte nicht erzeugt werden:\n${result.stderr.trim()}`);
  else console.log(`✓ Screenshot ${name}`);
}

rmSync(outputDirectory, { recursive: true, force: true });
mkdirSync(outputDirectory, { recursive: true });

const server = spawn('python3', ['-m', 'http.server', String(port), '--bind', '127.0.0.1'], {
  cwd: root,
  stdio: 'ignore'
});

try {
  await waitForServer();
  const chrome = findChrome();
  if (!chrome) throw new Error('Kein Chrome-/Chromium-Binary für Browserprüfung gefunden');
  const warmup = chromeRun(chrome, 'Chrome warm-up', ['--dump-dom', 'about:blank'], 800);
  if (warmup.status !== 0) throw new Error(`Chrome-Warm-up fehlgeschlagen: ${warmup.stderr.trim()}`);

  if (runAssertions) {
    const desktopClosed = dumpDom(chrome, 'rendered-dom-desktop-closed', 1512, 982, urls.desktopClosed);
    if (desktopClosed) {
      requireDom(desktopClosed, 'data-now-line-behind-cards="1"', 'Zeitstrich hinter Terminkarten');
      requireDom(desktopClosed, 'data-desktop-time-pill-count="0"', 'keine redundante Desktop-Zeitpille');
      requireDom(desktopClosed, 'data-card-semantic-truncation="1"', 'semantisch klassifizierte Terminkarten');
      requireDom(desktopClosed, 'data-account-name-complete="1"', 'vollständiger Benutzername');
      requireDom(desktopClosed, 'data-search-mode="desktop"', 'Desktop-Suchmodus');
      requireDom(desktopClosed, '>TAGESPLAN<', 'sichtbarer Kicker TAGESPLAN');
      requireDom(desktopClosed, 'Name, Termin oder freie Zeit suchen', 'neutraler Suchtext');
      requireDom(desktopClosed, '>Ctrl K<', 'Linux-/Windows-Tastaturhinweis');
      requireDom(desktopClosed, 'va-calendar-viewport', 'gemeinsamer Kalender-Viewport');
      forbidDom(desktopClosed, 'Zürich Enge · 08:00–18:00', 'redundanter Kopfzeilenkontext');
      const overflow = datasetNumber(desktopClosed, 'document-overflow-x');
      const calendarYOverflow = datasetNumber(desktopClosed, 'calendar-y-overflow');
      if (overflow !== 0) errors.push(`Desktop hat horizontalen Gesamtseitenüberlauf: ${overflow}`);
      if (!(calendarYOverflow <= 2)) errors.push(`Desktop-Master zeigt nicht den vollständigen Tag: interner Überlauf ${calendarYOverflow}px`);
    }

    const desktopOpen = dumpDom(chrome, 'rendered-dom-desktop-open', 1512, 982, urls.desktopOpen);
    if (desktopOpen) {
      requireDom(desktopOpen, 'data-visible-agenda-panels="1"', 'genau ein geöffnetes Agenda-Popover');
      requireDom(desktopOpen, 'data-permanent-agenda-container-count="0"', 'keine permanente Agenda-Fläche');
      requireDom(desktopOpen, 'va-agenda-section is-before', 'Agendaabschnitt Davor');
      requireDom(desktopOpen, 'va-agenda-section is-current', 'Agendaabschnitt Jetzt');
      requireDom(desktopOpen, 'va-agenda-section is-next', 'Agendaabschnitt Danach');
      requireDom(desktopOpen, '11:30–12:30', 'korrekte erste freie Lücke');
      requireDom(desktopOpen, 'va-now-label', 'separates Jetzt-Label in der Zeitachse');
    }

    const mobileOpen = dumpDom(chrome, 'rendered-dom-mobile-open', 390, 844, urls.mobileOpen);
    if (mobileOpen) {
      requireDom(mobileOpen, 'data-search-mode="icon"', 'mobile Suche als Schaltfläche');
      requireDom(mobileOpen, 'data-calendar-initial-now-positioned="1"', 'initiale mobile Position bei Jetzt');
      requireDom(mobileOpen, 'data-mobile-horizontal-scrollable="1"', 'horizontal bewegliche Mitarbeitendenfläche');
      requireDom(mobileOpen, 'data-mobile-staff-column-min="132"', '132-Pixel-Mindestbreite pro Person');
      requireDom(mobileOpen, '3 weitere laufen', 'explizite Offenlegung ausgeblendeter laufender Termine');
      requireDom(mobileOpen, 'Melanie</strong>', 'lesbarer Vorname im mobilen Mitarbeitendenkopf');
      const scrollTop = datasetNumber(mobileOpen, 'calendar-scroll-top');
      if (!(scrollTop > 0)) errors.push(`Mobiler Kalender wurde nicht zur aktuellen Zeit positioniert: scrollTop=${scrollTop}`);
      const overflow = datasetNumber(mobileOpen, 'document-overflow-x');
      if (overflow !== 0) errors.push(`Mobil hat horizontalen Gesamtseitenüberlauf: ${overflow}`);
    }

    const mobileScrolled = dumpDom(chrome, 'rendered-dom-mobile-scrolled', 390, 844, urls.mobileScrolled);
    if (mobileScrolled) {
      requireDom(mobileScrolled, 'data-mobile-horizontal-scroll-functional="1"', 'funktionale horizontale Mitarbeitendenbewegung');
      const delta = datasetNumber(mobileScrolled, 'mobile-horizontal-scroll-delta');
      const scrollLeft = datasetNumber(mobileScrolled, 'calendar-scroll-left');
      if (!(delta > 2 && scrollLeft > 2)) errors.push(`Mitarbeitendenbewegung wurde nicht physisch vollzogen: delta=${delta}, scrollLeft=${scrollLeft}`);
    }

    const landscapeOpen = dumpDom(chrome, 'rendered-dom-landscape-open', 844, 390, urls.landscapeOpen);
    if (landscapeOpen) {
      requireDom(landscapeOpen, 'data-search-mode="field"', 'Querformat-Suche als Feld');
      requireDom(landscapeOpen, 'data-calendar-initial-now-positioned="1"', 'initiale Querformatposition bei Jetzt');
      requireDom(landscapeOpen, '4 weitere laufen', 'Querformat legt vier weitere laufende Termine offen');
      requireDom(landscapeOpen, 'Name, Termin oder freie Zeit suchen', 'Suchfeld im Querformat');
      const scrollTop = datasetNumber(landscapeOpen, 'calendar-scroll-top');
      if (!(scrollTop > 0)) errors.push(`Querformatkalender wurde nicht zur aktuellen Zeit positioniert: scrollTop=${scrollTop}`);
    }

    const focus = dumpDom(chrome, 'rendered-dom-focus', 1512, 982, urls.focus);
    if (focus) {
      requireDom(focus, 'data-visible-staff-count="5"', 'Fokus behält fünf Mitarbeitende');
      requireDom(focus, 'aria-pressed="true"', 'fokussierter Personenkopf');
      const contextualTracks = datasetNumber(focus, 'focus-context-count');
      if (contextualTracks !== 4) errors.push(`Fokus soll vier Kontextspalten dimmen, gefunden ${contextualTracks}`);
    }
  }

  if (runCapture) {
    const viewports = [
      ['tagesplan-1366x768', 1366, 768, urls.desktopClosed],
      ['tagesplan-1440x900', 1440, 900, urls.desktopClosed],
      ['tagesplan-1512x982', 1512, 982, urls.desktopClosed],
      ['tagesplan-1920x1080', 1920, 1080, urls.desktopClosed],
      ['tagesplan-390x844', 390, 844, urls.desktopClosed],
      ['tagesplan-390x844-scrolled', 390, 844, urls.mobileScrolled],
      ['tagesplan-844x390', 844, 390, urls.desktopClosed],
      ['tagesplan-1512x982-open', 1512, 982, urls.desktopOpen],
      ['tagesplan-390x844-open', 390, 844, urls.mobileOpen]
    ];
    for (const [name, width, height, url] of viewports) screenshot(chrome, name, width, height, url);
  }
} catch (error) {
  errors.push(error.message);
} finally {
  server.kill('SIGTERM');
  rmSync(chromeProfile, { recursive: true, force: true });
}

if (errors.length) {
  console.error(`\nBrowserprüfung fehlgeschlagen (${errors.length}):`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`\n✓ Präzisionsstand der vertikalen Tagesfläche geprüft: ${urls.desktopOpen}`);
