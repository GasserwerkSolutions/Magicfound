const root = document.querySelector('#dashboard-root');
const pageContent = document.querySelector('#gw-page-content');
const query = new URLSearchParams(location.search);
const salonTime = window.__gasserwerkSalonTime;
if (!salonTime) throw new Error('Die gemeinsame Salonzeitquelle ist nicht geladen.');

const OPEN_MINUTE = 8 * 60;
const CLOSE_MINUTE = 18 * 60;
const DAY_DURATION = CLOSE_MINUTE - OPEN_MINUTE;
const PORTRAIT_STAFF_WIDTH = 132;
const NOW_ANCHOR_RATIO = 0.36;

const dateLabels = Object.freeze({
  weekdays: ['So.', 'Mo.', 'Di.', 'Mi.', 'Do.', 'Fr.', 'Sa.'],
  weekdaysLong: ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'],
  monthsLong: ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'],
  monthsShort: ['Jan.', 'Feb.', 'März', 'Apr.', 'Mai', 'Juni', 'Juli', 'Aug.', 'Sept.', 'Okt.', 'Nov.', 'Dez.']
});

const state = {
  scheduled: false,
  currentDate: salonTime.initialDate(),
  viewport: null,
  scrollTop: 0,
  scrollLeft: 0,
  userMovedCalendar: false,
  programmaticScroll: false,
  initialPositionKey: '',
  searchOpen: false,
  resizeTimer: 0,
  cardObserver: null,
  observedCards: new WeakSet()
};

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function referenceMinute() {
  return salonTime.referenceMinute();
}

function currentMinute() {
  return salonTime.minute();
}

function formatTime(minute) {
  const normalized = clamp(Math.round(minute), 0, 1439);
  return `${String(Math.floor(normalized / 60)).padStart(2, '0')}:${String(normalized % 60).padStart(2, '0')}`;
}

function effectiveTodayIso() {
  return salonTime.todayIso();
}

function isoDateParts(value) {
  const [year, month, day] = String(value || '').split('-').map(Number);
  if (!year || !month || !day) return null;
  const date = new Date(Date.UTC(year, month - 1, day, 12));
  return { date, year, month, day, weekday: date.getUTCDay() };
}

function formattedHeaderDate(value) {
  const parts = isoDateParts(value);
  if (!parts) return '';
  const compact = matchMedia('(max-width: 760px), (max-width: 900px) and (max-height: 600px)').matches;
  const medium = matchMedia('(max-width: 1450px)').matches;
  if (compact) return `${dateLabels.weekdays[parts.weekday]}, ${parts.day}.${parts.month}.`;
  if (medium) return `${dateLabels.weekdays[parts.weekday]}, ${parts.day}. ${dateLabels.monthsShort[parts.month - 1]}`;
  return `${dateLabels.weekdaysLong[parts.weekday]}, ${parts.day}. ${dateLabels.monthsLong[parts.month - 1]}`;
}

function isToday() {
  return state.currentDate === effectiveTodayIso();
}

function isCompactCalendar() {
  return matchMedia('(max-width: 900px), (max-height: 720px)').matches;
}

function isPortraitCompact() {
  return matchMedia('(max-width: 760px) and (orientation: portrait)').matches;
}

function isLandscapeCompact() {
  return matchMedia('(max-width: 900px) and (max-height: 600px) and (orientation: landscape)').matches;
}

function minutePercent(minute) {
  return clamp((minute - OPEN_MINUTE) / DAY_DURATION * 100, 0, 100);
}

function currentEventPayload(event) {
  return event?.detail?.payload ?? event?.detail?.data ?? event?.detail ?? {};
}

function setText(node, value) {
  if (node && node.textContent !== value) node.textContent = value;
}

function replaceSettingsIcon() {
  root?.querySelectorAll('[data-navigation-id="verwaltung"] svg').forEach((svg) => {
    if (svg.dataset.precisionIcon === 'management') return;
    svg.innerHTML = '<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="7" cy="18" r="2"/>';
    svg.dataset.precisionIcon = 'management';
  });
}

function platformShortcutLabel() {
  const platform = `${navigator.userAgentData?.platform ?? navigator.platform ?? ''} ${navigator.userAgent ?? ''}`;
  return /Mac|iPhone|iPad|iPod/i.test(platform) ? '⌘K' : 'Ctrl K';
}
