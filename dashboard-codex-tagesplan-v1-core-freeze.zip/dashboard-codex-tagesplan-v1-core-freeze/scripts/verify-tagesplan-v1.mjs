import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import vm from 'node:vm';
import { assertAutonomousDocument, assertAutonomyPolicySelfTest } from './tagesplan-v1-autonomy.mjs';

const root = process.cwd();
const builderPath = resolve(root, 'scripts/build-tagesplan-v1.mjs');
const referencePath = resolve(root, 'references/tagesplan/v1.0/tagesplan-reference.html');
const errors = [];

function requireText(html, text, label) {
  if (!html.includes(text)) errors.push(`Tagesplan-Core enthält nicht: ${label}`);
}

function requireAnyText(html, texts, label) {
  if (!texts.some((text) => html.includes(text))) errors.push(`Tagesplan-Core enthält nicht: ${label}`);
}

function forbid(html, pattern, label) {
  if (pattern.test(html)) errors.push(`Tagesplan-Core enthält Verbotenes: ${label}`);
}

function sourceDateEpoch() {
  const value = process.env.SOURCE_DATE_EPOCH;
  if (!/^\d+$/.test(value ?? '')) {
    throw new Error('SOURCE_DATE_EPOCH muss für Doppelbuild und Prüfung als nicht-negative Anzahl Unix-Sekunden gesetzt sein.');
  }

  const milliseconds = Number(value) * 1000;
  const date = new Date(milliseconds);
  if (!Number.isSafeInteger(milliseconds) || Number.isNaN(date.getTime())) {
    throw new Error(`SOURCE_DATE_EPOCH ist ausserhalb des unterstützten Bereichs: ${value}`);
  }
  return value;
}

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

function runBuild(iteration, epoch) {
  const result = spawnSync(process.execPath, [builderPath], {
    cwd: root,
    env: { ...process.env, SOURCE_DATE_EPOCH: epoch },
    encoding: 'utf8',
    maxBuffer: 40 * 1024 * 1024,
    windowsHide: true
  });

  if (result.error) {
    throw new Error(`Deterministischer Build ${iteration}/2 konnte nicht gestartet werden.\n${result.error.message}`);
  }
  if (result.status !== 0) {
    const signal = result.signal ? `; Signal ${result.signal}` : '';
    const details = [result.stdout, result.stderr].filter(Boolean).join('\n').trim();
    throw new Error(
      `Deterministischer Build ${iteration}/2 ist fehlgeschlagen (Exit ${result.status ?? 'unbekannt'}${signal}).${details ? `\n${details}` : ''}`
    );
  }

  let bytes;
  try {
    bytes = readFileSync(referencePath);
  } catch (error) {
    throw new Error(`Build ${iteration}/2 erzeugte kein lesbares Single-HTML-Artefakt.\n${error.message}`);
  }
  return { bytes, hash: sha256(bytes) };
}

let epoch;
let originalBytes;
try {
  assertAutonomyPolicySelfTest();
  epoch = sourceDateEpoch();
  originalBytes = readFileSync(referencePath);
} catch (error) {
  console.error(`Tagesplan-v1-Artefaktprüfung konnte nicht starten:\n- ${error.message}`);
  process.exit(1);
}

let firstBuild;
let secondBuild;
let buildError = null;
let restoreError = null;
try {
  firstBuild = runBuild(1, epoch);
  secondBuild = runBuild(2, epoch);
} catch (error) {
  buildError = error;
} finally {
  try {
    writeFileSync(referencePath, originalBytes);
  } catch (error) {
    restoreError = error;
  }
}

if (restoreError) {
  console.error(`Tagesplan-v1-Artefakt konnte nach der Prüfung nicht wiederhergestellt werden:\n- ${restoreError.message}`);
  process.exit(1);
}
if (buildError) {
  console.error(`Tagesplan-v1-Doppelbuild fehlgeschlagen:\n- ${buildError.message}`);
  process.exit(1);
}

if (firstBuild.hash !== secondBuild.hash || !firstBuild.bytes.equals(secondBuild.bytes)) {
  errors.push(`Doppelbuild ist nicht deterministisch: ${firstBuild.hash} != ${secondBuild.hash}`);
}

const originalHash = sha256(originalBytes);
if (originalHash !== secondBuild.hash || !originalBytes.equals(secondBuild.bytes)) {
  errors.push(`Vorhandenes Single-HTML-Artefakt driftet vom erwarteten Build: vorhanden ${originalHash}, erwartet ${secondBuild.hash}`);
}

const html = secondBuild.bytes.toString('utf8');
const size = secondBuild.bytes.length;
if (size > 5 * 1024 * 1024) errors.push(`Tagesplan-Core ist grösser als 5 MiB: ${size} Bytes`);

const styleTags = html.match(/<style\b[^>]*>/gi) ?? [];
const inlineScripts = [...html.matchAll(/<script\b(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi)];
if (styleTags.length !== 1) errors.push(`Erwartet genau ein eingebettetes Stylesheet, gefunden ${styleTags.length}`);
if (inlineScripts.length !== 1) errors.push(`Erwartet genau ein eingebettetes Skript, gefunden ${inlineScripts.length}`);

try {
  assertAutonomousDocument(html, 'Statisch geprüftes Tagesplan-v1-Artefakt');
} catch (error) {
  errors.push(error.message);
}

forbid(html, /\r/, 'CR-Zeichen statt normalisierter LF-Zeilenenden');
forbid(html, /<link\b[^>]*\brel=["']?stylesheet/i, 'externes Stylesheet');
forbid(html, /<script\b[^>]*\bsrc=/i, 'externes Skript');
forbid(html, /<img\b[^>]*\bsrc=["'](?!data:)/i, 'externes Bild');
forbid(html, /@import\b/i, 'nicht eingebetteter CSS-Import');
forbid(html, /\bimport\s+(?:[^('";]+\s+from\s+)?["']/i, 'ES-Modul-Import');
forbid(html, /\.\.\/\.\.\/(?:src|assets|pages)\//i, 'relativer Projektpfad');
forbid(html, /url\(["']?(?:https?:|\/\/)/i, 'externe CSS-Ressource');
forbid(html, /[A-Za-z]:\\(?:Users|home)\\/i, 'absoluter lokaler Dateipfad');
forbid(html, /experience\.css/i, 'eingebettete Experience-Styles');
forbid(html, /--gw-experience-/i, 'Wirkungssystem-CSS-Token');
forbid(html, /tagesplan-v1\.(?:css|js)/i, 'konkurrierender Legacy-V1-Pfad');
forbid(html, /tp-v1-service-icon/i, 'finale Dienstleistungssymbole');
forbid(html, /tp-v1-empty-habitat/i, 'alpiner Leerzustand');
forbid(html, /kantenblick/i, 'alpines Bildasset');
forbid(html, /data:image\/webp;base64,/i, 'eingebettetes alpines Asset');
forbid(html, /Heute ist es noch erstaunlich ruhig\./i, 'beseelter Leerzustandstext');
forbid(html, /data-gw-beseelung=["']enabled["']/i, 'aktivierte Beseelung');
forbid(html, /meta name=["']gw-generated-at["']/i, 'commitzeitabhängige Build-Metadaten');

[
  ['data-gw-reference="tagesplan-v1"', 'Referenzkennung'],
  ['data-gw-page="tagesplan"', 'Seitentyp'],
  ['meta name="gw-reference-version" content="1.0.0"', 'Version 1.0.0'],
  ['data-gw-core-path="surface-v1"', 'autoritativer Surface-Core-Pfad'],
  ['data-gw-beseelung="disabled"', 'deaktivierte Beseelung'],
  ['experiments/tagesplan-vertical-agenda/surface-v1.css', 'Surface-Core-Stylesheet'],
  ['experiments/tagesplan-vertical-agenda/surface-v1.js', 'Surface-Core-Controller'],
  ['calendarSurfaceClean', 'Single-Surface-Diagnostik'],
  ['calendarVerticalOwnerCount', 'Scrollowner-Diagnostik'],
  ['calendarPrimaryScrollOwner', 'primärer Kalender-Scrollowner'],
  ['calendarSurfaceOverflowX', 'horizontale Mitarbeitendenbewegung'],
  ['calendarDesktopFit', 'Desktop-Ganztagsregime'],
  ['calendarCompactProjection', 'kompaktes Scrollregime'],
  ['vaHourPixels', 'gemessene Stundenhöhe'],
  ['PRIMARY_TIME_ANCHORS', 'Definition der starken Zeitanker'],
  ['new Set([540, 720, 900, 1080])', 'exakte Anker-Minuten 09:00, 12:00, 15:00 und 18:00'],
  ['PRIMARY_TIME_ANCHORS.has(minute)', 'Anwendung der starken Zeitanker'],
  ['is-primary-anchor', 'sichtbare Klasse der starken Zeitanker'],
  ['Als Nächstes', 'Kopfzeilenagenda']
].forEach(([text, label]) => requireText(html, text, label));

[
  [['tpRenderState', 'data-tp-render-state'], 'Render-ready-Signal'],
  [['tpLayoutState', 'data-tp-layout-state'], 'Layout-stable-Signal'],
  [['tpDiagnosticsVersion', 'data-tp-diagnostics-version'], 'versionierte Layoutdiagnostik']
].forEach(([texts, label]) => requireAnyText(html, texts, label));

if (inlineScripts.length === 1) {
  try {
    new vm.Script(inlineScripts[0][1], { filename: 'tagesplan-reference.inline.js' });
  } catch (error) {
    errors.push(`Eingebettetes JavaScript ist syntaktisch ungültig: ${error.message}`);
  }
}

if (errors.length) {
  console.error(`Tagesplan-v1-Core-Prüfung fehlgeschlagen (${errors.length}):`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`✓ Vorhandenes Tagesplan-v1-Artefakt entspricht dem erwarteten lokalen Build: SHA-256 ${secondBuild.hash}.`);
console.log(`✓ Deterministischer Doppelbuild identisch und SOURCE_DATE_EPOCH ${epoch} validiert (${Math.round(size / 1024)} KiB).`);