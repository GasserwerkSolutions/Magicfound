# Kontrollprotokoll · Tagesplan v1.0 · Führender Chat

## Grundsatz

Codex implementiert. Der führende Chat bleibt Produkt-, Architektur- und Freeze-Freigabeinstanz. Ein grüner CI-Lauf ist notwendig, aber nicht hinreichend.

## Nach jedem Codex-Meilenstein einzureichen

- Codex-PR-URL;
- Base- und Head-SHA;
- geänderte und gelöschte Dateien;
- Architekturentscheidungen;
- lokale Testbefehle und Ergebnisse;
- GitHub-Actions-Läufe;
- Evidenzartefakt;
- Einzelbilder 1512×982, 1366×768, 390×844 und 844×390;
- maschinenlesbare Ready-/Scroll-/Overflow-Messwerte;
- bekannte Risiken;
- exakt formulierte offene Entscheidungen.

## Freigabestufen

```text
Architekturpfad freigegeben.
Gate A Geometrie freigegeben.
Gate B Funktion und Zustände freigegeben.
Gate C Accessibility und Resilienz freigegeben.
Freeze Candidate technisch abgenommen.
Core Freeze freigegeben. Finalen Tag setzen.
```

Ohne die jeweilige explizite Formel gilt keine stille oder implizite Freigabe.

## Kontrolle 1 · Architektur

- Root Cause des Ready-/Diagnosefehlers belegt;
- genau ein autoritativer V1-Pfad;
- Experiment, Test und Golden Master verwenden denselben Pfad;
- Tests nicht geschwächt;
- Produktsemantik unverändert.

## Kontrolle 2 · Geometrie

- 1512×982 Master;
- 1920×1080 Expansion;
- 1366×768 Stresstest;
- 110 % und 125 %;
- 390×844 und 844×390;
- Agenda und Fokus;
- horizontale Mitarbeitendenbewegung;
- Messwerte stimmen mit Screenshots überein;
- keine abgeschnittenen Inhalte oder versteckten Scrollbars.

## Kontrolle 3 · Funktion und Zustände

- Zeitwahrheit;
- Agenda, Fokus, Suche und Auswahl;
- normal, stress, quiet, empty, loading, error, offline, stale und forbidden;
- vor Öffnung, während Betrieb, nach Schluss;
- Vergangenheit und Zukunft;
- kein stiller Inhaltsverlust;
- keine aktive Beseelung im Core.

## Kontrolle 4 · Accessibility und Resilienz

- Tastatur und logische Tab-Reihenfolge;
- sichtbarer Fokus;
- Escape-Hierarchie;
- Fokuswiederherstellung;
- zugängliche Namen;
- Touchziele;
- Reduced Motion;
- Fehler-/Offline-/Berechtigungszustände;
- Chromium, Firefox und WebKit.

## Kontrolle 5 · Artefaktintegrität

- Single HTML lokal und per HTTP;
- keine externe Ressource;
- deterministischer Doppelbuild;
- Manifest und Checksummen;
- Source-/Artifact-Commit-Modell;
- bereinigter Branch;
- zwei grüne Kontrollläufe.

## Tag-Sperre

Der finale Tag `tagesplan-v1.0-core-freeze` darf erst nach der wortwörtlichen Freigabe gesetzt werden:

```text
Core Freeze freigegeben. Finalen Tag setzen.
```

## Nach dem Freeze

Beseelungsvarianten zweigen ausschließlich vom finalen Tag ab. Geprüft werden nur additive Wirkungskanäle. Änderungen an Daten, Geometrie, Status, Fokus, Suche, Scroll oder Tastatursemantik sind unzulässig.
