const ASCII_WHITESPACE = '[\\t\\n\\f\\r ]';
const ATTRIBUTE_VALUE = '(?:"([^"\\r\\n]*)"|\'([^\'\\r\\n]*)\'|([^\\s>\'"`]+))';

function cssScanText(css) {
  const withoutComments = css.replace(/\/\*[\s\S]*?\*\//g, ' ');
  const decoded = withoutComments.replace(/\\([0-9a-f]{1,6}[\t\n\f\r ]?|[\s\S])/gi, (_match, escape) => {
    const hexadecimal = /^[0-9a-f]{1,6}/i.exec(escape)?.[0];
    if (hexadecimal) {
      const codePoint = Number.parseInt(hexadecimal, 16);
      return codePoint === 0 || codePoint > 0x10ffff || (codePoint >= 0xd800 && codePoint <= 0xdfff)
        ? '\uFFFD'
        : String.fromCodePoint(codePoint);
    }
    return /^[\n\f\r]/.test(escape) ? '' : escape;
  });
  if (decoded.includes('\\')) {
    throw new Error('CSS enthält eine unvollständige oder nicht auswertbare Escape-Sequenz.');
  }
  return decoded;
}

function allowedEmbeddedReference(value, { fragment = false } = {}) {
  const target = value.trim();
  if (/^data:/i.test(target)) return true;
  return fragment && /^#[A-Za-z_][A-Za-z0-9_.:-]*$/.test(target);
}

function attributeValues(source, name) {
  const pattern = new RegExp(`\\b${name}\\s*=\\s*${ATTRIBUTE_VALUE}`, 'giu');
  return [...source.matchAll(pattern)].map((match) => match.slice(1, 4).find((value) => value !== undefined) ?? '');
}

function openingTags(source, names) {
  const pattern = new RegExp(`<(?:${names.join('|')})\\b[^>]*>`, 'giu');
  return [...source.matchAll(pattern)].map((match) => match[0]);
}

export function assertEmbeddedCssResources(css, label = 'CSS') {
  const scan = cssScanText(css);
  const urlPattern = new RegExp(
    `(?<![-_a-z0-9])url${ASCII_WHITESPACE}*\\(${ASCII_WHITESPACE}*(?:"([^"\\r\\n]*)"|'([^'\\r\\n]*)'|([^'"\\)\\r\\n]*))${ASCII_WHITESPACE}*\\)`,
    'gimu'
  );
  const potentialUrlPattern = new RegExp(`(?<![-_a-z0-9])url${ASCII_WHITESPACE}*\\(`, 'imu');
  let scrubbed = '';
  let cursor = 0;

  for (const match of scan.matchAll(urlPattern)) {
    const target = match.slice(1, 4).find((value) => value !== undefined) ?? '';
    if (!allowedEmbeddedReference(target, { fragment: true })) {
      throw new Error(`${label} enthält eine nicht eingebettete CSS-url-Ressource: ${JSON.stringify(target.trim())}`);
    }
    scrubbed += scan.slice(cursor, match.index);
    scrubbed += ' '.repeat(match[0].length);
    cursor = match.index + match[0].length;
  }
  scrubbed += scan.slice(cursor);

  if (potentialUrlPattern.test(scrubbed)) {
    throw new Error(`${label} enthält eine mehrdeutige oder nicht vollständig auswertbare CSS-url-Ressource.`);
  }
}

export function assertAutonomousDocument(html, label = 'Single-HTML-Artefakt') {
  const styleBlocks = [...html.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/giu)];
  styleBlocks.forEach((match, index) => assertEmbeddedCssResources(match[1], `${label}, Styleblock ${index + 1}`));
  attributeValues(html, 'style').forEach((value, index) => assertEmbeddedCssResources(value, `${label}, style-Attribut ${index + 1}`));

  if (/<script\b[^>]*\bsrc\s*=/iu.test(html)) throw new Error(`${label} enthält ein script-src.`);
  if (/<(?:iframe|embed)\b[^>]*\bsrc\s*=/iu.test(html)) throw new Error(`${label} enthält eine eingebettete ausführbare src-Ressource.`);
  if (/<object\b[^>]*\bdata\s*=/iu.test(html)) throw new Error(`${label} enthält eine object-data-Ressource.`);
  if (/<base\b[^>]*\bhref\s*=/iu.test(html)) throw new Error(`${label} enthält ein base-href.`);
  if (/<meta\b[^>]*\bhttp-equiv\s*=\s*["']?refresh\b/iu.test(html)) throw new Error(`${label} enthält eine Meta-Weiterleitung.`);

  for (const target of attributeValues(html, 'src')) {
    if (!allowedEmbeddedReference(target)) throw new Error(`${label} enthält eine nicht eingebettete src-Ressource: ${JSON.stringify(target.trim())}`);
  }
  for (const target of attributeValues(html, 'poster')) {
    if (!allowedEmbeddedReference(target)) throw new Error(`${label} enthält eine nicht eingebettete poster-Ressource: ${JSON.stringify(target.trim())}`);
  }
  for (const target of attributeValues(html, 'srcset')) {
    if (!/^data:[^\t\n\f\r ]+$/i.test(target.trim())) {
      throw new Error(`${label} enthält ein nicht eindeutig eingebettetes srcset: ${JSON.stringify(target.trim())}`);
    }
  }
  for (const target of attributeValues(html, 'xlink:href')) {
    if (!allowedEmbeddedReference(target, { fragment: true })) {
      throw new Error(`${label} enthält eine nicht eingebettete xlink:href-Ressource: ${JSON.stringify(target.trim())}`);
    }
  }

  for (const tag of openingTags(html, ['link'])) {
    const relation = attributeValues(tag, 'rel').join(' ').toLowerCase().split(/\s+/).filter(Boolean);
    const targets = attributeValues(tag, 'href');
    if (relation.includes('stylesheet') && targets.length) throw new Error(`${label} enthält ein Link-Stylesheet.`);
    const embeddedIcon = relation.some((value) => value.includes('icon'));
    for (const target of targets) {
      if (!embeddedIcon || !allowedEmbeddedReference(target)) {
        throw new Error(`${label} enthält eine nicht eingebettete oder nicht erlaubte Link-Ressource: ${JSON.stringify(target.trim())}`);
      }
    }
  }

  for (const tag of openingTags(html, ['image', 'use', 'feimage'])) {
    for (const target of attributeValues(tag, 'href')) {
      if (!allowedEmbeddedReference(target, { fragment: true })) {
        throw new Error(`${label} enthält eine nicht eingebettete SVG-href-Ressource: ${JSON.stringify(target.trim())}`);
      }
    }
  }

  const runtimeLoaders = [
    [/\bimport\s*\(/iu, 'dynamischen import()'],
    [/\bfetch\s*\(/iu, 'fetch()'],
    [/\bXMLHttpRequest\b/iu, 'XMLHttpRequest'],
    [/\bWebSocket\s*\(/iu, 'WebSocket'],
    [/\bEventSource\s*\(/iu, 'EventSource'],
    [/\bnavigator\s*\.\s*sendBeacon\s*\(/iu, 'sendBeacon()'],
    [/\bnavigator\s*\.\s*serviceWorker\s*\.\s*register\s*\(/iu, 'Service-Worker-Registrierung'],
    [/\bimportScripts\s*\(/iu, 'importScripts()'],
    [/\b(?:Shared)?Worker\s*\(/iu, 'Worker-Konstruktor'],
    [/\bnew\s+(?:Audio|FontFace)\s*\(/iu, 'dynamischen Medien-/Font-Loader'],
    [/\bsetAttribute\s*\(\s*["'](?:src|srcset|poster|xlink:href)["']/iu, 'dynamischen Ressourcen-Attribut-Setter'],
    [/\baddModule\s*\(/iu, 'Worklet-Modul-Loader']
  ];
  for (const [pattern, description] of runtimeLoaders) {
    if (pattern.test(html)) throw new Error(`${label} enthält einen dynamischen Runtime-Loader: ${description}.`);
  }
}

export function assertAutonomyPolicySelfTest() {
  const rejectedCss = [
    ['relative URL in @media print', '@media print { .proof { background: url("./print-leak.png") } }'],
    ['remote URL', '.proof { background: url(https://example.test/leak.png) }'],
    ['absolute URL', '.proof { mask-image: url("/absolute/leak.svg") }'],
    ['file URL', '.proof { src: url(file:///tmp/leak.woff2) }'],
    ['blob URL', '.proof { background: url(blob:https://example.test/id) }'],
    ['protocol-relative URL', '.proof { background: url(//example.test/leak.png) }'],
    ['escaped URL function', '.proof { background: u\\72l("./escaped-leak.png") }']
  ];
  for (const [name, css] of rejectedCss) {
    let rejected = false;
    try { assertEmbeddedCssResources(css, `Negativprobe ${name}`); }
    catch { rejected = true; }
    if (!rejected) throw new Error(`Autarkie-Negativprobe wurde akzeptiert: ${name}.`);
  }

  assertEmbeddedCssResources(
    '.data { background: url("data:image/svg+xml,%3Csvg%3E%3C/svg%3E") } .fragment { filter: url(#surface-filter) }',
    'Autarkie-Positivprobe'
  );
  assertAutonomousDocument(
    '<style>@media print { .x { background:url(data:image/png;base64,AA==) } }</style><img src="data:image/png;base64,AA=="><link rel="icon" href="data:image/png;base64,AA=="><svg><use href="#surface-icon"></use></svg>',
    'Autarkie-Dokument-Positivprobe'
  );

  const rejectedDocuments = [
    ['relative src', '<img src="./leak.png">'],
    ['absolute poster', '<video poster="/leak.png"></video>'],
    ['remote srcset', '<img srcset="https://example.test/leak.png 1x">'],
    ['relative icon', '<link rel="icon" href="./favicon.png">'],
    ['stylesheet href', '<link rel="stylesheet" href="data:text/css,body{}">'],
    ['relative SVG href', '<svg><image href="./leak.svg"></image></svg>'],
    ['runtime fetch', '<script>fetch("./leak.json")</script>']
  ];
  for (const [name, html] of rejectedDocuments) {
    let rejected = false;
    try { assertAutonomousDocument(html, `Negativprobe ${name}`); }
    catch { rejected = true; }
    if (!rejected) throw new Error(`Autarkie-Dokument-Negativprobe wurde akzeptiert: ${name}.`);
  }
}
