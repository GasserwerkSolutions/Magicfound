function searchButtonMarkup() {
  return `<button class="gw-button gw-button-quiet va-search-toggle" type="button" data-mobile-search-toggle aria-controls="gw-global-search" aria-expanded="${state.searchOpen}" aria-label="Suche öffnen">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>
  </button>`;
}

function ensureSearchControls() {
  const header = root?.querySelector('.gw-product-header');
  const search = root?.querySelector('.gw-header-search');
  const input = root?.querySelector('#gw-global-search');
  const actions = root?.querySelector('#gw-header-actions');
  if (!header || !search || !input || !actions) return;

  input.placeholder = 'Name, Termin oder freie Zeit suchen';
  input.setAttribute('aria-label', 'Name, Termin oder freie Zeit suchen');
  const shortcut = search.querySelector('kbd');
  setText(shortcut, platformShortcutLabel());

  if (!actions.querySelector('[data-mobile-search-toggle]')) {
    actions.insertAdjacentHTML('afterbegin', searchButtonMarkup());
  }
  const toggle = actions.querySelector('[data-mobile-search-toggle]');
  toggle?.setAttribute('aria-expanded', String(state.searchOpen));
  header.classList.toggle('is-mobile-search-open', state.searchOpen);

  const mode = isLandscapeCompact() ? 'field' : isPortraitCompact() ? 'icon' : 'desktop';
  if (root) root.dataset.searchMode = mode;
}

function ensureHeaderPrecision() {
  const kicker = root?.querySelector('.gw-page-kicker');
  setText(kicker, 'TAGESPLAN');
  if (root) root.dataset.kickerPrecision = kicker?.textContent === 'TAGESPLAN' ? '1' : '0';

  const dateButton = root?.querySelector('[data-open-date-picker]');
  const dateLabel = dateButton?.querySelector('span');
  const formatted = formattedHeaderDate(state.currentDate);
  if (formatted) setText(dateLabel, formatted);
  dateButton?.setAttribute('aria-label', `${formatted || 'Datum'} wählen`);

  const accountName = root?.querySelector('.gw-account-card strong');
  accountName?.setAttribute('title', accountName.textContent.trim());

  ensureSearchControls();
  replaceSettingsIcon();
  ensureNowButton();
}

function ensureNowButton() {
  const actions = root?.querySelector('#gw-header-actions');
  if (!actions) return;
  let nowControl = actions.querySelector('.va-header-now');
  if (nowControl && nowControl.tagName !== 'BUTTON') {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = nowControl.className;
    button.textContent = nowControl.textContent;
    nowControl.replaceWith(button);
    nowControl = button;
  }
  if (!nowControl) return;
  nowControl.type = 'button';
  nowControl.dataset.jumpToNow = '';
  nowControl.setAttribute('aria-label', `Zu jetzt springen, ${nowControl.textContent.trim()}`);

  const sidebarVisible = Boolean(root.querySelector('.gw-sidebar-v2')?.getClientRects().length);
  const pillVisible = Boolean(nowControl.getClientRects().length);
  root.dataset.desktopTimePillCount = String(sidebarVisible && pillVisible ? 1 : 0);
}
