# AGENTS.md · Gasserwerk Tagesplan v1.0

## Scope

Diese Regeln gelten für alle Arbeiten am Tagesplan-v1-Core-Freeze.

Lies zuerst vollständig und in dieser Reihenfolge:

- `docs/CODEX_HANDOFF_TAGESPLAN_V1_CORE_FREEZE.md`
- `docs/CODEX_TAGESPLAN_TIME_AND_CARD_IMPLEMENTATION.md`
- `docs/TAGESPLAN_V1_EXECUTION_CONTRACT.md`
- `docs/TAGESPLAN_V1_FREEZE_POLICY.md`
- `docs/decisions/ADR-004-vertical-day-agenda.md`
- `docs/decisions/ADR-005-collapsible-header-agenda.md`
- `docs/decisions/ADR-007-tagesplan-v1-golden-master.md`
- `docs/decisions/ADR-008-technical-freeze-before-beseelung.md`
- `docs/decisions/ADR-009-calendar-surface-before-appointment-cards.md`
- `references/tagesplan/v1.0/CONTRACT.md`

Bei einem Widerspruch zur älteren Freeze-Dokumentation präzisiert ADR-009 die Reihenfolge und den Umfang der neutralen Dienstleistungssymbole.

## Mission

Erzeuge einen neutralen, reproduzierbaren und vollständig geprüften technischen Core Freeze des Tagesplans v1.0. Beseelung beginnt erst nach dem unveränderlichen Freeze.

Die Ausführungsfolge innerhalb des Tagesplans lautet verbindlich:

```text
Kalenderfläche und Zeitwahrheit
→ Terminkarten und Dienstleistungssemantik
→ technischer Core Freeze
→ Beseelungsvarianten
```

`Termine` meint in dieser Reihenfolge die Terminkarten des Tagesplans, nicht die separate Produktseite `Termine`.

## Branching

- Ausgang: `feat/tagesplan-v1-golden-master`
- Codex-Arbeit: `codex/tagesplan-v1-core-freeze`
- Ziel des Codex-PR: `feat/tagesplan-v1-golden-master`
- Nie direkt auf `main` oder `feat/canonical-product-surface-v1` arbeiten.

## Non-negotiable

- Zeit vertikal, Mitarbeitende horizontal, 08:00–18:00.
- Eine Kalender-Surface.
- Global vergangene Zeitfläche; keine zeitlichen Kartentöne.
- Jetzt-Linie oberhalb des Rasters und hinter Terminkarten.
- Jetzt-Linie niemals über Karteninhalt oder Text.
- Fokus bleibt in derselben Teamfläche.
- Agenda ist ein nicht-modales Kopfzeilen-Popover.
- Keine still versteckten Inhalte.
- No-scroll Desktop nur bei mindestens 44 px/Stunde.
- Kompakt: exakt ein vertikaler Scroll-Owner im Kalender.
- Semantische Kartenkürzung statt zufälliger Ellipse.
- Neutrales hochwertiges SVG-Dienstleistungssymbolsystem ist Teil der Terminkartenphase und des Core Freeze.
- Keine alpine oder atmosphärische Beseelung im Core Freeze.

## Forbidden

- Tests zum Bestehen abschwächen.
- Scrollbars nur verstecken.
- separate Produktseite `Termine` beginnen.
- Terminkarten vor stabiler Kalenderfläche visuell finalisieren.
- zeitliche Kartentöne für vergangen, laufend oder künftig einführen.
- Jetzt-Linie über Kartentext legen.
- Emoji, Icon-Font oder externe Symbolressource verwenden.
- alpine Szene, Murmeltier oder emotionale Variante aktivieren.
- PR #3 mergen oder ready setzen.
- öffentliche Pages-Veröffentlichung auslösen.
- finalen Freeze-Tag ohne explizite Chatfreigabe setzen.
- Produktsemantik still ändern.

## Current technical focus

### Zuerst · Kalenderfläche

- Ready-/Layout-stable-Handshake herstellen.
- `surface-v1.*` und `tagesplan-v1.*` zu einem autoritativen Pfad konsolidieren.
- Experimentseite, Test und Single-HTML-Build auf denselben Pfad bringen.
- globale vergangene Zeitfläche und Jetzt-Linie nach `docs/CODEX_TAGESPLAN_TIME_AND_CARD_IMPLEMENTATION.md` herstellen.
- Zeitquelle `Europe/Zurich`, Minutenwechsel und Wiederaufnahme synchronisieren.
- alle Scroll-, Fokus- und Agenda-Invarianten nachweisen.

### Danach · Terminkarten

- Karteninformation nach realer Breite und Höhe staffeln.
- hochwertiges neutrales Inline-SVG-System für Schnitt, Farbe, Balayage/Highlights, Glossing/Tönung, Pflege, Beratung, Föhnen/Styling, Aufgabe, Pause und Fallback herstellen.
- Symbole ausschließlich fachlich, monochrom und statusneutral verwenden.
- vollständige Accessibility- und Kartenmatrix prüfen.

### Abschluss · Freeze

- `scripts/.tagesplan-v1-payload-01.part` und weitere temporäre Reste entfernen.
- Build mit gepinnter Toolchain und `SOURCE_DATE_EPOCH` deterministisch machen.
- Chromium, Firefox und WebKit prüfen.
- vollständiges Freeze-Paket erzeugen.

## Stop and ask

Stoppe bei jedem Konflikt zwischen Vertrag, Lesbarkeit, Touchziel, Browserabdeckung, Zeitwahrheit, Dienstleistungssemantik oder Testannahme. Liefere Optionen und Evidenz; triff keine stille Produktentscheidung.

## Reporting

Verwende das Berichtsschema im Codex-Handoff. Behaupte keinen Abschluss bei rotem Pflichtgate.
