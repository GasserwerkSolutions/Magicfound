# Gasserwerk Dashboard · offene Vertragsfragen

Status: **laufende Liste; offene Punkte werden nicht stillschweigend implementiert**

## Arbeitsregel

Diese Liste trennt drei Arten offener Punkte:

- **B – blockiert Referenzimplementierung:** Ohne Entscheid kann die Seite nicht korrekt gebaut werden.
- **I – blockiert erst Produktionsintegration:** Die Referenz kann mit Mock-Daten umgesetzt werden; der Backendadapter braucht später einen Entscheid.
- **V – Verfeinerung:** Produkt funktioniert ohne Entscheid, kann danach präzisiert werden.

Ein Punkt wird nur entfernt, wenn die Entscheidung in den gemeinsamen oder betreffenden Seitenvertrag übernommen wurde.

## Übergreifend

### Q-001 · Produktionsframework

**Klasse:** I

Welches Framework und welcher Routing-/State-Ansatz wird in der echten Anwendung verbindlich verwendet?

Der Referenzcode bleibt bis dahin frameworkneutral. Diese Frage darf keine HTML-/CSS-Qualität blockieren.

### Q-002 · stabile fachliche IDs

**Klasse:** I

Welche stabilen IDs liefert das Backend für Salon, Standort, Account, Kundschaft, Mitarbeitende, Dienstleistungen, Termine und operative Blöcke?

Die Referenz verwendet deterministische Fixture-IDs. Die Produktionsintegration darf Namen nicht als dauerhafte Identität verwenden.

### Q-003 · Rollen- und Capability-Matrix

**Klasse:** I

Welche Produktrollen existieren ausser `Inhaberin`, und welche Capabilities erhalten sie?

Fachliche Teamrollen wie `Top Stylistin`, `Stylistin`, `Lernende` und `Barber` sind keine Berechtigungsrollen.

### Q-004 · Salon-Zeitzone und Zeitquelle

**Klasse:** I

Kommt die autoritative aktuelle Zeit vom Server, vom Client oder aus einer synchronisierten Serverabweichung? Wie wird die Salon-Zeitzone pro Standort geliefert?

Für die Referenz wird eine kontrollierbare Uhr verwendet. Die Produktionsanwendung muss Uhrabweichungen und Sommerzeit berücksichtigen.

### Q-005 · Fehlerformat

**Klasse:** I

Welches normalisierte Fehlerobjekt liefert der Produktionsadapter für Validierung, Berechtigung, Konflikt, Netzwerk und unbekannte Fehler?

Die UI benötigt mindestens `kind`, `message`, `retryable`, `fieldErrors` und `correlationId`.

### Q-006 · Offline- und Stale-Strategie

**Klasse:** I

Welche Daten dürfen offline beziehungsweise veraltet weiter angezeigt oder bearbeitet werden? Wie wird ein späterer Konflikt behandelt?

Die Referenz stellt `offline` und `stale` dar, verspricht aber keine Offline-Mutation.

### Q-007 · Mehrstandortfähigkeit

**Klasse:** I

Ist ein Account genau einem Standort zugeordnet oder kann er zwischen mehreren Standorten wechseln? Welche Seitenzustände bleiben bei einem Standortwechsel erhalten?

### Q-008 · Audit und Datenschutz

**Klasse:** I

Welche Änderungen müssen protokolliert werden? Welche Kundendaten und internen Notizen gelten als besonders schützenswert? Welche Aufbewahrungs- und Löschregeln gelten?

## Tagesplan

### Q-DAY-001 · Arbeits- und Öffnungszeiten

**Klasse:** I

Werden Öffnungszeiten, individuelle Arbeitszeiten und Ausnahmen als getrennte Daten geliefert? Welche Quelle entscheidet, ob eine freie Fläche tatsächlich buchbar ist?

### Q-DAY-002 · Überschneidungs- und Konfliktregeln

**Klasse:** I

Welche Überlappungen sind erlaubt, welche nur mit Warnung und welche verboten? Berücksichtigt die Prüfung Mitarbeitende, Räume, Geräte oder parallele Phasen einer Dienstleistung?

### Q-DAY-003 · Dienstleistungsphasen

**Klasse:** I

Wie werden mehrphasige Termine fachlich modelliert? Die bestehende Referenz kennt `visitStep`, erfindet aber kein allgemeines Phasenmodell.

### Q-DAY-004 · Live-Rückkehrdauer

**Klasse:** V

Die Produktoberfläche erlaubt eine automatische Rückkehr nach 20–30 Sekunden echter Inaktivität. Der aktuelle Referenzwert darf 25 Sekunden betragen. Muss dieser Wert konfigurierbar sein?

### Q-DAY-005 · Tagesgrenzen

**Klasse:** I

Können Termine ausserhalb der offiziellen Öffnungszeit liegen? Wie werden Vorbereitungs-, Nachbearbeitungs- und Nachtschichten dargestellt?

## Termine

### Q-APT-001 · erlaubte Statusübergänge

**Klasse:** I

Welche Übergänge zwischen `pending`, `confirmed`, `arrived`, `completed`, `cancelled` und `no-show` sind erlaubt? Welche benötigen einen Grund oder eine Bestätigung?

### Q-APT-002 · Bestätigungskanäle

**Klasse:** I

Welche Kommunikationskanäle existieren für Anfrage, Bestätigung, Erinnerung und Absage? Liefert das Backend einen Versandstatus?

### Q-APT-003 · Preis und Zahlung

**Klasse:** I

Ist der Terminpreis ein Angebot, eine Momentaufnahme der Dienstleistung oder ein abrechenbarer Betrag? Wie werden Rabatte, Trinkgeld, MwSt. und Teilzahlungen behandelt?

## Kundschaft

### Q-CUS-001 · Kundenfelder

**Klasse:** I

Welche Felder sind verbindlich, welche optional und welche standort- oder salonkonfigurierbar? Dazu gehören E-Mail, Adresse, Geburtstag, bevorzugter Kontakt, Tags, Allergien und Rezepturen.

### Q-CUS-002 · vertrauliche Notizen

**Klasse:** I

Welche Notizarten benötigen eine eigene Capability, Protokollierung oder zeitliche Begrenzung?

### Q-CUS-003 · Dubletten und Zusammenführen

**Klasse:** I

Wie werden doppelte Kundenprofile erkannt und zusammengeführt? Welche Referenzen müssen beim Merge erhalten bleiben?

### Q-CUS-004 · Laufkundschaft

**Klasse:** I

Wann wird aus `Laufkundschaft` ein dauerhaftes Kundenprofil? Darf ein Termin ohne stabile Kunden-ID bestehen bleiben?

## Team

### Q-STAFF-001 · Beschäftigungs- und Verfügbarkeitsmodell

**Klasse:** I

Welche Daten beschreiben Vertragsumfang, reguläre Arbeitszeiten, Ausnahmen, Ferien, Krankheit und temporäre Einsatzorte?

### Q-STAFF-002 · fachliche Rolle versus Berechtigung

**Klasse:** I

Welche Kombinationen aus fachlicher Salonrolle und Produktberechtigungsrolle sind erlaubt? Werden beide unabhängig verwaltet?

### Q-STAFF-003 · Deaktivierung

**Klasse:** I

Wie werden ehemalige Mitarbeitende behandelt, deren historische Termine erhalten bleiben müssen?

## Angebot

### Q-SVC-001 · Varianten und Zusatzleistungen

**Klasse:** I

Sind Varianten eigene Dienstleistungen oder konfigurierbare Optionen? Wie werden Haarlänge, Materialzuschlag und Zusatzleistungen modelliert?

### Q-SVC-002 · Ressourcen und Phasen

**Klasse:** I

Kann eine Dienstleistung mehrere Mitarbeitende, Räume oder Geräte benötigen? Wie werden Einwirkzeiten und parallele Arbeit modelliert?

### Q-SVC-003 · Preis- und Dauerregeln

**Klasse:** I

Sind Preis und Dauer feste Werte, Bereiche oder abhängig von Person, Standort, Variante und Kundschaft?

## Verwaltung

### Q-ADM-001 · Integrationskatalog

**Klasse:** I

Welche Integrationen werden produktiv unterstützt, und welche Zustände brauchen sie: nicht verbunden, verbindet, verbunden, Fehler, erneute Autorisierung?

### Q-ADM-002 · Plan und Abrechnung

**Klasse:** I

Welche Accountrollen dürfen Vertrag, Plan, Rechnungen und Zahlungsmittel sehen oder ändern?

### Q-ADM-003 · Marken- und Standortvererbung

**Klasse:** I

Welche Einstellungen gelten global, pro Salon oder pro Standort?

## Login

### Q-AUTH-001 · Authentifizierungsmethoden

**Klasse:** I

Welche Methoden werden produktiv unterstützt: Passwort, Magic Link, SSO, Passkey oder Kombinationen?

### Q-AUTH-002 · MFA und sensible Aktionen

**Klasse:** I

Ist Mehrfaktor-Authentifizierung erforderlich? Müssen administrative Änderungen erneut bestätigt werden?

### Q-AUTH-003 · Sessionverhalten

**Klasse:** I

Wie lange gilt eine Session, wie werden parallele Sitzungen behandelt und wohin führt ein abgelaufener Login zurück?

## Onboarding

### Q-ONB-001 · Pflicht- und optionale Schritte

**Klasse:** I

Sind alle fünf Referenzschritte verpflichtend? Welche können übersprungen und später nachgeholt werden?

### Q-ONB-002 · Fortschrittsbesitz

**Klasse:** I

Gilt der Onboardingfortschritt pro Account, Salon oder Standort? Dürfen mehrere Personen gleichzeitig fortfahren?

### Q-ONB-003 · Aktivierungsgrenze

**Klasse:** I

Welche minimale Datenmenge macht einen Salon tatsächlich buchbar? Die Referenz verwendet Salonprofil, Dienstleistungen, Team und Arbeitszeiten als Kette, aber die Backendvalidierung ist noch offen.
