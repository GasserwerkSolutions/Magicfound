# ADR-003 · Vollständige Tageslandkarte, Arbeitsuhr und integrierte Verwaltung

Status: **Teilweise abgelöst durch ADR-004 – Arbeitsuhr, Navigation und Verwaltung bleiben gültig**  
Datum: 2026-08-24  
Betroffene Bereiche: Produktschale, Tagesplan, Navigation, Verwaltung

> ADR-004 löst ausschließlich die horizontale Tagesplangeometrie ab. Die feste Arbeitsuhr, die vierteilige Hauptnavigation und die integrierte card-first Verwaltung aus ADR-003 bleiben verbindlich.

## Kontext

Der bisherige operative Tagesplan zeigt auf Desktop vier Stunden pro sichtbarer Zeitfläche. Dieser Massstab verbessert die Kartenproportionen, verbirgt jedoch grosse Teile des Arbeitstages und benötigt zusätzliche Regeln für Live-Follow, manuelle Entkopplung, Jetzt-Rückkehr und automatische Rückkehr.

Parallel liegt eine erweiterte Referenz vor, in der Angebot, Team, Standorte und Verfügbarkeit card-first in die Verwaltung integriert sind und eine feste Arbeitsuhr in der Desktop-Seitenleiste verwendet wird.

Die visuelle Prüfung der ersten vollständigen Tageslandkarte zeigt zusätzlich: Zeitangaben in jeder Terminkarte wiederholen eine Information, die bereits durch Position und Zeitachse gegeben ist. Diese Wiederholung nimmt auf kurzen Karten wertvollen Raum ein und schwächt die Lesbarkeit der gemeinsamen Zeitlinie.

## Entscheidung

### 1. Ein kontinuierlicher Arbeitstag mit zwei leisen Tagesphasen

Auf Desktop und kompakten Laptop-Viewports wird der vollständige Arbeitstag in einem einzigen Zeitkoordinatenraum dargestellt.

- Vormittag: Öffnung bis Periodengrenze
- Nachmittag: Periodengrenze bis Schliessung
- Standardgrenze für `08:00–18:00`: `13:00`
- Breiten werden aus realen Minuten berechnet und nicht pauschal auf 50/50 gesetzt.
- Ein Termin über die Periodengrenze bleibt eine durchgehende Karte.
- Vormittag und Nachmittag sind weder Tabs noch getrennte Kalender.
- Die Tagesphasen bleiben visuell zurückhaltend; die kontinuierliche Zeitlinie ist die primäre Orientierung.

### 2. Stabile Tageslandkarte statt horizontaler Live-Nachführung

Auf Desktop ist der gesamte Tag sichtbar. Die aktuelle Zeit bewegt sich als mathematisch korrekter Cursor durch die stabile Tageslandkarte.

Entfallen im Desktop-Volltag:

- permanentes horizontales Live-Follow
- fixer Jetzt-Anker
- richtungsabhängige Jetzt-Rückkehr
- automatischer Rücksprung nach Inaktivität
- horizontaler Scrollbalken
- zusätzlicher Massstabswechsel „Ganzer Tag“, sofern die Tageslandkarte vollständig sichtbar ist

Erhalten bleiben:

- dünne Jetzt-Linie
- kompaktes Zeitlabel
- 15-/30-/60-Minuten-Raster
- Terminbreite proportional zur realen Dauer
- zusätzliche Bahnen nur bei echten Überschneidungen

### 3. Die Zeitachse trägt das Wann

Die sichtbare Startzeit wird aus Terminkarten in der Tageslandkarte entfernt.

- Position und Breite kommunizieren Start, Ende und Dauer.
- `aria-label`, Fokuszustand und Kontextpanel behalten die vollständige Zeitinformation.
- Die Karte priorisiert Kundschaft, Dienstleistung und Status.
- Bis 30 Minuten werden Initialen gezeigt.
- Ab 30 Minuten wird die Kundschaft gezeigt.
- Ab 60 Minuten kann zusätzlich die Dienstleistung erscheinen.
- Karten werden nicht unabhängig von der realen Dauer verkürzt.

Die Zeitachse erhält eine klare Hierarchie:

- 15 Minuten: feinste Rasterlinie
- 30 Minuten: mittlere Rasterlinie
- 60 Minuten: normale Stundenmarke
- 09:00, 12:00, 15:00 und 18:00: deutlich hervorgehobene Hauptanker

Die vier Hauptanker übersetzen die Orientierung der analogen Arbeitsuhr in die lineare Tagesfläche, ohne die fachlich eindeutigen 24-Stunden-Zeitwerte aufzugeben.

### 4. Mobile Projektion

Auf schmalen Hochformatflächen werden Vormittag und Nachmittag untereinander dargestellt. Der aktuelle Zeitraum steht auf dem heutigen Tag zuerst. Auf Tablet und Mobil-Querformat dürfen beide Perioden wieder nebeneinander erscheinen.

Ein Termin über die Periodengrenze wird mobil als eindeutig gekennzeichnete Fortsetzung dargestellt; fachlich bleibt er ein Objekt. Auch mobil bleibt die Zeit primär eine Eigenschaft der Achse und nicht redundanter Kartentext.

### 5. Feste Arbeitsuhr

Die Desktop-Seitenleiste erhält eine kompakte analoge Arbeitsuhr mit digitaler Salonzeit.

- Zeitzone: Salon-Zeitzone
- keine sichtbare Sekundenanzeige
- ruhige Aktualisierung
- Aktivierung führt zum heutigen Tagesplan und zur aktuellen Zeit
- die Uhr ersetzt zusätzliche permanente Heute-/Jetzt-Navigation
- auf Mobilgeräten wird keine grosse analoge Uhr gezeigt

### 6. Neue Hauptnavigation

Die dauerhafte Hauptnavigation enthält:

1. Tagesplan
2. Termine
3. Kundschaft
4. Verwaltung

`Team`, `Angebot`, `Standorte` und `Verfügbarkeit` werden als fachliche Verwaltungsbereiche in die card-first Verwaltungsseite integriert. Sie bleiben eigenständige Verwaltungsflächen, aber keine gleichrangigen globalen Navigationsziele.

### 7. Card-first Verwaltung

Die Verwaltungsübersicht führt zu:

- Angebot
- Team
- Standorte
- Verfügbarkeit

Sekundär nachgeordnet bleiben:

- Salonprofil
- Marke
- Integrationen
- Rollen & Zugriff
- Plan & Abrechnung
- Darstellung & App

Die Übersicht zeigt Orientierung und Handlungsbedarf. Details und Bearbeitung liegen hinter den jeweiligen Cards. Die Referenz simuliert keine produktive Persistenz.

## Invarianten

- Zeit, Raster, Termine, Aufgaben und Jetzt-Cursor verwenden dieselbe mathematische Zeitachse.
- Die Teamspalte bleibt deckend und räumlich stabil.
- Karten werden niemals unabhängig von der realen Termindauer verkürzt.
- Sichtbare Kartenzeit ist nicht erforderlich, solange Achse, zugänglicher Name und Kontextpanel die vollständige Zeit erhalten.
- Interne Aufgaben bleiben semantisch und visuell von Kundenterminen getrennt.
- Personenfokus bleibt ein vertikaler Einzeltag.
- `Heute` ändert das Datum; `Jetzt` bezeichnet die aktuelle Salonzeit.
- Auf anderen Tagen gibt es keine Jetzt-Linie.
- Backend-Endpunkte und Persistenz werden durch diese Referenz nicht vorweggenommen.

## Konsequenzen

### Positiv

- vollständige operative Tagesübersicht ohne verborgenes Zeitfenster
- weniger temporäre Modus- und Rückkehrlogik
- freie Lücken und kommende Belastung sind gleichzeitig sichtbar
- mehr nutzbarer Kartenraum für Kundschaft und Dienstleistung
- stärkere und schneller lesbare Zeitachse
- die Uhr wird zu einem funktionalen Produktmerkmal
- globale Navigation wird einfacher
- Verwaltungsbereiche erhalten eine klare gemeinsame Heimat

### Risiken

- 15-Minuten-Bereiche werden auf sehr schmalen Desktopflächen kleiner
- kurze Termine benötigen konsequent progressive Inhaltsdichte
- Nutzerinnen müssen die Zeit stärker aus Position und Raster lesen; die Achse muss deshalb visuell zuverlässig bleiben
- mobile Periodenfortsetzungen müssen eindeutig gestaltet werden
- die Tageslandkarte muss bei echten Überschneidungen weiterhin lesbar bleiben

## Migrationsfolge

1. Vergleichbare Referenzvariante unter `experiments/tagesplan-two-period/`
2. gemeinsame Produktschale V2 mit Uhr und neuer Navigation
3. responsive Abnahme bei 1366×768, 1512×982 und 1920×1080
4. mobile Abnahme bei 390×844 und 844×390
5. Zeithierarchie und karteninterne Informationsdichte abnehmen
6. Aktualisierung des Tagesplanvertrags nach visueller Freigabe
7. Übernahme in `pages/tagesplan/`
8. Aufbau von `pages/verwaltung/` aus der card-first Referenz
9. anschliessend Kundschaft und Termine auf dieselbe Schale migrieren
10. danach hochwertiger SVG-Dienstleistungssatz für Schneiden, Färben, Balayage, Glossing, Pflege, Beratung, Pause und interne Aufgaben

## Nicht Bestandteil

- Drag-and-drop oder Resize von Terminen
- produktive Backendintegration
- persistente Verwaltungsänderungen
- endgültige Frameworkentscheidung
- finaler SVG-Dienstleistungssatz in diesem Geometrieschritt
