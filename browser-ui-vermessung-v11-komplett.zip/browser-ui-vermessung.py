#!/usr/bin/env python3
"""DOM-/CSS-/Geometrie-Inventar im echten Chromium für lokale, vertrauenswürdige HTML-Dateien.

Beispiel:
  python browser-ui-vermessung.py --html 'seite.html' --output /mnt/data/messung.json
  python browser-ui-vermessung.py --html 'seite.html' --output /mnt/data/voll.json --full-css

Erfasst alle BODY-Elemente (auch verborgene), aktive Styles, Geometrie, Eltern-Kind-Bezüge,
Root-CSS-Variablen und ausdrücklich benannte Beispielszenarien.
Kein Beleg für tatsächliche Pixel-/Screenreader-Wahrnehmung; dafür zusätzliche Tests.
Nicht auf nicht vertrauenswürdigem HTML ausführen: Inline-JS wird ausgeführt.
"""
import argparse, hashlib, json, sys
from datetime import datetime, timezone
from pathlib import Path
from playwright.sync_api import sync_playwright

STYLE_PROPS = [
    'display','visibility','position','inset','top','right','bottom','left','z-index',
    'width','height','min-width','min-height','max-width','max-height',
    'box-sizing','margin-top','margin-right','margin-bottom','margin-left',
    'padding-top','padding-right','padding-bottom','padding-left',
    'border-top-width','border-right-width','border-bottom-width','border-left-width',
    'border-top-color','border-right-color','border-bottom-color','border-left-color',
    'border-top-left-radius','border-top-right-radius','border-bottom-right-radius','border-bottom-left-radius',
    'background-color','background-image','color','opacity','box-shadow',
    'font-family','font-size','font-weight','font-style','line-height','letter-spacing',
    'text-align','text-overflow','white-space','text-decoration-line',
    'grid-template-columns','grid-template-rows','grid-auto-flow',
    'flex-direction','flex-wrap','flex-grow','flex-shrink','align-items','justify-content',
    'gap','row-gap','column-gap','overflow-x','overflow-y','cursor','pointer-events',
    'transform','transition-duration','animation-duration','outline-color','outline-style','outline-width'
]
JS = r'''({allCSS,props}) => {
  const list=[...document.body.querySelectorAll('*')];
  const indices=new Map(list.map((e,i)=>[e,i]));
  const rounded=x=>Number.isFinite(x)?Math.round(x*1000)/1000:null;
  const rectJson=r=>({x:rounded(r.x),y:rounded(r.y),left:rounded(r.left),top:rounded(r.top),right:rounded(r.right),bottom:rounded(r.bottom),width:rounded(r.width),height:rounded(r.height)});
  const records=list.map((el,i)=>{
    const s=getComputedStyle(el);
    const rect=el.getBoundingClientRect();
    const names=allCSS?Array.from(s):props;
    const styles={};for(const name of names)styles[name]=s.getPropertyValue(name).trim();
    let parent=el.parentElement;
    const isVisible=s.display!=='none' && s.visibility!=='hidden' && Number(s.opacity)!==0 && rect.width>0 && rect.height>0 && !!el.getClientRects().length;
    let path='';
    if(el.id)path='#'+CSS.escape(el.id);
    else {
      const comps=[]; let cur=el;
      while(cur && cur!==document.body && comps.length<10){
        let n=1;for(let t=cur.previousElementSibling;t;t=t.previousElementSibling)if(t.localName===cur.localName)n++;
        comps.unshift(cur.localName+':nth-of-type('+n+')');cur=cur.parentElement;
      }
      path='body > '+comps.join(' > ');
    }
    const pseudo={};
    for(const p of ['::before','::after']){const ps=getComputedStyle(el,p);if(ps.content && ps.content!=='none' && ps.content!=='normal'){
      pseudo[p]={content:ps.content,display:ps.display,color:ps.color,backgroundColor:ps.backgroundColor};
    }}
    return {index:i,parentIndex:indices.has(parent)?indices.get(parent):null,selector:path,
      tag:el.localName,id:el.id||null,classes:typeof el.className==='string'?el.className.trim().split(/\s+/).filter(Boolean):[],
      role:el.getAttribute('role'),aria:{label:el.getAttribute('aria-label'),current:el.getAttribute('aria-current'),expanded:el.getAttribute('aria-expanded'),hidden:el.getAttribute('aria-hidden')},
      rect:rectJson(rect), visibleInLayout:isVisible,
      viewportIntersection:rect.right>0&&rect.bottom>0&&rect.left<innerWidth&&rect.top<innerHeight,
      styles,pseudo:Object.keys(pseudo).length?pseudo:undefined};
  });
  const root=getComputedStyle(document.documentElement);const vars={};
  for(const name of Array.from(root))if(name.startsWith('--'))vars[name]=root.getPropertyValue(name).trim();
  function snapshot(selector){return [...document.querySelectorAll(selector)].filter(e=>{let r=e.getBoundingClientRect();let s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0}).map(e=>({selector:e.id?'#'+e.id:e.className,rect:rectJson(e.getBoundingClientRect()),background:getComputedStyle(e).backgroundColor,fontSize:getComputedStyle(e).fontSize}));}
  return {meta:{title:document.title,url:location.href,viewport:{width:innerWidth,height:innerHeight,devicePixelRatio:devicePixelRatio},scroll:{width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight},allCssProperties:allCSS,domBodyElementCount:list.length,visibleLayoutCount:records.filter(e=>e.visibleInLayout).length,intersectingViewportCount:records.filter(e=>e.visibleInLayout&&e.viewportIntersection).length},
    rootCustomProperties:vars,records,
    v11Example:{calendarColumns:snapshot('.agenda-staff-column'),calendarTracks:snapshot('.agenda-staff-track'),calendarNames:snapshot('.agenda-staff-name')}};
}'''

def capture(html, scenario, browser, full_css=False, screenshot_dir=None):
    page=browser.new_page(viewport=scenario['viewport'], locale='de-CH', reduced_motion='reduce', device_scale_factor=1)
    errs=[]
    page.on('pageerror',lambda err:errs.append(str(err)))
    try:
        # The original HTML is an interactive standalone demo. No file:// origin necessary.
        page.set_content(html,wait_until='domcontentloaded',timeout=25000)
        page.evaluate('(target) => { if (typeof navigate === "function") navigate(target); }',scenario['route'])
        page.evaluate('document.fonts.ready')
        page.wait_for_timeout(110)
        results=page.evaluate(JS,{'allCSS':full_css,'props':STYLE_PROPS})
        results['meta']['scenario']=scenario['id'];results['meta']['route']=scenario['route'];results['meta']['pageErrors']=errs
        if screenshot_dir:
            dest=Path(screenshot_dir)/f"{scenario['id']}.png"
            page.screenshot(path=str(dest),full_page=False,animations='disabled')
            results['meta']['screenshot']=str(dest)
        return results
    finally:page.close()

def main():
    ap=argparse.ArgumentParser(description='Browserbasierte Element-/CSS-Vermessung')
    ap.add_argument('--html',required=True,help='Lokale vertrauenswürdige HTML-Datei')
    ap.add_argument('--output',required=True,help='Ergebnis-JSON')
    ap.add_argument('--full-css',action='store_true',help='ALLE durch den Browser aufgelösten CSS-Eigenschaften je Element, umfangreich')
    ap.add_argument('--screenshot-dir',help='Optional Screenshot-Verzeichnis')
    ap.add_argument('--chromium',default='/usr/bin/chromium')
    args=ap.parse_args()
    path=Path(args.html);html=path.read_text(encoding='utf-8')
    scenarios=[
        {'id':'kalender-desktop-1440','route':'calendar','viewport':{'width':1440,'height':900}},
        {'id':'kalender-mobile-390','route':'calendar','viewport':{'width':390,'height':844}},
        {'id':'heute-desktop-1440','route':'today','viewport':{'width':1440,'height':900}},
    ]
    if args.screenshot_dir:Path(args.screenshot_dir).mkdir(parents=True,exist_ok=True)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=args.chromium,headless=True,args=['--no-sandbox','--disable-gpu'])
        try:
            results=[capture(html,s,browser,args.full_css,args.screenshot_dir) for s in scenarios]
            version=browser.version
        finally:browser.close()
    result={'source':{'path':str(path.resolve()),'sha256':hashlib.sha256(html.encode()).hexdigest()},'measuredAtUtc':datetime.now(timezone.utc).isoformat(),'browser':{'name':'Chromium','version':version},'coverage':'3 named scenarios, all document.body descendants in each; Shadow DOM/iframes not traversed','scenarios':results}
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Ergebnis:',out)
    for s in results:
        m=s['meta'];columns=s['v11Example']['calendarColumns'];tracks=s['v11Example']['calendarTracks']
        print(f"  {m['scenario']}: {m['domBodyElementCount']} Elemente, {m['visibleLayoutCount']} mit Layout, {m['intersectingViewportCount']} im Viewport, {len(columns)} sichtbare Kalenderspalten, {len(tracks)} Tracks, {len(s['rootCustomProperties'])} Root-Tokens, {len(m['pageErrors'])} JS-Fehler")
        for col in columns[:3]:print('    Spalte',col['rect'])

if __name__=='__main__':main()
