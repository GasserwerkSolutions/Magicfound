# Verwaltung · Seitenvertrag

Status: **Zur Freigabe – Verwaltungsbereiche und Capability-Grenzen konsolidiert, Backendbereiche integrationsrelevant**  
Verantwortlicher Bereich: `Verwaltung`  
Direkter Referenzpfad: `/dashboard/pages/verwaltung/`  
Abhängige gemeinsame Verträge: `docs/contracts/README.md`, `docs/contracts/OPEN_QUESTIONS.md`

## 1. Zweck und primäre Arbeitsaufgabe

Die Seite `Verwaltung` bündelt seltenere salon-, konto- und systembezogene Einstellungen ausserhalb der operativen Arbeitsfläche.

Verbindliche Bereiche der Referenz:

- Salonprofil
- Marke
- Standorte
- Integrationen
- Rollen & Zugriff
- Plan & Abrechnung
- Darstellung & App

Primäre Arbeitsaufgabe:

- einen Verwaltungsbereich erkennen und gezielt öffnen
- aktuellen Konfigurationsstatus sehen
- mit passender Capability eine Änderung anfordern

Die Seite ist kein allgemeines Dashboard und darf operative Salonaktionen nicht mit Administrationsfunktionen vermischen.

Nicht Bestandteil dieser V1:

- produktive Zahlungsabwicklung
- vollständige Integrationskonfiguration
- endgültige Rollenmatrix
- Auditprotokoll-UI
- beliebige Systemkonsole

## 2. Eingabedaten

Datenquellenmethoden:

```js
getSessionContext()
getAdministrationSettings()
```

Normalisierter Eingang:

```js
{
  salonProfile,
  brand,
  locations,
  integrations,
  accessSummary,
  planAndBilling,
  productPreferences,
  sectionCapabilities
}
```

Erforderliche Felder pro Bereich:

- stabile `sectionId`
- `title`
- `description`
- `state`: `complete | incomplete | attention | unavailable`
- `requiredCapability`

Optionale Felder:

- Zusammenfassung des aktuellen Werts
- letzter Änderungszeitpunkt
- Integrationsstatus
- Eigentümerhinweis
- direkte Aktion

Capabilities:

- Eintritt: `administration:view`
- Salonprofil/Marke/Standorte: `administration:manage-salon`
- Rollen & Zugriff: `administration:manage-access`
- Plan & Abrechnung: `administration:view-billing`
- weitergehende Mutationscapabilities werden später ergänzt

## 3. Fachliches View-Model

```js
{
  sections: [
    {
      id,
      title,
      description,
      state,
      stateLabel,
      summary,
      requiredCapability,
      canOpen,
      canEdit,
      ownershipLabel
    }
  ],
  productPreferences: {
    themeMode,
    installAvailable,
    standaloneState
  },
  selectedSection: null | {
    id,
    title,
    fields,
    actions,
    warnings,
    capabilityState
  }
}
```

Invarianten:

- Verwaltungsbereiche sind fachlich getrennt und werden nicht als ein unstrukturiertes Formular geladen.
- `Darstellung & App` liegt hier und nicht in der operativen Kopfzeile.
- Rollen und Zugriff verwenden Produktrollen/Capabilities; fachliche Teamrollen werden nicht hieraus abgeleitet.
- Plan & Abrechnung kann als eigentümergebunden markiert werden.
- Ein nicht verfügbares Backendmodul wird als `unavailable` dargestellt und nicht durch eine Scheinbearbeitung ersetzt.
- Theme- und Installationszustand können browserseitig sein; Salon-/Kontodaten bleiben Adapterdaten.

## 4. Ausgehende Ereignisse

### Bereich öffnen

```js
{
  type: "administration:section-opened",
  payload: { sectionId, source: "administration-page", originCardId }
}
```

### Änderung anfordern

```js
{
  type: "administration:change-requested",
  payload: {
    sectionId,
    field,
    value,
    previousValue
  }
}
```

### Darstellung ändern

```js
{
  type: "product-preference:theme-change-requested",
  payload: { themeMode: "system" | "light" | "dark" }
}
```

### Installation anfordern

```js
{
  type: "product-install:requested",
  payload: { source: "administration-product-preferences" }
}
```

Browserseitige Installationsaufforderung wird nur ausgelöst, wenn sie tatsächlich verfügbar ist.

## 5. Ladezustand

- Produktschale und Seitentitel bleiben sichtbar.
- Bereichskarten zeigen strukturelle Skeletons.
- `Darstellung & App` darf bereits aus lokal verfügbarem Browserzustand angezeigt werden, sofern klar bleibt, welche Bereiche noch laden.
- Bei Detailladung bleibt die auslösende Karte markiert.
- Es werden keine Standardwerte als gespeicherte Salonwerte ausgegeben.

## 6. Leerzustand

Die Gesamtseite hat normalerweise keinen fachlich sinnvollen `empty`-Zustand, da die Bereiche selbst feststehen.

Mögliche Teil-Leerzustände:

- noch kein zusätzlicher Standort
- keine Integration verbunden
- keine bearbeitbaren Rollen ausser der aktuellen Standardrolle
- keine Rechnungen vorhanden

Jeder Teil-Leerzustand erklärt den Bereich und zeigt nur erlaubte nächste Handlungen. Ein nicht implementiertes Modul ist `unavailable`, nicht `empty`.

## 7. Fehlerzustand

Kernladefehler:

- feste Bereichsstruktur darf sichtbar bleiben.
- betroffene Bereiche zeigen Fehlerstatus und Retry.
- browserseitige Produktpräferenzen bleiben unabhängig nutzbar.

Teil-/Bereichsfehler:

- Fehler einer Integration verdeckt nicht Salonprofil oder Rollenverwaltung.
- Fehler in Plan & Abrechnung zeigt keine erfundenen Vertragsdaten.

Offline/Stale:

- letzte bekannte Einstellungen dürfen lesbar bleiben.
- Änderungen werden nicht als gespeichert dargestellt.
- lokale Themeänderung darf funktionieren, wird aber nicht mit einer serverseitigen Präferenz gleichgesetzt, solange die Synchronisationsregel offen ist.

## 8. Berechtigungszustände

- Ohne `administration:view` erscheint ein vollständiger Forbidden-Zustand.
- Jede Bereichskarte prüft ihre eigene Capability.
- Bereiche mit fehlender Capability können je nach Produktentscheidung vollständig verborgen oder als nicht zugänglich benannt werden; vertrauliche Zusammenfassungen dürfen nicht geliefert werden.
- `Rollen & Zugriff` benötigt `administration:manage-access`.
- `Plan & Abrechnung` benötigt mindestens `administration:view-billing`.
- Änderungen am Salon benötigen `administration:manage-salon`.
- Die endgültige Trennung zwischen Anzeigen und Ändern von Billing ist OFFEN.

## 9. Desktopverhalten

- Sidebar und normaler Produktkopf bleiben sichtbar.
- Verwaltungsbereiche erscheinen in einer ruhigen Kartenmatrix.
- Karten priorisieren Titel, Zweck, Status und eine klare Öffnungsaktion.
- Detail- und Bearbeitungsflächen verwenden gemeinsame Kontextpanels beziehungsweise klar definierte Unterflächen.
- Auf 14-Zoll-Viewports wird die Matrix verdichtet, ohne Beschreibungen unlesbar zu machen.
- Verwaltungsbereiche dürfen mehr vertikalen Dokumentfluss nutzen als der Tagesplan.
- Die Seite besitzt keinen horizontalen Gesamtüberlauf.

## 10. Mobilverhalten

- Bereichskarten werden einspaltig dargestellt.
- Titel und Status stehen vor längeren Beschreibungen.
- Detail/Bearbeitung öffnet als vollständige Inhaltsfläche oder unteres Sheet.
- Eigentümer- und Berechtigungshinweise bleiben vor einer Aktion sichtbar.
- Theme und Installation befinden sich weiterhin hier; sie kehren nicht in die operative Kopfzeile zurück.
- Die Seite scrollt vertikal und verwendet sichere Touch-Ziele.

## 11. Tastatur und Fokus

- Bereichskarten sind per Tastatur aktivierbar.
- `Enter` oder Leertaste öffnet den Bereich.
- Formulare verwenden sichtbare Labels und nachvollziehbare Fehlermeldungen.
- Speichern verschiebt den Fokus nicht ungefragt.
- Bei Feldfehlern geht der Fokus auf das erste fehlerhafte Feld und eine Zusammenfassung wird angekündigt.
- `Escape` schliesst die oberste Kontextfläche, sofern keine ungespeicherte Änderung eine bewusste Entscheidung benötigt.
- Schliessen stellt den Fokus auf die ursprüngliche Bereichskarte zurück.

## 12. Abnahmekriterien

- Seite ist direkt aufrufbar.
- Alle sieben verbindlichen Verwaltungsbereiche sind erkennbar.
- Darstellung und Installation befinden sich nicht in der operativen Kopfzeile.
- Bereichscapabilities werden unabhängig geprüft.
- `unavailable`, `loading`, `ready`, Teil-Leer-, Fehler-, Offline-, Stale- und Forbidden-Zustände sind vorhanden.
- Nicht geladene oder nicht implementierte Daten werden nicht durch Standardwerte ersetzt.
- Theme- und Installationszustand sind korrekt von serverseitigen Einstellungen getrennt.
- Formulare und Kontextflächen stellen Fokus zuverlässig wieder her.
- 14-Zoll, Standard-Desktop, Mobil und Tablet sind geprüft.
- Keine Gesamtseite läuft horizontal über.
- Keine Änderung wird ohne Bestätigung als gespeichert ausgegeben.

## 13. Integrationshinweise

- Offene Fragen: `Q-003`, `Q-005`, `Q-006`, `Q-007`, `Q-008`, `Q-ADM-001` bis `Q-ADM-003`, `Q-AUTH-002`.
- Jeder Verwaltungsbereich darf später einen eigenen Adapter oder Service besitzen; die Seite konsumiert weiterhin ein normalisiertes Bereichsmodell.
- Browserinstallation und Theme sind nicht automatisch Backendpersistenz.
- Rollen- und Rechteverwaltung muss capabilitybasiert bleiben.
- Plan- und Billingdaten werden weder simuliert noch aus anderen Accountdaten abgeleitet.
